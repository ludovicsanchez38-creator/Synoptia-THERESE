# Raccord FULL C17, analyse fermée

Observation : 2026-10-08T14:03:22.454107+00:00. Auteur : `/root/cycle17_gate_review`.

## Résultat

Un prochain lot **d'assemblage statique fermé** est concret. Les trois gels ne peuvent pas être superposés en choisissant simplement le G1 le plus récent. Aucun FULL, canari, import G1, test, processus, admission ou état de boucle n'a été exécuté/modifié pendant cette revue. ROOT7 et sa preuve Chrome restent une campagne WRAPPER séparée, non qualifiée ici.

Les trois INDEX sont byte-exacts : SQL48 `00f353fc…`, A/B80 `a16075d4…`, watchdog47 `edfc527a…`. Rehash de leurs références directes : 142 + 19 + 26 = **187 occurrences**, **134 références physiques distinctes**, aucun écart SHA/taille. Ce contrôle n'est pas une exploration récursive des observations historiques internes aux reçus. Les compteurs 48/80/47 désignent les lots d'origine, jamais des cas de test additionnés ni une qualification du composite. En particulier, l'INDEX A/B80 déclare 80 purs mais n'épingle pas un brut d'exécution de ces 80 cas dans ce dossier.

## Collisions exactes

| Jonction | Fait lu | Delta fermé requis |
| --- | --- | --- |
| G1 `Session.start` | A/B80 lignes 1799–2092 ajoute les 14 auxiliaires et métadonnées A/B ; watchdog47 lignes 1730–2011 ajoute la frontière complète de deadline avant allocation/Popen. | Composer les deux corps, sans retirer admission/source/argv/env/cwd/sinks/birth/gate ni la pré-liaison tardive SQL. |
| G1 `Session.stop` | A/B80 lignes 2403–2477 ajoute les diagnostics finaux A/B ; watchdog47 lignes 2323–2403 ferme le transport avant le reçu Session final et exige quiescence. | Fermeture transport **et** nettoyage des autres identités connues **et** deux passes ports3 **et** restauration des handlers. Les erreurs/ambiguïtés restent rouges et le taint monotone. |
| Relais root | A/B80 G1 ligne173 et SQL48 ligne168 pin `c8daab46…` ; watchdog G1 ligne168 et son fichier pin `9b271297…`. | Prendre le relais bootstrap9b et son pin ensemble. Sinon import exact refusé. |
| Lecteur après STOP | SQL48/coor ligne36 et watchdog/coor ligne38 gardent `008546a0…`, vérifié ligne293/301. A/B80 fournit `fd5256f0…`, 52 000 octets. | Dériver le pin du coordinateur vers le lecteur réellement émis ; ne pas renommer l'ancien reçu ni feindre byte-identité. |
| Chrome | Table A/B14 garde executable `/Applications/Google Chrome.app/…` et profil `5266a6b0…`. V8 WRAPPER utilise la copie QA, helper `7922a13b…` et profil `c9101b2a…`. | Choix/port A/B explicite, tout ensemble executable/helper/defaults/argv/profil/manifeste/attestation. Pas de permutation implicite ni de preuve native WRAPPER transposée. |

La comparaison AST des méthodes depuis la base SQL48 trouve **exactement deux corps modifiés concurremment** entre A/B80 et watchdog47 : `Session.start` et `Session.stop`. Les changements de globals/imports/pins ci-dessus sont des collisions supplémentaires, non couverts par ce seul résultat AST.

## Prochain lot recommandé, sans runtime

Dans un nouveau TMP, assembler un constructeur FULL **encore fermé** :

1. Base SQL48 : core/ABI reader/contrats et tables15/SQL read-view/Q littéraux/3 workers/admissions tardives/producteur après STOP/package78.
2. Reprendre le coordinateur, bridge, relais et bootstrap du watchdog47 ; ils conservent les seams SQL48 et ajoutent le serveur owner/peer kernel, arrêt sans nouvelles demandes, EOF et tick coopératif. Fusionner dans G1 les seules collisions start/stop, puis les autres fonctions A/B80, imports/table14 et reader de calibration fd525.
3. Reconstituer une version-vector explicite des **six modules RPC** : protocol et adapter A/B80 ne sont pas byte-identiques aux anciennes versions. Client/dispatcher/Unix/peer doivent être choisis et rehashés réellement, pas déduits de la proximité des dossiers. Bootstrap vérifie leurs identités de modules chargés.
4. Émettre la configuration/source-checkout physique A/B et textes rendus, commandes directes, table15, contextes/enveloppes/allocations, 14 descriptors Chrome, sources/fixtures avant start et bindings SQL tardifs sans SHA futur. Conserver les 27 étapes/78 obligations, les profils/modes/bornes existants et toutes les admissions/caps False, tables vides.
5. Ajouter les tests purs du **composite** : start expiré avant FD/Popen ; lancement A/B des 14 et métadonnées exactes ; fermeture transport avant receipt et ports3 ; abort/cleanup rouge qui n'empêche pas cleanup d'autres exacts ; lecteur fd525 accepté/ancien pin refusé ; relais9b exact/c8 refusé ; helper/executable/argv/defaults/profil discordants refusés. Les suites d'origine ne prouvent pas cette composition.

L'ordre après runtime reste : `stop_services` et bruts stables, puis records six calibrations / revue huit logs / SQL package sous la vraie garde SQL et les trois littéraux Q, puis `Session.stop` final et fermeture transport avant qualification/retour. **Ne pas fermer le transport à stop_services** : les phases SQL post-STOP et vrais relais de revues restent nécessaires. Aucune réduction des assertions XML/JSON/SQL/UI, des dénominateurs ni des bornes n'est proposée.

## Portes réellement manquantes avant un FULL actuel

- **Choisir un seul HEAD physique A/B et ses définitions.** Le core est paramétré par ce HEAD, mais `qualifier-c17.py` courant `b55ec5ec…` et `runtime78_adapter.py` `771efc5f…` sont encore fixés à `b517daed…`. Choisir un checkout actuel sans port causal explicite fait refuser le paquet. Les observations historiques et leurs 3 578 sources gardent leur contexte ; elles ne doivent pas devenir les nouvelles 3 579 entrées d'un checkout documentaire par réécriture d'un compteur.
- **Construire et revoir le composite fermé** : diffs/préimages/index complet, version-vector6, source Git/modes/dépendances/QA Python/Node, vrais profils finaux et manifests. Les tests de trois gels séparés ne remplacent pas les contre-épreuves du composite.
- **Émettre le préflight natif A/B séparé avant admission runtime.** `rpc_abi_reader.validate` lignes83–108, core.admission et bootstrap.validate_bootstrap exigent déjà des canaris `runtime78_exact_round` avec même acteur/ronde/HEAD/root/plan/context/modules/profils, peer non synthétique et locks frais. Aucun des trois gels ne fournit ce producteur ni ces résultats. Le constructeur doit prévoir ce chemin instrument-only et la vraie revue/rootGO avant le FULL, pas remplir `canaries_qualified=True` ou recycler WRAPPER/Q synthétique.
- **Raccord Chrome A/B14 puis preuve native propre à cette chaîne.** `AB_CHROME_PROFILE_NATIVE_QUALIFIED=False` bloque réellement load_admission ; ni le strict vert de la copie QA ni un éventuel ROOT7 vert ne lève cette porte A/B.
- **Deux acteurs réels, deux racines/rondes indépendantes.** Décisions root externes Q exactes, origine outil et bindings initiaux/tardifs authentiquement revus. B exige le shutdown A et un acteur distinct ; aucun JSON n'authentifie son écrivain.
- **Observations runtime et consommation complète.** Six axes dans la période active avec observed_at réel, TTL12h ; 78 runtime+revues 84 captures/exports Apple/huit flux ; obligations FULL exactes 129 unitaires, 82 runtime et 1 native pour122contrats, calibrations causales des consommateurs, couverture et arbitrage indépendant de toutes les anomalies. Les preuves unit-only/shared calibration-only ou natives préparées hors ronde ne deviennent pas automatiquement des résultats FULL par assemblage.

Les checks de sources/birth/plan aux frontières et les scans propriétaires ne sont pas des doublons supprimables. Le watchdog réduit uniquement le rehash causé par son tick ; relais/listeners/RPC gardent leurs contrôles physiques. Sa borne reste **coopérative**, pas une préemption hard-real-time ni une attribution exhaustive de tous descendants.

## Limites

Lecture de sources, AST et octets seulement. Les refs complètes et lignes de collisions sont dans `ANALYSE.json`. Aucun codesign/copie Chrome/kernel/libproc/lsof/socket/Node/SQL/Git workload, aucun test pur relancé, aucune qualification de résultat ROOT7. Aucun ancien gel, profil, source produit, admission, JSON app-loop ou mémoire modifié.

