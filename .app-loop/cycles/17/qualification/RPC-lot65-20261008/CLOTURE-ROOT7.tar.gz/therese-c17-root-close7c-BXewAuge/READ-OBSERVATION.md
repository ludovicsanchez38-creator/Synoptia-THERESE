# Clôture ROOT7, lecteur root

Le résultat natif rouge est inchangé. Le lecteur root finit vert à l'outil `419e7a`, exit 0 : 1 208 références, 35 jointures de signaux/birth. Reçu `67ac7b0b…`, 291 395 octets. Ce vert prouve la clôture physique, pas le canari ni le produit.

Les premières versions du lecteur ont refusé avant leur reçu final la résolution des INDEX historiques : `5fb130`, `9dc26e`, `7c29e7`, `f17751`. Ces observations dérivent des retours d'outils réels, sans prétendre être leurs stdout complets. Les scripts précédents et deux préimages sont conservés. Correction du lecteur uniquement : INDEX actuels V6/rootdomain ajoutés aux origines relatives exactes ; INDEX copiés sous preimages traités comme données historiques dont les fichiers sont rehashés, pas comme références relatives au dossier de la copie. Aucun bruit ni assertion native modifié.

Première archive ROOT7 : tar exit 0 avertit que le socket Unix ne peut être archivé. La version v2 canonique exclut explicitement le socket et le cache Vite ; ces exclusions ne remplacent pas la preuve de fermeture du transport archivée. La première archive reste seulement dans TMP. La copie binaire Chrome est toujours exclue.

Revue Shared4 favorable à la clôture rouge : 193 chemins et 2 078 références, 76 sources, 36 publications hardlink et dix jointures gate/release/birth ; six ACK causaux normaux, septième erreur avant Node. Cleanup physique sans résidu, deux passes sur trois ports, taint persistante. Cette note est un compte rendu reçu, pas un fichier écrit ni signé par le reviewer.

Gatekeeper : assessment réel `4c4b63`, spctl exit 0, copie QA acceptée comme Notarized Developer ID, reçu `92dbaaed…` de 14:04:22 UTC. Le refus ASP du framework suit l'interruption du wait de 3 microsecondes ; cause autonome non démontrée. Aucun délai ni permission élargi.
