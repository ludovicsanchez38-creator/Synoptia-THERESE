"""Doubles/AST/fixtures fichier uniquement. Aucun build, G1, Node ou runtime.

Les fichiers temporaires des cas Emitter ne sont pas des racines WRAPPER_CANARY
construites. Les contrôles de profils ne compilent aucun Seatbelt.
"""
from __future__ import annotations

import ast
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('fresh_wrapper_builder_under_test', HERE / 'build_fresh_wrapper.py')
builder = importlib.util.module_from_spec(spec)
spec.loader.exec_module(builder)
ROOT = Path('/private/tmp/therese-c17-wrapper-canary-builderunittest0001')  # jamais créée par ces tests


class PureBuilderTests(unittest.TestCase):
    def test_runner_events_delta_is_single_exact_parent_addition(self):
        source = (HERE / 'preimages/run_wrapper_canary-a912.py').read_text()
        derived = builder.runner_events_delta(source)
        old = '    for folder in (root / "session-rpc", root / "output", root / "runtime/calibration",\n'
        new = '    for folder in (root / "session-events", root / "session-rpc", root / "output", root / "runtime/calibration",\n'
        self.assertEqual(derived.count(new), 1)
        self.assertEqual(derived.replace(new, old, 1), source)

    def test_runner_events_delta_refuses_reapplication_and_different_anchor(self):
        source = (HERE / 'preimages/run_wrapper_canary-a912.py').read_text()
        with self.assertRaisesRegex(ValueError, 'Table parents QA initiale'):
            builder.runner_events_delta(builder.runner_events_delta(source))
        with self.assertRaisesRegex(ValueError, 'Ancre session-rpc'):
            builder.runner_events_delta(source.replace('for folder in (root / "session-rpc",',
                                                       'for folder in (root / "wrong-channel",', 1))
        with self.assertRaisesRegex(ValueError, 'Fonction parents QA exacte'):
            builder.runner_events_delta(source.replace('def prepare_qa_directories(',
                                                       'def wrong_function(', 1))

    def test_actual_runner_parent_function_old_omits_new_creates_events(self):
        source = (HERE / 'preimages/run_wrapper_canary-a912.py').read_text()
        def selected_function(text):
            node = next(n for n in ast.parse(text).body if isinstance(n, ast.FunctionDef)
                        and n.name == 'prepare_qa_directories')
            return compile(ast.Module(body=[node], type_ignores=[]), '<pure-selected-parent-function>', 'exec')
        for text, expected in ((source, False), (builder.runner_events_delta(source), True)):
            with tempfile.TemporaryDirectory(prefix='therese-c17-builder-v2-unit-', dir='/private/tmp') as directory:
                root = Path(directory)
                profile = root / 'profiles/service'
                paths = {'profile': profile, 'home': profile / 'home', 'tmp': profile / 'tmp',
                         'data': profile / 'data', 'test_data': profile / 'test-data',
                         'logs_data': profile / 'logs-data', 'vite_cache': root / 'runtime/vite-cache'}
                blueprint = SimpleNamespace(exact_root=lambda value: value, paths=lambda value: paths)
                namespace = {'Path': Path, 'blueprint': blueprint, 'require': builder.need}
                exec(selected_function(text), namespace)
                with patch.object(builder.subprocess, 'run', side_effect=AssertionError('OS workload forbidden')):
                    namespace['prepare_qa_directories'](root)
                events = root / 'session-events'
                self.assertEqual(events.is_dir(), expected)
                if expected:
                    self.assertEqual(events.stat().st_mode & 0o777, 0o700)
                    self.assertEqual(list(events.iterdir()), [])
                self.assertTrue((root / 'session-rpc/request').is_dir())
                self.assertFalse((root / 'runtime/calibration/logs-rpc').exists())
                self.assertFalse((root / 'binding.json').exists())
                self.assertFalse((root / 'decision.json').exists())
                self.assertNotIn('runtime_session', sys.modules)

    def test_pth_exact_baseline_rejects_added_removed_or_changed(self):
        raw = (builder.PROOFS / 'python-metadata-result.json').read_bytes()
        pth = {item['path']: item for item in json.loads(raw)['pth']}
        builder.verify_pth_snapshot(pth, raw)
        first = next(iter(pth))
        changes = [dict(pth, **{'/private/tmp/fixture-added.pth': {'path': '/private/tmp/fixture-added.pth', 'sha256': 'a' * 64, 'bytes': 1}}),
                   {key: row for key, row in pth.items() if key != first},
                   dict(pth, **{first: dict(pth[first], sha256='b' * 64)})]
        for mutated in changes:
            with self.assertRaisesRegex(ValueError, 'Ensemble/ref pth exact'):
                builder.verify_pth_snapshot(mutated, raw)
        with self.assertRaisesRegex(ValueError, 'Baseline metadata'):
            builder.verify_pth_snapshot(pth, raw + b' ')

    def test_future_root_accepts_only_absent_exact_root(self):
        with patch.object(Path, 'exists', return_value=False), patch.object(Path, 'is_symlink', return_value=False):
            self.assertEqual(builder.future_root(ROOT), ROOT)
        with self.assertRaisesRegex(ValueError, 'Root neuf'):
            builder.future_root(Path('/Users/synoptia/.therese'))

    def test_future_root_rejects_existing_and_symlink(self):
        with patch.object(Path, 'exists', return_value=True), self.assertRaisesRegex(ValueError, 'Root neuf'):
            builder.future_root(ROOT)
        with patch.object(Path, 'exists', return_value=False), patch.object(Path, 'is_symlink', return_value=True):
            with self.assertRaisesRegex(ValueError, 'Root neuf'):
                builder.future_root(ROOT)

    def test_ast_delta_only_slot_and_unicode_byte_offsets(self):
        source = '"""définition é"""\nFLAG = False\nWRAPPER_ADMISSION_TABLE: dict[str, dict] = {}\n'
        output = builder.assignment_delta(source, 'WRAPPER_ADMISSION_TABLE', {}, builder.wrapper_slot(ROOT))
        self.assertIn('FLAG = False', output)
        value = ast.literal_eval(ast.parse(output).body[-1].value)
        self.assertEqual(value, builder.wrapper_slot(ROOT))

    def test_ast_delta_rejects_prebound_or_duplicate(self):
        with self.assertRaisesRegex(ValueError, 'Ancre AST'):
            builder.assignment_delta('X = {"old": 1}\n', 'X', {}, {'new': 2})
        with self.assertRaisesRegex(ValueError, 'Ancre AST'):
            builder.assignment_delta('X = {}\nX = {}\n', 'X', {}, {'new': 2})

    def test_sql_sha_is_derived_not_old_root_pin(self):
        source = 'SQL_CONTRACT_SHA = "' + builder.OLD_SQL_SHA + '"\nHEAD = "unchanged"\n'
        output = builder.assignment_delta(source, 'SQL_CONTRACT_SHA', builder.OLD_SQL_SHA, 'c' * 64)
        self.assertEqual(ast.literal_eval(ast.parse(output).body[0].value), 'c' * 64)
        self.assertIn('HEAD = "unchanged"', output)

    def test_real_g1_definition_stays_closed_without_import(self):
        raw = (builder.PREP / 'g1-26/runtime_session.py').read_text()
        builder.validate_closed_g1(raw)
        for old, new in (('RUNTIME_ENABLED = False', 'RUNTIME_ENABLED = True'),
                         ('OS_STARTUP_QUALIFIED = False', 'OS_STARTUP_QUALIFIED = True')):
            self.assertEqual(raw.count(old), 1)
            with self.assertRaisesRegex(ValueError, 'Base G1 non fermée'):
                builder.validate_closed_g1(raw.replace(old, new, 1))
        self.assertNotIn('runtime_session', sys.modules)

    def test_emitter_exclusive_regular_file_and_checked_ref(self):
        with tempfile.TemporaryDirectory(prefix='therese-c17-builder-unit-', dir='/private/tmp') as directory:
            emitter = builder.Emitter(Path(directory))
            ref = emitter.write('fixture/raw.txt', b'synthetic fixture\n')
            self.assertEqual(builder.checked(ref), b'synthetic fixture\n')
            with self.assertRaisesRegex(ValueError, 'Sortie déjà'):
                emitter.write('fixture/raw.txt', b'replace forbidden')
            with self.assertRaisesRegex(ValueError, 'Ref modifiée'):
                builder.checked(dict(ref, sha256='a' * 64))

    def test_emitter_rejects_escape_and_symlink_parent(self):
        with tempfile.TemporaryDirectory(prefix='therese-c17-builder-unit-', dir='/private/tmp') as directory:
            root = Path(directory)
            emitter = builder.Emitter(root)
            with self.assertRaisesRegex(ValueError, 'Sortie déjà'):
                emitter.write('../escape.txt', b'fixture')
            (root / 'real').mkdir()
            (root / 'alias').symlink_to(root / 'real', target_is_directory=True)
            with self.assertRaisesRegex(ValueError, 'Parent de sortie alias'):
                emitter.write('alias/fixture.txt', b'fixture')

    def test_web_wrong_sha_refused_before_allocation_or_node(self):
        with patch.object(builder.os, 'mkdir') as mkdir, patch.object(builder.subprocess, 'run') as node:
            with self.assertRaisesRegex(ValueError, 'Seul successor'):
                builder.build(ROOT, web_profile_ref=dict(builder.WEB, sha256='a' * 64), chrome_profile_ref=builder.CHROME_PROFILE, authority_ref={})
            mkdir.assert_not_called()
            node.assert_not_called()

    def test_pin_failure_refused_before_allocation_or_node(self):
        with patch.object(builder, 'checked', return_value=b'fixture'), \
             patch.object(builder, 'checked_chrome_successor', return_value=('before fixture', 'after fixture')), \
             patch.object(builder, 'construction_authority', return_value={}), \
             patch.object(builder, 'validate_indexes', side_effect=ValueError('Index changé fixture')), \
             patch.object(builder.os, 'mkdir') as mkdir, patch.object(builder.subprocess, 'run') as node:
            with self.assertRaisesRegex(ValueError, 'Index changé'):
                builder.build(ROOT, web_profile_ref=builder.WEB, chrome_profile_ref=builder.CHROME_PROFILE, authority_ref={})
            mkdir.assert_not_called()
            node.assert_not_called()

    def test_external_authority_and_actual_registry_are_required(self):
        self_ref = {'path': str(HERE / 'build_fresh_wrapper.py'), 'sha256': 'd' * 64, 'bytes': 1}
        registry_ref = {'path': '/private/tmp/fixture-registry.json', 'sha256': 'a' * 64, 'bytes': 1}
        authority = {'schema': 'c17-root-fresh-wrapper-preparation-go-v1', 'status': 'go_prepare_only',
            'scope': 'WRAPPER_CANARY', 'root': str(ROOT), 'actor': '/root', 'head': builder.HEAD,
            'product_source_root': str(builder.QA), 'web_profile_ref': builder.WEB,
            'chrome_profile_ref': builder.CHROME_PROFILE, 'runner_boundary_index_ref': self_ref,
            'origin_kind': 'root_tool_call', 'builder_ref': self_ref, 'identity_registry_ref': registry_ref,
            'gpu_observation_ref': {'path': '/private/tmp/fixture-gpu.raw', 'sha256': 'b' * 64, 'bytes': 1}}
        registry = {'schema': 'c17-wrapper-canary-live-identity-registry-v1', 'head': builder.HEAD,
            'round_id': ROOT.name, 'chrome_profile_ref': builder.CHROME_PROFILE,
            'runner_boundary_index_ref': self_ref, 'actors': [{'actor': '/root', 'observed_by': 'SYNTHETIC_UNIT_DOUBLE',
                                             'observed_at_utc': '2026-10-08T00:00:00Z'}]}
        with patch.object(builder, 'reference', return_value=self_ref), \
             patch.object(builder, 'json_checked', side_effect=[authority, registry]), \
             patch.object(builder, 'checked', return_value=b'Metal: Supported'):
            self.assertEqual(builder.construction_authority(ROOT, {}, builder.WEB, builder.CHROME_PROFILE), authority)
        for changed in (dict(authority, root='/private/tmp/old'), dict(authority, actor='alias'),
                        dict(authority, status='runtime_go'), dict(authority, builder_ref={})):
            with patch.object(builder, 'reference', return_value=self_ref), \
                 patch.object(builder, 'json_checked', return_value=changed):
                with self.assertRaisesRegex(ValueError, 'GO externe'):
                    builder.construction_authority(ROOT, {}, builder.WEB, builder.CHROME_PROFILE)
        with patch.object(builder, 'reference', return_value=self_ref), \
             patch.object(builder, 'json_checked', side_effect=[authority, dict(registry, round_id='old-round')]):
            with self.assertRaisesRegex(ValueError, 'Registre réel neuf'):
                builder.construction_authority(ROOT, {}, builder.WEB, builder.CHROME_PROFILE)

    def test_node_vm_does_not_load_playwright_or_browser(self):
        self.assertNotIn('import(', builder.NODE_DEFAULTS_VM)
        self.assertNotIn('require(', builder.NODE_DEFAULTS_VM)
        self.assertIn('runInContext', builder.NODE_DEFAULTS_VM)
        self.assertIn('chromiumSandbox', (builder.PREP / 'auxiliary/source/chrome_contract.py').read_text())
        document = ast.parse((HERE / 'build_fresh_wrapper.py').read_text())
        imports = [node for node in ast.walk(document) if isinstance(node, (ast.Import, ast.ImportFrom))]
        self.assertFalse(any('runtime_session' in ast.unparse(node) for node in imports))
        self.assertIn("reference(Path(__file__).resolve()) == authority['builder_ref']", (HERE / 'build_fresh_wrapper.py').read_text())

    def test_candidate_index_resolves_only_its_own_relative_refs(self):
        pins, indexes = builder.validate_indexes()
        candidate = builder.CHROME_INDEX
        self.assertIn(candidate, indexes)
        self.assertIn(str(candidate.parent / 'README.md'), pins)
        self.assertIn(str(candidate.parent / 'chrome.sb'), pins)
        self.assertNotIn(str(builder.PREP / 'README.md'), pins)


class SuccessorV6Tests(unittest.TestCase):
    def test_only_exact_chrome_UI_then_unix_then_rootdomain_successor(self):
        before, after = builder.checked_chrome_successor(builder.CHROME_PROFILE)
        self.assertEqual(len(after.encode()) - len(before.encode()), 760)
        self.assertEqual(after.count('(allow mach-lookup'), 1)
        self.assertEqual(after.count('(global-name "com.apple.coreservices.launchservicesd")'), 1)
        self.assertEqual(after.count('(global-name "com.apple.windowserver.active")'), 1)
        self.assertEqual(after.count('(allow system-socket (socket-domain AF_UNIX))'), 1)
        self.assertEqual(after.count('(allow network-bind (local unix-socket (subpath (param "TMP_ROOT"))))'), 1)
        self.assertEqual(after.count('(allow iokit-open-user-client (iokit-user-client-class "RootDomainUserClient"))'), 1)
        self.assertNotIn('(allow iokit-open-user-client)', after)
        self.assertNotIn('(allow iokit-open-service', after)
        self.assertNotIn('(allow network-outbound (remote unix-socket', after)
        for field, value in (('sha256', 'a' * 64), ('path', '/private/tmp/wrong/chrome.sb'), ('bytes', 1417)):
            with self.subTest(field=field), self.assertRaisesRegex(ValueError, 'Seul successor Chrome RootDomainUserClient'):
                builder.checked_chrome_successor(dict(builder.CHROME_PROFILE, **{field: value}))

    def test_chrome_wrong_ref_refused_before_allocation(self):
        with patch.object(builder.os, 'mkdir') as mkdir, patch.object(builder.subprocess, 'run') as node:
            with self.assertRaisesRegex(ValueError, 'Seul successor Chrome RootDomainUserClient'):
                builder.build(ROOT, web_profile_ref=builder.WEB,
                    chrome_profile_ref=dict(builder.CHROME_PROFILE, sha256='a' * 64), authority_ref={})
            mkdir.assert_not_called()
            node.assert_not_called()

    def test_chrome_mutated_permission_is_refused(self):
        before = (builder.PREP / 'g1-26/chrome.sb').read_bytes()
        ui = Path(builder.CHROME_UI_PROFILE['path']).read_bytes()
        unix = Path(builder.CHROME_UNIX_PROFILE['path']).read_bytes()
        after = Path(builder.CHROME_PROFILE['path']).read_bytes()
        def checked_profile(ref):
            if ref == builder.CHROME_PROFILE:
                return after + b'\n(allow network-bind)\n'
            return ui if ref in (builder.CHROME_UI_PROFILE, builder.CHROME_UNIX_PREIMAGE) else unix
        with patch.object(builder, 'regular_bytes', return_value=before), \
             patch.object(builder, 'checked', side_effect=checked_profile):
            with self.assertRaisesRegex(ValueError, 'RootDomainUserClient exact'):
                builder.checked_chrome_successor(builder.CHROME_PROFILE)

    def test_chrome_wrong_preimage_is_refused(self):
        with patch.object(builder, 'regular_bytes', return_value=b'(deny default)\n'), \
             patch.object(builder, 'checked', return_value=b'fixture'):
            with self.assertRaisesRegex(ValueError, 'Préimage Chrome'):
                builder.checked_chrome_successor(builder.CHROME_PROFILE)

    def test_unix_preimage_must_be_exact_UI_profile(self):
        before = (builder.PREP / 'g1-26/chrome.sb').read_bytes()
        ui = Path(builder.CHROME_UI_PROFILE['path']).read_bytes()
        unix = Path(builder.CHROME_UNIX_PROFILE['path']).read_bytes()
        after = Path(builder.CHROME_PROFILE['path']).read_bytes()
        with patch.object(builder, 'regular_bytes', return_value=before), \
             patch.object(builder, 'checked', side_effect=[ui, unix, after, ui + b' ']):
            with self.assertRaisesRegex(ValueError, 'Préimage Unix différente'):
                builder.checked_chrome_successor(builder.CHROME_PROFILE)

    def test_rootdomain_preimage_must_be_exact_unix_profile(self):
        before = (builder.PREP / 'g1-26/chrome.sb').read_bytes()
        ui = Path(builder.CHROME_UI_PROFILE['path']).read_bytes()
        unix = Path(builder.CHROME_UNIX_PROFILE['path']).read_bytes()
        after = Path(builder.CHROME_PROFILE['path']).read_bytes()
        with patch.object(builder, 'regular_bytes', return_value=before), \
             patch.object(builder, 'checked', side_effect=[ui, unix, after, ui, unix + b' ']):
            with self.assertRaisesRegex(ValueError, 'Préimage RootDomain différente'):
                builder.checked_chrome_successor(builder.CHROME_PROFILE)

    def source_groups(self):
        def ref(relative):
            return {'path': str(ROOT / relative), 'sha256': 'a' * 64, 'bytes': 1}
        required = ast.literal_eval(next(node.value for node in ast.parse(
            (builder.PREP / 'g1-26/runtime_session.py').read_text()).body
            if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name)
            and node.targets[0].id == 'WRAPPER_INSTRUMENTS'))
        base = [ref(p) for p in required]
        base += [ref('fixture-base-' + str(i)) for i in range(63 - len(base))]
        witness = [ref('authorization/runner-boundary/' + p) for p in builder.WITNESS_FILES]
        deltas = [ref('proofs/fixture-delta-' + str(i) + '.diff') for i in range(6)]
        return base, witness, deltas

    def test_table76_preserves_all63_and_thirteen_additions(self):
        base, witness, deltas = self.source_groups()
        refs = builder.join_sources76(base, witness, deltas)
        self.assertEqual(refs, base + witness + deltas)
        self.assertEqual(len(refs), 76)
        self.assertEqual(len({r['path'] for r in refs}), 76)

    def test_table73_or_duplicate_is_refused(self):
        base, witness, deltas = self.source_groups()
        with self.assertRaisesRegex(ValueError, r'sources63\+7\+6'):
            builder.join_sources76(base, witness, deltas[:3])
        duplicated = list(witness)
        duplicated[0] = base[0]
        with self.assertRaisesRegex(ValueError, 'refs76 divergente/doublonnée'):
            builder.join_sources76(base, duplicated, deltas)

    def test_actual_wrapper_consumer_guards_accept76_without_importing_g1(self):
        base, witness, deltas = self.source_groups()
        refs = builder.join_sources76(base, witness, deltas)
        def selected_guard(path, function_name, literal):
            document = ast.parse(path.read_text())
            function = next(node for node in document.body if isinstance(node, ast.FunctionDef)
                            and node.name == function_name)
            call = next(node for node in ast.walk(function) if isinstance(node, ast.Call)
                        and isinstance(node.func, ast.Name) and node.func.id == 'require'
                        and len(node.args) >= 2 and isinstance(node.args[1], ast.Constant)
                        and node.args[1].value == literal)
            return compile(ast.Expression(call.args[0]), '<pure-actual-consumer-guard>', 'eval')
        require_table = selected_guard(builder.PREP / 'coordinator/run_wrapper_canary.py',
            'read_inputs', 'Références instrument26 absentes/doublonnées')
        env = {'refs': refs, 'refs_data': {'schema': 'c17-wrapper-canary-source-refs-v1'},
               'SOURCE_REFS_SCHEMA': 'c17-wrapper-canary-source-refs-v1'}
        self.assertTrue(eval(require_table, env))
        env['refs'] = refs + [refs[0]]
        self.assertFalse(eval(require_table, env))
        g1 = builder.PREP / 'g1-26/runtime_session.py'
        require_sources = selected_guard(g1, 'load_wrapper_canary_admission',
            'Instruments wrappers manquants/doublons')
        required = tuple(row['path'].removeprefix(str(ROOT) + '/') for row in base[:17])
        env = {'refs': refs, 'root': ROOT, 'WRAPPER_INSTRUMENTS': required,
               'decision': {'instruments': refs}}
        self.assertTrue(eval(require_sources, env))
        env['refs'] = refs[1:]
        self.assertFalse(eval(require_sources, env))
        self.assertNotIn('runtime_session', sys.modules)

    def test_witness_inputs_are_seven_closed_definitions_and_observed_pures(self):
        self.assertEqual(len(builder.WITNESS_FILES), 7)
        self.assertEqual(set(builder.WITNESS_FILES), {
            'source/runner_boundary.py', 'INDEX.json', 'tests/test_runner_boundary.py',
            'proofs/pure-test-receipt.json', 'proofs/returned-output.log',
            'diffs/calibrate-test-runner.py.diff', 'diffs/wrapper_blueprint.py.diff'})
        receipt = json.loads((builder.WITNESS / 'proofs/pure-test-receipt.json').read_text())
        self.assertEqual(receipt['exec_result']['exit_code'], 0)
        self.assertTrue(receipt['pins_unchanged'])
        self.assertFalse(receipt['native_qualification'])

    def test_helper_then_sql_pin_derivations_preserve_other_content(self):
        boundary = builder.load_pure('c17_boundary_pure_unit', builder.WITNESS / 'source/runner_boundary.py')
        original = (builder.PREP / 'coordinator/wrapper_blueprint.py').read_text()
        with_rootdir = boundary.derive_blueprint(original)
        fresh = builder.assignment_delta(with_rootdir, 'SQL_CONTRACT_SHA', builder.OLD_SQL_SHA, 'c' * 64)
        restored = builder.assignment_delta(fresh, 'SQL_CONTRACT_SHA', 'c' * 64, builder.OLD_SQL_SHA)
        # assignment_delta emploie repr : seule la ponctuation des quotes du pin change.
        restored_tree, original_tree = ast.parse(restored), ast.parse(with_rootdir)
        self.assertEqual(ast.dump(restored_tree, include_attributes=False),
                         ast.dump(original_tree, include_attributes=False))
        self.assertEqual(with_rootdir.replace(boundary.BLUEPRINT_AFTER, boundary.BLUEPRINT_BEFORE), original)
        self.assertNotIn('runtime_session', sys.modules)

    def test_new_cli_requires_explicit_chrome_and_closed_authority(self):
        source = (HERE / 'build_fresh_wrapper.py').read_text()
        self.assertIn("parser.add_argument('--chrome-profile-ref', type=json.loads, required=True)", source)
        self.assertIn("body.get('chrome_profile_ref') == chrome_ref", source)
        self.assertIn("registry.get('chrome_profile_ref') == chrome_ref", source)
        self.assertIn("registry.get('runner_boundary_index_ref') == body['runner_boundary_index_ref']", source)
        self.assertIn("chrome_profile_ref=args.chrome_profile_ref", source)

    def test_order_before_allocation_and_final_source76(self):
        document = ast.parse((HERE / 'build_fresh_wrapper.py').read_text())
        function = next(n for n in document.body if isinstance(n, ast.FunctionDef) and n.name == 'build')
        text = ast.unparse(function)
        self.assertLess(text.index('checked_chrome_successor('), text.index('os.mkdir('))
        self.assertLess(text.index('validate_indexes('), text.index('os.mkdir('))
        self.assertLess(text.index('boundary.derive_overlay(overlay)'), text.index('for target, raw in overlay'))
        self.assertLess(text.index('boundary.derive_blueprint(blueprint_base)'), text.index("assignment_delta(blueprint_with_rootdir"))
        self.assertLess(text.index('join_sources76('), text.index("refs_ref = emitter.json('authorization/source-refs.json'"))
        self.assertIn("reference(root / 'g1/chrome.sb')", text)
        self.assertIn("cwd=str(root)", (HERE / 'build_fresh_wrapper.py').read_text())



class ChromeUIV6Tests(unittest.TestCase):
    def test_old_UI_profile_ref_refused_before_any_allocation(self):
        with patch.object(builder.os, 'mkdir') as mkdir, patch.object(builder.subprocess, 'run') as node:
            with self.assertRaisesRegex(ValueError, 'Seul successor Chrome RootDomainUserClient'):
                builder.build(ROOT, web_profile_ref=builder.WEB,
                    chrome_profile_ref=builder.CHROME_UI_PROFILE, authority_ref={})
            mkdir.assert_not_called()
            node.assert_not_called()

    def test_old_metadata_only_ref_refused_before_any_allocation(self):
        old = {'path': '/private/tmp/therese-c17-chrome-metadata-only-1ma6wMfU/chrome.sb',
               'sha256': 'c2595ed573acee1f4bdac62ed46a043d1c051d9716545aa88a095a53e1467ec4',
               'bytes': 1194}
        with patch.object(builder.os, 'mkdir') as mkdir, patch.object(builder.subprocess, 'run') as node:
            with self.assertRaisesRegex(ValueError, 'Seul successor Chrome RootDomainUserClient'):
                builder.build(ROOT, web_profile_ref=builder.WEB, chrome_profile_ref=old, authority_ref={})
            mkdir.assert_not_called()
            node.assert_not_called()

    def test_old_unix_profile_ref_refused_before_any_allocation(self):
        with patch.object(builder.os, 'mkdir') as mkdir, patch.object(builder.subprocess, 'run') as node:
            with self.assertRaisesRegex(ValueError, 'Seul successor Chrome RootDomainUserClient'):
                builder.build(ROOT, web_profile_ref=builder.WEB,
                    chrome_profile_ref=builder.CHROME_UNIX_PROFILE, authority_ref={})
            mkdir.assert_not_called()
            node.assert_not_called()

    def test_UI_arbitrary_mach_or_metadata_permission_refused(self):
        before = (builder.PREP / 'g1-26/chrome.sb').read_bytes()
        ui = Path(builder.CHROME_UI_PROFILE['path']).read_bytes()
        unix = Path(builder.CHROME_UNIX_PROFILE['path']).read_bytes()
        after = Path(builder.CHROME_PROFILE['path']).read_bytes()
        for mutant in (ui.replace(b'com.apple.windowserver.active', b'com.apple.other-service'),
                       ui + b'\n(allow file-read-metadata (subpath "/"))\n'):
            with self.subTest(mutant=mutant[-80:]), patch.object(builder, 'regular_bytes', return_value=before), \
                 patch.object(builder, 'checked', side_effect=[mutant, unix, after]):
                with self.assertRaisesRegex(ValueError, 'deux noms Mach'):
                    builder.checked_chrome_successor(builder.CHROME_PROFILE)

    def test_unix_rights_cannot_expand_or_move_outside_tmp_root(self):
        before = (builder.PREP / 'g1-26/chrome.sb').read_bytes()
        ui = Path(builder.CHROME_UI_PROFILE['path']).read_bytes()
        unix = Path(builder.CHROME_UNIX_PROFILE['path']).read_bytes()
        after = Path(builder.CHROME_PROFILE['path']).read_bytes()
        for mutant in (unix.replace(b'(allow network-bind (local unix-socket (subpath (param "TMP_ROOT"))))',
                                     b'(allow network-bind (local unix-socket (subpath (param "HOME_ROOT"))))', 1),
                       unix + b'\n(allow network-outbound (remote unix-socket (subpath "/private/tmp")))\n',
                       unix + b'\n(allow network-bind)\n'):
            def checked_profile(ref):
                if ref == builder.CHROME_UNIX_PROFILE:
                    return mutant
                if ref in (builder.CHROME_UI_PROFILE, builder.CHROME_UNIX_PREIMAGE):
                    return ui
                return after if ref == builder.CHROME_PROFILE else unix
            with self.subTest(mutant=mutant[-100:]), patch.object(builder, 'regular_bytes', return_value=before), \
                 patch.object(builder, 'checked', side_effect=checked_profile):
                with self.assertRaisesRegex(ValueError, 'bind Unix local TMP_ROOT'):
                    builder.checked_chrome_successor(builder.CHROME_PROFILE)

    def test_rootdomain_cannot_be_other_class_or_wildcard(self):
        before = (builder.PREP / 'g1-26/chrome.sb').read_bytes()
        ui = Path(builder.CHROME_UI_PROFILE['path']).read_bytes()
        unix = Path(builder.CHROME_UNIX_PROFILE['path']).read_bytes()
        after = Path(builder.CHROME_PROFILE['path']).read_bytes()
        exact = b'(allow iokit-open-user-client (iokit-user-client-class "RootDomainUserClient"))'
        for mutant in (after.replace(exact, b'(allow iokit-open-user-client (iokit-user-client-class "AGXDeviceUserClient"))'),
                       after.replace(exact, b'(allow iokit-open-user-client)'),
                       after + b'\n(allow iokit-open-user-client)\n',
                       after + b'\n(allow iokit-open-service)\n'):
            def checked_profile(ref):
                if ref in (builder.CHROME_UI_PROFILE, builder.CHROME_UNIX_PREIMAGE):
                    return ui
                if ref == builder.CHROME_PROFILE:
                    return mutant
                return unix
            with self.subTest(mutant=mutant[-100:]), patch.object(builder, 'regular_bytes', return_value=before), \
                 patch.object(builder, 'checked', side_effect=checked_profile):
                with self.assertRaisesRegex(ValueError, 'RootDomainUserClient exact'):
                    builder.checked_chrome_successor(builder.CHROME_PROFILE)

    def test_all_nonprofile_functions_byte_or_AST_equivalent_to_v5(self):
        old_text = (HERE / 'preimages/build_fresh_wrapper-v5.py').read_text()
        new_text = (HERE / 'build_fresh_wrapper.py').read_text()
        old, new = ast.parse(old_text), ast.parse(new_text)
        old_functions = {n.name: n for n in old.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))}
        new_functions = {n.name: n for n in new.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))}
        self.assertEqual(set(old_functions), set(new_functions))
        for name in old_functions:
            if name in {'checked_chrome_successor', 'gather_pins', 'validate_indexes'}:
                continue
            with self.subTest(function=name):
                self.assertEqual(ast.dump(ast.parse(ast.unparse(new_functions[name])), include_attributes=False),
                    ast.dump(ast.parse(ast.unparse(old_functions[name])), include_attributes=False))
        def assignments(tree):
            return {n.targets[0].id: ast.dump(n.value, include_attributes=False)
                    for n in tree.body if isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Name)}
        old_values, new_values = assignments(old), assignments(new)
        self.assertEqual(set(new_values) - set(old_values),
                         {'CHROME_UNIX_PROFILE', 'CHROME_ROOTDOMAIN_PREIMAGE', 'CHROME_UNIX_INDEX'})
        self.assertEqual(set(old_values) - set(new_values), set())
        changed = {key for key in old_values if old_values[key] != new_values[key]}
        self.assertEqual(changed, {'CHROME_PROFILE', 'CHROME_INDEX', 'INDEX_PINS'})
        self.assertNotIn('runtime_session', sys.modules)


if __name__ == '__main__':
    unittest.main(verbosity=2)
