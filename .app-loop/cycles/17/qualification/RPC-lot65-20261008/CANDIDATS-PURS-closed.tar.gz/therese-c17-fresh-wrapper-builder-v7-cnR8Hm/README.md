# Builder WRAPPER V7, préparation fermée

Auteur : /root/cycle17_gate_review. Ce dossier est additif, les gels V6 et antérieurs sont inchangés.

## Delta effectif

La cible Chrome est exclusivement /private/tmp/therese-c17-chrome-qa-copy-RoZmwsja/Google Chrome.app.

Le constructeur remplace ses constantes CHROME/FRAMEWORK et bundle_root. Le delta G1 part de la préimage effective f8e9daacbb9b88b628aeefbd33ba86df45135eba571241c26d3d5721b3a4e781 : deux seules valeurs Path, CHROME et bundle de validate_auxiliary_binding. Le reste de son AST doit être égal. La prévisualisation reste fermée, sans slot WRAPPER rempli.

Le profil chrome.sb remplace uniquement le subpath /Applications/Google Chrome.app par le bundle QA exact. Les permissions RootDomainUserClient, Mach, Unix, CDP 17594 et les autres permissions sont byte-exactes. Les cinq argv conservent leurs options Playwright, cwd et bornes, hormis la cible exécutable. Les tables, délais, XML/JSON, quinze feuilles, SQL, source HEAD 2d69 et les 76 refs sont conservés.

Le futur build remplira uniquement le slot WRAPPER exact de sa nouvelle racine, après ce delta G1. RUNTIME_ENABLED/OS_STARTUP_QUALIFIED/caps et admission A/B FULL restent fermés. Aucun ancien canari ou test pur ne qualifie ce nouveau G1.

## Preuve réelle de copie, pas signature synthétique

Le préflight exige dans l'autorité externe chrome_qa_copy_ref égal à :
/private/tmp/therese-c17-chrome-qa-copy-RoZmwsja/v3-receipt.json
SHA f97793cb43454051da734685185cb5d4e5b5ffbabc516580287195ef3d32993c, 17160 octets.

Ce reçu est une exécution réelle du root. Le constructeur le lit et rehash ses pièces pertinentes, les deux binaires physiques, les flux de codesign. Il exige le vrai copy-strict-deep exit 0, signal/error null, argv --verify --deep --strict --verbose=4 sur la copie exacte et les lignes brutes valid on disk / Designated Requirement. Il ne lance ni codesign ni retrait d'attribut.

Les refus antérieurs sur l'app originale restent rouges. L'écart com.apple.provenance de la copie est conservé via provenance_delta_ref ; le critère est all_non_finderinfo_copy_baseline_attrs_unchanged, pas une égalité source/copie des xattrs. Source avant/après, absence de hardlinks, quarantaine et liste FinderInfo finie restent obligatoires. Aucun statut Gatekeeper, architecture autre que la mesure réelle ou signature de release n'est inféré.

Le JSON n'authentifie pas lui-même root. Une vraie autorisation outil externe exacte, un nouveau registre réel et une nouvelle racine demeurent nécessaires.

## Vérification effectivement exécutée

47 tests purs, 0 failure/error/skip, exit 0, 2.296 s unittest. Ils reprennent les 37 assertions V6 et ajoutent 10 cas QA. Les fixtures de fichiers et les mocks sont explicitement synthétiques ; un cas lit la vraie preuve root de copie sans exécuter sa commande. Aucun import G1 entier ou produit, socket, processus OS/Node/Chrome, build ou copie de l'app. Tous les pins avant/après sont égaux.

proofs/pure-tests-returned-output.txt est la sortie renvoyée par exec_command, non un sink direct réétiqueté. Le reçu et le retour outil sont préservés à côté. proofs/static-syntax.json indique seulement le parsing AST et l'égalité du preview avec le vrai corps de transformation sélectionné ; cela ne prouve pas un startup.

Commande des mêmes tests :
python3 -I -B /private/tmp/therese-c17-fresh-wrapper-builder-v7-cnR8Hm/run_pure.py

## Futur usage root uniquement

Le constructeur attend --prepare, --root (racine neuve exacte), --web-profile-ref, --chrome-profile-ref et --authority-ref (JSON SHA/bytes exacts). Le GO c17-root-fresh-wrapper-preparation-go-v1 doit lier ce builder, ce profil QA, la vraie preuve de copie, les sources, le témoin runner et le registre observé par le root.

La commande future de préparation est :
python3 -I -B /private/tmp/therese-c17-fresh-wrapper-builder-v7-cnR8Hm/build_fresh_wrapper.py --prepare --root <NOUVELLE_RACINE_WRAPPER> --web-profile-ref <REF_JSON_WEB51ff> --chrome-profile-ref <REF_JSON_c9101b2a> --authority-ref <REF_JSON_GO_ROOT_FRAIS>

Ne pas exécuter cette commande avec des placeholders. Elle peut ensuite produire une racine de préparation, jamais une qualification native. Le GO natif doit rester séparé et exact.

## Limites et profil web

Ce lot n'a créé ni lancé aucune racine WRAPPER, ne copie/modifie pas Chrome et ne démarre aucun runtime. FULL, release et publication restent false.

WEB51ff reste byte-exact avec son ancien subpath /Applications/Google Chrome.app. Chrome auxiliaire utilise son profil distinct ; supprimer ce droit web n'est pas incorporé implicitement et exigerait un gel web séparé et des pins/autorités neufs. SQL, réseau, HOME utilisateur et anciens gels ne sont pas élargis.

Après construction éventuelle, le root doit relire les nouveaux pins physiques et le SQL, puis autoriser le seul canari WRAPPER. Le vrai résultat peut encore être rouge ; ni la signature de la copie ni les tests purs n'attestent le confinement ou le fonctionnement du navigateur.
