"""Exécution de tests purs seulement ; aucun G1 complet, build ni sous-processus."""
from __future__ import annotations
import ast
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import sys
import time
import unittest

HERE = Path(__file__).resolve().parent
FORBIDDEN = []

def audit(event, args):
    if event in {'subprocess.Popen', 'os.system', 'os.posix_spawn', 'ctypes.dlopen'} or event.startswith('os.exec') or event.startswith('socket.'):
        FORBIDDEN.append(event)
        raise RuntimeError('Pure tests: forbidden runtime event ' + event)
    if event == 'import' and args and isinstance(args[0], str) and (
        args[0] == 'runtime_session' or args[0].startswith('runtime78_admitted') or args[0] == 'app' or args[0].startswith('app.')):
        FORBIDDEN.append(event + ':' + args[0])
        raise RuntimeError('Pure tests: forbidden instrumentation/product import')
sys.addaudithook(audit)

def pins():
    return {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(HERE.rglob('*'))
            if path.is_file() and not path.name.endswith('.pyc') and '__pycache__' not in path.parts}

before = pins()
started = time.time()
spec = importlib.util.spec_from_file_location('v7_pure_tests', HERE / 'test_build_fresh_wrapper.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
stream = io.StringIO()
result = unittest.TextTestRunner(stream=stream, verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(module))
after = pins()
record = {'schema': 'c17-wrapper-builder-v7-pure-tests-v1', 'actor': '/root/cycle17_gate_review',
          'started_at_unix': started, 'completed_at_unix': time.time(),
          'tests_run': result.testsRun, 'failures': len(result.failures), 'errors': len(result.errors),
          'skips': len(result.skipped), 'source_before': before, 'source_after': after,
          'pins_unchanged': before == after, 'forbidden_attempts': FORBIDDEN,
          'G1_imported': 'runtime_session' in sys.modules, 'build_executed': False,
          'QA_copy_created': False, 'native_executed': False, 'FULL': False,
          'fixture_scope': 'unit temporary files/mocks plus read-only actual root signature receipt',
          'output': stream.getvalue()}
print(json.dumps(record, ensure_ascii=False, indent=2))
raise SystemExit(0 if result.wasSuccessful() and before == after and not FORBIDDEN else 1)
