"""Rejeu root A/B80, fixtures seules, aucun import du G1 entier ni OS."""
import contextlib
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import time
import unittest

HERE = Path(__file__).resolve().parent
SOURCE = Path('/private/tmp/therese-c17-ab14-listener-stop-4TFcYl')
INDEX_SHA = 'a16075d4bc28cc3811c2589e546b99e31ec4ab33bd86d18665bf9315fd2c3a2c'

def reference(path):
    path = Path(path)
    raw = path.read_bytes()
    return {'path': str(path), 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}

index_ref = reference(SOURCE / 'INDEX.json')
assert index_ref['sha256'] == INDEX_SHA
index = json.loads((SOURCE / 'INDEX.json').read_bytes())
assert index['runtime_admitted'] is index['full_admitted'] is index['native_tested'] is False
pins = [index_ref, reference(__file__)]
for row in index['files']:
    relative = Path(row['path'])
    assert not relative.is_absolute() and '..' not in relative.parts
    pin = dict(row, path=str(SOURCE / relative))
    assert reference(pin['path']) == pin
    pins.append(pin)
for row in index['origins']:
    actual = reference(row['path'])
    assert actual['sha256'] == row['sha256']
    pins.append(actual)
for copied, origin in (
    ('preimages/runtime_session.py', '/private/tmp/therese-c17-full-aux-port-tfka3X/g1/runtime_session.py'),
    ('preimages/build-calibrations-c17.py', '/private/tmp/therese-c17-calibration-builder-v3-1MRJ1RAZ/build-calibrations-c17.py'),
    ('preimages/test_build_calibrations_c17.py', '/private/tmp/therese-c17-calibration-builder-v3-1MRJ1RAZ/test_build_calibrations_c17.py'),
):
    before, current = reference(SOURCE / copied), reference(origin)
    assert (before['sha256'], before['bytes']) == (current['sha256'], current['bytes'])
    pins.append(current)
attempts = []
created = set()
fixture_pattern = re.compile(r'therese-c17-(?:direct-round-[ab]|qualification-fixture)-[a-f0-9]{12}\Z')

def owned_output(target):
    target = Path(os.fsdecode(target)).resolve()
    return target.is_relative_to(HERE) or any(target.is_relative_to(root) for root in created)

def audit(event, args):
    if event.startswith(('subprocess.', 'socket.', 'ctypes.', 'os.exec', 'os.spawn',
                         'os.posix_spawn', 'os.fork', 'os.kill', 'os.system', 'pty.spawn')):
        attempts.append(event)
        raise AssertionError('OS interdit dans un rejeu pur : ' + event)
    if event == 'os.mkdir' and isinstance(args[0], (str, bytes)):
        target = Path(os.fsdecode(args[0])).resolve()
        if target in created and target.exists():
            # mkdir(exist_ok=True) re-vérifie un parent déjà privé, sans le créer.
            meta = target.lstat()
            assert target.is_dir() and not target.is_symlink() and meta.st_uid == os.getuid() and meta.st_mode & 0o077 == 0
        elif target.parent == Path('/private/tmp') and fixture_pattern.fullmatch(target.name):
            assert not target.exists() and args[1] == 0o700
            created.add(target)
        elif not owned_output(target):
            attempts.append('mkdir:' + str(target))
            raise AssertionError('Création hors sorties/fixtures exactes : ' + str(target))
    if event == 'open' and len(args) > 2 and isinstance(args[2], int) and args[2] & (os.O_WRONLY | os.O_RDWR):
        if isinstance(args[0], (str, bytes)) and not owned_output(args[0]):
            attempts.append('write:' + os.fsdecode(args[0]))
            raise AssertionError('Écriture hors sorties/fixtures exactes')

class ImportGuard:
    def find_spec(self, fullname, path=None, target=None):
        if fullname.rsplit('.', 1)[-1] in ('runtime_session', 'runtime78_core', 'runtime78_coordinator',
                'session_rpc_adapter', 'rpc_unix', 'rpc_peer'):
            attempts.append('full_import:' + fullname)
            raise AssertionError('Import G1/OS entier interdit : ' + fullname)

sys.addaudithook(audit)
sys.meta_path.insert(0, ImportGuard())
started = time.monotonic()
with (HERE / 'stdout.log').open('x') as stdout, (HERE / 'stderr.log').open('x') as stderr:
    with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
        suite = unittest.TestSuite()
        for folder, pattern in (('tests', 'test_*.py'), ('calibration', 'test_build_calibrations_c17.py')):
            suite.addTests(unittest.defaultTestLoader.discover(str(SOURCE / folder), pattern=pattern,
                           top_level_dir=str(SOURCE / folder)))
        result = unittest.TextTestRunner(stream=stderr, verbosity=2).run(suite)
unchanged = all(reference(row['path']) == row for row in pins)
fixtures_closed = all(not root.exists() for root in created)
passed = result.testsRun == 80 and result.wasSuccessful() and not result.skipped and unchanged and not attempts and fixtures_closed
receipt = {'schema': 'c17-root-ab80-pure-replay-v1', 'actor': '/root', 'tests': result.testsRun,
    'failures': len(result.failures), 'errors': len(result.errors), 'skipped': len(result.skipped),
    'source_refs': pins, 'unchanged': unchanged, 'forbidden_attempts': attempts,
    'stdout': reference(HERE / 'stdout.log'), 'stderr': reference(HERE / 'stderr.log'),
    'fixture_roots_created': sorted(str(root) for root in created), 'fixtures_closed': fixtures_closed,
    'elapsed_seconds': time.monotonic() - started, 'passed': passed,
    'G1_imported': False, 'native_workload_executed': False, 'FULL': False, 'release': False}
with (HERE / 'receipt.json').open('x') as stream:
    stream.write(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'passed': passed, 'tests': result.testsRun, 'receipt': reference(HERE / 'receipt.json')}))
raise SystemExit(0 if passed else 1)
