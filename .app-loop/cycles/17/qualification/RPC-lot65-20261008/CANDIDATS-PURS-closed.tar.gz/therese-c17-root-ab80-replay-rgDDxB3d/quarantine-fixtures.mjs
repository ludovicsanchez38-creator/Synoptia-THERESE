import fs from 'node:fs';
import crypto from 'node:crypto';
import path from 'node:path';
const out='/private/tmp/therese-c17-root-ab80-replay-rgDDxB3d';
const filename=out+'/receipt.json';
const raw=fs.readFileSync(filename);
if(crypto.createHash('sha256').update(raw).digest('hex')!=='b219292fca1e97f9610af8654a158315d053a681383e8c9ec7fe9bfc24c33756')throw Error('Reçu premier rouge changé');
const receipt=JSON.parse(raw);
if(receipt.passed!==false||receipt.tests!==80||receipt.failures!==60||receipt.unchanged!==true)throw Error('Premier rouge inattendu');
const quarantine=out+'/failed-fixtures';
fs.mkdirSync(quarantine,{mode:0o700});
const moved=[];
for(const source of receipt.fixture_roots_created){
 if(!fs.existsSync(source))continue;
 const st=fs.lstatSync(source);
 if(path.dirname(source)!=='/private/tmp'||!/^therese-c17-(?:direct-round-[ab]|qualification-fixture)-[a-f0-9]{12}$/.test(path.basename(source))||!st.isDirectory()||st.isSymbolicLink()||st.uid!==process.getuid()||(st.mode&0o077)!==0||fs.realpathSync(source)!==source)throw Error('Fixture hors périmètre exact '+source);
 const destination=quarantine+'/'+path.basename(source);
 if(fs.existsSync(destination))throw Error('Destination déjà présente');
 fs.renameSync(source,destination);
 moved.push({source,destination,dev:st.dev,ino:st.ino});
}
const result={schema:'c17-root-pure-fixtures-recoverable-quarantine-v1',actor:'/root',original_receipt_sha256:'b219292fca1e97f9610af8654a158315d053a681383e8c9ec7fe9bfc24c33756',moved,count:moved.length,no_fixture_deleted:true,original_receipt_unchanged:true,at:new Date().toISOString(),native:false,FULL:false};
fs.writeFileSync(out+'/fixtures-quarantine-receipt.json',JSON.stringify(result,null,2)+'\n',{flag:'wx',mode:0o600});
console.log(JSON.stringify({moved:moved.length,no_fixture_deleted:true,remaining_at_original_paths:receipt.fixture_roots_created.filter(p=>fs.existsSync(p)).length}));
