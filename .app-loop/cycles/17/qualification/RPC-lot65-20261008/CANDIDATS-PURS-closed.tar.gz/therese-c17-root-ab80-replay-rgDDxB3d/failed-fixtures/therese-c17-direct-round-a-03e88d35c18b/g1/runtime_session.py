# synthetic Session module
