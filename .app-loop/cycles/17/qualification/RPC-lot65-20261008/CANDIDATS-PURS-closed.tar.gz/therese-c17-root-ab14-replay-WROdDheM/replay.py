"""Rejeu root A/B14, tests purs uniquement, aucun import G1 ni OS."""
import contextlib
import ctypes
import hashlib
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import time
import unittest

HERE = Path(__file__).resolve().parent
SOURCE = Path('/private/tmp/therese-c17-full-aux-port-tfka3X')

def reference(path):
    path = Path(path)
    digest = hashlib.sha256()
    count = 0
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            count += len(chunk)
            digest.update(chunk)
    return {'path': str(path), 'sha256': digest.hexdigest(), 'bytes': count}

index_ref = {'path': str(SOURCE / 'INDEX.json'), 'sha256': '180f39008ec2af98fe38cfd234cb89b9d7bbdb4ad9e5dd5caa45265837f77eb3', 'bytes': 5540}
assert reference(index_ref['path']) == index_ref
index = json.loads(Path(index_ref['path']).read_bytes())
assert index['full_admitted'] is False and index['runtime_enabled'] is False
assert index['os_startup_qualified'] is False and index['chrome_profile_native_qualified'] is False
pins = index['files'] + [index_ref, reference(__file__)]
assert len(index['files']) == 19 and all(reference(row['path']) == row for row in pins)
attempts = []

def deny(*args, **kwargs):
    attempts.append('forbidden_process_socket_native')
    raise AssertionError('Rejeu pur : processus, socket et appels natifs interdits')

for module, names in ((subprocess, ('Popen', 'run', 'check_output', 'call', 'check_call')),
                      (socket, ('socket', 'socketpair', 'create_connection')),
                      (os, ('system', 'fork', 'execve', 'posix_spawn', 'posix_spawnp', 'kill', 'killpg')),
                      (ctypes, ('CDLL', 'PyDLL'))):
    for name in names:
        if hasattr(module, name):
            setattr(module, name, deny)

class ImportGuard:
    def find_spec(self, fullname, path=None, target=None):
        if fullname.rsplit('.', 1)[-1] in ('runtime_session', 'runtime78_core', 'runtime78_coordinator',
                'session_rpc_adapter', 'sql_worker', 'current_contract', 'package78', 'rpc_unix', 'rpc_peer'):
            attempts.append('full_import:' + fullname)
            raise AssertionError('Import complet G1/OS interdit : ' + fullname)

sys.meta_path.insert(0, ImportGuard())
sys.path.insert(0, str(SOURCE / 'tests'))
started = time.monotonic()
with (HERE / 'stdout.log').open('x') as stdout, (HERE / 'stderr.log').open('x') as stderr:
    with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
        result = unittest.TextTestRunner(stream=stderr, verbosity=2).run(
            unittest.defaultTestLoader.discover(str(SOURCE / 'tests'), pattern='test_ab_auxiliary_port.py'))
unchanged = all(reference(row['path']) == row for row in pins)
g1_imported = any(name.rsplit('.', 1)[-1] == 'runtime_session' for name in sys.modules)
passed = result.testsRun == 14 and result.wasSuccessful() and not result.skipped and unchanged and not attempts and not g1_imported
receipt = {'schema': 'c17-root-ab14-pure-replay-v1', 'actor': '/root',
    'tests': result.testsRun, 'failures': len(result.failures), 'errors': len(result.errors), 'skipped': len(result.skipped),
    'source_refs': pins, 'unchanged': unchanged, 'forbidden_attempts': attempts,
    'stdout': reference(HERE / 'stdout.log'), 'stderr': reference(HERE / 'stderr.log'),
    'elapsed_seconds': time.monotonic() - started, 'passed': passed,
    'root_built': False, 'G1_imported': g1_imported, 'native_workload_executed': False,
    'FULL': False, 'release': False,
    'known_unclosed_joins': ['three_port_scans_vs_calibration_reader_two', 'python_listener_worker_WRAPPER_only']}
with (HERE / 'receipt.json').open('x') as stream:
    stream.write(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'passed': passed, 'tests': result.testsRun, 'receipt': reference(HERE / 'receipt.json')}))
raise SystemExit(0 if passed else 1)
