# Premier préflight du harnais root62

Retour réel `bd45a6`, exit1, avant chargement des tests et avant tout sink de test.
Le harnais utilisait à tort le parent de chaque INDEX comme base relative :
`support-v2/support-v2/render_support.py` ne pouvait donc pas être lu.

Le contrat lu dans `validate_indexes` exige la racine PREP pour les définitions,
et le parent seulement pour les trois INDEX de profil Chrome explicites. La
copie successor du harnais applique cette base exacte et conserve cette préimage.
Aucun code de test, de constructeur, G1, application ou ancien gel n'est changé.
Ce document est une note dérivée du retour outil, pas un stdout/stderr direct.
