"""Contrat pur, non admis, des auxiliaires Chrome du cycle 17 A/B.

Ce module ne démarre rien et ne lit aucun profil. Le futur coordinateur devra
lier ses lignes à des commandes/sources physiques puis obtenir un GO distinct.
"""
from __future__ import annotations

import json
import re
from pathlib import Path


ROOT_PATTERN = re.compile(r"therese-(c17-direct-round-([ab])-[0-9a-f]{12})\Z")
HEX40 = re.compile(r"[0-9a-f]{40}\Z")
HEX64 = re.compile(r"[0-9a-f]{64}\Z")
PORTS = (17593, 5173, 17594)
CHROME = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
CHROME_V5_SHA = "9c6d17def6fa847f0740bb2398d52a8ef6dfc3a8279563dd1bda815d7892e872"
CHROME_V5_BYTES = 1698
DISABLED_ARGS = ["--disable-background-networking", "--disable-component-update", "--disable-sync"]

# Ces lignes décrivent les invocations, pas les 78 obligations métier.
# Un même fichier P157 est invoqué deux fois, pour deux contextes distincts.
CALIBRATE_JOBS = (
    "rpc-all-runtime_ui-visual_capture-network_capture",
    "rpc-screen-negative",
    "rpc-screen-positive-visual",
    "rpc-screen-positive-network",
    "rpc-screen-restored",
)
DIRECT_SITES = (
    ("recipe-general", "runtime/recette-c17.mjs"),
    ("recipe-invoices", "runtime/recette-facturation-p160-v2.mjs"),
    ("recipe-crm", "runtime/recette-crm-focus.mjs"),
    ("B1713", "complements/instruments/b1713-clavier-v3.mjs"),
    ("P157-800", "complements/instruments/p157-pipeline-root-oracle.mjs"),
    ("P157-1440", "complements/instruments/p157-pipeline-root-oracle.mjs"),
    ("B1755", "complements/instruments/b1755-garde-v3.mjs"),
    ("P162", "complements/instruments/p162-colonnes-v3.mjs"),
    ("coverage", "runtime/couverture-ecran-c17.mjs"),
)
ALL_JOBS = CALIBRATE_JOBS + tuple(stage for stage, _ in DIRECT_SITES)


def need(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def _under(path: str, root: Path) -> bool:
    """Garde lexicale seulement ; le consommateur doit vérifier le FS physique."""
    target = Path(path)
    return target.is_absolute() and ".." not in target.parts and (target == root or root in target.parents)


def _reference(ref: dict, root: Path | None = None) -> None:
    need(type(ref) is dict and set(ref) == {"path", "sha256", "bytes"}, "Référence incomplète")
    need(type(ref["path"]) is str and Path(ref["path"]).is_absolute(), "Chemin ref non absolu")
    need(type(ref["sha256"]) is str and HEX64.fullmatch(ref["sha256"]) is not None,
         "SHA ref invalide")
    need(type(ref["bytes"]) is int and ref["bytes"] > 0, "Taille ref absente")
    if root is not None:
        need(_under(ref["path"], root), "Référence hors round")


def validate_identity(identity: dict) -> tuple[Path, str]:
    """Contrôle la forme A/B ; aucune attestation Git physique n'est créée ici."""
    need(type(identity) is dict, "Identité absente")
    keys = {"root", "round_id", "round_name", "actor", "head", "product_source_root",
            "qa_python", "prepared_config_ref", "source_checkout_ref", "source_manifest_ref"}
    need(keys <= set(identity), "Identité/source checkout A/B incomplète")
    root = Path(identity["root"])
    match = ROOT_PATTERN.fullmatch(root.name)
    need(root.is_absolute() and root.parent == Path("/private/tmp") and match is not None,
         "Racine A/B non canonique")
    need(identity["round_id"] == match.group(1) and identity["round_name"] == match.group(2).upper(),
         "ID logique/campagne différents de la racine")
    need(identity["actor"] in {"/root", "/root/cycle17_gate_review", "/root/environment_routes",
                               "/root/native_policy_review"}, "Acteur A/B inconnu")
    need(type(identity["head"]) is str and HEX40.fullmatch(identity["head"]) is not None,
         "HEAD A/B absent ou non vérifié")
    source = Path(identity["product_source_root"])
    python = Path(identity["qa_python"])
    need(source.is_absolute() and ".." not in source.parts and source != root
         and source.name == "source" and source.parent.parent == Path("/private/tmp")
         and source.parent.name.startswith("therese-c17-"),
         "Forme du checkout QA neuf A/B absente")
    need(python == source / ".venv-conforme/bin/python", "Python QA autre que le checkout frais")
    for key, path in (("prepared_config_ref", root / "prepared-config.json"),
                      ("source_checkout_ref", root / "authorization/source-checkout.json"),
                      ("source_manifest_ref", root / "authorization/source-files.json")):
        _reference(identity[key], root)
        need(identity[key]["path"] == str(path), "Ref config/checkout/manifeste autre A/B")
    return root, match.group(2).upper()


def expected_rows(root: Path) -> dict[str, dict]:
    """Plan physique attendu des 14 profils, sans argv/env calculés à tort."""
    result = {}
    for job in ALL_JOBS:
        name = "aux-chrome-" + job
        base = root / "auxiliary" / name
        options = {"headless": False, "channel": "chrome", "chromiumSandbox": True}
        if job != CALIBRATE_JOBS[0]:
            options["args"] = DISABLED_ARGS.copy()
        result[job] = {
            "job": job, "name": name, "role": "auxiliary-" + name,
            "logical_parent": "calibrate" if job in CALIBRATE_JOBS else job,
            "port": 17594, "executable": CHROME,
            "profile": str(base / "profile"),
            "stdout": str(base / "stdout.log"), "stderr": str(base / "stderr.log"),
            "start_path": str(base / "start.json"),
            "services_path": str(base / "services.json"),
            "stop_path": str(base / "stop.json"),
            "original_options": options,
            "source_script": dict(DIRECT_SITES).get(job),
        }
    return result


def metadata_requirements(root: Path, *, git_snapshot_ref: dict,
                          context_refs: dict[str, dict]) -> dict[str, dict[str, str]]:
    """Huit ajouts RPC actuels et neuf ajouts directs proposés, non activés.

    Les consommateurs Node/G1 courants n'acceptent pas encore le contexte
    A/B des neuf stages directs.
    """
    _reference(git_snapshot_ref, root)
    need(set(context_refs) == set(ALL_JOBS), "Contextes A/B incomplets")
    for reference in context_refs.values():
        _reference(reference, root)
    git = json.dumps(git_snapshot_ref, sort_keys=True)
    result = {
        "rpc-all-test_runner": {"C17_AUX_GIT_SNAPSHOT_REF": git},
        "rpc-all-logs": {"C17_AUX_GIT_SNAPSHOT_REF": git,
                         "C17_AUX_LOGS_RUN": str(root / "runtime/calibration/logs-rpc")},
        "rpc-all-screen_coverage": {"C17_AUX_GIT_SNAPSHOT_REF": git},
    }
    for job in CALIBRATE_JOBS:
        result[job] = {"C17_AUX_CONTEXT_REF": json.dumps(context_refs[job], sort_keys=True)}
    result[CALIBRATE_JOBS[0]]["C17_AUX_GIT_SNAPSHOT_REF"] = git
    for job, _ in DIRECT_SITES:
        result[job] = {"C17_AUX_CONTEXT_REF": json.dumps(context_refs[job], sort_keys=True),
                       "C17_AUX_GIT_SNAPSHOT_REF": git}
    return result


def validate_candidate(identity: dict, *, descriptors: dict, context_refs: dict,
                       git_snapshot_ref: dict, chrome_profile_ref: dict,
                       peer_socket: str, source_pins: dict) -> dict:
    """Valide des entrées préliées ; renvoie un candidat, jamais une admission."""
    root, campaign = validate_identity(identity)
    expected = expected_rows(root)
    need(type(descriptors) is dict and set(descriptors) == set(ALL_JOBS),
         "Quatorze descriptors exacts absents/en trop")
    need(type(context_refs) is dict and set(context_refs) == set(ALL_JOBS),
         "Quatorze contextes exacts absents/en trop")
    need(type(source_pins) is dict and set(source_pins) == set(ALL_JOBS),
         "Sources des quatorze invocations non liées")
    _reference(git_snapshot_ref, root)
    _reference(chrome_profile_ref, root)
    need(chrome_profile_ref["sha256"] == CHROME_V5_SHA
         and chrome_profile_ref["bytes"] == CHROME_V5_BYTES,
         "Profil Chrome V5 exact absent/non qualifié")
    need(peer_socket == str(root / "session-rpc/peer.sock"), "Socket RPC autre root")
    for job, row in descriptors.items():
        need(type(row) is dict and all(row.get(k) == v for k, v in expected[job].items()),
             "Descriptor auxiliaire différent : " + job)
        need(set(row) == set(expected[job]) | {"argv", "env", "cwd", "deadline",
                                             "launch_defaults_ref"},
             "Descriptor auxiliaire libre/incomplet : " + job)
        need(type(row["argv"]) is list and row["argv"] and
             all(type(arg) is str for arg in row["argv"]) and row["argv"][0] == CHROME,
             "argv Chrome non prélié : " + job)
        need(type(row["env"]) is dict and all(type(k) is str and type(v) is str
                                              for k, v in row["env"].items()),
             "Env Chrome non prélié : " + job)
        home = row["env"].get("HOME", "")
        need(_under(home, root)
             and row["env"].get("CFFIXED_USER_HOME") == home
             and _under(row["env"].get("TMPDIR", ""), root)
             and _under(row["env"].get("PLAYWRIGHT_BROWSERS_PATH", ""), root),
             "Profil Chrome non jetable : " + job)
        need(row["cwd"] == str(root) and row["deadline"] == 50,
             "Cwd/borne startup Chrome différente : " + job)
        _reference(row["launch_defaults_ref"], root)
        _reference(context_refs[job], root)
        _reference(source_pins[job], root)
        need(len({row["profile"], row["stdout"], row["stderr"]}) == 3,
             "Profil/sinks confondus : " + job)
    need(len({descriptors[j]["profile"] for j in ALL_JOBS}) == 14,
         "Profil Chrome partagé entre jobs")
    need(len({descriptors[j]["stdout"] for j in ALL_JOBS}) == 14 and
         len({descriptors[j]["stderr"] for j in ALL_JOBS}) == 14,
         "Sinks Chrome partagés entre jobs")
    metadata = metadata_requirements(root, git_snapshot_ref=git_snapshot_ref,
                                     context_refs=context_refs)
    return {
        "schema": "c17-ab-fourteen-chrome-candidate-v1",
        "scope": "A_OR_B_DIRECT_ROUND_INSTRUMENTS_ONLY",
        "actor": identity["actor"], "round_id": identity["round_id"],
        "round_name": campaign, "root": str(root), "head": identity["head"],
        "ports": list(PORTS), "calibration_rpc_children": list(CALIBRATE_JOBS),
        "direct_stage_invocations": [name for name, _ in DIRECT_SITES],
        "command_count": 14, "rpc_child_count_total": 15,
        "profile_candidate_ref": chrome_profile_ref,
        "prepared_config_ref": identity["prepared_config_ref"],
        "source_checkout_ref": identity["source_checkout_ref"],
        "source_manifest_ref": identity["source_manifest_ref"],
        "git_snapshot_ref": git_snapshot_ref,
        "proposed_metadata": metadata,
        "context_refs": context_refs, "source_pins": source_pins,
        "peer_socket": peer_socket,
        "lifecycle": ["owned_services_17593_5173", "auxiliary_start_birth_gate",
                      "owned_cdp_17594_before_child", "child_raw_exit",
                      "auxiliary_stop_absence_17594", "ack_after_stable_logs",
                      "final_ports_absence_17593_5173_17594"],
        "admission": False, "OS_qualified": False, "FULL_qualified": False,
        "caps_promoted": False,
    }


def activate(*_args: object, **_kwargs: object) -> None:
    raise RuntimeError("Contrat préparatoire uniquement : admission A/B, profils et runtime non qualifiés")
