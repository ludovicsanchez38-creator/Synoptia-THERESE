# Cycle 17, port auxiliaire Chrome A/B, candidat statique

Ce dossier est une copie dérivée. Il ne modifie ni le dépôt THÉRÈSE, ni les gels antérieurs, ni une QA réelle. Aucun service, navigateur, profil utilisateur ou canari natif n'a été lancé ici.

Base G1 : `/private/tmp/therese-c17-full-rpc-sql-reader-cdc3JA/INDEX.json` (SHA `00f353fc6ce3695b5937a115dcd4111abbe983e147c0aa1007b4f5e53332d703`). Base transport : gel transport-26 copié byte-exact puis modifié ici. Base des quatorze invocations : `/private/tmp/therese-c17-full-aux-ab-v2-qynmPs/ab_auxiliary.py`, conservée sous `preimages/` ; sa référence V5 n'est pas reprise comme preuve native. `g1/chrome.sb` copie exactement le candidat RootDomainUserClient SHA `5266a6b026b5eb8192e030b5c27cc0001b65fce97d5840a9979e16a0d4ac151d` (1 914 octets), sans qualification OS.

La table ferme cinq enfants RPC Chrome et neuf étapes Node directes, avec un profil/sinks distincts par invocation. G1 compare les quatorze descriptors, commandes, contextes A/B, checkout, snapshot Git, sources Node, options Playwright, binaire/framework Chrome et port 17594 avant d'envisager un démarrage. Le listener continue à utiliser deux observations globales attribuées, sans acceptation de PID étranger. La borne Chrome 50 s sert à l'admission de démarrage, pas à une durée de vie de 50 s. La feuille est close avant ACK RPC ; les étapes directes closent Chrome à `finish`. `stop_services` et `stop` exigent ensuite l'absence globale des ports 17593, 5173 et 17594. Les cinq jobs WRAPPER existants restent distincts.

Garde non levée : `RUNTIME_ENABLED=False`, `OS_STARTUP_QUALIFIED=False`, les quatre capacités G1 à `False`, `ADMISSION_TABLE={}` et `AB_CHROME_PROFILE_NATIVE_QUALIFIED=False`. Le profil candidat et la signature de Chrome ne sont pas qualifiés. Les tests sont purs/synthétiques ; ils ne prouvent ni Seatbelt, ni CDP, ni fermeture physique.

Producteur futur requis : le blueprint A/B de gel48 émet cinq contextes Chrome RPC, pas les neuf directs. Il doit préémettre les quatorze `auxiliary_context_refs`, `auxiliary_descriptors` et commandes correspondantes sous une QA A/B neuve, épingler le pont Node et les scripts, et fournir une attestation de profil Chrome native séparée avant toute promotion. Le bootstrap RPC/SQL partagé reste une dépendance distincte. Aucun ancien reçu WRAPPER ne peut servir de ronde FULL A/B.

Contrôles effectués : `python3 -I -B -m unittest discover -s tests -v` (14 tests PASS), `ast.parse` de quatre sources Python et `node --check auxiliary/aux_node.mjs` (PASS). Les tests extraient une fonction G1 par AST sans importer G1 et emploient des documents synthétiques pour les joins RPC ; aucune vérification physique n'en découle.

Les préimages et les diffs `git diff --no-index` sont dans `preimages/` et `diffs/`. La seule nouvelle règle Seatbelt se trouve dans le diff du profil Chrome candidat. L'`INDEX.json` de ce dossier épingle tous les fichiers et origines mentionnés, sans autorité d'admission.
