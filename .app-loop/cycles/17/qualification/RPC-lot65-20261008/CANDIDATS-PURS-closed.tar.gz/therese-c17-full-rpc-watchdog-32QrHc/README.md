# Cycle 17, watchdog RPC léger, préparation additive fermée

Auteur : `/root/shared4_execution`. Base immuable : `/private/tmp/therese-c17-full-rpc-bootstrap-GjAo7Z/INDEX.json`, SHA `a4110e56403661f1603080ad45614a55da9aa913c9e00370b0eaffff697f9ce6`.

Le tick `OwnedRpcBootstrap.check_deadline()` contrôle seulement la deadline Python monotonic finie, sa valeur immuable dans le contexte, et l'expiration. Il ne lit aucun fichier, owner kernel ou plan. `check_boundary()` contrôle la deadline, effectue les mêmes rehashs complets/birth/plan qu'avant, puis contrôle à nouveau la deadline. Un rehash long dépassant l'échéance refuse l'action, sans prétendre à une préemption dure.

G1 `check_round_deadline(*, verify_sources=False)` conserve le tick léger par défaut ; la valeur doit être un vrai booléen. G1 `start` et l'attachement bootstrap emploient la frontière complète. Le coordinateur l'emploie avant/après chaque execute, phase in-process non-cleanup et vraie attente de revue. Bootstrap contrôle aussi les deux frontières de sa création. Les validations sources existantes de G1 start/finish/cleanup et du relais restent intactes. STOP cleanup demeure autorisé après la deadline.

Périmètre de performance limité : `root_stage_relay.exchange` continue sa garde complète admission/source/birth à chaque attente10ms. Les requêtes RPC et listeners conservent aussi leurs contrôles physiques. Ce lot supprime le rehash complet **causé par le watchdog de G1.wait**, pas tous les contrôles des pollers. Aucun cache, TTL, permission, plafond, commande, oracle, HEAD ou décision n'a été changé.

47 méthodes pures réellement exécutées : 35 cas de la base adaptés aux nouveaux chemins, dont le refus owner déplacé explicitement de tick à frontière, puis 12 cas watchdog. Ces derniers exécutent notamment le vrai wait sur trois ticks, le vrai execute imbriqué du coordinateur sur doubles, et les refus source/owner/contexte/deadline. Les sources G1/core/coordinateur/RPC complets ne sont pas importées. Les sources RUNTIME/OS/capacités restent False, tables vides.

Les deux setUp utilisent TemporaryDirectory sous un TMP de sortie déclaré par le runner, avec cleanup. HERE reste le chemin AST/pins, aucune fixture n'est créée dans ce gel. Le JSON wait présent sous synthetic-fixtures est une donnée read-only épinglée, explicitement synthétique. Le reçu pur conserve le texte combiné retourné par exec_command58979f, pas un sink stdout/stderr direct ; 47 PASS,0 failure/error/skip,8 pins égaux avant/après. Aucun workload Popen/socket/libproc/signal/G1 natif.

Invocation pure de reprise : `python3 -I -B run-pure.py` depuis ce dossier. Aucun runtime ou constructeur de ronde n'est appelé. Le replay35 ancien est conservé et n'a pas été relancé. Préimages exactes sous origins, cinq diffs exhaustifs sous diffs, bridge/relais copiés sans delta.

Ce lot ne fusionne pas A/B14. Sa fusion future devra composer les méthodes G1 communes, repinner les modules exacts, puis résoudre les deux jonctions A/B14 avouées : scans ports3 vs lecteur calibrations2, worker Python encore WRAPPER-only. Le producteur14/9scripts, vrai checkout/HEAD courant, profils/calibrations natives et autorités root externes restent nécessaires. Aucun FULL/A-B/OS, admission, flag ou succès runtime n'est déduit de ces tests.
