#!/usr/bin/env python3
"""Port strict des six reçus C17 depuis des bruts clos de la même ronde.

Aucun instrument n'est lancé ici. Le reçu d'arrêt est obligatoire : ce port se
consomme après stop-runtime, contrairement à l'ordre historique B4.
"""
from __future__ import annotations

import argparse
from datetime import UTC, datetime, timedelta
import hashlib
import json
import math
import os
from pathlib import Path
import re
import stat
import xml.etree.ElementTree as ET


ROUND = re.compile(r"therese-c17-direct-round-[ab]-[0-9a-f]{12}")
HEX40 = re.compile(r"[0-9a-f]{40}")
HEX64 = re.compile(r"[0-9a-f]{64}")
ACTORS = frozenset({"/root", "/root/cycle17_gate_review", "/root/environment_routes",
                    "/root/native_policy_review"})
RAW = {
    "summary": "runtime/calibration/all-rpc/calibration-summary.json",
    "test_runner": "runtime/calibration/test-runner-rpc/test-runner-controls.json",
    "logs": "runtime/calibration/logs-rpc/logs-controls.json",
    "browser": "runtime/calibration/browser-rpc/browser-controls.json",
    "screen_coverage": "runtime/calibration/screen-rpc/screen-controls.json",
}
INSTRUMENTS = ("test_runner", "logs", "runtime_ui", "visual_capture",
               "network_capture", "screen_coverage")
REVISION = "v3"
TTL = timedelta(seconds=43200)
QUALIFICATION_ROOT = Path(
    "/Users/synoptia/Desktop/Dev Synoptia/Synoptia-THERESE-c15-codex/.app-loop/cycles/17/qualification"
)


def need(condition: bool, reason: str) -> None:
    if not condition:
        raise ValueError(reason)


def iso(value: str) -> datetime:
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    need(parsed.tzinfo is not None, "Horodatage sans fuseau")
    return parsed.astimezone(UTC)


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def ref(path: Path) -> dict[str, str]:
    return {"path": str(path), "sha256": sha(path)}


def round_root(path: Path) -> Path:
    need(path.is_absolute() and path.parent == Path("/private/tmp")
         and ROUND.fullmatch(path.name) is not None, "Racine A/B directe requise")
    need(path.resolve(strict=True) == path and path.is_dir() and not path.is_symlink(),
         "Racine non canonique")
    meta = path.lstat()
    need(meta.st_uid == os.getuid() and stat.S_IMODE(meta.st_mode) & 0o077 == 0,
         "Racine QA non privée/non possédée")
    return path


def regular(path: Path, roots: tuple[Path, ...]) -> Path:
    need(path.is_absolute() and path.resolve(strict=True) == path,
         "Fichier non canonique")
    need(any(path.is_relative_to(root) for root in roots), "Fichier hors QA admise")
    meta = path.lstat()
    need(stat.S_ISREG(meta.st_mode) and meta.st_uid == os.getuid(),
         "Fichier non régulier/non possédé")
    return path


def pinned(value: dict, roots: tuple[Path, ...], *, exact: Path | None = None) -> Path:
    need(isinstance(value, dict) and isinstance(value.get("path"), str)
         and HEX64.fullmatch(value.get("sha256", "")) is not None,
         "Référence SHA absente")
    path = regular(Path(value["path"]), roots)
    need(exact is None or path == exact, "Chemin de preuve différent")
    need(sha(path) == value["sha256"], "SHA de preuve différent")
    if "bytes" in value:
        need(path.stat().st_size == value["bytes"], "Taille de preuve différente")
    return path


def read(value: dict, roots: tuple[Path, ...], *, exact: Path | None = None) -> dict:
    return json.loads(pinned(value, roots, exact=exact).read_text(encoding="utf-8"))


def same(value: dict, *, actor: str, round_id: str, head: str) -> None:
    need(value.get("actor") == actor and value.get("round_id") == round_id
         and value.get("head") == head, "Autre acteur/ronde/HEAD")


def _private_profile_dir(value: str, root: Path, label: str) -> Path:
    need(isinstance(value, str), "Chemin QA absent : " + label)
    path = Path(value)
    need(path.is_absolute() and path.is_relative_to(root), "Profil hors QA : " + label)
    try:
        resolved = path.resolve(strict=True)
    except OSError as exc:
        raise ValueError("Profil QA absent/non canonique : " + label) from exc
    need(resolved == path, "Profil QA avec symlink : " + label)
    meta = path.lstat()
    need(stat.S_ISDIR(meta.st_mode) and meta.st_uid == os.getuid(),
         "Profil QA non possédé/non dossier : " + label)
    return path


def verify_private_profile(root: Path, running: dict, stopped: dict) -> None:
    """La pile close garde le même profil physique jetable de la ronde A/B."""
    for key in ("temporary_root", "home", "data_dir"):
        need(key in running and running.get(key) == stopped.get(key),
             "Profil running/stopped discordant : " + key)
    temporary = _private_profile_dir(running["temporary_root"], root, "temporary_root")
    need(temporary.parent == root / "profiles", "Profil temporaire hors profiles QA")
    meta = temporary.lstat()
    need(stat.S_IMODE(meta.st_mode) & 0o077 == 0,
         "Profil temporaire QA non privé")
    home = _private_profile_dir(running["home"], root, "home")
    data = _private_profile_dir(running["data_dir"], root, "data_dir")
    need(home == temporary / "home" and data == temporary / "data",
         "HOME/données hors profil temporaire QA")
    for key, expected in (("verified_data_dir", data),
                          ("verified_db_path", data / "therese.db")):
        need(key in running and key in stopped and running[key] == stopped[key],
             "Chemin vérifié running/stopped discordant : " + key)
        path = Path(running[key]) if isinstance(running[key], str) else Path("")
        need(path == expected, "Chemin vérifié hors profil QA : " + key)
        if key == "verified_db_path":
            try:
                resolved = path.resolve(strict=True)
            except OSError as exc:
                raise ValueError("DB QA absente/non canonique") from exc
            meta = path.lstat()
            need(resolved == path and stat.S_ISREG(meta.st_mode)
                 and meta.st_uid == os.getuid(), "DB QA non régulière/non possédée/symlink")


def xml_counts(path: Path) -> dict[str, int]:
    tree = ET.parse(path).getroot()
    suites = [tree] if tree.tag == "testsuite" else list(tree.iter("testsuite"))
    return {key: sum(int(suite.attrib.get(key, "0")) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")}


def verify_xml_case(path: Path, tool: str, defect: bool) -> None:
    root = ET.parse(path).getroot()
    cases = list(root.iter("testcase"))
    need(len(cases) == 1, "Testcase témoin absent/dupliqué : " + tool)
    case = cases[0]
    identity = (("test_temoin_c17", "test_temoin_c17") if tool == "pytest" else
                ("calibrationC17.test.ts", "détecte le défaut puis l’état sain"))
    need((case.get("classname"), case.get("name")) == identity,
         "Testcase autre témoin : " + tool)
    failures = case.findall("failure")
    need(len(failures) == int(defect) and not case.findall("error")
         and not case.findall("skipped") and len(list(root.iter("failure"))) == int(defect)
         and not list(root.iter("error")) and not list(root.iter("skipped")),
         "Défaut XML témoin absent/inattendu : " + tool)
    if defect:
        failure = failures[0]
        message, body = failure.get("message", ""), failure.text or ""
        expected = "assert 2 == 1" if tool == "pytest" else "expected 2 to be 1"
        need(expected in message and "2" in body and "1" in body,
             "Échec XML non causal : " + tool)


def verify_test_runner(data: dict, root: Path) -> None:
    controls = data.get("controls")
    need(isinstance(controls, dict) and set(controls) == {
        "pytest-positive", "pytest-negative", "vitest-positive", "vitest-negative"},
        "Quatre contrôles runner absents")
    for name, row in controls.items():
        defect = name.endswith("-positive")
        xml = pinned({"path": row["xml"], "sha256": row["sha256"]}, (root,),
                     exact=root / "runtime/calibration/test-runner-rpc" / f"{name}.xml")
        expected = {"tests": 1, "failures": int(defect), "errors": 0, "skipped": 0}
        need(row["pass"] is True and row["exit_code"] == int(defect)
             and row["counts"] == xml_counts(xml) == expected, "Témoin runner faux : " + name)
        verify_xml_case(xml, name.split("-", 1)[0], defect)
        regular(root / "runtime/calibration/test-runner-rpc" / f"{name}.log", (root,))
    witnesses = data.get("witnesses")
    need(isinstance(witnesses, dict) and len(witnesses) == 3, "Trois témoins runner absents")
    for path, digest in witnesses.items():
        pinned({"path": path, "sha256": digest}, (root,))


def verify_logs(data: dict, root: Path, temporary_root: str, stage: dict) -> None:
    need(data["negative_control"]["pass"] is True
         and data["positive_control"]["pass"] is True, "Témoin logs faux")
    need(data.get("run_id") == "logs-rpc"
         and data["data_dir"] == str(Path(temporary_root) / "logs-rpc"),
         "Journaux hors profil temporaire")
    raw = pinned({"path": data["raw_log"], "sha256": data["raw_log_sha256"]}, (root,),
                 exact=root / "runtime/calibration/logs-rpc/therese-temoin.log")
    lines = raw.read_text(encoding="utf-8").splitlines()
    need(len(lines) >= 2, "Journal témoin vide/incomplet")
    records = [json.loads(line) for line in lines]
    need(all(isinstance(row, dict) for row in records), "Journal JSON invalide")
    before, injected = records[:-1], records[-1]
    run_id = data["run_id"]
    healthy = [row for row in before if row.get("message") == "TEMOIN-C17-SAIN"
               and row.get("level") == "INFO"
               and row.get("extra", {}).get("calibration_run") == run_id]
    errors = [row for row in records if row.get("message") == "TEMOIN-C17-ERREUR-INJECTEE"
              and row.get("level") == "ERROR"
              and row.get("extra", {}).get("calibration_run") == run_id]
    need(len(healthy) == len(errors) == 1 and errors[0] is injected
         and not any(row.get("level") == "ERROR" for row in before),
         "Marqueurs INFO/ERROR corrélés absents ou mal ordonnés")
    start, end = iso(stage["started_at"]), iso(stage["completed_at"])
    timestamps = [iso(row["timestamp"]) for row in records]
    need(timestamps == sorted(timestamps)
         and all(start <= timestamp <= end for timestamp in timestamps)
         and iso(healthy[0]["timestamp"]) <= iso(injected["timestamp"]),
         "Horodatages logs hors calibration/désordonnés")
    need(data["negative_control"].get("healthy_markers") == 1
         and data["negative_control"].get("records") == len(before)
         and data["positive_control"].get("correlated_errors") == 1
         and data["positive_control"].get("records") == len(records),
         "Comptages bruts logs discordants")


def verify_browser(data: dict, root: Path, qa_source: Path, data_dir: str) -> None:
    need(data.get("repo") == str(qa_source) and data.get("identity") ==
         {"status": 200, "tokenPresent": True}, "Navigateur/identité QA absents")
    need(data["environment"]["data_dir"] == data_dir
         and data["pageErrors"] == [], "Navigateur hors pile ou erreur page")
    need(data["runtime_ui"]["negativeOk"] is True
         and data["runtime_ui"]["positiveOk"] is True, "Témoin UI faux")
    visual = data["visual_capture"]
    negative, positive = visual["negative"], visual["positive"]
    browser_dir = root / "runtime/calibration/browser-rpc"
    paths = [browser_dir / name for name in
             ("visual-negative-a.png", "visual-negative-b.png", "visual-positive.png")]
    need(negative["files"] == [str(paths[0]), str(paths[1])]
         and positive["file"] == str(paths[2]), "Captures autre dossier")
    hashes = [sha(regular(path, (root,))) for path in paths]
    need(negative["a"] == hashes[0] and negative["b"] == hashes[1]
         and positive["c"] == hashes[2] and negative["identical"] is True
         and positive["differs"] is True and positive["visible"] is True
         and hashes[0] == hashes[1] != hashes[2], "Témoin visuel non vérifié")
    network = data["network_capture"]
    need(network["negative"] == {"status": 200, "detected": True}
         and network["positive"] == {"status": 503, "detected": True},
         "Témoin réseau faux")
    guard = network["guard"]
    need(all(not guard.get(key) for key in
             ("bloquees", "websockets_bloques", "telechargements", "popups", "portReel")),
         "Réseau/port hors QA")
    witnesses = data.get("sourcePreserved")
    need(isinstance(witnesses, dict) and witnesses, "Source navigateur non suivie")
    for path, item in witnesses.items():
        source = regular(Path(path), (root, qa_source))
        need(item["before"] == item["after"] == sha(source),
             "Source navigateur modifiée")


def verify_screen(data: dict, root: Path, qa_source: Path, data_dir: str) -> Path:
    need(data["stack"]["data_dir"] == data_dir, "Écran autre pile")
    source = pinned({"path": data["source"], "sha256": data["source_sha256"]}, (root,))
    need(source.name == "couverture-ecran-c17.mjs", "Instrument écran différent")
    pinned({"path": data["calibrated_copy"], "sha256": data["copy_sha256"]},
           (root,), exact=root / "runtime/calibration/screen-rpc/couverture-ecran-calibree.mjs")
    for label in ("negative", "positive_visual", "positive_network", "restored"):
        row = data[label]
        target = root / "runtime/calibration/screen-rpc" / (
            "positive-visual" if label == "positive_visual" else
            "positive-network" if label == "positive_network" else label)
        expected = target / ("interruption.json" if label == "positive_network" else "rapport.json")
        pinned({"path": row["path"], "sha256": row["sha256"]}, (root,), exact=expected)
        report = json.loads(expected.read_text())
        need(row["pass"] is True, "Témoin écran faux : " + label)
        code_ok = (row["exit_code"] != 0 if label == "positive_network"
                   else row["exit_code"] == 0)
        need(code_ok, "Code écran inattendu : " + label)
        if label in ("negative", "restored"):
            need(row["anomalies"] == report["anomalies"] == [],
                 "Écran sain avec anomalies")
        elif label == "positive_visual":
            types = {item["type"] for item in report["anomalies"]}
            need(set(row["types"]) == types
                 and {"contenu-rogne", "nom-accessible-vide"} <= types,
                 "Anomalies visuelles témoins absentes")
        else:
            blocked = report["garde"]["bloquees"]
            need(row["blocked"] == blocked
                 and any(item["url"] == "https://calibration.invalid/probe" for item in blocked)
                 and "jeton=temoin" not in expected.read_text(),
                 "Refus réseau témoin absent/non expurgé")
    need(data["negative"]["anomalies"] == data["restored"]["anomalies"] == [],
         "Écran sain avec anomalies")
    need(data["positive_network"]["query_redacted"] is True,
         "Témoin réseau non expurgé")
    snapshots = data.get("sources_preserved")
    need(isinstance(snapshots, dict) and snapshots, "Sources écran non préservées")
    for name, digest in snapshots.items():
        path = Path(name) if Path(name).is_absolute() else qa_source / name
        need(sha(regular(path, (root, qa_source))) == digest, "Source écran modifiée")
    return source


def _admitted_stage_spec(raw: dict, g1_stage: str, root: Path, authority: dict) -> dict:
    """La commande vient du binding root, jamais du reçu qui la décrit."""
    binding = authority["binding_data"]
    commands = binding.get("commands")
    need(isinstance(commands, dict), "Table de commandes G1 absente")
    spec = commands.get(g1_stage)
    if spec is None:
        stage_ref = raw.get("stage_binding")
        decision_ref = raw.get("stage_decision")
        origin_ref = raw.get("stage_origin")
        need(all(isinstance(item, dict) for item in (stage_ref, decision_ref, origin_ref)),
             "Admission tardive d'étape absente")
        stage = read(stage_ref, (QUALIFICATION_ROOT,))
        decision = read(decision_ref, (QUALIFICATION_ROOT,))
        pinned(origin_ref, (QUALIFICATION_ROOT,))
        plan = binding.get("stage_plans", {}).get(g1_stage)
        need(isinstance(plan, dict)
             and stage.get("schema") == "c17-runtime78-stage-binding-v1"
             and decision.get("schema") == "c17-runtime78-stage-go-v1"
             and stage.get("initial_binding") == authority["binding"]
             and decision.get("initial_binding") == authority["binding"]
             and stage.get("stage_id") == decision.get("stage_id") == g1_stage
             and decision.get("provided_by") == "/root"
             and decision.get("stage_binding") == stage_ref
             and decision.get("root_review_origin") == origin_ref
             and stage.get("planned_decision") == plan.get("decision") == {
                 "path": decision_ref["path"], "decision_id": decision.get("decision_id")}
             and stage_ref["path"] == plan.get("binding_path"),
             "Admission tardive G1 non liée au plan initial")
        spec = stage.get("command")
        need(isinstance(spec, dict) and spec.get("timeout_seconds") == plan.get("timeout_seconds"),
             "Commande/bornes tardives G1 différentes")
        for body in (stage, decision):
            need(all(body.get(key) == expected for key, expected in (
                ("actor", authority["actor"]), ("round_id", authority["round_id"]),
                ("head", authority["head"]), ("qa_root", str(root)),
                ("round_name", authority["round_name"]))),
                "Admission tardive autre acteur/ronde/HEAD")
    need(isinstance(spec, dict), "Commande G1 absente")
    expected_keys = {"argv", "role", "mode", "timeout_seconds", "env", "cwd",
                     "stdout_path", "stderr_path", "combine_stderr", "derived_deadline"}
    need(set(spec) == expected_keys and spec.get("role") == "stage-" + g1_stage
         and spec.get("mode") == "web" and spec.get("combine_stderr") is False
         and spec.get("derived_deadline") == "start_monotonic_plus_exact_timeout"
         and spec.get("cwd") == str(root)
         and spec.get("stdout_path") == str(root / "ledger" / g1_stage / "stdout.log")
         and spec.get("stderr_path") == str(root / "ledger" / g1_stage / "stderr.log")
         and type(spec.get("timeout_seconds")) in (int, float)
         and spec["timeout_seconds"] == (120 if g1_stage == "start-runtime" else 1200)
         and isinstance(spec.get("env"), dict) and isinstance(spec.get("argv"), list)
         and len(spec["argv"]) >= 2,
         "Commande G1 admise hors recette readiness/calibrate")
    return spec


def _effective_stage_env(spec: dict, raw: dict, g1_stage: str, root: Path,
                         authority: dict) -> dict:
    module_ref = authority["successor_data"].get("session", {}).get("module")
    need(isinstance(module_ref, dict), "Module Session G1 absent de la décision")
    module_path = Path(module_ref["path"])
    need(module_path.is_relative_to(root) or module_path.is_relative_to(QUALIFICATION_ROOT)
         or (module_path.is_relative_to(Path("/private/tmp")) and len(module_path.parts) > 3
             and module_path.parts[3].startswith("therese-c17-")),
         "Module Session G1 hors copie QA")
    pinned(module_ref, (root, QUALIFICATION_ROOT, Path("/private/tmp")))
    started, timeout = raw.get("started_monotonic"), spec["timeout_seconds"]
    need(type(started) in (int, float) and math.isfinite(started) and started > 0,
         "Début monotone réel G1 absent")
    deadline = started + timeout
    return spec["env"] | {
        "QA_ROOT": str(root), "C17_RUNTIME_MODULE_DIR": str(Path(module_ref["path"]).parent),
        "C17_SESSION_ACTOR": authority["actor"],
        "C17_SESSION_ROUND_ID": authority["round_id"],
        "C17_SESSION_HEAD": authority["head"],
        "C17_SESSION_STAGE": g1_stage, "C17_SESSION_ROOT": str(root),
        "C17_SESSION_EVENTS": str(root / "session-events"),
        "C17_SESSION_DECISION_ID": authority["admission_data"]["decision_id"],
        "C17_SESSION_BINDING_SHA256": authority["binding"]["sha256"],
        "C17_SESSION_ROUND_NAME": authority["round_name"],
        "C17_SESSION_DECISION_REF": json.dumps(authority["admission"], sort_keys=True),
        "C17_SESSION_BINDING_REF": json.dumps(authority["binding"], sort_keys=True),
        "C17_SESSION_OUTER_DEADLINE_MONOTONIC": str(deadline),
    }


def _check_execution(value: dict, stage: str, root: Path, *, actor: str,
                     round_id: str, head: str, authority: dict) -> dict:
    same(value, actor=actor, round_id=round_id, head=head)
    need(value.get("exit_code") == 0 and value.get("instrument_error") is None,
         "Étape non verte : " + stage)
    if stage == "stop-runtime":
        need(value.get("kind") == "in_process_owned_phase"
             and value.get("operation") == "stop-runtime", "Arrêt non possédé")
    else:
        g1_stage = "start-runtime" if stage == "readiness" else stage
        need(value.get("stage_id") == stage
             and value.get("g1_stage_id") == g1_stage
             and value.get("kind") == "subprocess_execution_derived_from_real_owned_session"
             and value.get("raw_not_relabelled") is True,
             "Enveloppe d'exécution sans reçu G1 réel")
        raw = read(value["real_session_receipt"], (root,))
        same(raw, actor=actor, round_id=round_id, head=head)
        campaign = root.name.removeprefix("therese-c17-direct-round-")[0].upper()
        identity = raw.get("root_identity")
        need(isinstance(identity, dict) and all(type(identity.get(key)) is int for key in
             ("pid", "ppid", "pgid", "uid", "start_sec", "start_usec"))
             and identity["pid"] > 0 and identity["ppid"] > 0
             and identity["pgid"] > 0 and identity["uid"] >= 0
             and identity["start_sec"] > 0 and 0 <= identity["start_usec"] < 1_000_000,
             "Birth G1 stage absente")
        owner = raw.get("owner")
        need(isinstance(owner, dict) and all(type(owner.get(key)) is int for key in
             ("pid", "ppid", "pgid", "uid", "start_sec", "start_usec"))
             and identity.get("parent_birth") == [owner["pid"], owner["start_sec"], owner["start_usec"]]
             and identity.get("role") == "stage-" + g1_stage
             and identity.get("attribution") == "popen_child_before_workload"
             and identity in raw.get("attributed", []),
             "Birth G1 non corroborée par ledger/owner")
        started_monotonic, timeout = raw.get("started_monotonic"), raw.get("timeout_seconds")
        need(type(started_monotonic) in (int, float) and math.isfinite(started_monotonic)
             and type(timeout) in (int, float) and math.isfinite(timeout) and timeout > 0
             and raw.get("outer_deadline_monotonic") == started_monotonic + timeout,
             "Borne G1 stage non dérivée")
        elapsed = raw.get("cleanup_elapsed_seconds")
        need(type(elapsed) in (int, float) and math.isfinite(elapsed) and 0 <= elapsed <= 8,
             "Cleanup G1 stage hors borne physique")
        spec = _admitted_stage_spec(raw, g1_stage, root, authority)
        expected_argv = ([str(authority["qa_source"] / ".venv-conforme/bin/python"),
                          str(root / "runtime78-successor/readiness_owned.py"), str(root),
                          "--decision", authority["successor"]["path"],
                          "--decision-sha256", authority["successor"]["sha256"]]
                         if g1_stage == "start-runtime" else
                         [str(authority["qa_source"] / ".venv-conforme/bin/python"),
                          str(root / "runtime/calibrate-all.py")])
        need(spec["argv"] == expected_argv, "Commande G1 autre instrument")
        expected_env = _effective_stage_env(spec, raw, g1_stage, root, authority)
        need(raw.get("schema") == "c17-runtime78-owned-stage-receipt-v1"
             and raw.get("stage_id") == g1_stage and raw.get("exit_code") == 0
             and raw.get("instrument_error") is None and raw.get("raw_stable") is True
             and raw.get("log_stability_proved") is True
             and raw.get("cleanup_deadline_met") is True
             and raw.get("cleanup_taint") == [] and raw.get("timed_out") is False
             and raw.get("released") is True and raw.get("role") == "stage-" + g1_stage
             and raw.get("qa_root") == str(root) and raw.get("round_name") == campaign
             and raw.get("execution_scope") == "runtime78_exact_round"
             and isinstance(raw.get("argv"), list) and bool(raw["argv"])
             and isinstance(raw.get("cwd"), str) and isinstance(raw.get("environment"), dict)
             and raw["argv"] == value.get("command") == spec["argv"]
             and raw["cwd"] == value.get("cwd") == spec["cwd"]
             and raw["environment"] == value.get("effective_environment") == expected_env
             and raw.get("timeout_seconds") == spec["timeout_seconds"]
             and raw.get("stdout") == value.get("stdout")
             and raw.get("stderr") == value.get("stderr")
             and raw["stdout"]["path"] == spec["stdout_path"]
             and raw["stderr"]["path"] == spec["stderr_path"]
             and raw.get("completed_at") == value.get("completed_at")
             and raw.get("started_at") == value.get("started_at"),
             "Reçu G1 brut non clos/discordant")
        for key in ("admission", "binding"):
            need(raw.get(key) == authority[key], "Autorité G1 stage différente : " + key)
            pinned(raw[key], (QUALIFICATION_ROOT,))
    for channel in ("stdout", "stderr"):
        pinned(value[channel], (root,))
    need(value.get("source_check_before") == value.get("source_check_after")
         and bool(value.get("source_check_before")), "Source modifiée/non contrôlée")
    return value


def verify_owned_service_stop(stop: dict, start: dict, stage: dict, root: Path,
                              *, actor: str, round_id: str, head: str,
                              authority: dict, qa_source: Path) -> None:
    """Suit le vrai Session.stop_services publié dans le stdout in-process."""
    need(stop.get("no_subprocess_command_claimed") is True
         and isinstance(stop.get("parent_identity_observed"), dict),
         "Arrêt in-process sans identité parent observée")
    identity = stop["parent_identity_observed"]
    need(all(type(identity.get(key)) is int for key in
             ("pid", "ppid", "pgid", "uid", "start_sec", "start_usec")),
         "Identité parent stop incomplète")
    stdout = pinned(stop["stdout"], (root,), exact=root / "ledger/stop-runtime/stdout.log")
    lines = stdout.read_text(encoding="utf-8").splitlines()
    need(len(lines) == 1, "Ref Session.stop_services stdout absente/ambiguë")
    cleanup_ref = json.loads(lines[0])
    need(isinstance(cleanup_ref, dict) and isinstance(cleanup_ref.get("path"), str),
         "Ref Session.stop_services invalide")
    cleanup_path = Path(cleanup_ref["path"])
    need(cleanup_path.parent == root / "ledger"
         and re.fullmatch(r"session-stop-services-[1-9][0-9]*\.json", cleanup_path.name) is not None,
         "Reçu Session.stop_services hors ledger exact")
    raw = read(cleanup_ref, (root,))
    same(raw, actor=actor, round_id=round_id, head=head)
    campaign = root.name.removeprefix("therese-c17-direct-round-")[0].upper()
    need(raw.get("schema") == "c17-runtime78-owned-service-stop-v1"
         and raw.get("cycle") == 17 and raw.get("kind") == "actual_in_process_owned_controller_phase"
         and raw.get("call") == "Session.stop_services"
         and raw.get("qa_root") == str(root) and raw.get("round_name") == campaign
         and raw.get("execution_scope") == "runtime78_exact_round",
         "Reçu G1 stop hors vraie ronde A/B")
    for key in ("admission", "binding"):
        real = [read(item["real_session_receipt"], (root,)) for item in (start, stage)]
        need(key in real[0] and real[0][key] == real[1].get(key) == raw.get(key) == authority[key],
             "Admission/binding stop non liés aux stages")
        pinned(raw[key], (QUALIFICATION_ROOT,))
    cleanup = raw.get("cleanup")
    need(raw.get("services_stopped") is True and raw.get("clean") is True
         and raw.get("cleanup_error") is None and raw.get("log_stability_tainted") is False
         and raw.get("log_stability_proved") is True and raw.get("cleanup_deadline_met") is True
         and isinstance(cleanup, dict) and cleanup.get("clean") is True
         and cleanup.get("termination_of_exact_targets_proved") is True
         and cleanup.get("remaining_attributed") == cleanup.get("ambiguities") == cleanup.get("errors") == []
         and raw.get("launched_services") == ["backend", "vite"]
         and raw.get("unlaunched_handles") == []
         and raw.get("remaining_handles") == [] and raw.get("cleanup_taint") == []
         and raw.get("attribution_errors") == [],
         "Services G1 non clos propres/stables")
    service_refs = raw.get("service_receipts")
    need(isinstance(service_refs, list) and len(service_refs) == 2,
         "Deux reçus terminaux de services absents")
    for name, service_ref in zip(("backend", "vite"), service_refs):
        service = read(service_ref, (root,), exact=root / "ledger" / name / "receipt.json")
        same(service, actor=actor, round_id=round_id, head=head)
        start_ref = service.get("service_start_receipt")
        need(isinstance(start_ref, dict), "Reçu de démarrage service absent : " + name)
        service_start = read(start_ref, (root,), exact=root / "ledger" / name / "service-start.json")
        same(service_start, actor=actor, round_id=round_id, head=head)
        need(service.get("schema") == "c17-runtime78-owned-stage-receipt-v1"
             and service.get("stage_id") == service_start.get("stage_id") == name
             and service.get("role") == "persistent-" + name
             and service.get("qa_root") == service_start.get("qa_root") == str(root)
             and service.get("root_identity") == service_start.get("root_identity")
             and service.get("owner") == service_start.get("owner")
             and service.get("admission") == authority["admission"]
             and service.get("binding") == authority["binding"]
             and service.get("termination_proved") is True
             and service.get("output_archived") is True
             and service.get("raw_stable") is True
             and service.get("log_stability_proved") is True
             and service.get("cleanup_deadline_met") is True
             and service.get("cleanup_taint") == []
             and service.get("instrument_error") is None,
             "Reçu terminal service rouge/étranger : " + name)
    elapsed = raw.get("cleanup_elapsed_seconds")
    need(type(elapsed) in (int, float) and math.isfinite(elapsed) and 0 <= elapsed <= 8,
         "Deadline physique stop_services dépassée/absente")
    need(raw.get("ports_absence_proved") is True and raw.get("ports_absent") == [17593, 5173],
         "Ports QA non prouvés absents")
    ports_path = Path(raw["ports_absence_receipt"]["path"])
    need(ports_path.parent == root / "ledger"
         and re.fullmatch(r"ports-absence-[1-9][0-9]*\.json", ports_path.name) is not None,
         "Reçu ports-absence hors ledger exact")
    ports = read(raw["ports_absence_receipt"], (root,))
    same(ports, actor=actor, round_id=round_id, head=head)
    need(ports.get("schema") == "c17-runtime78-ports-absence-v1"
         and ports.get("phase") == "services-stop" and ports.get("qa_root") == str(root)
         and ports.get("ports_absence_proved") is True and ports.get("ports_absent") == [17593, 5173]
         and ports.get("residuals") == ports.get("ambiguities") == ports.get("attribution_errors") == []
         and isinstance(ports.get("scans"), list) and len(ports["scans"]) == 2,
         "Reçu ports-absence rouge/incomplet")
    observations = []
    for pass_index, scan in enumerate(ports["scans"]):
        need(isinstance(scan, list) and len(scan) == 2
             and [item.get("port") for item in scan] == [17593, 5173],
             "Scan ports QA absent/extra/désordonné : " + str(pass_index))
        for item in scan:
            port = item["port"]
            diagnostic = item.get("identity")
            need(isinstance(diagnostic, dict) and all(type(diagnostic.get(key)) is int for key in
                 ("pid", "ppid", "pgid", "uid", "start_sec", "start_usec"))
                 and diagnostic["pid"] > 0 and diagnostic["start_sec"] > 0
                 and diagnostic["ppid"] == identity["pid"]
                 and diagnostic["uid"] == identity["uid"]
                 and diagnostic["pgid"] == diagnostic["pid"]
                 and diagnostic.get("parent_birth") == [identity["pid"], identity["start_sec"], identity["start_usec"]]
                 and diagnostic.get("role") == "diagnostic-lsof"
                 and diagnostic.get("attribution") == "popen_child_before_workload",
                 "Birth diagnostic lsof non attribuée")
            need(item.get("argv") == ["/usr/sbin/lsof", "-nP", f"-iTCP:{port}",
                                        "-sTCP:LISTEN", "-F", "p"]
                 and item.get("launch") == [str(qa_source / ".venv-conforme/bin/python"),
                                            "-I", "-B",
                                            str(Path(authority["successor_data"]["session"]["module"]["path"]).parent
                                                / "lsof_gate.py"), str(port)]
                 and item.get("returncode") == 1 and item.get("stdout") == ""
                 and item.get("stderr") == "" and item.get("pids") == []
                 and item.get("cleanup") is None
                 and type(item.get("elapsed_seconds")) in (int, float)
                 and math.isfinite(item["elapsed_seconds"])
                 and item["elapsed_seconds"] >= 0,
                 "lsof non concluante : port occupé/erreur/commande différente")
            captured, observed = iso(diagnostic["captured_at"]), iso(item["observed_at"])
            need(iso(stop["started_at"]) <= captured <= observed <= iso(stop["completed_at"]),
                 "Diagnostic lsof hors arrêt")
            observations.append(observed)
    need(observations == sorted(observations) and observations[-1] <= iso(ports["observed_at"]),
         "Ordre des scans lsof non physique")
    need(iso(stop["started_at"]) <= iso(ports["observed_at"]) <= iso(stop["completed_at"]),
         "Ports absents hors fenêtre de stop réelle")


def verify_authority(request: dict, root: Path, *, actor: str,
                     round_id: str, head: str, qa_source: Path) -> dict:
    refs = request.get("g1_authority")
    need(isinstance(refs, dict) and set(refs) == {"successor", "admission", "binding"},
         "Trois refs autorité G1 absentes")
    successor, admission, binding = (read(refs[key], (QUALIFICATION_ROOT,))
                                     for key in ("successor", "admission", "binding"))
    campaign = root.name.removeprefix("therese-c17-direct-round-")[0].upper()
    for value in (successor, admission, binding):
        same(value, actor=actor, round_id=round_id, head=head)
        need(value.get("qa_root") == str(root) and value.get("round_name") == campaign,
             "Autorité G1 autre QA/campagne")
    need(successor.get("schema") == "c17-runtime78-successor-admission-v1"
         and successor.get("provided_by") == "/root" and successor.get("phase") == "runtime"
         and admission.get("schema") == "c17-runtime78-session-root-go-v1"
         and binding.get("schema") == "c17-runtime78-session-binding-v1"
         and successor.get("session_decision") == refs["admission"]
         and successor.get("session_binding") == refs["binding"]
         and admission.get("binding") == refs["binding"],
         "Chaîne successor/admission/binding G1 rompue")
    return {"admission": refs["admission"], "binding": refs["binding"],
            "admission_data": admission, "binding_data": binding,
            "successor": refs["successor"], "successor_data": successor,
            "actor": actor, "round_id": round_id, "head": head,
            "round_name": campaign, "qa_source": qa_source}


def verify_source_checkout(source_ref: dict, root: Path, qa_source: Path,
                           config: dict, *, actor: str, round_id: str, head: str) -> None:
    checkout = read(source_ref, (root,), exact=root / "authorization/source-checkout.json")
    same(checkout, actor=actor, round_id=round_id, head=head)
    campaign = root.name.removeprefix("therese-c17-direct-round-")[0].upper()
    need(checkout.get("schema") == "c17-direct-round-source-checkout-v1"
         and checkout.get("head") == checkout.get("git_head") == head
         and checkout.get("qa_root") == str(root) and checkout.get("round_name") == campaign
         and checkout.get("product_source_root") == str(qa_source)
         and checkout.get("git_tree_verified") is True,
         "Attestation checkout A/B physique absente")
    head_file = pinned(checkout["git_head_ref"], (qa_source,), exact=qa_source / ".git/HEAD")
    need(head_file.read_text(encoding="utf-8").strip() == head,
         "HEAD Git QA physique différent")
    manifest = read(checkout["source_manifest_ref"], (root,),
                    exact=root / "authorization/source-files.json")
    need(manifest.get("schema") == "c17-root-fresh-git-source-manifest-v1"
         and manifest.get("status") == "PASS" and manifest.get("head") == head
         and manifest.get("product_source_root") == str(qa_source)
         and manifest.get("git_tree_verified") is True
         and isinstance(manifest.get("files"), list),
         "Manifeste Git QA absent/étranger")
    rows = {row["path"]: row for row in manifest["files"]}
    need(len(rows) == len(manifest["files"]), "Manifeste Git QA avec doublons")
    need(config.get("python") == str(qa_source / ".venv-conforme/bin/python")
         and config.get("frontend_qa") == str(qa_source / "src/frontend")
         and config.get("frontend_dependencies") == str(qa_source / "src/frontend/node_modules")
         and config.get("playwright_dependencies") == str(qa_source / "node_modules"),
         "Source QA différente des chemins préparés")
    need(isinstance(config.get("product_sources"), dict) and bool(config["product_sources"])
         and isinstance(config.get("frontend_qa_sources"), dict),
         "Sources préparées non listées")
    for name, digest in config["product_sources"].items():
        path = qa_source / name
        row = rows.get(str(path))
        need(row is not None and row.get("sha256") == digest,
             "Source produit absente du checkout QA : " + name)
        pinned(row, (qa_source,), exact=path)
        content = path.read_bytes()
        blob = hashlib.sha1(b"blob " + str(len(content)).encode() + b"\0" + content).hexdigest()
        need(row.get("git_blob") == blob, "Blob Git produit non concordant : " + name)
    for name, digest in config["frontend_qa_sources"].items():
        path = qa_source / name
        row = rows.get(str(path))
        need(row is not None and row.get("sha256") == digest,
             "Source frontend absente du checkout QA : " + name)
        pinned(row, (qa_source,), exact=path)
        content = path.read_bytes()
        blob = hashlib.sha1(b"blob " + str(len(content)).encode() + b"\0" + content).hexdigest()
        need(row.get("git_blob") == blob, "Blob Git frontend non concordant : " + name)


def prepare(request_ref: dict, *, now: datetime | None = None) -> tuple[Path, list[dict], dict]:
    request_path = Path(request_ref["path"])
    root = round_root(request_path.parents[1])
    request = read(request_ref, (root,),
                   exact=root / "authorization/calibration-builder-request.json")
    need(request.get("schema") == "c17-calibration-builder-request-v2"
         and request.get("root") == str(root), "Demande/QA différente")
    actor, round_id, head = request["actor"], request["round_id"], request["head"]
    need(actor in ACTORS and round_id == root.name.removeprefix("therese-")
         and re.fullmatch(r"c17-direct-round-[ab]-[0-9a-f]{12}", round_id) is not None
         and HEX40.fullmatch(head) is not None,
         "Identité A/B absente")
    source_refs = request["round_sources"]
    need(set(source_refs) == {"configuration", "running_manifest", "stopped_manifest", "source_checkout"},
         "Sources de ronde non épinglées")
    config = read(source_refs["configuration"], (root,), exact=root / "prepared-config.json")
    same(config, actor=actor, round_id=round_id, head=head)
    campaign = root.name.removeprefix("therese-c17-direct-round-")[0].upper()
    need(config["root"] == str(root) and config.get("campaign") == campaign
         and config.get("cycle") == 17, "Config autre racine/campagne")
    qa_source = Path(request["qa_source"])
    need(qa_source.is_absolute() and qa_source.resolve(strict=True) == qa_source
         and qa_source.is_dir() and qa_source.is_relative_to(Path("/private/tmp")),
         "Source QA non canonique")
    verify_source_checkout(source_refs["source_checkout"], root, qa_source, config,
                           actor=actor, round_id=round_id, head=head)
    authority = verify_authority(request, root, actor=actor, round_id=round_id,
                                 head=head, qa_source=qa_source)
    refs = request["executions"]
    need(set(refs) == {"start", "calibrate", "stop"}, "Trois exécutions exactes requises")
    start = _check_execution(read(refs["start"], (root,),
        exact=root / "ledger/start-runtime/execution.json"), "readiness", root,
        actor=actor, round_id=round_id, head=head, authority=authority)
    stage = _check_execution(read(refs["calibrate"], (root,),
        exact=root / "ledger/calibrate/execution.json"), "calibrate", root,
        actor=actor, round_id=round_id, head=head, authority=authority)
    stop = _check_execution(read(refs["stop"], (root,),
        exact=root / "ledger/stop-runtime/execution.json"), "stop-runtime", root,
        actor=actor, round_id=round_id, head=head, authority=authority)
    verify_owned_service_stop(stop, start, stage, root,
                              actor=actor, round_id=round_id, head=head,
                              authority=authority, qa_source=qa_source)
    started, observed, stopped = iso(start["completed_at"]), iso(stage["completed_at"]), iso(stop["started_at"])
    need(started <= iso(stage["started_at"]) <= observed <= stopped
         <= iso(stop["completed_at"]), "Calibration hors fenêtre start/stop")
    clock = now or datetime.now(UTC)
    need(clock.tzinfo is not None, "Horloge de construction sans fuseau")
    current = clock.astimezone(UTC)
    need(iso(stop["completed_at"]) <= current < observed + TTL,
         "Arrêt futur ou calibration expirée avant construction")
    running = read(source_refs["running_manifest"], (root,),
                   exact=root / "runtime/pile-reprise-running-preserved.json")
    stopped_stack = read(source_refs["stopped_manifest"], (root,),
                         exact=root / "runtime/pile-reprise.json")
    need(running["status"] == "running" and stopped_stack["status"] == "stopped"
         and running["head_at_start"] == stopped_stack["head_at_start"] == head
         and running["data_dir"] == stopped_stack["data_dir"], "Manifestes running/stopped non concordants")
    verify_private_profile(root, running, stopped_stack)
    raw_refs = request["raw_results"]
    need(set(raw_refs) == set(RAW), "Cinq preuves brutes exactes requises")
    raws = {name: read(raw_refs[name], (root,), exact=root / relative)
            for name, relative in RAW.items()}
    for name, raw in raws.items():
        need(raw.get("status") == "passed" and raw.get("head") == head,
             "Brut rouge/autre HEAD : " + name)
    summary, test, logs, browser, screen = (raws[name] for name in RAW)
    need(summary.get("cycle") == 17 and summary.get("repo") == str(qa_source),
         "Résumé autre checkout")
    results = summary.get("results")
    names = ("test_runner", "logs", "runtime_ui-visual_capture-network_capture", "screen_coverage")
    need(isinstance(results, list) and [row["instruments"] for row in results] == list(names),
         "Familles de calibration manquantes")
    for row in results:
        expected_log = root / "runtime/calibration/all-rpc" / (row["instruments"] + ".log")
        need(row["exit_code"] == 0 and row["log"] == str(expected_log), "Enfant calibration rouge")
        regular(expected_log, (root,))
    need(test.get("cycle") == logs.get("cycle") == browser.get("cycle") == screen.get("cycle") == 17,
         "Brut autre cycle")
    need(test.get("repo") == str(qa_source), "Runner autre checkout")
    verify_test_runner(test, root)
    verify_logs(logs, root, running["temporary_root"], stage)
    verify_browser(browser, root, qa_source, running["data_dir"])
    screen_source = verify_screen(screen, root, qa_source, running["data_dir"])
    pytest_log = regular(root / "runtime/calibration/test-runner-rpc/pytest-negative.log", (root,))
    version = re.search(r"Python ([^,]+), pytest-([^,\s]+)", pytest_log.read_text())
    need(version is not None, "Versions Python/pytest non observées")
    vitest = regular(qa_source / "src/frontend/node_modules/vitest/package.json", (qa_source,))
    playwright = regular(qa_source / "node_modules/playwright/package.json", (qa_source,))
    logging_source = regular(qa_source / "src/backend/app/core/logging_config.py", (qa_source,))
    vitest_version = json.loads(vitest.read_text())["version"]
    need(json.loads(playwright.read_text())["version"] == browser["playwrightVersion"],
         "Playwright différent du brut")
    browser_versions = "Chrome " + browser["chromiumVersion"] + "; Playwright " + browser["playwrightVersion"] + "; Node " + browser["nodeVersion"]
    tool_versions = {
        "test_runner": f"Python {version[1]}; pytest {version[2]}; Vitest {vitest_version}",
        "logs": f"Python {version[1]}; app.core.logging_config SHA256 {sha(logging_source)}",
        "runtime_ui": browser_versions, "visual_capture": browser_versions,
        "network_capture": browser_versions,
        "screen_coverage": f"Node {browser['nodeVersion']}; screen helper SHA256 {screen['source_sha256']}",
    }
    need(all(tool_versions.values()), "Version d'outil absente")
    sources = {
        "test_runner": {"pytest_log": ref(pytest_log), "vitest_manifest_current_read": ref(vitest)},
        "logs": {"logging_implementation": ref(logging_source)},
        "runtime_ui": {"versions_from_raw": raw_refs["browser"], "playwright_manifest": ref(playwright)},
        "visual_capture": {"versions_from_raw": raw_refs["browser"], "playwright_manifest": ref(playwright)},
        "network_capture": {"versions_from_raw": raw_refs["browser"], "playwright_manifest": ref(playwright)},
        "screen_coverage": {"helper": ref(screen_source)},
    }
    controls = {
        "test_runner": {"negative": {key: row for key, row in test["controls"].items() if key.endswith("negative")},
                        "positive": {key: row for key, row in test["controls"].items() if key.endswith("positive")}},
        "logs": {"negative": logs["negative_control"], "positive": logs["positive_control"]},
        "runtime_ui": browser["runtime_ui"],
        "visual_capture": browser["visual_capture"],
        "network_capture": browser["network_capture"],
        "screen_coverage": {key: screen[key] for key in ("negative", "positive_visual", "positive_network", "restored")},
    }
    evidence = {"test_runner": raw_refs["test_runner"], "logs": raw_refs["logs"],
                "runtime_ui": raw_refs["browser"], "visual_capture": raw_refs["browser"],
                "network_capture": raw_refs["browser"], "screen_coverage": raw_refs["screen_coverage"]}
    environment = {"system": "darwin", "repo": str(qa_source), "head": head,
                   "runtime_revision": REVISION, "execution_profile": running["temporary_root"]}
    observed_at = stage["completed_at"]  # octets de l'horodatage réel, pas normalisation dérivée
    expires_at = (observed + TTL).isoformat()
    recorded_at = current.isoformat()
    records = []
    for name in INSTRUMENTS:
        records.append({"cycle": 17, "actor": actor, "round_id": round_id, "head": head,
            "runtime_revision": REVISION, "instrument": name, "status": "pass",
            "positive_control": "pass", "negative_control": "pass", "tool_version": tool_versions[name],
            "environment": environment | {"observed_browser_environment":
                browser["environment"] if name in ("runtime_ui", "visual_capture", "network_capture", "screen_coverage") else None},
            "evidence": evidence[name], "observations": controls[name],
            "calibration_execution": refs["calibrate"],
            "observed_during": {"started_at": stage["started_at"], "completed_at": stage["completed_at"]},
            "recorded_at": recorded_at, "observed_at": observed_at, "expires_at": expires_at,
            "validity_policy": {"ttl_hours": 12, "basis": "actual closed calibration completion",
                "invalidated_by": "Relevant source, tool/dependency, browser configuration or runtime environment change"},
            "version_provenance": sources[name], "raw_results_not_relabelled": True,
            "new_calibration_execution": False,
            "family_shared_explicitly": raw_refs["browser"]["path"] if name in
                ("runtime_ui", "visual_capture", "network_capture") else None})
    index = {"schema": "c17-calibration-records-v3-index-v1", "cycle": 17,
             "actor": actor, "round_id": round_id, "head": head,
             "runtime_revision": REVISION, "calibrations": [], "count": 6,
             "request": request_ref, "round_sources": source_refs,
             "g1_authority": request["g1_authority"],
             "actual_start": refs["start"], "actual_stop": refs["stop"]}
    return root, records, index


def write_new(path: Path, value: dict) -> None:
    data = (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode()
    fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, "wb") as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())


def build(request_ref: dict, *, now: datetime | None = None) -> dict:
    root, records, index = prepare(request_ref, now=now)
    out = root / "calibration-records-v3"
    out.mkdir(mode=0o700, exist_ok=False)
    for row in records:
        target = out / (row["instrument"] + ".json")
        write_new(target, row)
        index["calibrations"].append(ref(target))
    write_new(out / "index.json", index)
    return ref(out / "index.json")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--request", required=True, type=Path)
    parser.add_argument("--request-sha256", required=True)
    args = parser.parse_args()
    result = build({"path": str(args.request), "sha256": args.request_sha256})
    print(json.dumps({"status": "six_records_built_from_closed_round_not_FULL",
                      "index": result}, ensure_ascii=False))


if __name__ == "__main__":
    main()
