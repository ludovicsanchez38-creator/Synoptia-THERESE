"""Pure/static checks only: never imports G1, opens a socket, or runs Chrome."""
from __future__ import annotations

import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import unittest


BASE = Path(__file__).resolve().parents[1]
ROOT = Path("/private/tmp/therese-c17-direct-round-a-0123456789ab")


def table():
    path = BASE / "g1/ab_auxiliary_table.py"
    spec = importlib.util.spec_from_file_location("ab_auxiliary_table_pure", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def function_source(path: Path, name: str) -> str:
    text = path.read_text()
    tree = ast.parse(text)
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == name:
            return ast.get_source_segment(text, node)
    raise AssertionError(name)


def pure_g1_function(name: str, namespace: dict):
    """Compile just one function AST, never import runtime_session/G1."""
    tree = ast.parse((BASE / "g1/runtime_session.py").read_text())
    node = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == name)
    module = ast.Module(body=[node], type_ignores=[])
    ast.fix_missing_locations(module)
    scope = {"__builtins__": __builtins__, "Path": Path, "json": json,
             "require": lambda truth, message: None if truth else (_ for _ in ()).throw(ValueError(message)),
             "ab_aux": table(), **namespace}
    exec(compile(module, "<pure-extracted-G1-function>", "exec"), scope)
    return scope[name]


class AuxiliaryTable(unittest.TestCase):
    def test_five_plus_nine_exact_and_unique(self):
        module = table()
        self.assertEqual(len(module.RPC_JOBS), 5)
        self.assertEqual(len(module.DIRECT_SITES), 9)
        self.assertEqual(len(module.JOBS), len(set(module.JOBS)))
        self.assertEqual(len(module.JOBS), 14)
        self.assertEqual(len(module.NAMES), 14)
        self.assertEqual(module.JOBS[0], "rpc-all-runtime_ui-visual_capture-network_capture")
        self.assertEqual(module.JOBS[-1], "coverage")

    def test_root_and_campaign_cannot_be_relabeled(self):
        module = table()
        self.assertTrue(module.scope(ROOT, "A"))
        self.assertTrue(module.scope(Path(str(ROOT).replace("-a-", "-b-")), "B"))
        for path, campaign in ((ROOT, "B"), (ROOT.parent / "therese-c17-wrapper-canary-0123456789ab", "A"),
                               (Path("/tmp") / ROOT.name, "A"),
                               (ROOT.parent / "therese-c17-direct-round-a-0123456789ag", "A")):
            self.assertFalse(module.scope(path, campaign))

    def test_rows_profiles_sinks_and_options_are_distinct(self):
        module = table()
        rows = [module.expected_row(ROOT, job) for job in module.JOBS]
        for key in ("name", "profile", "stdout", "stderr", "start_path", "stop_path"):
            self.assertEqual(len({row[key] for row in rows}), 14)
        self.assertEqual({row["logical_parent"] for row in rows[:5]}, {"calibrate"})
        self.assertEqual([row["logical_parent"] for row in rows[5:]], [row["job"] for row in rows[5:]])
        self.assertEqual(rows[0]["original_options"],
                         {"headless": False, "channel": "chrome", "chromiumSandbox": True})
        self.assertEqual(rows[-1]["original_options"]["args"], module.DISABLED_ARGS)
        self.assertEqual({row["port"] for row in rows}, {17594})
        with self.assertRaises(ValueError):
            module.expected_row(ROOT, "invented-job")

    def test_metadata_closed_by_site_not_prefix(self):
        module = table()
        self.assertEqual(module.required_metadata(module.RPC_JOBS[0]),
                         {"C17_AUX_CONTEXT_REF", "C17_AUX_GIT_SNAPSHOT_REF"})
        for job in module.RPC_JOBS[1:]:
            self.assertEqual(module.required_metadata(job), {"C17_AUX_CONTEXT_REF"})
        for job, _ in module.DIRECT_SITES:
            self.assertEqual(module.required_metadata(job),
                             {"C17_AUX_CONTEXT_REF", "C17_AUX_GIT_SNAPSHOT_REF"})
        self.assertEqual(module.required_metadata("rpc-all-logs"),
                         {"C17_AUX_GIT_SNAPSHOT_REF", "C17_AUX_LOGS_RUN"})
        self.assertEqual(module.required_metadata("rpc-random"), set())


class StaticLifecycle(unittest.TestCase):
    def test_g1_admission_and_caps_remain_closed(self):
        source = (BASE / "g1/runtime_session.py").read_text()
        tree = ast.parse(source)
        assignments = {target.id: node.value for node in tree.body if isinstance(node, ast.Assign)
                       for target in node.targets if isinstance(target, ast.Name)}
        assignments.update({node.target.id: node.value for node in tree.body
                            if isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name)})
        for key in ("RUNTIME_ENABLED", "OS_STARTUP_QUALIFIED", "AB_CHROME_PROFILE_NATIVE_QUALIFIED"):
            self.assertIs(assignments[key].value, False)
        self.assertIsInstance(assignments["ADMISSION_TABLE"], ast.Dict)
        self.assertEqual(assignments["ADMISSION_TABLE"].keys, [])
        admission = function_source(BASE / "g1/runtime_session.py", "load_admission")
        self.assertIn("validate_ab_auxiliary_binding", admission)
        self.assertIn("AB_CHROME_PROFILE_NATIVE_QUALIFIED", admission)
        profile = (BASE / "g1/chrome.sb").read_bytes()
        module = table()
        self.assertEqual((hashlib.sha256(profile).hexdigest(), len(profile)),
                         (module.CHROME_CANDIDATE_SHA256, module.CHROME_CANDIDATE_BYTES))

    def test_start_before_leaf_close_before_ack_and_three_ports(self):
        path = BASE / "g1/runtime_session.py"
        start = function_source(path, "start")
        finish = function_source(path, "finish")
        self.assertLess(start.index("self.start_auxiliary_for_job(name)"), start.index("wrapped = sandbox"))
        self.assertIn("ab_aux.JOBS", start)
        self.assertIn("Script Node direct A/B autre", start)
        self.assertIn("self.close_auxiliary_for_job(job", finish)
        self.assertIn("ab_aux.JOBS", finish)
        self.assertIn("(*PORTS, AUXILIARY_PORT)", function_source(path, "prove_ports_absent"))
        self.assertIn('"A", "B"', function_source(path, "stop_services"))
        self.assertIn('"A", "B"', function_source(path, "stop"))

    def test_adapter_and_protocol_keep_five_rpc_only(self):
        adapter = (BASE / "transport/session_rpc_adapter.py").read_text()
        protocol = (BASE / "transport/rpc_protocol.py").read_text()
        self.assertIn("slot['name'] in self.protocol.CHROME_JOBS", adapter)
        self.assertIn("self.session.checked_auxiliary_terminal", adapter)
        self.assertIn("self.protocol.validate_auxiliary_terminal", adapter)
        self.assertIn("ab_scope(root, context)", protocol)
        self.assertIn("row['id'] in CHROME_JOBS", protocol)

    def test_node_table_and_context_are_explicit(self):
        source = (BASE / "auxiliary/aux_node.mjs").read_text()
        self.assertIn("export const AB_DIRECT_JOBS", source)
        self.assertIn("export const AB_JOBS", source)
        self.assertIn("c17-ab-auxiliary-context-v1", source)
        self.assertIn("c17-direct-round-source-checkout-v1", source)
        self.assertIn("gitHead(context.git_snapshot_ref", source)
        self.assertIn("process.argv.includes", source)
        self.assertIn("await listener(17594)", source)


class MetadataFunction(unittest.TestCase):
    def setUp(self):
        self.root = ROOT
        self.source = Path("/private/tmp/therese-c17-source-new/source")
        self.head = "a" * 40
        self.context_ref = {"path": str(ROOT / "auxiliary/aux-chrome-recipe-general/context.json"),
                            "sha256": "a" * 64, "bytes": 100}
        self.git_ref = {"path": str(ROOT / "authorization/git-snapshot.json"),
                        "sha256": "b" * 64, "bytes": 100}
        self.checkout_ref = {"path": str(ROOT / "authorization/source-checkout.json"),
                             "sha256": "c" * 64, "bytes": 100}
        self.binding = {"auxiliary_context_refs": {"recipe-general": self.context_ref},
                        "git_snapshot_ref": self.git_ref, "source_checkout_ref": self.checkout_ref}
        self.context = {"schema": "c17-ab-auxiliary-context-v1", "scope": "runtime78_exact_round",
                        "root": str(ROOT), "stage": "recipe-general", "head": self.head,
                        "product_source_root": str(self.source), "source_checkout_ref": self.checkout_ref}
        self.snapshot = {"schema": "c17-wrapper-physical-git-snapshot-v1",
                         "head": self.head, "source_root": str(self.source)}
        documents = {self.context_ref["path"]: self.context, self.git_ref["path"]: self.snapshot}
        self.check = pure_g1_function("validate_ab_child_metadata", {
            "checked_json_ref": lambda ref, root: documents[ref["path"]]})

    def test_direct_metadata_requires_both_exact_refs(self):
        env = {"C17_AUX_CONTEXT_REF": json.dumps(self.context_ref),
               "C17_AUX_GIT_SNAPSHOT_REF": json.dumps(self.git_ref)}
        self.check(self.root, self.binding, env, "recipe-general", self.head, self.source)
        with self.assertRaises(ValueError):
            self.check(self.root, self.binding, {"C17_AUX_CONTEXT_REF": env["C17_AUX_CONTEXT_REF"]},
                       "recipe-general", self.head, self.source)
        with self.assertRaises(ValueError):
            self.check(self.root, self.binding, env | {"C17_AUX_UNBOUND": "x"},
                       "recipe-general", self.head, self.source)

    def test_wrong_context_or_git_ref_cannot_pass(self):
        env = {"C17_AUX_CONTEXT_REF": json.dumps(self.context_ref),
               "C17_AUX_GIT_SNAPSHOT_REF": json.dumps(self.git_ref)}
        with self.assertRaises(ValueError):
            self.check(self.root, self.binding, env, "recipe-general", "b" * 40, self.source)
        with self.assertRaises(ValueError):
            self.check(self.root, self.binding, env | {"C17_AUX_GIT_SNAPSHOT_REF": json.dumps(self.context_ref)},
                       "recipe-general", self.head, self.source)
        with self.assertRaises(ValueError):
            self.check(self.root, self.binding, env, "recipe-general", self.head,
                       Path("/private/tmp/other-source/source"))

    def test_logs_path_is_not_freely_selected(self):
        env = {"C17_AUX_GIT_SNAPSHOT_REF": json.dumps(self.git_ref),
               "C17_AUX_LOGS_RUN": str(self.root / "runtime/calibration/logs-rpc"),
               "PYTHONPATH": f"{self.root / 'auxiliary-ports/runtime'}:{self.source}:{self.source / 'src/backend'}"}
        self.check(self.root, self.binding, env, "rpc-all-logs", self.head, self.source)
        with self.assertRaises(ValueError):
            self.check(self.root, self.binding, env | {"C17_AUX_LOGS_RUN": str(self.root / "other")},
                       "rpc-all-logs", self.head, self.source)
        with self.assertRaises(ValueError):
            self.check(self.root, self.binding, env | {"PYTHONPATH": str(self.source)},
                       "rpc-all-logs", self.head, self.source)


class ProtocolJoin(unittest.TestCase):
    """Pure join tests with synthetic documents; not physical file/OS proof."""

    def setUp(self):
        spec = importlib.util.spec_from_file_location("rpc_protocol_pure", BASE / "transport/rpc_protocol.py")
        self.protocol = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.protocol)
        self.job = "rpc-screen-negative"
        self.name = "aux-chrome-" + self.job
        self.identity = {"pid": 123, "start_sec": 100, "start_usec": 1,
                         "ppid": 22, "uid": 501, "pgid": 123}
        self.refs = {name: {"path": str(ROOT / (name + ".json")), "sha256": name * 64, "bytes": 10}
                     for name in ("closure", "start", "stop", "leaf", "raw", "gate", "release", "services",
                                  "stdout", "stderr")}
        self.context = {"actor": "/root", "round_id": ROOT.name.removeprefix("therese-"),
                        "head": "a" * 40, "root": str(ROOT)}
        common = {"actor": self.context["actor"], "round_id": self.context["round_id"],
                  "head": self.context["head"], "root_identity": self.identity,
                  "binding_sha256": "b" * 64}
        self.documents = {
            "leaf": {"stage_id": self.job, "exit_code": 1},
            "closure": common | {"schema": "c17-g1-rpc-auxiliary-closure-v1",
                "scope": "runtime78_exact_round", "job": self.job,
                "leaf_receipt_ref": self.refs["leaf"], "start_ref": self.refs["start"],
                "stop_ref": self.refs["stop"], "termination_proved": True,
                "output_archived": True, "cleanup_clean": True, "cleanup_deadline_met": True,
                "remaining_attributed": [], "ambiguities": [], "errors": [],
                "cleanup_elapsed_seconds": 0.2, "port_absent": 17594,
                "log_stability_proved": True, "tainted": False},
            "start": common | {"schema": "c17-g1-auxiliary-start-v1",
                "scope": "runtime78_exact_round", "name": self.name,
                "role": "auxiliary-" + self.name, "stage": self.job, "released": True,
                "gate_ref": self.refs["gate"], "release_ref": self.refs["release"],
                "gated_command": ["chrome"]},
            "stop": common | {"schema": "c17-g1-auxiliary-stop-v1",
                "scope": "runtime78_exact_round", "name": self.name,
                "role": "auxiliary-" + self.name, "stage": self.job,
                "receipt_refs": [self.refs["start"], self.refs["raw"], self.refs["leaf"]],
                "leaf_exit_code": 1, "controller_signals_attributed": True,
                "port_absence_scans": [{"pids": []}, {"pids": []}],
                "auxiliary_services_ref": self.refs["services"], "raw_stable": True,
                "taint": False},
            "raw": {"root_identity": self.identity, "stage_id": self.name,
                "termination_proved": True, "output_archived": True,
                "output_archive_errors": [], "cleanup_deadline_met": True,
                "cleanup_elapsed_seconds": 0.2, "cleanup": {"clean": True,
                "remaining_attributed": [], "ambiguities": [], "errors": []},
                "stdout": self.refs["stdout"], "stderr": self.refs["stderr"]},
            "gate": {"pid": 123, "ppid": 22, "uid": 501, "pgid": 123,
                     "command": ["chrome"]},
            "release": {"gate": {"pid": 123, "ppid": 22, "uid": 501, "pgid": 123,
                                   "command": ["chrome"]}, "identity": self.identity},
            "services": {},
        }
        self.protocol.checked_json = lambda ref, root=None: self.documents[Path(ref["path"]).stem]
        self.protocol.read_reference = lambda ref, root=None: b"synthetic"

    def joined(self, *, normal=True):
        return self.protocol.validate_auxiliary_terminal(self.refs["closure"],
            {"id": self.job}, ROOT, self.context, self.refs["leaf"],
            normal=normal, binding_sha256="b" * 64)

    def test_ab_normal_nonzero_raw_exit_is_not_changed(self):
        self.assertEqual(self.joined()["leaf_receipt_ref"], self.refs["leaf"])
        self.assertEqual(self.documents["leaf"]["exit_code"], 1)

    def test_wrong_scope_or_missing_second_absence_fails(self):
        self.documents["closure"]["scope"] = "WRAPPER_CANARY"
        with self.assertRaises(self.protocol.RpcInstrumentError):
            self.joined()
        self.documents["closure"]["scope"] = "runtime78_exact_round"
        self.documents["stop"]["port_absence_scans"] = [{"pids": []}]
        with self.assertRaises(self.protocol.RpcInstrumentError):
            self.joined()

    def test_wrong_cleanup_or_context_fails(self):
        self.documents["raw"]["cleanup_deadline_met"] = False
        with self.assertRaises(self.protocol.RpcInstrumentError):
            self.joined()
        self.documents["raw"]["cleanup_deadline_met"] = True
        self.documents["start"]["head"] = "c" * 40
        with self.assertRaises(self.protocol.RpcInstrumentError):
            self.joined()


if __name__ == "__main__":
    unittest.main()
