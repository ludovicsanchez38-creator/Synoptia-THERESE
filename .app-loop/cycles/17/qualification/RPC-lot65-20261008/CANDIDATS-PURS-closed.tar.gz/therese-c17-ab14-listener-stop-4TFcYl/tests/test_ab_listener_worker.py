"""Pure AST execution of the changed worker/owner guards; never import G1."""
from __future__ import annotations

import ast
import importlib.util
import json
import os
from pathlib import Path
import re
import secrets
import shutil
from types import SimpleNamespace
import unittest
from unittest.mock import patch


BASE = Path(__file__).resolve().parents[1]
SOURCE = BASE / "g1/runtime_session.py"
SPEC = importlib.util.spec_from_file_location("ab_auxiliary_table_pure", BASE / "g1/ab_auxiliary_table.py")
assert SPEC and SPEC.loader
ab_aux = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(ab_aux)
HEAD = "a" * 40


class Reached(Exception):
    pass


def extract(name: str, namespace: dict):
    tree = ast.parse(SOURCE.read_text())
    node = next(n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef) and n.name == name)
    module = ast.Module(body=[node], type_ignores=[])
    ast.fix_missing_locations(module)
    scope = {"Path": Path, "os": os, "re": re, "json": json, "ab_aux": ab_aux,
             "WRAPPER_PATTERN": re.compile(r"therese-c17-wrapper-canary-[a-z0-9_]{8,64}\Z"),
             "PORTS": (17593, 5173),
             "require": lambda ok, why: None if ok else (_ for _ in ()).throw(ValueError(why)),
             **namespace}
    exec(compile(module, "<pure G1 function>", "exec"), scope)
    return scope[name]


class PythonListenerWorker(unittest.TestCase):
    def setUp(self):
        self.root = Path("/private/tmp") / ("therese-c17-direct-round-a-" + secrets.token_hex(6))
        self.root.mkdir(mode=0o700)
        self.calls = []

    def tearDown(self):
        shutil.rmtree(self.root)

    def env(self, round_name="A", stage="start-runtime", root=None):
        root = root or self.root
        return {"C17_SESSION_HEAD": HEAD, "C17_SESSION_ROUND_NAME": round_name,
                "C17_SESSION_STAGE": stage, "C17_SESSION_ROOT": str(root),
                "C17_SESSION_EVENTS": str(root / "session-events"),
                "C17_SESSION_ACTOR": "/root", "C17_SESSION_ROUND_ID": root.name.removeprefix("therese-"),
                "C17_SESSION_DECISION_REF": json.dumps({"path": "/qa/Q/decision.json", "sha256": "b" * 64}),
                "C17_SESSION_BINDING_REF": json.dumps({"path": "/qa/Q/binding.json", "sha256": "c" * 64})}

    def function(self):
        def admission(root, **kw):
            self.calls.append((root, kw))
            raise Reached()
        return extract("request_owned_listener_observation", {"load_admission": admission})

    def test_a_b_exact_round_stage_and_head_reach_real_admission(self):
        function = self.function()
        for round_name, root in (("A", self.root),
                                 ("B", Path(str(self.root).replace("-a-", "-b-")))):
            if round_name == "B":
                root.mkdir(mode=0o700)
                self.addCleanup(shutil.rmtree, root)
            with patch.dict(os.environ, self.env(round_name, "density", root), clear=True):
                with self.assertRaises(Reached):
                    function(root, {}, 5173, root / "ownership-density.jsonl", stage_id="density", deadline=5)
            loaded_root, kwargs = self.calls[-1]
            self.assertEqual(loaded_root, root)
            self.assertEqual(kwargs["round_name"], round_name)
            self.assertEqual(kwargs["expected_head"], HEAD)
            self.assertEqual(kwargs["round_id"], root.name.removeprefix("therese-"))

    def test_mismatched_campaign_or_root_rejected_before_admission(self):
        function = self.function()
        with patch.dict(os.environ, self.env("B"), clear=True):
            with self.assertRaisesRegex(ValueError, "hors contexte QA exact"):
                function(self.root, {}, 17593, self.root / "ownership-traces.jsonl",
                         stage_id="start-runtime", deadline=5)
        self.assertEqual(self.calls, [])

    def test_listener_probe_not_promoted_to_a_b(self):
        function = self.function()
        with patch.dict(os.environ, self.env("A", "listener-probe"), clear=True):
            with self.assertRaisesRegex(ValueError, "hors contexte QA exact"):
                function(self.root, {}, 17593, self.root / "ownership-traces.jsonl",
                         stage_id="listener-probe", deadline=5)
        self.assertEqual(self.calls, [])

    def test_wrong_ttl_or_journal_rejected_before_admission(self):
        function = self.function()
        with patch.dict(os.environ, self.env(), clear=True):
            for deadline, journal in ((6, self.root / "ownership-traces.jsonl"),
                                      (5, self.root / "outside.jsonl")):
                with self.assertRaisesRegex(ValueError, "hors contexte QA exact"):
                    function(self.root, {}, 17593, journal, stage_id="start-runtime", deadline=deadline)
        self.assertEqual(self.calls, [])

    def test_owner_a_b_serves_only_readiness_density(self):
        (self.root / "session-events").mkdir()
        owner = type("Owner", (), {})()
        owner.round_name, owner.root = "A", self.root
        owner.events_seen = set()
        function = extract("_serve_python_listener_requests", {})
        self.assertIsNone(function(owner, {"name": "start-runtime"}))
        self.assertIsNone(function(owner, {"name": "density"}))
        self.assertIsNone(function(owner, {"name": "listener-probe"}))
        owner.round_name = "B"
        self.assertIsNone(function(owner, {"name": "density"}))  # A root never serves B.
        capture = next(node for node in ast.walk(ast.parse(SOURCE.read_text()))
                       if isinstance(node, ast.FunctionDef) and node.name == "_capture_listener")
        self.assertIn("self._listener_scope_guard()", ast.get_source_segment(SOURCE.read_text(), capture))

    def owner_request(self, *, override=None, worker_status=0):
        events = self.root / "session-events"
        events.mkdir(exist_ok=True)
        path = events / ("listener-request-start-runtime-" + "a" * 32 + ".json")
        path.write_text("{}\n")
        birth = {"pid": 51, "ppid": 10, "pgid": 51, "uid": os.getuid(),
                 "start_sec": 100, "start_usec": 1}
        request = {"schema": "c17-runtime78-owned-listener-request-v1",
                   "actor": "/root", "round_id": self.root.name.removeprefix("therese-"),
                   "head": HEAD, "qa_root": str(self.root), "stage": "start-runtime",
                   "decision_id": "decision-a", "binding_sha256": "b" * 64,
                   "deadline_seconds": 5, "request_monotonic": 99.0,
                   "port": 17593, "expected_root_identity": birth,
                   "journal": str(self.root / "ownership-traces.jsonl")}
        request.update(override or {})
        published = []
        owner = SimpleNamespace(round_name="A", root=self.root, events_seen=set(),
            actor="/root", round_id=self.root.name.removeprefix("therese-"), head=HEAD,
            decision={"decision_id": "decision-a"}, binding_ref={"sha256": "b" * 64},
            handles={"backend": {"root_identity": birth}},
            ledger=SimpleNamespace(info=lambda pid: {"status": worker_status},
                                   unchanged=lambda old, current: True),
            _listener_scope_guard=lambda: None,
            _capture_listener=lambda stage, port, journal: {
                "receipt": {"path": str(self.root / "ledger/listener.json"), "sha256": "c" * 64},
                "result": {"status": "owned"}})
        function = extract("_serve_python_listener_requests", {
            "time": SimpleNamespace(monotonic=lambda: 100.0),
            "read_published_json": lambda root, selected: request,
            "publish_json": lambda root, selected, body: published.append((selected, body)),
            "reference": lambda selected: {"path": str(selected), "sha256": "d" * 64},
            "PUBLICATION_PROTOCOL": "exclusive-pending-fsync-hardlink-v1",
        })
        return owner, function, published

    def test_owner_a_b_actor_round_birth_ttl_and_response_are_real_guards(self):
        owner, function, published = self.owner_request()
        function(owner, {"name": "start-runtime", "root_identity": {"pid": 12}})
        self.assertEqual(len(published), 1)
        self.assertEqual(published[0][1]["status"], "owned")
        self.assertEqual(published[0][1]["port"], 17593)
        self.assertEqual(len(owner.events_seen), 1)
        for changed in ({"actor": "/someone-else"}, {"deadline_seconds": 6},
                        {"request_monotonic": 94.0}, {"expected_root_identity": {"pid": 99}}):
            owner, function, published = self.owner_request(override=changed)
            with self.assertRaisesRegex(ValueError, "hors contexte, birth, fraîcheur"):
                function(owner, {"name": "start-runtime", "root_identity": {"pid": 12}})
            self.assertEqual(published, [])
        owner, function, published = self.owner_request(worker_status=5)
        with self.assertRaisesRegex(ValueError, "Worker RPC sans birth vivante"):
            function(owner, {"name": "start-runtime", "root_identity": {"pid": 12}})
        self.assertEqual(published, [])


if __name__ == "__main__":
    unittest.main()
