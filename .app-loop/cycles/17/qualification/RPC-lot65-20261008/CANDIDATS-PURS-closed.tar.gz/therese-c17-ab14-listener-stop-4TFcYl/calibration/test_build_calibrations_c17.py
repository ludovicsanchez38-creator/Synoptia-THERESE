"""Pure filesystem fixtures for the C17 six-calibration builder; no OS workload."""
from __future__ import annotations

from datetime import UTC, datetime, timedelta
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import secrets
import shutil
import unittest


SOURCE = Path(__file__).with_name("build-calibrations-c17.py")
SPEC = importlib.util.spec_from_file_location("c17_calibration_builder_pure", SOURCE)
assert SPEC and SPEC.loader
builder = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(builder)

ACTOR = "/root"
HEAD = "2d69e30c9c6dd18823ee6102271876003a6a67cc"
T0 = datetime(2026, 10, 8, 10, 0, tzinfo=UTC)


def write(path: Path, data: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")


def bytes_file(path: Path, value: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(value)


def ref(path: Path) -> dict[str, str]:
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def at(minutes: int) -> str:
    return (T0 + timedelta(minutes=minutes)).isoformat()


class BuilderTests(unittest.TestCase):
    def setUp(self) -> None:
        self.root = Path("/private/tmp") / ("therese-c17-direct-round-a-" + secrets.token_hex(6))
        self.root.mkdir(mode=0o700)
        self.qualification = Path("/private/tmp") / ("therese-c17-qualification-fixture-" + secrets.token_hex(6))
        self.qualification.mkdir(mode=0o700)
        self.previous_qualification_root = builder.QUALIFICATION_ROOT
        builder.QUALIFICATION_ROOT = self.qualification
        self.qa = self.root / "qa-source"
        self.qa.mkdir()
        self.profile = self.root / "profiles/therese-c17-codex-runtime-fixture"
        self.profile.mkdir(parents=True, mode=0o700)
        (self.profile / "home").mkdir()
        (self.profile / "data").mkdir()
        bytes_file(self.profile / "data/therese.db", b"fixture-db\n")
        self.data_dir = str(self.profile / "data")
        self.round = self.root.name.removeprefix("therese-")
        self.identity = {"actor": ACTOR, "round_id": self.round, "head": HEAD}
        self._fixture()

    def tearDown(self) -> None:
        builder.QUALIFICATION_ROOT = self.previous_qualification_root
        shutil.rmtree(self.root)
        shutil.rmtree(self.qualification)

    def _execution(self, stage: str, started: int, completed: int) -> dict:
        g1_stage = "start-runtime" if stage == "readiness" else stage
        base = {**self.identity, "stage_id": stage, "exit_code": 0,
                "instrument_error": None, "started_at": at(started), "completed_at": at(completed),
                "source_check_before": {"fixture": "same"},
                "source_check_after": {"fixture": "same"}}
        for name in ("stdout", "stderr"):
            path = self.root / "ledger" / g1_stage / (name + ".log")
            bytes_file(path, b"fixture\n")
            base[name] = ref(path)
        if stage == "stop-runtime":
            ports_path = self.root / "ledger/ports-absence-1.json"
            service_refs = []
            for offset, name in enumerate(("backend", "vite")):
                folder = self.root / "ledger" / name
                service_start_path = folder / "service-start.json"
                child = {"pid": 20 + offset, "ppid": 10, "pgid": 20 + offset,
                         "uid": os.getuid(), "start_sec": 120 + offset, "start_usec": 2,
                         "role": "persistent-" + name, "parent_birth": [10, 100, 0],
                         "attribution": "popen_child_before_workload"}
                owner = {"pid": 10, "ppid": 9, "pgid": 10, "uid": os.getuid(),
                         "start_sec": 100, "start_usec": 0}
                write(service_start_path, {**self.identity, "schema": "c17-runtime78-owned-service-start-v1",
                    "stage_id": name, "qa_root": str(self.root), "root_identity": child,
                    "owner": owner})
                receipt_path = folder / "receipt.json"
                write(receipt_path, {**self.identity, "schema": "c17-runtime78-owned-stage-receipt-v1",
                    "stage_id": name, "role": "persistent-" + name, "qa_root": str(self.root),
                    "root_identity": child, "owner": owner, "service_start_receipt": ref(service_start_path),
                    "admission": self.g1_authority["admission"], "binding": self.g1_authority["binding"],
                    "termination_proved": True, "output_archived": True,
                    "raw_stable": True, "log_stability_proved": True,
                    "cleanup_deadline_met": True, "cleanup_taint": [], "instrument_error": None})
                service_refs.append(ref(receipt_path))
            def lsof(port: int, second: int) -> dict:
                stamp = (T0 + timedelta(minutes=15, seconds=second)).isoformat()
                birth = {"pid": 1000 + second, "ppid": 10, "pgid": 1000 + second,
                         "uid": os.getuid(), "start_sec": 100 + second, "start_usec": 1,
                         "parent_birth": [10, 100, 0], "role": "diagnostic-lsof",
                         "attribution": "popen_child_before_workload", "captured_at": stamp}
                return {"port": port, "argv": ["/usr/sbin/lsof", "-nP", f"-iTCP:{port}",
                                                  "-sTCP:LISTEN", "-F", "p"],
                        "launch": [str(self.qa / ".venv-conforme/bin/python"), "-I", "-B",
                                   str(self.root / "g1/lsof_gate.py"), str(port)],
                        "identity": birth, "returncode": 1, "stdout": "", "stderr": "",
                        "cleanup": None, "elapsed_seconds": 0.05, "pids": [],
                        "observed_at": stamp}
            write(ports_path, {**self.identity, "schema": "c17-runtime78-ports-absence-v1",
                "phase": "services-stop", "qa_root": str(self.root), "ports_absence_proved": True,
                "ports_absent": [17593, 5173], "auxiliary_ports_absent": [17594],
                "residuals": [], "ambiguities": [],
                "attribution_errors": [],
                "scans": [[lsof(17593, 10), lsof(5173, 20), lsof(17594, 25)],
                          [lsof(17593, 30), lsof(5173, 40), lsof(17594, 45)]],
                "observed_at": (T0 + timedelta(minutes=15, seconds=50)).isoformat()})
            cleanup_path = self.root / "ledger/session-stop-services-1.json"
            write(cleanup_path, {**self.identity, "schema": "c17-runtime78-owned-service-stop-v1",
                "cycle": 17, "kind": "actual_in_process_owned_controller_phase",
                "call": "Session.stop_services", "qa_root": str(self.root), "round_name": "A",
                "execution_scope": "runtime78_exact_round", "admission": self.g1_authority["admission"],
                "binding": self.g1_authority["binding"], "services_stopped": True,
                "clean": True, "cleanup_error": None, "log_stability_tainted": False,
                "log_stability_proved": True, "cleanup_deadline_met": True,
                "cleanup_elapsed_seconds": 0.5, "launched_services": ["backend", "vite"],
                "unlaunched_handles": [], "remaining_handles": [], "cleanup_taint": [],
                "service_receipts": service_refs,
                "attribution_errors": [], "ports_absence_proved": True,
                "ports_absent": [17593, 5173], "auxiliary_ports_absent": [17594],
                "ports_absence_receipt": ref(ports_path),
                "cleanup": {"clean": True, "termination_of_exact_targets_proved": True,
                            "remaining_attributed": [], "ambiguities": [], "errors": []}})
            stdout_path = Path(base["stdout"]["path"])
            bytes_file(stdout_path, (json.dumps(ref(cleanup_path)) + "\n").encode())
            base["stdout"] = ref(stdout_path)
            return base | {"kind": "in_process_owned_phase", "operation": stage,
                           "no_subprocess_command_claimed": True,
                           "parent_identity_observed": {"pid": 10, "ppid": 9, "pgid": 10,
                                                        "uid": 501, "start_sec": 100, "start_usec": 0}}
        raw_path = self.root / "ledger" / g1_stage / "receipt.json"
        spec = self.specs[g1_stage]
        command = spec["argv"]
        deadline = 100.0 + spec["timeout_seconds"]
        environment = spec["env"] | {
            "QA_ROOT": str(self.root), "C17_RUNTIME_MODULE_DIR": str(self.root / "g1"),
            "C17_SESSION_ACTOR": ACTOR, "C17_SESSION_ROUND_ID": self.round,
            "C17_SESSION_HEAD": HEAD, "C17_SESSION_STAGE": g1_stage,
            "C17_SESSION_ROOT": str(self.root),
            "C17_SESSION_EVENTS": str(self.root / "session-events"),
            "C17_SESSION_DECISION_ID": self.round,
            "C17_SESSION_BINDING_SHA256": self.g1_authority["binding"]["sha256"],
            "C17_SESSION_ROUND_NAME": "A",
            "C17_SESSION_DECISION_REF": json.dumps(self.g1_authority["admission"], sort_keys=True),
            "C17_SESSION_BINDING_REF": json.dumps(self.g1_authority["binding"], sort_keys=True),
            "C17_SESSION_OUTER_DEADLINE_MONOTONIC": str(deadline),
        }
        owner = {"pid": 10, "ppid": 9, "pgid": 10, "uid": os.getuid(),
                 "start_sec": 100, "start_usec": 0}
        child = {"pid": 11, "ppid": 10, "pgid": 11, "uid": os.getuid(),
                 "start_sec": 101, "start_usec": 1, "role": "stage-" + g1_stage,
                 "parent_birth": [10, 100, 0], "attribution": "popen_child_before_workload"}
        write(raw_path, {**self.identity, "schema": "c17-runtime78-owned-stage-receipt-v1",
            "stage_id": g1_stage, "exit_code": 0, "instrument_error": None,
            "started_at": at(started), "completed_at": at(completed), "raw_stable": True,
            "log_stability_proved": True, "cleanup_deadline_met": True,
            "cleanup_taint": [], "timed_out": False, "released": True,
            "root_identity": child, "owner": owner, "attributed": [child],
            "role": "stage-" + g1_stage, "qa_root": str(self.root), "round_name": "A",
            "execution_scope": "runtime78_exact_round", "argv": command,
            "cwd": str(self.root), "environment": environment,
            "stdout": base["stdout"], "stderr": base["stderr"],
            "started_monotonic": 100.0, "timeout_seconds": spec["timeout_seconds"],
            "outer_deadline_monotonic": deadline, "cleanup_elapsed_seconds": 0.5,
            "admission": self.g1_authority["admission"],
            "binding": self.g1_authority["binding"],
            **(self.stage_links if g1_stage == "start-runtime" else {})})
        return base | {"kind": "subprocess_execution_derived_from_real_owned_session",
                       "raw_not_relabelled": True, "real_session_receipt": ref(raw_path),
                       "g1_stage_id": g1_stage,
                       "command": command, "cwd": str(self.root),
                       "effective_environment": environment}

    def _fixture(self) -> None:
        root = self.root
        head_file = self.qa / ".git/HEAD"
        bytes_file(head_file, (HEAD + "\n").encode())
        frontend_source = self.qa / "src/frontend/index.html"
        bytes_file(frontend_source, b"<html></html>\n")
        logging_source = self.qa / "src/backend/app/core/logging_config.py"
        bytes_file(logging_source, b"# fixture\n")
        product_sources = {"src/frontend/index.html": ref(frontend_source)["sha256"],
                           "src/backend/app/core/logging_config.py": ref(logging_source)["sha256"]}
        manifest_path = root / "authorization/source-files.json"
        rows = [{"path": str(path), "sha256": ref(path)["sha256"],
                 "bytes": path.stat().st_size,
                 "git_blob": hashlib.sha1(b"blob " + str(path.stat().st_size).encode()
                                           + b"\0" + path.read_bytes()).hexdigest()}
                for path in (frontend_source, logging_source)]
        write(manifest_path, {"schema": "c17-root-fresh-git-source-manifest-v1",
            "status": "PASS", "head": HEAD, "product_source_root": str(self.qa),
            "git_tree_verified": True, "files": rows})
        checkout_path = root / "authorization/source-checkout.json"
        write(checkout_path, {**self.identity, "schema": "c17-direct-round-source-checkout-v1",
            "qa_root": str(root), "round_name": "A",
            "head": HEAD, "git_head": HEAD, "product_source_root": str(self.qa),
            "git_tree_verified": True, "git_head_ref": ref(head_file),
            "source_manifest_ref": ref(manifest_path)})
        binding_path = self.qualification / "session-binding.json"
        module_path = root / "g1/runtime_session.py"
        bytes_file(module_path, b"# synthetic Session module\n")
        stage_binding_path = self.qualification / "start-runtime-binding.json"
        stage_decision_path = self.qualification / "start-runtime-decision.json"
        stage_decision_id = self.round + "-start-runtime"
        plan = {"path": str(stage_decision_path), "decision_id": stage_decision_id}
        python = str(self.qa / ".venv-conforme/bin/python")
        def spec(name: str, argv: list[str], bound: int) -> dict:
            return {"argv": argv, "role": "stage-" + name, "mode": "web",
                    "timeout_seconds": bound, "env": {"HOME": str(self.profile / "home")},
                    "cwd": str(root), "stdout_path": str(root / "ledger" / name / "stdout.log"),
                    "stderr_path": str(root / "ledger" / name / "stderr.log"),
                    "combine_stderr": False,
                    "derived_deadline": "start_monotonic_plus_exact_timeout"}
        self.specs = {"calibrate": spec("calibrate", [python, str(root / "runtime/calibrate-all.py")], 1200)}
        write(binding_path, {**self.identity, "schema": "c17-runtime78-session-binding-v1",
            "qa_root": str(root), "round_name": "A", "commands": {"calibrate": self.specs["calibrate"]},
            "stage_plans": {"start-runtime": {"timeout_seconds": 120,
                                             "decision": plan,
                                             "binding_path": str(stage_binding_path)}}})
        admission_path = self.qualification / "session-admission.json"
        write(admission_path, {**self.identity, "schema": "c17-runtime78-session-root-go-v1",
            "qa_root": str(root), "round_name": "A", "decision_id": self.round,
            "binding": ref(binding_path)})
        successor_path = self.qualification / "successor-admission.json"
        write(successor_path, {**self.identity, "schema": "c17-runtime78-successor-admission-v1",
            "provided_by": "/root", "phase": "runtime",
            "qa_root": str(root), "round_name": "A", "session_decision": ref(admission_path),
            "session_binding": ref(binding_path), "session": {"module": ref(module_path)}})
        self.g1_authority = {"successor": ref(successor_path),
                             "admission": ref(admission_path), "binding": ref(binding_path)}
        self.specs["start-runtime"] = spec("start-runtime",
            [python, str(root / "runtime78-successor/readiness_owned.py"), str(root),
             "--decision", self.g1_authority["successor"]["path"],
             "--decision-sha256", self.g1_authority["successor"]["sha256"]], 120)
        stage_origin = self.qualification / "start-runtime-origin.json"
        write(stage_origin, {"source": "synthetic_fixture_only"})
        write(stage_binding_path, {**self.identity, "schema": "c17-runtime78-stage-binding-v1",
            "qa_root": str(root), "round_name": "A", "stage_id": "start-runtime",
            "initial_binding": self.g1_authority["binding"],
            "planned_decision": plan, "command": self.specs["start-runtime"]})
        write(stage_decision_path, {**self.identity, "schema": "c17-runtime78-stage-go-v1",
            "qa_root": str(root), "round_name": "A", "stage_id": "start-runtime",
            "decision_id": stage_decision_id, "provided_by": "/root",
            "initial_binding": self.g1_authority["binding"],
            "stage_binding": ref(stage_binding_path), "root_review_origin": ref(stage_origin)})
        self.stage_links = {"stage_binding": ref(stage_binding_path),
                            "stage_decision": ref(stage_decision_path),
                            "stage_origin": ref(stage_origin)}
        config_path = root / "prepared-config.json"
        write(config_path, {**self.identity, "root": str(root), "repo": str(self.qa),
            "cycle": 17, "campaign": "A",
            "python": str(self.qa / ".venv-conforme/bin/python"),
            "frontend_qa": str(self.qa / "src/frontend"),
            "frontend_dependencies": str(self.qa / "src/frontend/node_modules"),
            "playwright_dependencies": str(self.qa / "node_modules"),
            "product_sources": product_sources,
            "frontend_qa_sources": {"src/frontend/index.html": ref(frontend_source)["sha256"]}})
        stack = {"head_at_start": HEAD, "data_dir": self.data_dir,
                 "temporary_root": str(self.profile), "home": str(self.profile / "home"),
                 "verified_data_dir": self.data_dir,
                 "verified_db_path": str(self.profile / "data/therese.db"),
                 "repo": str(self.qa)}
        running_path = root / "runtime/pile-reprise-running-preserved.json"
        stopped_path = root / "runtime/pile-reprise.json"
        write(running_path, stack | {"status": "running"})
        write(stopped_path, stack | {"status": "stopped"})
        execution_paths = {
            "start": ("start-runtime", "readiness", 1, 2),
            "calibrate": ("calibrate", "calibrate", 5, 10),
            "stop": ("stop-runtime", "stop-runtime", 15, 16),
        }
        executions = {}
        for key, (folder, stage, started, completed) in execution_paths.items():
            path = root / "ledger" / folder / "execution.json"
            write(path, self._execution(stage, started, completed))
            executions[key] = ref(path)
        all_dir = root / "runtime/calibration/all-rpc"
        names = ("test_runner", "logs", "runtime_ui-visual_capture-network_capture", "screen_coverage")
        results = []
        for name in names:
            path = all_dir / (name + ".log")
            bytes_file(path, b"child complete\n")
            results.append({"instruments": name, "exit_code": 0, "log": str(path)})
        summary = all_dir / "calibration-summary.json"
        write(summary, {"cycle": 17, "status": "passed", "head": HEAD,
                        "repo": str(self.qa), "results": results})

        test_dir = root / "runtime/calibration/test-runner-rpc"
        controls = {}
        for tool in ("pytest", "vitest"):
            for label in ("positive", "negative"):
                name, defect = f"{tool}-{label}", label == "positive"
                xml = test_dir / (name + ".xml")
                identity = (('test_temoin_c17', 'test_temoin_c17') if tool == 'pytest' else
                            ('calibrationC17.test.ts', 'détecte le défaut puis l’état sain'))
                failure = ('<failure message="assert 2 == 1">assert 2 == 1</failure>' if tool == 'pytest' else
                           '<failure message="expected 2 to be 1">Expected 1 Received 2</failure>') if defect else ''
                bytes_file(xml, (f'<testsuite tests="1" failures="{int(defect)}" errors="0" skipped="0">'
                                 f'<testcase classname="{identity[0]}" name="{identity[1]}">{failure}</testcase>'
                                 '</testsuite>\n').encode())
                bytes_file(test_dir / (name + ".log"),
                           b"Python 3.13.5, pytest-8.4.2\n" if name == "pytest-negative" else b"case\n")
                controls[name] = {"pass": True, "exit_code": int(defect), "xml": str(xml),
                                  "sha256": ref(xml)["sha256"],
                                  "counts": {"tests": 1, "failures": int(defect), "errors": 0, "skipped": 0}}
        witness_paths = [test_dir / name for name in
                         ("test_temoin_c17.py", "calibrationC17.test.ts", "vitest.runtime.config.mjs")]
        for path in witness_paths:
            bytes_file(path, b"witness\n")
        test = test_dir / "test-runner-controls.json"
        write(test, {"instrument": "test_runner", "cycle": 17, "status": "passed",
                     "head": HEAD, "repo": str(self.qa), "controls": controls,
                     "witnesses": {str(path): ref(path)["sha256"] for path in witness_paths}})
        vitest = self.qa / "src/frontend/node_modules/vitest/package.json"
        write(vitest, {"version": "3.2.1"})
        write(self.qa / "node_modules/playwright/package.json", {"version": "1.55.0"})
        bytes_file(self.qa / "src/backend/app/core/logging_config.py", b"# fixture\n")

        logs_dir = root / "runtime/calibration/logs-rpc"
        log_file = logs_dir / "therese-temoin.log"
        log_records = [
            {"timestamp": at(8), "level": "INFO", "message": "Logging configure", "extra": {}},
            {"timestamp": at(9), "level": "INFO", "message": "TEMOIN-C17-SAIN",
             "extra": {"calibration_run": "logs-rpc"}},
            {"timestamp": (T0 + timedelta(minutes=9, seconds=1)).isoformat(),
             "level": "ERROR", "message": "TEMOIN-C17-ERREUR-INJECTEE",
             "extra": {"calibration_run": "logs-rpc"}},
        ]
        bytes_file(log_file, ("\n".join(json.dumps(row) for row in log_records) + "\n").encode())
        logs = logs_dir / "logs-controls.json"
        write(logs, {"instrument": "logs", "cycle": 17, "status": "passed", "head": HEAD,
                     "data_dir": str(self.profile / "logs-rpc"), "run_id": "logs-rpc",
                     "raw_log": str(log_file), "raw_log_sha256": ref(log_file)["sha256"],
                     "negative_control": {"pass": True, "healthy_markers": 1, "records": 2},
                     "positive_control": {"pass": True, "correlated_errors": 1, "records": 3}})

        browser_dir = root / "runtime/calibration/browser-rpc"
        a, b, c = (browser_dir / name for name in
                   ("visual-negative-a.png", "visual-negative-b.png", "visual-positive.png"))
        bytes_file(a, b"PNG-clean")
        bytes_file(b, b"PNG-clean")
        bytes_file(c, b"PNG-defect")
        frontend_source = self.qa / "src/frontend/index.html"
        browser = browser_dir / "browser-controls.json"
        write(browser, {"cycle": 17, "status": "passed", "head": HEAD, "repo": str(self.qa),
            "identity": {"status": 200, "tokenPresent": True},
            "environment": {"data_dir": self.data_dir}, "pageErrors": [],
            "runtime_ui": {"negativeOk": True, "positiveOk": True},
            "visual_capture": {"negative": {"files": [str(a), str(b)], "a": ref(a)["sha256"],
                "b": ref(b)["sha256"], "identical": True},
                "positive": {"file": str(c), "c": ref(c)["sha256"], "differs": True, "visible": True}},
            "network_capture": {"negative": {"status": 200, "detected": True},
                "positive": {"status": 503, "detected": True}, "guard": {}},
            "sourcePreserved": {str(frontend_source): {
                "before": ref(frontend_source)["sha256"], "after": ref(frontend_source)["sha256"]}},
            "chromiumVersion": "140.0.0.0", "playwrightVersion": "1.55.0", "nodeVersion": "v22.19.0"})

        screen_dir = root / "runtime/calibration/screen-rpc"
        source = root / "runtime/couverture-ecran-c17.mjs"
        bytes_file(source, b"// fixture\n")
        copy = screen_dir / "couverture-ecran-calibree.mjs"
        bytes_file(copy, b"// fixture with injection\n")
        screen_rows = {}
        for label in ("negative", "positive-visual", "positive-network", "restored"):
            path = screen_dir / label / ("interruption.json" if label == "positive-network" else "rapport.json")
            report = ({"garde": {"bloquees": [{"url": "https://calibration.invalid/probe"}]}}
                      if label == "positive-network" else
                      {"anomalies": [{"type": "contenu-rogne"}, {"type": "nom-accessible-vide"}]}
                      if label == "positive-visual" else {"anomalies": []})
            write(path, report)
            key = label.replace("-", "_")
            screen_rows[key] = {"path": str(path), "sha256": ref(path)["sha256"],
                                "exit_code": 2 if label == "positive-network" else 0,
                                "pass": True}
            if label in ("negative", "restored"):
                screen_rows[key]["anomalies"] = []
            if label == "positive-visual":
                screen_rows[key]["types"] = ["contenu-rogne", "nom-accessible-vide"]
            if label == "positive-network":
                screen_rows[key]["blocked"] = report["garde"]["bloquees"]
        screen_rows["positive_network"]["query_redacted"] = True
        screen = screen_dir / "screen-controls.json"
        write(screen, {"instrument": "screen_coverage", "cycle": 17, "status": "passed",
                       "head": HEAD, "stack": {"data_dir": self.data_dir},
                       "source": str(source), "source_sha256": ref(source)["sha256"],
                       "calibrated_copy": str(copy), "copy_sha256": ref(copy)["sha256"],
                       "sources_preserved": {"src/frontend/index.html": ref(frontend_source)["sha256"]},
                       **screen_rows})
        raw_paths = {"summary": summary, "test_runner": test, "logs": logs,
                     "browser": browser, "screen_coverage": screen}
        self.request = {"schema": "c17-calibration-builder-request-v2", "root": str(root),
                        "qa_source": str(self.qa), **self.identity, "executions": executions,
                        "round_sources": {"configuration": ref(config_path),
                            "running_manifest": ref(running_path), "stopped_manifest": ref(stopped_path),
                            "source_checkout": ref(checkout_path)},
                        "g1_authority": self.g1_authority,
                        "raw_results": {key: ref(path) for key, path in raw_paths.items()}}
        self.request_path = root / "authorization/calibration-builder-request.json"
        write(self.request_path, self.request)

    def _request_ref(self) -> dict:
        return ref(self.request_path)

    def _replace(self, path: Path, content: dict, slot: str, key: str) -> None:
        write(path, content)
        self.request[slot][key] = ref(path)
        write(self.request_path, self.request)

    def _change_stack(self, key: str, value: object, *, stopped_only: bool = False) -> None:
        names = ("stopped_manifest",) if stopped_only else ("running_manifest", "stopped_manifest")
        for name in names:
            path = Path(self.request["round_sources"][name]["path"])
            stack = json.loads(path.read_text())
            if value is None:
                stack.pop(key, None)
            else:
                stack[key] = value
            self._replace(path, stack, "round_sources", name)

    def _assert_profile_refused(self, message: str) -> None:
        with self.assertRaisesRegex(ValueError, message):
            builder.build(self._request_ref(), now=T0 + timedelta(minutes=20))
        self.assertFalse((self.root / "calibration-records-v3").exists())

    def _change_service_stop(self, key: str, value: object) -> None:
        receipt_path = self.root / "ledger/session-stop-services-1.json"
        receipt = json.loads(receipt_path.read_text())
        receipt[key] = value
        write(receipt_path, receipt)
        stdout = self.root / "ledger/stop-runtime/stdout.log"
        bytes_file(stdout, (json.dumps(ref(receipt_path)) + "\n").encode())
        execution_path = self.root / "ledger/stop-runtime/execution.json"
        execution = json.loads(execution_path.read_text())
        execution["stdout"] = ref(stdout)
        self._replace(execution_path, execution, "executions", "stop")

    def _change_stage_raw(self, key: str, value: object) -> None:
        receipt_path = self.root / "ledger/calibrate/receipt.json"
        raw = json.loads(receipt_path.read_text())
        raw[key] = value
        write(receipt_path, raw)
        execution_path = self.root / "ledger/calibrate/execution.json"
        execution = json.loads(execution_path.read_text())
        execution["real_session_receipt"] = ref(receipt_path)
        self._replace(execution_path, execution, "executions", "calibrate")

    def _change_stage_and_envelope(self, key: str, envelope_key: str, value: object) -> None:
        receipt_path = self.root / "ledger/calibrate/receipt.json"
        raw = json.loads(receipt_path.read_text())
        raw[key] = value
        write(receipt_path, raw)
        execution_path = self.root / "ledger/calibrate/execution.json"
        execution = json.loads(execution_path.read_text())
        execution[envelope_key] = value
        execution["real_session_receipt"] = ref(receipt_path)
        self._replace(execution_path, execution, "executions", "calibrate")

    def _change_ports(self, mutate) -> None:
        path = self.root / "ledger/ports-absence-1.json"
        ports = json.loads(path.read_text())
        mutate(ports)
        write(path, ports)
        self._change_service_stop("ports_absence_receipt", ref(path))

    def _change_log(self, content: bytes) -> None:
        raw_path = self.root / "runtime/calibration/logs-rpc/therese-temoin.log"
        bytes_file(raw_path, content)
        control_path = self.root / "runtime/calibration/logs-rpc/logs-controls.json"
        control = json.loads(control_path.read_text())
        control["raw_log_sha256"] = ref(raw_path)["sha256"]
        self._replace(control_path, control, "raw_results", "logs")

    def _change_xml(self, name: str, content: bytes) -> None:
        xml = self.root / "runtime/calibration/test-runner-rpc" / (name + ".xml")
        bytes_file(xml, content)
        controls_path = self.root / "runtime/calibration/test-runner-rpc/test-runner-controls.json"
        controls = json.loads(controls_path.read_text())
        controls["controls"][name]["sha256"] = ref(xml)["sha256"]
        self._replace(controls_path, controls, "raw_results", "test_runner")

    def test_six_records_are_from_one_closed_round(self) -> None:
        output = builder.build(self._request_ref(), now=T0 + timedelta(minutes=20))
        index = json.loads(Path(output["path"]).read_text())
        self.assertEqual(index["count"], 6)
        self.assertEqual({json.loads(Path(item["path"]).read_text())["instrument"]
                          for item in index["calibrations"]}, set(builder.INSTRUMENTS))
        for item in index["calibrations"]:
            row = json.loads(Path(item["path"]).read_text())
            self.assertEqual(row["observed_at"], at(10))
            self.assertEqual(row["expires_at"], at(10 + 12 * 60))
            self.assertEqual(row["calibration_execution"], self.request["executions"]["calibrate"])
            self.assertEqual((row["actor"], row["round_id"], row["head"]),
                             (ACTOR, self.round, HEAD))

    def test_red_browser_is_not_relabelled(self) -> None:
        path = Path(self.request["raw_results"]["browser"]["path"])
        raw = json.loads(path.read_text()) | {"status": "failed"}
        self._replace(path, raw, "raw_results", "browser")
        with self.assertRaisesRegex(ValueError, "Brut rouge"):
            builder.build(self._request_ref(), now=T0 + timedelta(minutes=20))
        self.assertFalse((self.root / "calibration-records-v3").exists())

    def test_unclosed_g1_stage_is_rejected(self) -> None:
        path = self.root / "ledger/calibrate/receipt.json"
        raw = json.loads(path.read_text()) | {"raw_stable": False}
        write(path, raw)
        execution_path = Path(self.request["executions"]["calibrate"]["path"])
        execution = json.loads(execution_path.read_text())
        execution["real_session_receipt"] = ref(path)
        self._replace(execution_path, execution, "executions", "calibrate")
        with self.assertRaisesRegex(ValueError, "G1 brut non clos"):
            builder.build(self._request_ref(), now=T0 + timedelta(minutes=20))
        self.assertFalse((self.root / "calibration-records-v3").exists())

    def test_observed_at_keeps_exact_terminal_timestamp_text(self) -> None:
        terminal = self.root / "ledger/calibrate/receipt.json"
        raw = json.loads(terminal.read_text())
        raw["completed_at"] = "2026-10-08T10:10:00Z"
        write(terminal, raw)
        execution_path = Path(self.request["executions"]["calibrate"]["path"])
        execution = json.loads(execution_path.read_text())
        execution["completed_at"] = raw["completed_at"]
        execution["real_session_receipt"] = ref(terminal)
        self._replace(execution_path, execution, "executions", "calibrate")
        output = builder.build(self._request_ref(), now=T0 + timedelta(minutes=20))
        index = json.loads(Path(output["path"]).read_text())
        row = json.loads(Path(index["calibrations"][0]["path"]).read_text())
        self.assertEqual(row["observed_at"], "2026-10-08T10:10:00Z")

    def test_out_of_window_stage_is_rejected(self) -> None:
        path = Path(self.request["executions"]["stop"]["path"])
        stop = json.loads(path.read_text()) | {"started_at": at(9)}
        self._replace(path, stop, "executions", "stop")
        with self.assertRaisesRegex(ValueError, "hors fenêtre"):
            builder.build(self._request_ref(), now=T0 + timedelta(minutes=20))
        self.assertFalse((self.root / "calibration-records-v3").exists())

    def test_expired_stage_is_rejected(self) -> None:
        with self.assertRaisesRegex(ValueError, "expirée"):
            builder.build(self._request_ref(), now=T0 + timedelta(hours=13))
        self.assertFalse((self.root / "calibration-records-v3").exists())

    def test_mutated_capture_is_rejected(self) -> None:
        path = self.root / "runtime/calibration/browser-rpc/visual-positive.png"
        bytes_file(path, b"changed after capture")
        with self.assertRaisesRegex(ValueError, "Témoin visuel non vérifié"):
            builder.build(self._request_ref(), now=T0 + timedelta(minutes=20))
        self.assertFalse((self.root / "calibration-records-v3").exists())

    def test_existing_records_are_never_replaced(self) -> None:
        output = builder.build(self._request_ref(), now=T0 + timedelta(minutes=20))
        original = Path(output["path"]).read_bytes()
        with self.assertRaises(FileExistsError):
            builder.build(self._request_ref(), now=T0 + timedelta(minutes=21))
        self.assertEqual(Path(output["path"]).read_bytes(), original)

    def test_wrong_round_name_is_rejected(self) -> None:
        self.request["round_id"] = "therese-c17-wrapper-canary-false"
        write(self.request_path, self.request)
        with self.assertRaisesRegex(ValueError, "Identité A/B"):
            builder.build(self._request_ref(), now=T0 + timedelta(minutes=20))
        self.assertFalse((self.root / "calibration-records-v3").exists())

    def test_temporary_root_outside_round_is_rejected(self) -> None:
        self._change_stack("temporary_root", "/private/tmp/other-qa-profile")
        self._assert_profile_refused("Profil hors QA")

    def test_home_outside_round_is_rejected(self) -> None:
        self._change_stack("home", "/Users/synoptia/.therese")
        self._assert_profile_refused("Profil hors QA")

    def test_data_outside_round_is_rejected(self) -> None:
        self._change_stack("data_dir", "/private/tmp/other-data")
        self._assert_profile_refused("Profil hors QA")

    def test_temporary_root_symlink_outside_round_is_rejected(self) -> None:
        link = self.root / "profiles/link"
        link.symlink_to(Path("/private/tmp"))
        self._change_stack("temporary_root", str(link))
        self._assert_profile_refused("Profil QA avec symlink")

    def test_data_symlink_outside_round_is_rejected(self) -> None:
        link = self.profile / "linked-data"
        link.symlink_to(Path("/private/tmp"))
        self._change_stack("data_dir", str(link))
        self._assert_profile_refused("Profil QA avec symlink")

    def test_db_outside_data_is_rejected(self) -> None:
        self._change_stack("verified_db_path", str(self.root / "outside.db"))
        self._assert_profile_refused("Chemin vérifié hors profil QA")

    def test_missing_verified_db_is_rejected(self) -> None:
        self._change_stack("verified_db_path", None)
        self._assert_profile_refused("Chemin vérifié running/stopped discordant")

    def test_missing_verified_data_dir_is_rejected(self) -> None:
        self._change_stack("verified_data_dir", None)
        self._assert_profile_refused("Chemin vérifié running/stopped discordant")

    def test_db_symlink_outside_round_is_rejected(self) -> None:
        db = self.profile / "data/therese.db"
        db.rename(self.profile / "data/therese.original")
        db.symlink_to(Path("/private/tmp"))
        self._assert_profile_refused("DB QA non régulière/non possédée/symlink")

    def test_running_stopped_home_mismatch_is_rejected(self) -> None:
        self._change_stack("home", str(self.profile / "different-home"), stopped_only=True)
        self._assert_profile_refused("Profil running/stopped discordant")

    def test_missing_home_is_rejected(self) -> None:
        self._change_stack("home", None)
        self._assert_profile_refused("Profil running/stopped discordant")

    def test_non_private_temporary_root_is_rejected(self) -> None:
        self.profile.chmod(0o755)
        self._assert_profile_refused("Profil temporaire QA non privé")

    def test_non_private_round_root_is_rejected(self) -> None:
        self.root.chmod(0o755)
        self._assert_profile_refused("Racine QA non privée/non possédée")

    def test_stop_envelope_without_session_stop_services_is_rejected(self) -> None:
        stdout = self.root / "ledger/stop-runtime/stdout.log"
        bytes_file(stdout, b'{"status":"stopped"}\n')
        path = self.root / "ledger/stop-runtime/execution.json"
        execution = json.loads(path.read_text())
        execution["stdout"] = ref(stdout)
        self._replace(path, execution, "executions", "stop")
        self._assert_profile_refused("Ref Session.stop_services invalide")

    def test_red_service_cleanup_is_rejected(self) -> None:
        self._change_service_stop("services_stopped", False)
        self._assert_profile_refused("Services G1 non clos")

    def test_service_stop_without_terminal_receipts_is_rejected(self) -> None:
        self._change_service_stop("service_receipts", [])
        self._assert_profile_refused("Deux reçus terminaux de services absents")

    def test_false_service_terminal_receipt_is_rejected(self) -> None:
        service_path = self.root / "ledger/backend/receipt.json"
        service = json.loads(service_path.read_text())
        service["termination_proved"] = False
        write(service_path, service)
        stop_path = self.root / "ledger/session-stop-services-1.json"
        stop = json.loads(stop_path.read_text())
        stop["service_receipts"][0] = ref(service_path)
        self._change_service_stop("service_receipts", stop["service_receipts"])
        self._assert_profile_refused("Reçu terminal service rouge")

    def test_unbounded_service_cleanup_is_rejected(self) -> None:
        self._change_service_stop("cleanup_elapsed_seconds", 8.1)
        self._assert_profile_refused("Deadline physique stop_services")

    def test_missing_ports_absence_is_rejected(self) -> None:
        self._change_service_stop("ports_absence_proved", False)
        self._assert_profile_refused("Ports QA/CDP non prouvés absents")

    def test_empty_scans_with_green_flags_are_rejected(self) -> None:
        self._change_ports(lambda ports: ports.update(scans=[[], []]))
        self._assert_profile_refused("Scan ports QA/CDP absent")

    def test_additional_port_scan_is_rejected(self) -> None:
        def extra(ports):
            ports["scans"][0].append({"port": 17594, "pids": [999]})
        self._change_ports(extra)
        self._assert_profile_refused("Scan ports QA/CDP absent")

    def test_cdp_scan_truncated_is_rejected(self) -> None:
        self._change_ports(lambda ports: ports["scans"][1].pop())
        self._assert_profile_refused("Scan ports QA/CDP absent")

    def test_cdp_present_is_rejected_even_with_green_flags(self) -> None:
        def occupied(ports):
            ports["scans"][0][2]["pids"] = [887]
            ports["scans"][0][2]["returncode"] = 0
            ports["scans"][0][2]["stdout"] = "p887\n"
        self._change_ports(occupied)
        self._assert_profile_refused("lsof non concluante")

    def test_cdp_foreign_lsof_birth_is_rejected(self) -> None:
        self._change_ports(lambda ports: ports["scans"][1][2]["identity"].update(ppid=999))
        self._assert_profile_refused("Birth diagnostic lsof non attribuée")

    def test_cdp_absence_flag_only_is_rejected(self) -> None:
        self._change_service_stop("auxiliary_ports_absent", None)
        self._assert_profile_refused("Ports QA/CDP non prouvés absents")

    def test_cdp_receipt_flag_only_is_rejected(self) -> None:
        self._change_ports(lambda ports: ports.update(auxiliary_ports_absent=[]))
        self._assert_profile_refused("Reçu ports-absence rouge")

    def test_lsof_error_cannot_prove_absence(self) -> None:
        def broken(ports):
            ports["scans"][0][0]["returncode"] = 2
        self._change_ports(broken)
        self._assert_profile_refused("lsof non concluante")

    def test_lsof_total_elapsed_over_communicate_budget_can_still_be_valid(self) -> None:
        def observed(ports):
            ports["scans"][0][0]["elapsed_seconds"] = 2.5
        self._change_ports(observed)
        output = builder.build(self._request_ref(), now=T0 + timedelta(minutes=20))
        self.assertEqual(json.loads(Path(output["path"]).read_text())["count"], 6)

    def test_lsof_wrong_parent_birth_is_rejected(self) -> None:
        def unrelated(ports):
            ports["scans"][0][0]["identity"]["parent_birth"] = [99, 100, 0]
        self._change_ports(unrelated)
        self._assert_profile_refused("Birth diagnostic lsof non attribuée")

    def test_other_admission_on_stop_is_rejected(self) -> None:
        self._change_service_stop("admission", self.g1_authority["binding"])
        self._assert_profile_refused("Admission/binding stop non liés")

    def test_empty_log_with_green_flags_is_rejected(self) -> None:
        self._change_log(b"")
        self._assert_profile_refused("Journal témoin vide")

    def test_uncorrelated_log_with_green_flags_is_rejected(self) -> None:
        raw = self.root / "runtime/calibration/logs-rpc/therese-temoin.log"
        content = raw.read_text().replace("logs-rpc", "foreign-run")
        self._change_log(content.encode())
        self._assert_profile_refused("Marqueurs INFO/ERROR corrélés")

    def test_log_counts_discordant_are_rejected(self) -> None:
        path = self.root / "runtime/calibration/logs-rpc/logs-controls.json"
        controls = json.loads(path.read_text())
        controls["positive_control"]["records"] = 4
        self._replace(path, controls, "raw_results", "logs")
        self._assert_profile_refused("Comptages bruts logs discordants")

    def test_log_timestamp_outside_calibration_is_rejected(self) -> None:
        raw = self.root / "runtime/calibration/logs-rpc/therese-temoin.log"
        rows = [json.loads(line) for line in raw.read_text().splitlines()]
        rows[0]["timestamp"] = at(4)
        self._change_log(("\n".join(json.dumps(row) for row in rows) + "\n").encode())
        self._assert_profile_refused("Horodatages logs hors calibration")

    def test_testsuite_without_testcase_is_rejected(self) -> None:
        self._change_xml("pytest-positive", b'<testsuite tests="1" failures="1" errors="0" skipped="0"/>\n')
        self._assert_profile_refused("Testcase témoin absent")

    def test_positive_xml_without_failure_is_rejected(self) -> None:
        self._change_xml("pytest-positive", b'<testsuite tests="1" failures="1" errors="0" skipped="0">'
                         b'<testcase classname="test_temoin_c17" name="test_temoin_c17"/>'
                         b'</testsuite>\n')
        self._assert_profile_refused("Défaut XML témoin absent")

    def test_stage_without_birth_is_rejected(self) -> None:
        self._change_stage_raw("root_identity", {})
        self._assert_profile_refused("Birth G1 stage absente")

    def test_stage_birth_not_in_attributed_ledger_is_rejected(self) -> None:
        self._change_stage_raw("attributed", [])
        self._assert_profile_refused("Birth G1 non corroborée")

    def test_stage_unreleased_is_rejected(self) -> None:
        self._change_stage_raw("released", False)
        self._assert_profile_refused("Reçu G1 brut non clos")

    def test_stage_stdout_not_raw_is_rejected(self) -> None:
        self._change_stage_raw("stdout", self.g1_authority["binding"])
        self._assert_profile_refused("Reçu G1 brut non clos")

    def test_stage_other_environment_is_rejected(self) -> None:
        self._change_stage_raw("environment", {"HOME": "/private/tmp/foreign"})
        self._assert_profile_refused("Reçu G1 brut non clos")

    def test_stage_binding_ref_not_request_authority_is_rejected(self) -> None:
        self._change_stage_raw("binding", self.g1_authority["admission"])
        self._assert_profile_refused("Autorité G1 stage différente")

    def test_stage_cleanup_elapsed_over_eight_is_rejected(self) -> None:
        self._change_stage_raw("cleanup_elapsed_seconds", 8.01)
        self._assert_profile_refused("Cleanup G1 stage hors borne")

    def test_raw_and_envelope_repinning_cannot_change_admitted_argv(self) -> None:
        self._change_stage_and_envelope("argv", "command", ["/qa/other", "instrument.py"])
        self._assert_profile_refused("Reçu G1 brut non clos/discordant")

    def test_raw_and_envelope_repinning_cannot_change_admitted_environment(self) -> None:
        self._change_stage_and_envelope("environment", "effective_environment", {"HOME": "/private/tmp/other"})
        self._assert_profile_refused("Reçu G1 brut non clos/discordant")

    def test_binding_without_command_or_stage_decision_is_rejected(self) -> None:
        raw = json.loads((self.root / "ledger/calibrate/receipt.json").read_text())
        authority = builder.verify_authority(self.request, self.root, actor=ACTOR,
            round_id=self.round, head=HEAD, qa_source=self.qa)
        authority["binding_data"]["commands"] = {}
        with self.assertRaisesRegex(ValueError, "Admission tardive d'étape absente"):
            builder._admitted_stage_spec(raw, "calibrate", self.root, authority)

    def test_authority_copied_into_round_is_not_root_qualification(self) -> None:
        source = Path(self.g1_authority["successor"]["path"])
        copied = self.root / "authorization/copied-successor.json"
        bytes_file(copied, source.read_bytes())
        self.request["g1_authority"]["successor"] = ref(copied)
        write(self.request_path, self.request)
        self._assert_profile_refused("Fichier hors QA admise")

    def test_config_other_frontend_qa_is_rejected(self) -> None:
        path = self.root / "prepared-config.json"
        config = json.loads(path.read_text())
        config["frontend_qa"] = "/private/tmp/other/frontend"
        self._replace(path, config, "round_sources", "configuration")
        self._assert_profile_refused("Source QA différente des chemins")

    def test_config_other_python_is_rejected(self) -> None:
        path = self.root / "prepared-config.json"
        config = json.loads(path.read_text())
        config["python"] = "/private/tmp/other-venv/bin/python"
        self._replace(path, config, "round_sources", "configuration")
        self._assert_profile_refused("Source QA différente des chemins")

    def test_missing_checkout_attestation_is_rejected(self) -> None:
        path = self.root / "authorization/source-checkout.json"
        checkout = json.loads(path.read_text())
        checkout["schema"] = "c17-wrapper-canary-source-checkout-v1"
        self._replace(path, checkout, "round_sources", "source_checkout")
        self._assert_profile_refused("Attestation checkout A/B physique absente")

    def test_false_checkout_git_blob_is_rejected(self) -> None:
        manifest_path = self.root / "authorization/source-files.json"
        manifest = json.loads(manifest_path.read_text())
        manifest["files"][0]["git_blob"] = "0" * 40
        write(manifest_path, manifest)
        checkout_path = self.root / "authorization/source-checkout.json"
        checkout = json.loads(checkout_path.read_text())
        checkout["source_manifest_ref"] = ref(manifest_path)
        self._replace(checkout_path, checkout, "round_sources", "source_checkout")
        self._assert_profile_refused("Blob Git produit non concordant")


if __name__ == "__main__":
    unittest.main()
