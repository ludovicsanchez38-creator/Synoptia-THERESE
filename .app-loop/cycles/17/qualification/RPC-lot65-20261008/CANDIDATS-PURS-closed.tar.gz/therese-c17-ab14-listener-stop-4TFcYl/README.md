# Raccord A/B14 : listener Python et arrêt CDP

Statut : **préparation statique, non admise et non exécutée en natif**. Cette
copie est un delta additif des gels A/B14 `180f3900…` et builder six
calibrations `f50938df…`. Les deux originaux et leurs résultats historiques
restent inchangés. Aucun artefact de ronde A/B n'est produit ici.

## Contrat fermé

- Le worker Python `request_owned_listener_observation` accepte les racines
  A/B canoniques exclusivement pour `start-runtime` et `density`. Il conserve
  `WRAPPER_CANARY` et ses trois stages exacts. Il transmet le vrai nom de
  ronde et `expected_head` à `load_admission` ; le parent recontrôle la
  décision, le binding, la source, le service/birth, l'acteur, le round, le
  journal et la fenêtre monotone de 5 s avant de répondre. Aucun lsof local
  ou repli dans le worker.
- `Session._serve_python_listener_requests` sert les deux stages A/B exacts
  uniquement sous `ab_aux.scope`. La garde physique `_capture_listener`
  inchangée relit l'admission avant le scan. Elle n'est pas placée dans la
  boucle vide de polling, qui rehasherait les sources à chaque itération.
- Le reçu G1 `prove_ports_absent` **reste byte-exact** : deux passes de trois
  diagnostics globaux `[17593, 5173, 17594]`, et les champs distincts
  `ports_absent=[17593,5173]`, `auxiliary_ports_absent=[17594]`. Le lecteur
  dérivé du builder v3 exige maintenant les trois diagnostics à chaque
  passe, vérifie pour chacun argv/launcher/birth/UID/PGID/rc=1/flux vides/
  PIDs vides/fenêtre, et compare les deux champs d'absence dans le reçu
  stop et la preuve lsof. Il n'existe aucun chemin `len2 OU len3`.

## Vérification faite par l'auteur

`python3 -I -B -m unittest discover -s tests -p 'test_*.py' -q` : 20 cas purs
PASS (dont 6 nouveaux). `python3 -I -B -m unittest discover -s calibration
-p 'test_build_calibrations_c17.py' -q` : 60 cas de fixtures purs PASS
(55 originaux, 5 nouveaux). Les négatifs nouveaux refusent notamment CDP
présent, scan tronqué, birth étrangère et drapeau isolé. Les fonctions G1
sont seulement extraites par AST pour ces tests, sans import du contrôleur
ni Popen. Aucun socket, Chrome, service, QA réelle ou profil n'a été lancé.

## Jonctions encore fermées

Ce dossier n'est pas un candidat FULL autonome. Une future fusion doit pinner
les nouvelles sources `g1/runtime_session.py` et
`calibration/build-calibrations-c17.py` dans les décisions/bindings A/B,
conserver les autres sources du gel A/B14 et résoudre explicitement le HEAD,
le profil Chrome réellement qualifié et les capacités/admissions encore à
`False`. Le builder historique f509 ne doit pas être exécuté sur un reçu à
trois diagnostics sans ce nouveau pin de lecteur. Le profil web lu ne donne
pas de lecture Q externe ; le `worker_context` historique lit déjà cette
autorité avant ce worker. Ce droit/une read-view qualifiée reste une barrière
distincte, non levée par ce delta ni par les tests synthétiques.

Préimages byte-exactes : `preimages/`. Diffs fonctionnels et du test builder :
`diffs/`. Le test worker est un ajout neuf. Aucun booléen de capacité ni
table d'admission n'a été promu.
