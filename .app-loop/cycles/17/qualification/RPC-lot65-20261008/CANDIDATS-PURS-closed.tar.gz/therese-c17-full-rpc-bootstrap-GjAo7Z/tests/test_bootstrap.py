"""Tests purs : vrais corps sélectionnés AST, doubles SYNTHÉTIQUES seulement."""
from __future__ import annotations
import ast
import copy
import hashlib
import json
import math
from pathlib import Path
import sys
from types import SimpleNamespace as NS
import unittest

HERE = Path(__file__).resolve().parent.parent
IDENTITY = {"pid": 901, "start_sec": 100, "start_usec": 2, "ppid": 900, "uid": 501, "pgid": 901}
LABELS = ("all-test_runner", "all-logs", "all-runtime_ui-visual_capture-network_capture", "all-screen_coverage",
    "test-pytest-positive", "test-pytest-negative", "test-vitest-positive", "test-vitest-negative",
    "screen-negative", "screen-positive-visual", "screen-positive-network", "screen-restored",
    "sql-b1753", "sql-b1760", "sql-b1753-power")
IDS = ["rpc-" + label for label in LABELS]


def need(value, message):
    if not value:
        raise ValueError(message)


def selected(path, names, namespace, *, methods=()):
    tree = ast.parse(path.read_text())
    nodes = []
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.ClassDef)) and node.name in names:
            nodes.append(node)
        elif isinstance(node, ast.ClassDef) and node.name == "Session":
            nodes.extend(item for item in node.body if isinstance(item, ast.FunctionDef) and item.name in methods)
    namespace = dict(namespace)
    exec(compile(ast.fix_missing_locations(ast.Module(body=nodes, type_ignores=[])), str(path), "exec"), namespace)
    return NS(**namespace)


class Clock:
    def __init__(self):
        self.value = 100.0
    def monotonic(self):
        return self.value
    def sleep(self, seconds):
        self.value += seconds


class Core:
    """Références en mémoire : n'authentifie aucun acteur ni fichier OS."""
    def __init__(self, trace):
        self.trace, self.data = trace, {}
        self.RUNTIME_ENABLED = True  # DOUBLE ; les sources complètes restent False.
        self.HERE = HERE / "successor"
        self.refs = {}
    def checked(self, ref, **kwargs):
        need(type(ref) is dict and isinstance(ref.get("path"), str), "synthetic ref absent")
        need(ref == self.refs.get(ref["path"]), "synthetic ref changed")
        return Path(ref["path"])
    def ref(self, path):
        path = str(path)
        return self.refs.setdefault(path, {"path": path, "sha256": hashlib.sha256(path.encode()).hexdigest(), "bytes": 10})
    def load(self, path):
        return copy.deepcopy(self.data[str(path)])
    def inside(self, root, path):
        need(path.is_relative_to(root), "outside synthetic fixture")
        return path
    def save_new(self, root, path, value):
        self.trace.append("save-transport")
        if getattr(self, "save_refused", False):
            raise OSError("synthetic save refused")
        need(str(path) not in self.data, "synthetic exclusive receipt")
        self.data[str(path)] = copy.deepcopy(value)
    def config_identity(self, config, root):
        need(config["root"] == str(root), "synthetic config foreign")


class Protocol:
    def digest(self, value):
        return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()
    def same_identity(self, left, right):
        need(left == right, "synthetic observed owner differs")


class Server:
    def __init__(self, trace, snapshots=None):
        self.trace, self.closed = trace, False
        self.snapshots = list(snapshots or [{"errors": [], "active": 0,
            "synthetic_peer": False, "OS_qualified": False, "FULL": False}])
    def pump(self):
        self.trace.append("pump")
        return copy.deepcopy(self.snapshots.pop(0) if len(self.snapshots) > 1 else self.snapshots[0])
    def close(self):
        self.trace.append("close-socket")
        self.closed = True


class Dispatcher:
    def __init__(self, trace, rows):
        self.trace, self.descriptors = trace, rows
        self.errors, self.tainted_requesters = [], set()
        self.jobs = {row["id"]: {"state": "complete", "token": row["id"], "row": row,
            "request_ref": {"path": "/synthetic/request/" + row["id"]},
            "ack_ref": {"path": "/synthetic/ack/" + row["id"]}} for row in rows}
        self.poll = lambda: (_ for _ in ()).throw(AssertionError("NO acceptance poll during final close"))
    def _descendants(self, requester):
        return set()
    def parent_quiescent(self, requester):
        return not any(job["state"] not in {"complete", "timeout", "error"}
            and job["row"]["requester_id"] == requester for job in self.jobs.values())
    def abort_parent(self, requester, reason):
        self.trace.append("abort-" + requester)
        self.tainted_requesters.add(requester)
        return {}
    def _poll_job(self, job):
        self.trace.append("poll-known-job")
        job["state"] = "error"


class BootstrapTests(unittest.TestCase):
    def setUp(self):
        self.trace, self.clock = [], Clock()
        self.core, self.protocol = Core(self.trace), Protocol()
        self.root = HERE / "synthetic-fixtures"
        self.config = {"actor": "/root/environment_routes", "campaign": "A",
            "round_id": "c17-direct-round-a-123456789abc", "head": "a" * 40, "root": str(self.root)}
        rows = [{"id": ident, "requester_id": "calibrate"} for ident in IDS]
        self.context = {"deadline_monotonic": 1000, "owner_identity": IDENTITY, "root": str(self.root)}
        self.session = NS(root=self.root, actor=self.config["actor"], head=self.config["head"],
            round_id=self.config["round_id"], round_name="A", closed=False, handles={},
            log_stability_tainted=False, ledger=NS(owner=IDENTITY))
        self.session.binding_ref = self.core.ref(self.root / "binding.json")
        self.session.binding = {"source_refs": [], "rpc_context_ref": self.core.ref(self.root / "context.json"),
            "rpc_plan_ref": self.core.ref(self.root / "plan.json"), "rpc_descriptors": {row["id"]: row for row in rows},
            "qa_root": str(self.root), "round_name": "A", "head": self.config["head"]}
        self.session.validate_sources = lambda: self.trace.append("sources")
        self.session.parent_phase_identity = lambda: dict(IDENTITY)
        self.session.verify_rpc_plan = lambda: self.trace.append("plan")
        self.path = HERE / "successor/root_rpc_bootstrap.py"
        self.own = self.core.ref(self.path)
        self.session.binding["source_refs"].append(self.own)
        self.session.binding["rpc_bootstrap_ref"] = self.own
        self.modules = {"rpc_protocol.py": self.protocol}
        self.ns = selected(self.path, ("RoundDeadlineExceeded", "need", "modules_exact", "load_modules",
            "validate_bootstrap", "OwnedRpcBootstrap", "bootstrap", "validate_close"),
            {"Path": Path, "math": math, "sys": NS(modules={}), "__file__": str(self.path),
             "time": self.clock, "MODULES": ("rpc_protocol.py", "rpc_client.py", "rpc_dispatcher.py",
                "session_rpc_adapter.py", "rpc_unix.py", "rpc_peer.py"),
             "LOAD_ORDER": ("rpc_protocol.py", "rpc_peer.py", "rpc_client.py",
                "session_rpc_adapter.py", "rpc_dispatcher.py", "rpc_unix.py"),
             "CLOSE_SCHEMA": "c17-runtime78-root-rpc-transport-close-v1",
             "CLEANUP_SECONDS": 8, "EOF_SECONDS": 5, "TERMINAL": frozenset(("complete", "timeout", "error"))})
        self.state = self.ns.OwnedRpcBootstrap(self.core, self.session, self.modules, self.own,
            {"context": self.context})
        self.state.dispatcher = Dispatcher(self.trace, rows)
        self.state.server = Server(self.trace)
        for job in self.state.dispatcher.jobs.values():
            for name in ("request_ref", "ack_ref"):
                job[name] = self.core.ref(job[name]["path"])
            refs = {name: self.core.ref(self.root / "synthetic-channels" / (job["row"]["id"] + "-" + name))
                    for name in ("receipt_ref", "cleanup_ref", "stdout_ref", "stderr_ref")}
            self.core.data[job["ack_ref"]["path"]] = refs | {
                "id": job["row"]["id"], "state": "complete", "request_ref": job["request_ref"],
                "actor": self.session.actor, "round_id": self.session.round_id, "head": self.session.head,
                "exit_code": -6, "instrument_error": None, "tainted": False,
                "termination_proved": True, "log_stability_proved": True, "signals": []}

    def valid_close(self):
        ref = self.state.close_before_session_receipt()
        return ref, self.core.load(ref["path"])

    def test_complete_15_eof_then_close_then_save(self):
        ref, raw = self.valid_close()
        self.assertTrue(raw["normal_closure"])
        self.assertEqual(len(raw["jobs"]), 15)
        self.assertLess(self.trace.index("pump"), self.trace.index("close-socket"))
        self.assertLess(self.trace.index("close-socket"), self.trace.index("save-transport"))
        self.ns.validate_close(self.core, self.session, ref)

    def test_eof_observation_not_administrative_close(self):
        self.state.server.snapshots[0]["active"] = 1
        _, raw = self.valid_close()
        self.assertTrue(raw["closed"])
        self.assertFalse(raw["quiescent"])
        self.assertFalse(raw["normal_closure"])
        self.assertTrue(self.session.log_stability_tainted)
        self.assertLessEqual(raw["client_eof_elapsed_seconds"], 5.02)

    def test_missing_one_job_not_full_table(self):
        self.state.dispatcher.jobs.pop(IDS[-1])
        ref, raw = self.valid_close()
        self.assertFalse(raw["normal_closure"])
        with self.assertRaises(ValueError):
            self.ns.validate_close(self.core, self.session, ref)

    def test_timeout_preserves_monotone_taint(self):
        self.state.dispatcher.jobs[IDS[-1]]["state"] = "timeout"
        _, raw = self.valid_close()
        self.assertFalse(raw["normal_closure"])
        self.assertTrue(raw["tainted"])

    def test_cleanup_pending_abort_only_known_jobs_no_new_poll(self):
        self.state.dispatcher.jobs[IDS[0]]["state"] = "running"
        _, raw = self.valid_close()
        self.assertIn("poll-known-job", self.trace)
        self.assertIn("abort-calibrate", self.trace)
        self.assertFalse(raw["normal_closure"])

    def test_uncertain_token_stays_pending_bounded8(self):
        self.state.dispatcher.jobs[IDS[0]] |= {"state": "cleanup_pending", "token": None}
        _, raw = self.valid_close()
        self.assertEqual(raw["pending_jobs"], [IDS[0]])
        self.assertFalse(raw["quiescent"])
        self.assertTrue(raw["tainted"])
        self.assertLessEqual(raw["cleanup_elapsed_seconds"], 8.02)

    def test_transport_errors_preserved(self):
        self.state.server.snapshots[0]["errors"] = [{"reason": "synthetic framing invalid"}]
        _, raw = self.valid_close()
        self.assertEqual(raw["errors"][0]["reason"], "synthetic framing invalid")
        self.assertTrue(raw["tainted"])

    def test_synthetic_peer_cannot_claim_physical_closure(self):
        self.state.server.snapshots[0]["synthetic_peer"] = True
        _, raw = self.valid_close()
        self.assertFalse(raw["normal_closure"])

    def test_deadline_exact_equality_taints(self):
        self.clock.value = self.state.deadline_monotonic
        with self.assertRaises(self.ns.RoundDeadlineExceeded):
            self.state.check_deadline()
        self.assertTrue(self.session.log_stability_tainted)

    def test_deadline_nan_refused(self):
        with self.assertRaises(ValueError):
            self.ns.OwnedRpcBootstrap(self.core, self.session, self.modules, self.own,
                {"context": self.context | {"deadline_monotonic": float("nan")}})

    def test_owner_changed_refused_before_factory(self):
        self.session.parent_phase_identity = lambda: IDENTITY | {"start_usec": 9}
        with self.assertRaises(ValueError):
            self.state.check_deadline()
        self.assertTrue(self.session.log_stability_tainted)
        self.assertNotIn("pump", self.trace)

    def test_context_or_deadline_mutation_refused(self):
        self.context["deadline_monotonic"] += 1
        with self.assertRaises(ValueError):
            self.state.check_deadline()

    def test_source_changed_refused_socket_still_closed(self):
        self.core.refs[str(self.path)]["sha256"] = "f" * 64
        # own is same dict in this simple double; replace the stored pin, not mutate both.
        self.core.refs[str(self.path)] = self.own | {"sha256": "b" * 64}
        with self.assertRaises(ValueError):
            self.state.close_before_session_receipt()
        self.assertTrue(self.state.server.closed)
        self.assertTrue(self.session.log_stability_tainted)

    def test_save_refused_retry_is_new_receipt_not_new_transport(self):
        self.core.save_refused = True
        with self.assertRaises(OSError):
            self.state.close_before_session_receipt()
        self.assertTrue(self.state.server.closed)
        self.core.save_refused = False
        ref = self.state.close_before_session_receipt()
        self.assertTrue(ref["path"].endswith("rpc-transport-close-2.json"))
        self.assertEqual(self.trace.count("close-socket"), 1)
        self.assertFalse(self.core.load(ref["path"])["normal_closure"])

    def test_final_consumer_refuses_mutations(self):
        ref, base = self.valid_close()
        mutations = (("closed", False), ("quiescent", False), ("normal_closure", False),
            ("completed_all_15", False), ("tainted", True), ("execution_scope", "WRAPPER_CANARY"),
            ("actor", "/root"), ("round_name", "B"), ("before_final_session_receipt", False),
            ("cleanup_elapsed_seconds", 8.1), ("client_eof_elapsed_seconds", 5.1),
            ("OS_qualified", True), ("FULL", True))
        for field, value in mutations:
            with self.subTest(field=field):
                self.core.data[ref["path"]] = base | {field: value}
                with self.assertRaises(ValueError):
                    self.ns.validate_close(self.core, self.session, ref)

    def test_terminal_request_ack_rehashed(self):
        ref, base = self.valid_close()
        changed = base["jobs"][IDS[-1]]["ack_ref"]["path"]
        self.core.refs[changed] = self.core.refs[changed] | {"sha256": "f" * 64}
        with self.assertRaises(ValueError):
            self.ns.validate_close(self.core, self.session, ref)

    def test_terminal_raw_channels_rehashed_and_negative_exit_preserved(self):
        ref, base = self.valid_close()
        self.ns.validate_close(self.core, self.session, ref)  # ACK rc -6 reste brut, pas succès métier.
        ack = self.core.data[base["jobs"][IDS[-1]]["ack_ref"]["path"]]
        changed = ack["stdout_ref"]["path"]
        self.core.refs[changed] = self.core.refs[changed] | {"sha256": "f" * 64}
        with self.assertRaises(ValueError):
            self.ns.validate_close(self.core, self.session, ref)

    def test_abort_time_included_and_over8_stays_red(self):
        self.state.dispatcher.jobs[IDS[0]]["state"] = "running"
        def slow_abort(*args):
            self.clock.value += 9
        self.state.dispatcher.abort_parent = slow_abort
        _, raw = self.valid_close()
        self.assertGreaterEqual(raw["cleanup_elapsed_seconds"], 9)
        self.assertFalse(raw["normal_closure"])
        self.assertTrue(raw["tainted"])

    def test_bootstrap_closed_flags_or_missing_refs_refused(self):
        self.session.attach_owned_rpc_bootstrap = lambda x: None
        self.core.rpc_abi = NS(validate=lambda *a, **k: {"context": self.context})
        g1 = NS(RUNTIME_ENABLED=False, OS_STARTUP_QUALIFIED=False, ADMISSION_TABLE={},
            _ACTIVE_SESSION=self.session)
        with self.assertRaisesRegex(ValueError, "fermé"):
            self.ns.validate_bootstrap(self.core, g1, self.session, {}, self.config)
        g1.RUNTIME_ENABLED, g1.OS_STARTUP_QUALIFIED, g1.ADMISSION_TABLE = True, True, {"synthetic": 1}
        with self.assertRaisesRegex(ValueError, "non prélié"):
            self.ns.validate_bootstrap(self.core, g1, self.session, {"rpc": {}}, self.config)

    def test_six_exact_module_names_pins(self):
        refs = {name: self.core.ref(self.root / "rpc" / name) for name in self.ns.MODULES}
        self.session.binding["source_refs"] += list(refs.values())
        self.ns.modules_exact(self.core, self.session, refs)
        refs.pop("rpc_peer.py")
        with self.assertRaisesRegex(ValueError, "Six"):
            self.ns.modules_exact(self.core, self.session, refs)

    def test_module_cache_collision_refused_without_import(self):
        refs = {name: self.core.ref(self.root / "rpc" / name) for name in self.ns.MODULES}
        self.session.binding["source_refs"] += list(refs.values())
        self.ns.load_modules.__globals__["sys"].modules["rpc_protocol"] = NS()
        with self.assertRaisesRegex(ValueError, "déjà chargé"):
            self.ns.load_modules(self.core, self.session, refs)

    def bootstrap_doubles(self):
        """Exécute bootstrap réel ; factories/imports sont des doubles déclarés."""
        for relative in ("session-events", "session-rpc/request", "session-rpc/ack",
                         "session-rpc/cancel", "session-rpc/enrollment"):
            (self.root / relative).mkdir(parents=True, exist_ok=True)
        rows = self.state.dispatcher.descriptors
        linked = {"context": self.context, "plan": {"descriptors": rows}}
        refs = {name: self.core.ref(self.root / "rpc" / name) for name in self.ns.MODULES}
        self.session.binding["source_refs"] += list(refs.values())
        self.core.rpc_abi = NS(validate=lambda *a, **k: linked)
        g1 = NS(RUNTIME_ENABLED=True, OS_STARTUP_QUALIFIED=True, ADMISSION_TABLE={"synthetic": 1},
            _ACTIVE_SESSION=self.session, RPC_REQUESTERS={"calibrate"}, RPC_CHILDREN={},
            SOURCE=self.root, HERE=self.root / "g1", reference=self.core.ref,
            read_published_json=lambda *a: {}, checked_json_ref=lambda *a: {}, save=lambda *a: None)
        server = Server(self.trace)
        def adapter(session, api, **kwargs):
            self.trace.append("adapter")
            return NS(session=session, api=api, **kwargs)
        def dispatch(root, context, descriptors, enrollments, adapter):
            self.trace.append("dispatcher")
            obj = Dispatcher(self.trace, descriptors)
            obj.attach_transport = lambda item: self.trace.append("attach-transport")
            return obj
        def create_server(*args):
            self.trace.append("socket-factory-DOUBLE")
            return server
        modules = {name: NS() for name in self.ns.MODULES}
        modules.update({"rpc_protocol.py": self.protocol,
            "session_rpc_adapter.py": NS(SessionRpcAdapter=adapter),
            "rpc_dispatcher.py": NS(RpcDispatcher=dispatch), "rpc_unix.py": NS(create_server=create_server)})
        def load(core, session, refs):
            self.ns.modules_exact(core, session, refs)
            self.trace.append("six-modules-pinned-DOUBLE-no-import")
            return modules
        self.ns.bootstrap.__globals__["load_modules"] = load
        self.session.attach_rpc_dispatcher = lambda d: self.trace.append("attach-g1-dispatcher")
        self.session.attach_owned_rpc_bootstrap = lambda state: self.trace.append("attach-owned-lifecycle")
        return g1, {"rpc": {"bootstrap": self.own, "modules": refs}}, server

    def test_real_bootstrap_six_modules_then_socket_then_g1_hooks(self):
        g1, decision, server = self.bootstrap_doubles()
        state = self.ns.bootstrap(self.core, g1, self.session, decision, self.config)
        self.assertIs(state.server, server)
        self.assertLess(self.trace.index("six-modules-pinned-DOUBLE-no-import"), self.trace.index("socket-factory-DOUBLE"))
        self.assertLess(self.trace.index("attach-transport"), self.trace.index("attach-g1-dispatcher"))
        self.assertLess(self.trace.index("attach-g1-dispatcher"), self.trace.index("attach-owned-lifecycle"))

    def test_real_bootstrap_wrong_owner_has_no_socket(self):
        g1, decision, server = self.bootstrap_doubles()
        self.session.parent_phase_identity = lambda: IDENTITY | {"start_sec": 111}
        with self.assertRaises(ValueError):
            self.ns.bootstrap(self.core, g1, self.session, decision, self.config)
        self.assertNotIn("socket-factory-DOUBLE", self.trace)

    def test_real_bootstrap_attach_error_closes_socket_and_taints(self):
        g1, decision, server = self.bootstrap_doubles()
        self.session.attach_owned_rpc_bootstrap = lambda state: (_ for _ in ()).throw(ValueError("synthetic late pin"))
        with self.assertRaises(ValueError):
            self.ns.bootstrap(self.core, g1, self.session, decision, self.config)
        self.assertTrue(server.closed)
        self.assertTrue(self.session.log_stability_tainted)


class G1SeamsTests(unittest.TestCase):
    def setUp(self):
        self.trace, self.clock, self.saved = [], Clock(), {}
        self.root = HERE / "synthetic-fixtures"
        self.base = {"schema": "c17-runtime78-root-rpc-transport-close-v1",
            "execution_scope": "runtime78_exact_round", "actor": "/root/environment_routes",
            "round_id": "c17-direct-round-a-123456789abc", "round_name": "A", "head": "a" * 40,
            "qa_root": str(self.root), "binding": {"path": "/synthetic/binding"},
            "source": {"path": "/synthetic/bootstrap"}, "context_ref": {"path": "/synthetic/context"},
            "plan_ref": {"path": "/synthetic/plan"}, "before_final_session_receipt": True,
            "closed": True, "quiescent": True, "normal_closure": True, "tainted": False}
        self.session = NS(root=self.root, actor=self.base["actor"], round_id=self.base["round_id"],
            round_name="A", head=self.base["head"], binding_ref=self.base["binding"],
            binding={"rpc_bootstrap_ref": self.base["source"], "rpc_context_ref": self.base["context_ref"],
                     "rpc_plan_ref": self.base["plan_ref"]}, closed=False, log_stability_tainted=False)
        self.session._owned_rpc_bootstrap = NS(close_before_session_receipt=self.close,
            check_deadline=lambda: self.trace.append("deadline"))
        self.ns = selected(HERE / "g1/runtime_session.py", (), {"require": need, "Path": Path,
            "time": self.clock, "json": json, "sys": NS(argv=["synthetic-test"]),
            "save": self.save, "reference": lambda path: {"path": str(path)},
            "checked_json_ref": lambda ref, root: copy.deepcopy(self.base),
            "PERSISTENT": frozenset(("persistent-backend", "persistent-vite"))},
            methods=("check_round_deadline", "_close_owned_rpc_transport", "stop", "wait", "publish_rpc_enrollment"))
        self.session._close_owned_rpc_transport = lambda: self.ns._close_owned_rpc_transport(self.session)
        self.session.check_round_deadline = lambda: self.ns.check_round_deadline(self.session)

    def close(self):
        self.trace.append("transport-close")
        return {"path": "/synthetic/transport-close"}

    def save(self, root, path, value):
        self.trace.append("save-" + path.name)
        self.saved[str(path)] = copy.deepcopy(value)

    def prepare_stop(self):
        self.session._defer_interrupts = False
        self.session.close_attempts = 0
        self.session._interruptions, self.session.prelaunch_errors = [], []
        self.session.handles = {"witness": {"role": "stage-witness", "termination_proved": True,
            "output_archived": True, "terminal_receipt_ref": {"path": "/synthetic/stage"}, "output_archive_errors": []}}
        self.session.decision_ref = {"path": "/synthetic/decision"}
        self.session._released_birth = lambda h: True
        self.session._launch_summary = lambda: {"unlaunched_handles": []}
        self.session._restore_interrupt_handlers_if_quiescent = lambda c: self.trace.append("restore") or True
        self.session.finish = lambda targets: self.trace.append("finish-handles") or {
            "clean": True, "cleanup": {"clean": True, "remaining_attributed": [], "ambiguities": [], "errors": []},
            "cleanup_error": None}

    def test_real_stop_transport_before_handles_and_final_save(self):
        self.prepare_stop()
        ref = self.ns.stop(self.session)
        raw = self.saved[ref["path"]]
        self.assertLess(self.trace.index("transport-close"), self.trace.index("finish-handles"))
        self.assertLess(self.trace.index("transport-close"), self.trace.index("save-session-close-1.json"))
        self.assertTrue(raw["rpc_transport_clean"])
        self.assertTrue(raw["session_closed"])
        self.assertIn("restore", self.trace)

    def test_close_error_does_not_skip_handle_cleanup(self):
        self.prepare_stop()
        self.session._owned_rpc_bootstrap.close_before_session_receipt = lambda: (_ for _ in ()).throw(OSError("synthetic write"))
        ref = self.ns.stop(self.session)
        raw = self.saved[ref["path"]]
        self.assertIn("finish-handles", self.trace)
        self.assertEqual(raw["rpc_transport_error"]["type"], "OSError")
        self.assertFalse(raw["rpc_transport_clean"])
        self.assertFalse(raw["log_stability_proved"])
        self.assertTrue(raw["log_stability_tainted"])

    def test_missing_bootstrap_cannot_make_stop_green(self):
        self.prepare_stop()
        self.session._owned_rpc_bootstrap = None
        ref = self.ns.stop(self.session)
        raw = self.saved[ref["path"]]
        self.assertIn("finish-handles", self.trace)
        self.assertFalse(raw["session_closed"])
        self.assertFalse(raw["log_stability_proved"])

    def test_close_other_scope_refused_after_cleanup(self):
        self.prepare_stop()
        self.base["execution_scope"] = "inert_fixture"
        ref = self.ns.stop(self.session)
        raw = self.saved[ref["path"]]
        self.assertFalse(raw["rpc_transport_clean"])
        self.assertIn("finish-handles", self.trace)

    def test_wait_expiry_finishes_real_body_in_finally(self):
        entry = {"name": "mapping78", "role": "stage-mapping78", "released": True}
        self.session.handles = {"mapping78": entry}
        self.session.check_round_deadline = lambda: (_ for _ in ()).throw(TimeoutError("synthetic round"))
        self.session.finish = lambda targets: self.trace.append("finish-wait")
        self.ns.wait.__globals__["RPC_CHILDREN"] = set()
        self.ns.wait.__globals__["RPC_REQUESTERS"] = set()
        with self.assertRaises(TimeoutError):
            self.ns.wait(self.session, entry)
        self.assertIn("finish-wait", self.trace)
        self.assertTrue(self.session.log_stability_tainted)

    def test_deadline_missing_hook_refused(self):
        self.session._owned_rpc_bootstrap = None
        with self.assertRaisesRegex(ValueError, "absents"):
            self.ns.check_round_deadline(self.session)

    def test_real_enrollment_published_before_registry_then_release(self):
        entry = {"name": "calibrate", "environment": {"C17_RPC_CONTEXT_REF": "synthetic-ref"},
            "released": False, "root_identity": IDENTITY, "verified_before_release": IDENTITY,
            "outer_deadline_monotonic": 200, "process": NS(poll=lambda: None)}
        path = self.root / "session-rpc/enrollment/calibrate.json"
        # Use a real declared fixture directory only to satisfy the real parent guard.
        path.parent.mkdir(parents=True, exist_ok=True)
        self.session.binding["source_refs"] = [{"path": "/synthetic/source"}]
        descriptors = [{"id": name} for name in IDS]
        self.session.binding["rpc_descriptors"] = {row["id"]: row for row in descriptors}
        context = {"context_id": "b" * 32}
        dispatcher = NS(context=context, descriptors=descriptors,
            enroll_requester=lambda value: self.trace.append("enroll-registry"))
        self.session._rpc_dispatcher = dispatcher
        self.session.ledger = NS(attribute=lambda: self.trace.append("attribute"),
            info=lambda pid: IDENTITY | {"status": 1},
            unchanged=lambda a, b: all(a[k] == b[k] for k in IDENTITY))
        self.session.verify_rpc_plan = lambda: {"descriptors": descriptors}
        env = {"context": context, "enrollment_path": str(path)}
        published = {}
        glob = self.ns.publish_rpc_enrollment.__globals__
        glob.update({"RPC_REQUESTERS": {"calibrate"},
            "validate_rpc_context_ref": lambda *a, **k: env,
            "PUBLICATION_PROTOCOL": "exclusive-pending-fsync-hardlink-v1",
            "publish_json": lambda root, path, value: (published.update({str(path): value}),
                                                       self.trace.append("publish-enrollment")),
            "read_published_json": lambda root, path: published[str(path)]})
        self.ns.publish_rpc_enrollment(self.session, entry, {"path": "/synthetic/gate"})
        self.trace.append("publish-release")  # caller ordering also checked against real start AST below.
        self.assertLess(self.trace.index("publish-enrollment"), self.trace.index("enroll-registry"))
        self.assertLess(self.trace.index("enroll-registry"), self.trace.index("publish-release"))


class StaticAndConsumerTests(unittest.TestCase):
    def test_flags_and_tables_unchanged_false_empty(self):
        tree = ast.parse((HERE / "g1/runtime_session.py").read_text())
        values = {}
        for node in tree.body:
            target = node.targets[0] if isinstance(node, ast.Assign) else node.target if isinstance(node, ast.AnnAssign) else None
            if isinstance(target, ast.Name) and target.id in {"RUNTIME_ENABLED", "OS_STARTUP_QUALIFIED", "CAPABILITIES",
                                                             "ADMISSION_TABLE", "WRAPPER_ADMISSION_TABLE"}:
                values[target.id] = ast.literal_eval(node.value)
        self.assertIs(values["RUNTIME_ENABLED"], False)
        self.assertIs(values["OS_STARTUP_QUALIFIED"], False)
        self.assertFalse(any(values["CAPABILITIES"].values()))
        self.assertEqual(values["ADMISSION_TABLE"], {})
        self.assertEqual(values["WRAPPER_ADMISSION_TABLE"], {})

    def test_start_keeps_enrollment_before_release_and_guard_before_Popen(self):
        tree = ast.parse((HERE / "g1/runtime_session.py").read_text())
        cls = next(node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == "Session")
        start = next(node for node in cls.body if isinstance(node, ast.FunctionDef) and node.name == "start")
        calls = [node for node in ast.walk(start) if isinstance(node, ast.Call)]
        enroll = next(node.lineno for node in calls if isinstance(node.func, ast.Attribute) and node.func.attr == "publish_rpc_enrollment")
        release = next(node.lineno for node in calls if isinstance(node.func, ast.Name) and node.func.id == "publish_json"
            and len(node.args) > 1 and isinstance(node.args[1], ast.Name) and node.args[1].id == "release")
        check = next(node.lineno for node in calls if isinstance(node.func, ast.Attribute) and node.func.attr == "check_round_deadline")
        popen = next(node.lineno for node in calls if isinstance(node.func, ast.Attribute) and node.func.attr == "Popen")
        self.assertLess(enroll, release)
        self.assertLess(check, popen)

    def test_coordinate_bootstrap_precedes_first_workload_final_join_after_stop(self):
        tree = ast.parse((HERE / "successor/runtime78_coordinator.py").read_text())
        node = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "coordinate")
        calls = [n for n in ast.walk(node) if isinstance(n, ast.Call)]
        boot = next(n.lineno for n in calls if isinstance(n.func, ast.Attribute) and n.func.attr == "bootstrap")
        first = next(n.lineno for n in calls if isinstance(n.func, ast.Name) and n.func.id == "execute"
            and n.args and isinstance(n.args[0], ast.Constant) and n.args[0].value == "prepare-runtime")
        stop = next(n.lineno for n in calls if isinstance(n.func, ast.Attribute) and n.func.attr == "stop")
        validate = next(n.lineno for n in calls if isinstance(n.func, ast.Attribute) and n.func.attr == "validate_close")
        self.assertLess(boot, first)
        self.assertLess(stop, validate)

    def test_real_bridge_requires_terminal_transport_fields(self):
        ns = selected(HERE / "successor/g1_bridge.py", ("require", "runtime_scope", "verify_shutdown"), {})
        config = {"campaign": "A", "actor": "/root/environment_routes", "round_id": "logical",
            "head": "a" * 40, "root": "/synthetic"}
        raw = config | {"round_name": "A", "qa_root": config["root"], "execution_scope": "runtime78_exact_round",
            "schema": "c17-runtime78-owned-session-close-v1", "session_closed": True,
            "clean": True, "cleanup_error": None, "log_stability_tainted": False,
            "log_stability_proved": True, "cleanup": {"clean": True,
                "remaining_attributed": [], "ambiguities": [], "errors": []},
            "launched_services": ["backend", "vite"], "unlaunched_handles": [],
            "ports_absence_proved": True, "ports_absent": [17593, 5173],
            "ports_absence_receipt": {"path": "/synthetic/ports"},
            "rpc_transport_closed": True, "rpc_transport_quiescent": True, "rpc_transport_clean": True,
            "rpc_transport_error": None, "rpc_transport_receipt": {"path": "/synthetic/rpc"}}
        ns.verify_shutdown(raw, config, final=True)
        for field in ("rpc_transport_closed", "rpc_transport_quiescent", "rpc_transport_clean", "rpc_transport_receipt"):
            with self.subTest(field=field):
                mutant = dict(raw)
                mutant.pop(field)
                with self.assertRaises(ValueError):
                    ns.verify_shutdown(mutant, config, final=True)
