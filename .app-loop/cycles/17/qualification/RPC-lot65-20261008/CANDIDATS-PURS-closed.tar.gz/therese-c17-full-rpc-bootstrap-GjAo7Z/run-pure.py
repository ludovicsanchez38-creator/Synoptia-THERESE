"""Exécuteur pur AST/doubles ; aucun instrument complet importé."""
from __future__ import annotations
import ast
from datetime import datetime, UTC
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import sys
import time
import unittest

ROOT = Path(__file__).resolve().parent
PATHS = [ROOT / path for path in ("successor/root_rpc_bootstrap.py", "successor/runtime78_coordinator.py",
    "successor/g1_bridge.py", "g1/runtime_session.py", "g1/root_stage_relay.py", "tests/test_bootstrap.py", "run-pure.py")]


def pins():
    return {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in PATHS}


def guarded(event, args):
    if event.startswith(("subprocess.", "socket.", "ctypes.", "os.exec", "os.spawn", "os.posix_spawn",
                         "os.fork", "os.kill", "os.system", "pty.spawn")):
        raise RuntimeError("Pure guard rejects " + event)
    if event == "import" and args[0] in {"runtime78_core", "runtime78_coordinator", "runtime_session",
        "session_rpc_adapter", "rpc_protocol", "rpc_client", "rpc_dispatcher", "rpc_unix", "rpc_peer"}:
        raise RuntimeError("No full instrumentation import " + args[0])
    if event == "open" and len(args) > 2 and isinstance(args[2], int) and args[2] & (os.O_WRONLY | os.O_RDWR):
        path = Path(os.fsdecode(args[0])) if isinstance(args[0], (str, bytes)) else None
        if path is not None and not path.resolve().is_relative_to(ROOT / "synthetic-fixtures"):
            raise RuntimeError("Pure write outside declared fixtures " + str(path))


def main():
    before = pins()
    for path in PATHS:
        ast.parse(path.read_text(), filename=str(path))
    sys.addaudithook(guarded)
    start = datetime.now(UTC).isoformat()
    tick = time.monotonic()
    spec = importlib.util.spec_from_file_location("bootstrap_pure_tests", ROOT / "tests/test_bootstrap.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    suite = unittest.defaultTestLoader.loadTestsFromModule(module)
    stream = io.StringIO()
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    after = pins()
    print(json.dumps({"schema": "c17-pure-bootstrap-test-result-v1", "actor": "/root/shared4_execution",
        "started_at": start, "completed_at": datetime.now(UTC).isoformat(),
        "elapsed_seconds": time.monotonic() - tick, "tests": result.testsRun,
        "failures": len(result.failures), "errors": len(result.errors), "skipped": len(result.skipped),
        "passed": result.wasSuccessful() and before == after,
        "sources_before": before, "sources_after": after, "sources_unchanged": before == after,
        "output": stream.getvalue(), "synthetic_fixtures_only": True,
        "full_instrument_import": False, "process_socket_signal_libproc": False,
        "runtime_admission": False, "OS_qualified": False, "FULL": False}, ensure_ascii=False))
    return 0 if result.wasSuccessful() and before == after else 1


if __name__ == "__main__":
    raise SystemExit(main())
