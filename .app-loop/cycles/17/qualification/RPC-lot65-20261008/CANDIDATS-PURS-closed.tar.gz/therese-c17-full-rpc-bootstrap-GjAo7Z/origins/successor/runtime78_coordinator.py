"""Coordinateur proposé runtime78 : Session exacte ou fermeture totale.

Le code d'orchestration ci-dessous ne démarre rien dans ce lot. G1, G5,
les profils réellement calibrés et chaque commande/revue root sont des
prérequis exacts. Aucun runtime.py start/stop de secours n'existe.
"""
from __future__ import annotations

import argparse
import contextlib
import json
import os
from pathlib import Path
import sys
import time
import traceback

import runtime78_core as core
import current_contract
import package78
import g1_bridge
import sql_worker
import sql_protocol
import sql_read_view
import runtime_bounds
import calibration_round_producer
import full_rpc_parent_binding as full_rpc_binding

SESSION_METHODS = ('start', 'wait', 'stop_services', 'stop', 'services_receipt',
                   'observe_owned_listeners', 'parent_phase_identity', 'await_root_review',
                   'await_stage_binding', 'admit_stage_binding')
# Inventaire historique des huit bornes nulles, désormais proposées exactement
# par runtime_bounds. Les services gardent 50 s de startup, jamais une lifetime.
FORMER_UNSET_BOUNDS = ('persistent-backend', 'persistent-vite', 'build-calibrations-v3', 'density',
                       'B1753-power', 'mapping78', 'contract-review-wait', 'independent-review-wait')
CALIBRATION_BUILDER_SHA256 = '008546a0f25ad6a0b002a8320011b5ec6aaf4f8b9d62d22a6e2ff6ab0b97c42f'


def arguments(config: dict, root: Path, decision_ref: dict, reviewed: dict) -> dict:
    python, node = str(core.PYTHON), str(core.NODE)
    successor = root / 'runtime78-successor'
    decision_argv = ['--decision', decision_ref['path'], '--decision-sha256', decision_ref['sha256']]
    trace = [node, '--import', str(root / 'trace-chrome.mjs')]
    result = {
        'prepare-runtime': ([python, str(root / 'runtime/runtime.py'), 'prepare'], 'web', 120),
        'persistent-backend': ([python, '-m', 'uvicorn', config['factory'], '--factory', '--loop', 'asyncio',
            '--host', '127.0.0.1', '--port', '17593'], 'web', 50),
        'persistent-vite': ([str(core.QA_SOURCE / 'src/frontend/node_modules/.bin/vite'), '--host', '127.0.0.1',
            '--port', '5173', '--strictPort', '--config', str(root / 'runtime/vite.runtime.config.mjs'), '--configLoader', 'native'], 'web', 50),
        'readiness': ([python, str(successor / 'readiness_owned.py'), str(root), *decision_argv], 'web', 120),
        'calibrate': ([python, str(root / 'runtime/calibrate-all.py')], 'web', 1200),
        'recipe-general': ([*trace, str(root / 'runtime/recette-c17.mjs')], 'web', 360),
        'recipe-invoices': ([*trace, str(root / 'runtime/recette-facturation-p160-v2.mjs')], 'web', 360),
        'recipe-crm': ([*trace, str(root / 'runtime/recette-crm-focus.mjs')], 'web', 360),
        'density': ([python, str(successor / 'density_owned.py'), str(root), *decision_argv], 'web', 1500),
    }
    instruments = root / 'complements/instruments'
    for name, script in [('B1713', 'b1713-clavier-v3.mjs'), ('P157-800', 'p157-pipeline-root-oracle.mjs'),
                         ('P157-1440', 'p157-pipeline-root-oracle.mjs'), ('B1755', 'b1755-garde-v3.mjs'), ('P162', 'p162-colonnes-v3.mjs')]:
        guard = ['--import', str(instruments / 'p162-garde-get-v3.mjs')] if name == 'P162' else []
        result[name] = ([*trace, *guard, str(instruments / script)], 'web', 360)
    if 'contract' in reviewed:
        contract_sha = reviewed['contract']['sha256']
        for name in ('B1753', 'B1753-power', 'B1760'):
            script = 'preparer-harness-b1753-power.py' if name.endswith('-power') else 'preparer-et-executer-harness-root-stack.py'
            result[name] = ([python, str(instruments / script), '--group', 'B1753' if name.endswith('-power') else name,
                '--actor', config['actor'], '--round-id', config['round_id'], '--out', str(root / 'complements/runs' / name),
                '--reviewed-contract-sha', contract_sha], 'sql', 360)
    if 'calibration_request' in reviewed:
        request_ref = reviewed['calibration_request']
        core.checked(request_ref, root=root)
        result['build-calibrations-v3'] = ([python, str(root / 'build-calibrations-v3.py'),
            '--request', request_ref['path'], '--request-sha256', request_ref['sha256']], 'sql', 120)
    stack = None
    if (root / 'runtime/pile-reprise.json').is_file():
        stack = core.stack_profile(config, root)
    if stack:
        result['coverage'] = ([*trace, str(root / 'runtime/couverture-ecran-c17.mjs'), '--base',
            'http://127.0.0.1:5173/?port=17593', '--expected-data-dir', stack['data_dir'], '--sortie', str(root / 'coverage'),
            '--largeurs', '1440,800', '--themes', 'light,dark'], 'web', 1500)
    if 'visual' in reviewed and 'apple' in reviewed:
        result['mapping78'] = ([python, str(root / 'build-runtime78-map.py'), str(root), '--out', str(root / 'runtime78-map'),
            '--visual-review', reviewed['visual']['path'], '--pdf-review', reviewed['apple']['path']], 'sql', 120)
    for name, reference in reviewed.get('sql_requests', {}).items():
        core.need(name in sql_protocol.PHASES, 'Demande hors des trois workers SQL')
        result[name] = ([python, str(successor / 'sql_worker.py'), name, str(root),
            '--request', reference['path'], '--request-sha256', reference['sha256']], 'sql', 120)
    return result


def command_spec(config: dict, root: Path, stage: str, decision_ref: dict, binding: dict, reviewed: dict,
                 *, session=None, binding_ref: dict | None = None, stage_admissions: dict | None = None,
                 rpc_preparation: dict | None = None) -> dict:
    definitions = arguments(config, root, decision_ref, reviewed)
    core.need(stage in definitions, 'Commande non disponible avant sa vraie revue/manifest')
    argv, mode, inherited_bound = definitions[stage]
    g1_name, _ = g1_bridge.name_role(stage)
    row = binding['commands'].get(g1_name)
    if stage in sql_protocol.PHASES or stage == 'build-calibrations-v3':
        core.need(row is None, 'Worker SQL/request ou builder post-STOP ne peut être prélié avant sa vraie revue')
    plan = binding.get('stage_plans', {}).get(g1_name)
    core.need(isinstance(row, dict) or isinstance(plan, dict), 'Binding/plan exact d’étape absent ; aucune référence future devinée')
    timeout = inherited_bound if inherited_bound is not None else (row or plan).get('timeout_seconds')
    runtime_bounds.exact_bound(g1_name, timeout)
    core.need(isinstance(timeout, (int, float)) and not isinstance(timeout, bool) and timeout > 0, 'Borne root absente : ' + stage)
    env = core.environment(config, root, mode, g1_name)
    combined = stage in ('persistent-backend', 'persistent-vite')
    if combined:
        stdout = root / ('runtime/backend-runtime.log' if stage.endswith('backend') else 'runtime/vite-runtime.log')
        stderr = None
    else:
        ledger = root / 'ledger' / ('start-runtime' if stage == 'readiness' else stage)
        stdout, stderr = ledger / 'stdout.log', ledger / 'stderr.log'
    spec = g1_bridge.binding_spec(stage, argv, mode, timeout, env, str(root),
                                 str(stdout), str(stderr) if stderr else None, combined)
    if stage in full_rpc_binding.direct.DIRECT_PARENTS:
        core.need(isinstance(rpc_preparation, dict), "Préparation RPC 15/root manquante avant binding parent")
        spec = full_rpc_binding.coordinator_parent(stage, spec,
            blueprint=rpc_preparation["blueprint"], bundle=rpc_preparation["bundle"],
            git_ref=rpc_preparation["git_ref"], reviewed=reviewed)
    if row is not None:
        core.need(row == spec, 'Binding ne correspond pas à la commande/cwd/env/borne/sinks exacts : ' + stage)
    else:
        core.need(session is not None and isinstance(binding_ref, dict) and isinstance(stage_admissions, dict),
                  'Admission d’étape vivante absente')
        bound = binding['review_wait_bounds']['stage-binding-wait']
        runtime_bounds.exact_bound('stage-binding-wait', bound, wait=True)
        core.need(isinstance(bound, (int, float)) and not isinstance(bound, bool) and 0 < bound <= 1500,
                  'Attente admission d’étape sans borne exacte')
        # Pas de transport/GO simulé. G1 doit effectivement fournir ces méthodes
        # et vérifier l'origine réelle avant d'ajouter une admission immuable.
        delivery = session.await_stage_binding(g1_name, expected_command=spec,
            initial_binding_ref=binding_ref, timeout=bound)
        for reference in ('binding', 'decision', 'origin'):
            core.checked(delivery[reference])
        stage_binding = core.load(delivery['binding']['path'])
        stage_decision = core.load(delivery['decision']['path'])
        g1_bridge.verify_stage_binding_links(delivery, stage_binding, stage_decision,
            stage, spec, config, binding_ref, binding)
        session.admit_stage_binding(binding_ref=delivery['binding'], decision_ref=delivery['decision'],
                                    origin_ref=delivery['origin'])
        stage_admissions[g1_name] = delivery  # registre d'observations, pas modification du binding initial.
    return spec


def verify_execution(receipt_ref: dict, config: dict, root: Path, stage: str, spec: dict,
                     *, session_ref: dict, session_decision: dict, binding_ref: dict, module_ref: dict,
                     stage_admission: dict | None = None) -> dict:
    raw = core.load(core.checked(receipt_ref, root=root))
    package78.same_round(raw, config)
    core.need(raw.get('admission') == session_ref and raw.get('binding') == binding_ref,
              'Reçu sans chaîne de décisions/binding exacte')
    if stage_admission is not None:
        core.need(raw.get('stage_binding') == stage_admission['binding']
                  and raw.get('stage_decision') == stage_admission['decision']
                  and raw.get('stage_origin') == stage_admission['origin'], 'Admission tardive absente du reçu réel')
    effective_env = g1_bridge.effective_environment(spec, raw, config, session_ref,
                                                   session_decision, binding_ref, module_ref)
    g1_bridge.verify_stage(raw, stage, spec, config, effective_env)
    for channel in ('stdout', 'stderr'):
        core.checked(raw[channel], root=root)
    return raw


def emit_execution(root: Path, config: dict, raw: dict, receipt_ref: dict, stage: str,
                   *, source_before: dict, source_after: dict) -> dict:
    # Une enveloppe dérivée énumère sa vraie source. Elle n'est jamais un brut
    # ni un nouveau lancement, et ne prétend pas exécuter runtime.py start.
    envelope = {key: raw[key] for key in ('actor', 'round_id', 'head', 'started_at', 'completed_at',
        'exit_code', 'stdout', 'stderr', 'instrument_error')}
    envelope.update({'kind': 'subprocess_execution_derived_from_real_owned_session', 'command': raw['argv'],
        'stage_id': stage, 'g1_stage_id': raw['stage_id'], 'real_session_receipt': receipt_ref,
        'raw_not_relabelled': True, 'cwd': raw['cwd'], 'effective_environment': raw['environment'],
        'source_check_before': source_before, 'source_check_after': source_after})
    ledger_stage = 'start-runtime' if stage == 'readiness' else stage
    path = root / 'ledger' / ledger_stage / 'execution.json'
    core.save_new(root, path, envelope)
    return core.ref(path)


def in_process(root: Path, config: dict, session, stage: str, operation, *, operation_source: dict) -> tuple[dict, object]:
    core.need(core.RUNTIME_ENABLED, 'Phase in-process fermée dans ce lot statique')
    identity = session.parent_phase_identity()
    g1_bridge.identity(identity)
    core.need(identity['pid'] == os.getpid() and identity['uid'] == os.getuid(),
              'Parent in-process différent du parent réellement observé par Session')
    core.need(stage not in ('bind-current-context-contract', 'eight-logs-review', 'package78'),
              'Phase SQL sans worker OS borné admis : aucun fallback parent non confiné')
    core.checked(operation_source)
    started = core.now()
    before = core.sources_unchanged(config)
    ledger = root / 'ledger' / stage
    core.inside(root, ledger / 'stdout.log')
    ledger.mkdir(mode=0o700, parents=True, exist_ok=False)
    out_fd = os.open(ledger / 'stdout.log', os.O_CREAT | os.O_EXCL | os.O_WRONLY | os.O_NOFOLLOW, 0o600)
    try:
        err_fd = os.open(ledger / 'stderr.log', os.O_CREAT | os.O_EXCL | os.O_WRONLY | os.O_NOFOLLOW, 0o600)
    except BaseException:
        os.close(out_fd)
        raise
    code, error, result = 0, None, None
    with os.fdopen(out_fd, 'w', buffering=1) as out, os.fdopen(err_fd, 'w', buffering=1) as err:
        try:
            with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
                result = operation()
                print(json.dumps(result, ensure_ascii=False), flush=True)
        except BaseException as caught:
            code = 1
            error = {'type': type(caught).__name__, 'message': str(caught)}
            traceback.print_exc(file=err)
        finally:
            for stream in (out, err):
                stream.flush()
                os.fsync(stream.fileno())
    completed = core.now()
    after = core.sources_unchanged(config)
    core.need(before == after, 'Source changée pendant phase in-process')
    envelope = {'kind': 'in_process_owned_phase', 'actor': config['actor'], 'round_id': config['round_id'],
        'head': core.HEAD, 'command': list(sys.argv), 'operation': stage, 'operation_source': operation_source,
        'parent_identity_observed': identity, 'started_at': started, 'completed_at': completed, 'exit_code': code,
        'instrument_error': error, 'stdout': core.ref(ledger / 'stdout.log'), 'stderr': core.ref(ledger / 'stderr.log'),
        'source_check_before': before, 'source_check_after': after, 'no_subprocess_command_claimed': True}
    path = ledger / 'execution.json'
    core.save_new(root, path, envelope)
    core.need(code == 0, 'Phase in-process échouée, bruts conservés : ' + stage)
    return core.ref(path), result


def await_exact_review(root: Path, config: dict, session, phase: str,
                       *, timeout: float, expected: dict) -> dict:
    core.need(core.RUNTIME_ENABLED, 'Attente de décision fermée dans ce lot statique')
    runtime_bounds.exact_bound('contract-review-wait' if phase == 'contract-review' else 'independent-review-wait', timeout, wait=True)
    core.need(isinstance(timeout, (int, float)) and not isinstance(timeout, bool) and 0 < timeout <= 1500,
              'Attente revue non bornée ou hors plafond1500 refusée')
    # Le transport réel doit recevoir l'origine root et ses références APRÈS
    # observation. Aucun SHA futur imprévisible n'est prétendu préapprouvé.
    # L'API de relais est proposée ici mais non admise : aucune porte ne s'ouvre.
    delivered = session.await_root_review(phase, expected_refs=expected, timeout=timeout)
    core.checked(delivered['origin'])
    decision_ref = delivered['decision']
    decision = core.admission(decision_ref, phase, config=config, root=root)
    core.need(decision['root_review_origin'] == delivered['origin']
              and all(decision['reviewed_refs'][key] == value for key, value in expected.items()), 'Revue réelle autre référence/origine')
    return {'decision': decision, 'decision_ref': decision_ref, 'review': delivered.get('review')}


def build_calibrations_after_stop(root: Path, config: dict, decision_ref: dict,
                                 session_ref: dict, binding_ref: dict, stop_ref: dict,
                                 reviewed: dict, execute) -> dict:
    """Les contrôles ont été observés avant STOP ; seuls les records sont écrits après."""
    checkout_ref = core.ref(root / 'authorization/source-checkout.json')
    request_ref = calibration_round_producer.publish_request(root,
        core.ref(root / 'prepared-config.json'), checkout_ref,
        decision_ref, session_ref, binding_ref, stop_ref)
    reviewed['calibration_request'] = request_ref
    build_ref = execute('build-calibrations-v3')
    build_execution = core.load(core.checked(build_ref, root=root))
    build_stdout = core.checked(build_execution['stdout'], root=root).read_text(encoding='utf-8')
    lines = build_stdout.splitlines()
    core.need(len(lines) == 1, 'Builder six calibrations sans sortie unique')
    built = json.loads(lines[0])
    index_ref = core.ref(root / 'calibration-records-v3/index.json')
    core.need(built.get('status') == 'six_records_built_from_closed_round_not_FULL'
              and built.get('index') == index_ref,
              'Sortie builder différente des six calibrations closes')
    index = core.load(core.checked(index_ref, root=root))
    core.need(index.get('schema') == 'c17-calibration-records-v3-index-v1'
              and index.get('actor') == config['actor']
              and index.get('round_id') == config['round_id']
              and index.get('head') == config['head']
              and isinstance(index.get('request'), dict)
              and all(index['request'].get(key) == request_ref.get(key)
                      for key in ('path', 'sha256'))
              and isinstance(index.get('actual_stop'), dict)
              and all(index['actual_stop'].get(key) == stop_ref.get(key)
                      for key in ('path', 'sha256'))
              and index.get('count') == 6
              and isinstance(index.get('calibrations'), list)
              and len(index['calibrations']) == 6,
              'Index des six calibrations absent/étranger')
    for calibration_ref in index['calibrations']:
        core.checked(calibration_ref, root=root)
    reviewed.pop('calibration_request')  # La revue package conserve son schéma historique.
    return index_ref


def coordinate(root: Path, decision_ref: dict, binding_ref: dict, *, expected_head: str,
               rpc_preparation: dict | None = None) -> dict:
    core.need(core.RUNTIME_ENABLED, 'Runtime fermé dans ce lot statique')
    core.configure_direct_round(root, binding_ref, expected_head=expected_head)
    config = core.load(core.round_root(root) / 'prepared-config.json')
    core.config_identity(config, root)
    core.need(core.sha(root / 'build-calibrations-v3.py') == CALIBRATION_BUILDER_SHA256,
              'Builder six calibrations v3 gelé différent')
    decision = core.admission(decision_ref, 'runtime', config=config, root=root)
    binding = core.load(core.checked(binding_ref))
    core.need(binding['schema'] == 'c17-runtime78-session-binding-v1' and binding['actor'] == config['actor']
              and binding['round_id'] == config['round_id'] and binding['head'] == core.HEAD
              and binding['qa_root'] == str(root), 'Binding Session étranger/non revu')
    core.need(decision['session_binding'] == binding_ref, 'Décision ne porte pas le binding exact')
    session_ref = decision['session_decision']
    session_decision = core.load(core.checked(session_ref))
    g1_bridge.verify_decision_links(decision_ref, decision, session_ref, session_decision,
                                   binding_ref, binding, config)
    canaries = core.load(core.checked(decision['fresh_OS_canaries']))
    package78.same_round(canaries, config)
    core.need(canaries['status'] == 'passed' and canaries['instrument_error'] is None
              and canaries['cleanup'] == [] and canaries['profiles'] == binding['profiles']
              and canaries['fresh_lock_import_checks'] is True, 'Canaris réels/profils/imports frais non admis')
    module = core.import_admitted(decision['session']['module'], 'runtime78_admitted_session')
    core.need(module.API_SCHEMA == core.SESSION_ABI, 'Session ABI différente')
    core.need(all(callable(getattr(module.Session, name, None)) for name in SESSION_METHODS), 'API Session incomplète avant allocation')
    session = module.Session(root, actor=config['actor'], round_id=config['round_id'], round_name=config['campaign'],
        decision_ref=session_ref, binding_ref=binding_ref, expected_head=expected_head)
    core.need(all(callable(getattr(session, name, None)) for name in SESSION_METHODS), 'API réelle Session incomplète')
    reviewed: dict = {}
    stage_admissions: dict = {}
    own_source = core.ref(Path(__file__))
    final_cleanup = None
    primary_error = None
    result = None

    def execute(stage: str) -> dict:
        before = core.sources_unchanged(config)
        spec = command_spec(config, root, stage, decision_ref, binding, reviewed,
                            session=session, binding_ref=binding_ref, stage_admissions=stage_admissions,
                            rpc_preparation=rpc_preparation)
        if stage in core.UI_CONTEXTS or stage.startswith('recipe-') or stage == 'coverage':
            session.observe_owned_listeners(stage, [17593, 5173], root / 'ownership-traces.jsonl')
        entry = g1_bridge.start(session, stage, spec)
        receipt = session.wait(entry)
        raw = verify_execution(receipt, config, root, stage, spec, session_ref=session_ref,
            session_decision=session_decision, binding_ref=binding_ref, module_ref=decision['session']['module'],
            stage_admission=stage_admissions.get(g1_bridge.name_role(stage)[0]))
        after = core.sources_unchanged(config)
        core.need(before == after, 'Sources changées pendant cette étape réelle')
        return emit_execution(root, config, raw, receipt, stage, source_before=before, source_after=after)

    def execute_sql(stage: str, payload: dict, phase_decision_ref: dict) -> dict:
        request_ref = sql_worker.prepare_request(root, config, stage, payload, decision_ref, phase_decision_ref)
        reviewed.setdefault('sql_requests', {})[stage] = request_ref
        execution_ref = execute(stage)  # vrai enfant G1, sql, deux FD directs, timeout du binding exact.
        execution = core.load(core.checked(execution_ref, root=root))
        stdout = core.checked(execution['stdout'], root=root).read_bytes()
        result = sql_protocol.parse_stdout(stdout, stage, config, request_ref)
        for key in ('output', 'worker_receipt'):
            core.checked(result[key], root=root)
        worker = core.load(result['worker_receipt']['path'])
        request = core.load(core.checked(request_ref, root=root))
        core.need(worker['request'] == request_ref and worker['output'] == result['output']
            and worker['worker_source'] == core.ref(root / 'runtime78-successor/sql_worker.py')
            and worker['stage_id'] == stage and worker['mode'] == 'sql'
            and worker['read_view'] == request['read_view']
            and worker['runtime_decision'] == decision_ref and worker['phase_decision'] == phase_decision_ref
            and worker['configuration'] == request['configuration'] and worker['inputs'] == payload
            and worker['session_binding'] == binding_ref == request['session_binding']
            and worker['source_checkout'] == request['source_checkout']
            and worker['expected_head'] == core.HEAD == request['expected_head']
            and type(worker['qualified']) is int and worker['qualified'] == 0
            and worker['source_check_before'] == worker['source_check_after'],
            'Worker/requête/sortie/source/contexte différents')
        package78.same_round(worker, config)
        read_view = sql_read_view.verify_parent_view(core, root, worker['read_view'])
        core.need(worker['read_copies_actually_rehashed'] == read_view['copies'], 'Copies effectivement rehashées différentes')
        core.sources_unchanged(config)
        return result['output']

    try:
        execute('prepare-runtime')
        # Services persistants : deux FD combinés exclusifs, pas ledger vert
        # fictif pour un service encore vivant. G1 garde leurs vrais births.
        for stage in ('persistent-backend', 'persistent-vite'):
            spec = command_spec(config, root, stage, decision_ref, binding, reviewed)
            g1_bridge.start(session, stage, spec)
        services = g1_bridge.verify_services(session.services_receipt(), config)
        for service in ('backend', 'vite'):
            core.checked(services[service]['start_receipt'], root=root)
        core.save_new(root, root / 'ledger/services-observation.json', services)
        manifest = root / 'runtime/pile-reprise.json'
        stack = core.stack_profile(config, root)
        for role in ('backend', 'vite'):
            real = services[role]
            stack[role].update({'pid': real['identity']['pid'], 'birth_identity': real['identity']})
        stack['head_at_start'] = core.HEAD
        stack['offline_factory_sha256'] = config['product_sources']['tests/couverture/backend_offline.py']
        stack['status'] = 'starting'
        core.rewrite_owned(root, manifest, core.sha(manifest), stack)
        execute('readiness')
        in_process(root, config, session, 'preserve-running-byte-exact', lambda: preserve_running(root, config), operation_source=own_source)
        execute('calibrate')
        for stage in ('recipe-general', 'recipe-invoices', 'recipe-crm', 'density'):
            execute(stage)
        contract = execute_sql('bind-current-context-contract', {}, decision_ref)
        reviewed['contract'] = contract
        delivery = await_exact_review(root, config, session, 'contract-review',
            timeout=binding['review_wait_bounds']['contract-review-wait'], expected={'contract': contract,
                'running_copy': core.ref(root / 'runtime/pile-reprise-running-preserved.json')})
        current_contract.require_review(root, config, delivery['decision_ref'], contract)
        for stage in (*core.UI_CONTEXTS, 'B1753', 'B1753-power', 'B1760', 'coverage'):
            execute(stage)

        def stop_services() -> dict:
            cleanup_ref = session.stop_services()
            cleanup = core.load(core.checked(cleanup_ref, root=root))
            g1_bridge.verify_shutdown(cleanup, config, final=False)
            core.checked(cleanup['ports_absence_receipt'], root=root)
            stack = core.stack_profile(config, root)
            stack['status'] = 'stopped'
            stack['stopped_at'] = core.now()
            core.rewrite_owned(root, manifest, core.sha(manifest), stack)
            return cleanup_ref

        stop_ref, cleanup_ref = in_process(root, config, session, 'stop-runtime', stop_services, operation_source=own_source)
        index_ref = build_calibrations_after_stop(root, config, decision_ref, session_ref,
            binding_ref, stop_ref, reviewed, execute)
        log_ref = execute_sql('eight-logs-review', {'stop_execution': stop_ref, 'service_cleanup': cleanup_ref}, decision_ref)
        reviewed.update({'logs': log_ref, 'calibrations': index_ref})
        for key in ('visual', 'apple'):
            expected = {'coverage': core.ref(root / 'coverage/rapport.json')} if key == 'visual' else {
                'harness': core.ref(root / 'complements/runs/B1760/harness-receipt.json'),
                'exports': pdf_review_inputs(root)}
            delivery = await_exact_review(root, config, session, 'independent-review',
                timeout=binding['review_wait_bounds']['independent-review-wait'], expected=expected)
            reference = delivery['review']
            core.checked(reference)
            core.need(delivery['decision']['reviewed_refs'][key] == reference, 'Revue indépendante non livrée par root')
            reviewed[key] = reference
        execute('mapping78')
        reviewed['mapping'] = core.ref(root / 'runtime78-map/mapping78.json')
        delivery = await_exact_review(root, config, session, 'independent-review',
            timeout=binding['review_wait_bounds']['independent-review-wait'], expected={'mapping': reviewed['mapping']})
        reviewed['semantic'] = delivery['review']
        core.need(delivery['decision']['reviewed_refs']['semantic'] == reviewed['semantic'], 'Revue78 non livrée par root')
        delivery = await_exact_review(root, config, session, 'package-review',
            timeout=binding['review_wait_bounds']['independent-review-wait'], expected=reviewed)
        package_decision_ref = delivery['decision_ref']
        package_ref = execute_sql('package78', {key: reviewed[key] for key in
            ('mapping', 'visual', 'apple', 'semantic', 'logs', 'calibrations')}, package_decision_ref)
        result = {'package': package_ref, 'qualified': 0, 'state_mutated': False, 'plateau_produced': False}
    except BaseException as error:
        primary_error = error
        raise
    finally:
        # Même après erreur de binding/source/revue : G1 nettoie seulement ses
        # identities canoniques, jamais une adoption depuis une chaîne PID.
        try:
            final_cleanup = session.stop()
            final = core.load(core.checked(final_cleanup, root=root))
            g1_bridge.verify_shutdown(final, config, final=True)
            core.checked(final['ports_absence_receipt'], root=root)
        except BaseException as cleanup_error:
            if primary_error is not None:
                raise BaseExceptionGroup('Échec original et cleanup final conservés', [primary_error, cleanup_error])
            raise
    core.need(result is not None, 'Aucun package provisoire réellement assemblé')
    return result | {'final_cleanup': final_cleanup, 'provisional_only': True}


def preserve_running(root: Path, config: dict) -> dict:
    core.stack_profile(config, root, running=True)
    source = root / 'runtime/pile-reprise.json'
    before = core.sha(source)
    destination = root / 'runtime/pile-reprise-running-preserved.json'
    core.write_new(root, destination, source.read_bytes())
    core.need(core.sha(source) == core.sha(destination) == before, 'Copie running réelle non stable')
    return core.ref(destination)


def pdf_review_inputs(root: Path) -> list[dict]:
    base = root / 'complements/runs/B1760/exports'
    paths = sorted(base.glob('pdf-*/c16-nodeid.json'))
    core.need(len(paths) == 10, 'Dix exports réels absents avant revue Apple')
    result = []
    for node in paths:
        for path in (node, node.parent / 'piece.pdf', node.parent / 'preuve-pdf.json'):
            result.append(core.ref(core.checked(core.ref(path), root=root)))
    return result


def save_logs(root: Path, config: dict, stop_ref: dict, cleanup_ref: dict) -> dict:
    data = package78.scan_eight(root, config, stop_ref, cleanup_ref)
    path = root / 'eight-logs-review.json'
    core.save_new(root, path, data)
    core.need(data['no_matches'], 'Erreur présente dans un des huit logs réels')
    return core.ref(path)


def main() -> int:
    # Les options futures sont documentées ; aucun JSON ne peut lever False.
    if not core.RUNTIME_ENABLED:
        return core.closed_main()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root', type=Path)
    parser.add_argument('--decision', type=Path, required=True)
    parser.add_argument('--decision-sha256', required=True)
    parser.add_argument('--binding', type=Path, required=True)
    parser.add_argument('--binding-sha256', required=True)
    parser.add_argument('--expected-head', required=True)
    args = parser.parse_args()
    result = coordinate(args.root, {'path': str(args.decision), 'sha256': args.decision_sha256},
        {'path': str(args.binding), 'sha256': args.binding_sha256}, expected_head=args.expected_head)
    print(json.dumps(result, ensure_ascii=False))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
