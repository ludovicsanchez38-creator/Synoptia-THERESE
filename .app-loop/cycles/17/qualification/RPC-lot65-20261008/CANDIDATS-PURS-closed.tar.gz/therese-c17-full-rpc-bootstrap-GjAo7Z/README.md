# Bootstrap FULL RPC A/B, préparation fermée

Acteur auteur : /root/shared4_execution. Ce lot est un overlay statique distinct du gel48 cdc3JA, jamais une admission ni une campagne. Aucun fichier du gel48, produit, dépôt, state ou .app-loop n'a été modifié.

## Raccord préparé

- Le coordinateur installe root_rpc_bootstrap avant prepare-runtime, après les contrôles de décision, source physique A/B, HEAD paramétré, canaris futurs et vraie Session.
- decision.rpc.bootstrap, binding.rpc_bootstrap_ref et source_refs doivent désigner les mêmes octets du helper copié sous la ronde. Sans ces refs root externes, refus.
- Les six modules RPC viennent exactement de decision.rpc.modules. Le chargeur vérifie tous les pins root avant import, refuse un ancien module RPC en cache, enregistre les modules pour les contrôles G1, rehash après import et compare leurs dépendances partagées. Aucun sys.path fallback.
- Le vrai owner observé par Session doit égaler le contexte scellé. Les 15 descriptors, 30 sinks et six demandeurs restent fermés par le lecteur gel48 et G1 attach_rpc_dispatcher. Aucun nouvel argv/env/nonce/birth n'est produit.
- L'ordre G1 existant admit_root → gate vérifié → enrollment physique → registre root → release est inchangé. Les tests exécutent le vrai corps publish_rpc_enrollment sur doubles, plus vérifient l'ordre du vrai start par AST.
- Unix create_server conserve le socket exact root/session-rpc/peer.sock et LOCAL_PEERPID hors JSON. G1.wait pilote dispatcher.poll sans Session.wait enfant. Le fichier RPC seul ne prouve toujours pas son auteur.
- Les canaux session-events et session-rpc/{request,ack,cancel,enrollment} doivent déjà être préparés. Le bootstrap ne les crée pas.

## Clôture avant le reçu final

Session.stop appelle le hook exact de bootstrap AVANT finish handles, restauration des handlers et ses reçus finaux. Une exception de clôture est enregistrée/taintée, mais finish reste tenté. Pas de faux green depuis un handle absent ou un socket seulement fermé administrativement.

Le helper arrête uniquement les jobs déjà enregistrés. Il ne rappelle pas dispatcher.poll pendant la finalisation, car celui-ci accepterait de nouvelles demandes. Il utilise les méthodes privées existantes _descendants/_poll_job des sources exactes. Ces APIs privées restent une dépendance à relire lors d'un futur delta dispatcher.

Le temps cleanup mesuré inclut abort/finish/ticks ; >8 s reste rouge. Le drainage EOF est limité coopérativement à5 s, connexion conservée pour la revalidation client après ACK. server.close est tenté même rouge. Un appel synchronisé à adapter.abort/finish peut lui-même dépasser la fenêtre : les ticks ne sont pas une primitive de préemption hard-real-time ; le reçu ne peut alors être normal. Session.stop possède encore le nettoyage final des vrais handles.

Le reçu rpc-transport-close-N est additif/exclusif. Il distingue closed, quiescent, normal_closure, jobs15, erreurs/taint et snapshot pré-close. Un save refusé ne rouvre ni socket ni flux ; nouvel essai = nouveau reçu tainté.

Le consommateur final exige les 15 jobs complets, le vrai scope A/B, EOF0, zéro erreurs/taint et les bornes8/5. Il rehash request+ACK+receipt+cleanup+stdout+stderr de chaque job, et le reçu auxiliaire s'il existe. Tout returncode int, dont -6, reste brut ; il ne signifie jamais réussite métier.

## Watchdog proposé

Le guard utilise exactement context.deadline_monotonic déjà scellé par le root vivant, avec time.monotonic Python. Aucune durée, port ou timeout métier n'est augmenté ; aucune origine Node hrtime n'est comparée.

Contrôles avant start, à chaque tick wait G1, au relais des revues/bindings root, aux frontières execute/in_process et au retour final du coordinateur. Le nettoyage reste autorisé après l'échéance. Taint monotone et aucune réussite de coordinateur si sa clôture dépasse le deadline.

Contrôle coopératif seulement : une opération in-process/source I/O/import bloquante n'est pas préemptée atomiquement. Les watchdogs/stops autonomes OS et une calibration physique A/B restent non démontrés. Le plafond historique proposé12884 s n'est ni adopté ni mesuré ici.

## Dépendances encore fermées

RUNTIME_ENABLED=False, OS_STARTUP_QUALIFIED=False, quatre CAPABILITIES=False, ADMISSION_TABLE et WRAPPER_ADMISSION_TABLE vides. Aucun test, JSON ou constructor de ce lot ne les ouvre.

Les six modules transport-26, dont adapter gel48, sont des définitions de raccord, pas des preuves FULL actuelles. Le delta protocol/adapter/G1/Node auxiliaires A/B14 d'Env est séparé ; aucune incorporation ni qualification implicite. Les listeners/arrêts ports A/B, les14 auxiliaires, les autres UI/captures, la QA Git/HEAD courante, profils et vraies décisions externe/Q demeurent obligations future root. Une preuve WRAPPER ne satisfait pas les canaris exacts A/B du lecteur RPC.

Ce dossier ne contient pas un checkout QA/Session complet prêt à lancer. Les quatre fichiers modifiés sont des overlays avec leurs préimages byte-exactes ; les autres définitions restent référencées par les inputs SHA de INDEX. Aucun builder, root effectif, admission, PID futur ou table auto-GO n'est créé.

## Preuves pures et commande

35 méthodes unittest, zéro failure/error/skip. Exécution réelle exec_command751736, 2026-10-08T13:11:18.218934Z →13:11:18.556867Z, exit0 ; sept pins avant/après égaux. Les fixtures sont synthétiques et seuls les corps sélectionnés AST sont exécutés. Aucun import complet G1/core/coordinator/transport, Popen workload, libproc, signal ou socket.

Le JSON proofs/pure-35-returned-output.json est une conservation dérivée du texte combiné réellement retourné par l'outil, pas un sink stdout/stderr direct. Les tests30/33 intermédiaires verts ne sont pas35 cas supplémentaires ; leurs pins diffèrent et restent historiques. Aucun rouge de workload n'est inventé.

```sh
env -i HOME=/private/tmp/therese-c17-full-rpc-bootstrap-GjAo7Z TMPDIR=/private/tmp/therese-c17-full-rpc-bootstrap-GjAo7Z /private/tmp/therese-c17-full-suite-ps_tgzy5/source/.venv-conforme/bin/python -I -B /private/tmp/therese-c17-full-rpc-bootstrap-GjAo7Z/run-pure.py
```

Qualification native et FULL : aucune.
