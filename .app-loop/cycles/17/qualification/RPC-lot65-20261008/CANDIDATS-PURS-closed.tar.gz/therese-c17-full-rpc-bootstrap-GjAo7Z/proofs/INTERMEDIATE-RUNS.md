# Observations intermédiaires

Ces nombres sont des étapes d'un même lot, pas des cas distincts cumulables.

- exec_command3f2060 : 30 tests, exit0, zéro failure/error/skip, 2026-10-08T13:09:03.440138Z→13:09:03.724403Z,0.28376900000148453 s. Texte complet dans le retour outil ; la présente note n'est pas un raw sink. Helperc3eb3428…, tests9d296c2f…, sept pins avant/après égaux.
- exec_command8410ee : 33 tests, exit0, zéro failure/error/skip, résultat retourné conservé dans pure-33-intermediate-returned-output.json. Helperc3eb3428…, tests0b049452…, sept pins avant/après égaux.
- exec_command751736 : 35 tests finaux, exit0, résultat retourné complet conservé dans pure-35-returned-output.json. Helpera9865736…, tests0f30d18d…, sept pins avant/après égaux.

Les ajouts35 incluent le temps d'abort dans la fenêtre cleanup et le rehash des canaux terminaux. Aucun changement d'oracle produit ; aucun runtime.
