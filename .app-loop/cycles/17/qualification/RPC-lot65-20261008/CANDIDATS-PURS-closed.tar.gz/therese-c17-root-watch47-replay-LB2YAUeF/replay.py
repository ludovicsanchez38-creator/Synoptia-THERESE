"""Rejeu root watchdog47 : corps AST, fixtures jetables, aucun G1 ou OS."""
import contextlib
import ctypes
import hashlib
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import time
import unittest

HERE = Path(__file__).resolve().parent
SOURCE = Path('/private/tmp/therese-c17-full-rpc-watchdog-32QrHc')
INDEX_REF = {'path': str(SOURCE / 'INDEX.json'), 'sha256': 'edfc527a8636ad3ac94be5393a0f5cffed9d9cd14787160d8bcb97412262dca5', 'bytes': 8073}

def ref(path):
    path = Path(path)
    digest = hashlib.sha256()
    count = 0
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1048576), b''):
            digest.update(chunk)
            count += len(chunk)
    return {'path': str(path), 'sha256': digest.hexdigest(), 'bytes': count}

assert ref(INDEX_REF['path']) == INDEX_REF
index = json.loads(Path(INDEX_REF['path']).read_bytes())
assert not index['flags']['RUNTIME_ENABLED'] and not index['flags']['OS_STARTUP_QUALIFIED']
assert index['flags']['ADMISSION_TABLE'] == index['flags']['WRAPPER_ADMISSION_TABLE'] == {}
pins = {}

def collect(value):
    if isinstance(value, list):
        for item in value:
            collect(item)
    elif isinstance(value, dict):
        if set(value) == {'path', 'sha256', 'bytes'}:
            assert Path(value['path']).is_absolute()
            assert ref(value['path']) == value
            assert value['path'] not in pins or pins[value['path']] == value
            pins[value['path']] = value
        else:
            for item in value.values():
                collect(item)

collect(index)
collect(json.loads(Path(index['base_index']['path']).read_bytes()))
collect(INDEX_REF)
collect(ref(__file__))
fixture_root = HERE / 'fixtures'
fixture_root.mkdir(mode=0o700)
os.environ['C17_PURE_FIXTURE_ROOT'] = str(fixture_root)
attempts = []

def audit(event, args):
    if event.startswith(('subprocess.', 'socket.', 'ctypes.', 'os.exec', 'os.spawn',
                         'os.posix_spawn', 'os.fork', 'os.kill', 'os.system', 'pty.spawn')):
        attempts.append(event)
        raise AssertionError('Appel OS interdit dans le rejeu pur : ' + event)
    if event == 'open' and len(args) > 2 and isinstance(args[2], int) and args[2] & (os.O_WRONLY | os.O_RDWR):
        if isinstance(args[0], (str, bytes)):
            target = Path(os.fsdecode(args[0])).resolve()
            if not target.is_relative_to(HERE):
                attempts.append('write:' + str(target))
                raise AssertionError('Écriture hors sortie root : ' + str(target))

class ImportGuard:
    def find_spec(self, fullname, path=None, target=None):
        if fullname.rsplit('.', 1)[-1] in ('runtime_session', 'runtime78_core', 'runtime78_coordinator',
                'session_rpc_adapter', 'rpc_protocol', 'rpc_client', 'rpc_dispatcher', 'rpc_unix', 'rpc_peer'):
            attempts.append('full_import:' + fullname)
            raise AssertionError('Import entier G1/RPC/OS interdit : ' + fullname)

sys.addaudithook(audit)
sys.meta_path.insert(0, ImportGuard())
sys.path.insert(0, str(SOURCE / 'tests'))
started = time.monotonic()
with (HERE / 'stdout.log').open('x') as stdout, (HERE / 'stderr.log').open('x') as stderr:
    with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
        result = unittest.TextTestRunner(stream=stderr, verbosity=2).run(
            unittest.defaultTestLoader.discover(str(SOURCE / 'tests'), pattern='test_bootstrap.py'))
unchanged = all(ref(row['path']) == row for row in pins.values())
fixtures_closed = not any(fixture_root.iterdir())
passed = result.testsRun == 47 and result.wasSuccessful() and not result.skipped and unchanged and not attempts and fixtures_closed
receipt = {'schema': 'c17-root-watchdog47-pure-replay-v1', 'actor': '/root',
    'tests': result.testsRun, 'failures': len(result.failures), 'errors': len(result.errors),
    'skipped': len(result.skipped), 'source_refs': list(pins.values()), 'unchanged': unchanged,
    'forbidden_attempts': attempts, 'stdout': ref(HERE / 'stdout.log'), 'stderr': ref(HERE / 'stderr.log'),
    'fixture_output_root': str(fixture_root), 'fixtures_closed': fixtures_closed,
    'elapsed_seconds': time.monotonic() - started, 'passed': passed,
    'root_built': False, 'G1_imported': False, 'native_workload_executed': False,
    'FULL': False, 'release': False}
with (HERE / 'receipt.json').open('x') as stream:
    stream.write(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'passed': passed, 'tests': result.testsRun, 'receipt': ref(HERE / 'receipt.json')}))
raise SystemExit(0 if passed else 1)
