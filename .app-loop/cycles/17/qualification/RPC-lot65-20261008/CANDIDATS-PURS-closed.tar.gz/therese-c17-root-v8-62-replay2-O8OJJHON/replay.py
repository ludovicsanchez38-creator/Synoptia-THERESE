"""Rejeu root des62 tests V8, aucun build/G1 entier/sous-processus/socket."""
import contextlib
import ctypes
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import socket
import ssl
import subprocess
import sys
import time
import unittest
import unittest.mock
import urllib.request

HERE = Path(__file__).resolve().parent
SOURCE = Path('/private/tmp/therese-c17-fresh-wrapper-builder-v8-pB5tPP')
INDEX_REF = {'path': str(SOURCE / 'INDEX.json'), 'sha256': '278e5a8a9a0aa1cca8c2de02b9278c417416615ac8be492457a583516b2537ca', 'bytes': 13620}

def reference(path):
    path = Path(path)
    digest = hashlib.sha256()
    count = 0
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1048576), b''):
            digest.update(chunk)
            count += len(chunk)
    return {'path': str(path), 'sha256': digest.hexdigest(), 'bytes': count}

assert reference(INDEX_REF['path']) == INDEX_REF
index = json.loads(Path(INDEX_REF['path']).read_bytes())
assert all(value is False for value in index['closed'].values())
pins = {}

def collect(value, base):
    if isinstance(value, list):
        for row in value:
            collect(row, base)
    elif isinstance(value, dict):
        if isinstance(value.get('path'), str) and isinstance(value.get('sha256'), str) and len(value['sha256']) == 64:
            path = Path(value['path'])
            if not path.is_absolute():
                assert '..' not in path.parts
                path = base / path
            actual = reference(path)
            assert actual['sha256'] == value['sha256']
            assert value.get('bytes', actual['bytes']) == actual['bytes']
            assert str(path) not in pins or pins[str(path)] == actual
            pins[str(path)] = actual
        else:
            for row in value.values():
                collect(row, base)

collect(index, SOURCE)
for row in index['external_index_refs']:
    path = Path(row['path'])
    document = json.loads(path.read_bytes())
    profile_indexes = {
        Path('/private/tmp/therese-c17-chrome-unixbind-PUUOvY00/INDEX.json'),
        Path('/private/tmp/therese-c17-chrome-rootdomain-h5whIv/INDEX.json'),
        Path('/private/tmp/therese-c17-fresh-wrapper-builder-v7-cnR8Hm/profile/INDEX.json'),
    }
    base = path.parent if path in profile_indexes else Path('/private/tmp/therese-c17-rpc-integration-UctqC8UG')
    collect(document, base)
collect(INDEX_REF, SOURCE)
collect(reference(__file__), HERE)
collect(reference('/private/tmp/therese-c17-wrapper-source-kGvU1hdx/proofs/python-metadata-result.json'), SOURCE)
attempts = []

def deny(*args, **kwargs):
    attempts.append('forbidden_process_socket_native')
    raise AssertionError('Rejeu pur : processus/socket/native interdits')

for module, names in ((subprocess, ('Popen', 'run', 'check_output', 'call', 'check_call')),
                      (socket, ('socket', 'socketpair', 'create_connection')),
                      (os, ('system', 'fork', 'forkpty', 'execve', 'posix_spawn', 'posix_spawnp', 'kill', 'killpg')),
                      (ctypes, ('CDLL', 'PyDLL'))):
    for name in names:
        if hasattr(module, name):
            setattr(module, name, deny)

class ImportGuard:
    def find_spec(self, fullname, path=None, target=None):
        if fullname == 'app' or fullname.startswith('app.') or fullname.rsplit('.', 1)[-1] in (
                'runtime_session', 'runtime78_core', 'runtime78_coordinator', 'rpc_unix', 'rpc_peer'):
            attempts.append('full_import:' + fullname)
            raise AssertionError('Import complet G1/produit/OS interdit : ' + fullname)

sys.meta_path.insert(0, ImportGuard())
started = time.monotonic()
with (HERE / 'stdout.log').open('x') as stdout, (HERE / 'stderr.log').open('x') as stderr:
    with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
        result = unittest.TextTestRunner(stream=stderr, verbosity=2).run(
            unittest.defaultTestLoader.discover(str(SOURCE), pattern='test_build_fresh_wrapper.py'))
unchanged = all(reference(row['path']) == row for row in pins.values())
g1_imported = any(name.rsplit('.', 1)[-1] == 'runtime_session' for name in sys.modules)
passed = result.testsRun == 62 and result.wasSuccessful() and not result.skipped and unchanged and not attempts and not g1_imported
receipt = {'schema': 'c17-root-v8-62-pure-replay-v1', 'actor': '/root',
    'tests': result.testsRun, 'failures': len(result.failures), 'errors': len(result.errors), 'skipped': len(result.skipped),
    'source_refs': list(pins.values()), 'unchanged': unchanged, 'forbidden_attempts': attempts,
    'stdout': reference(HERE / 'stdout.log'), 'stderr': reference(HERE / 'stderr.log'),
    'elapsed_seconds': time.monotonic() - started, 'passed': passed,
    'root_built': False, 'G1_imported': g1_imported, 'native_workload_executed': False,
    'FULL': False, 'release': False}
with (HERE / 'receipt.json').open('x') as stream:
    stream.write(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'passed': passed, 'tests': result.testsRun, 'receipt': reference(HERE / 'receipt.json')}))
raise SystemExit(0 if passed else 1)
