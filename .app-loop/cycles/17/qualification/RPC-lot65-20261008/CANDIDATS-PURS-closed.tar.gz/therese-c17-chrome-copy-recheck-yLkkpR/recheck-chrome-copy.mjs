// Read-only, point-in-time successor to copy-and-verify-v3.mjs.
// Never imports or executes the mutating v3 collector.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';

const EVIDENCE_ROOT = '/private/tmp/therese-c17-chrome-qa-copy-RoZmwsja';
const ORIGINAL = '/Applications/Google Chrome.app';
const COPY = EVIDENCE_ROOT + '/Google Chrome.app';
const V3 = Object.freeze({
  path: EVIDENCE_ROOT + '/v3-receipt.json',
  sha256: 'f97793cb43454051da734685185cb5d4e5b5ffbabc516580287195ef3d32993c',
  bytes: 17160,
});
const SCHEMA = 'c17-root-independent-chrome-copy-recheck-v1';
const fail = why => { throw new Error(why); };
const need = (ok, why) => { if (!ok) fail(why); };
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');

function regularBytes(filename) {
  const st = fs.lstatSync(filename);
  need(st.isFile() && !st.isSymbolicLink() && st.nlink === 1, 'Non-regular/symlink/hardlinked evidence: ' + filename);
  const fd = fs.openSync(filename, fs.constants.O_RDONLY | fs.constants.O_NOFOLLOW);
  try {
    const before = fs.fstatSync(fd);
    const bytes = fs.readFileSync(fd);
    const after = fs.fstatSync(fd);
    need(before.dev === after.dev && before.ino === after.ino && before.size === after.size &&
      before.mtimeMs === after.mtimeMs && before.ino === st.ino && bytes.length === st.size,
      'Evidence mutated during read: ' + filename);
    return bytes;
  } finally { fs.closeSync(fd); }
}

function reference(filename) {
  const bytes = regularBytes(filename);
  return {path: filename, bytes: bytes.length, sha256: sha(bytes)};
}

function readPinned(ref, expectedPath) {
  need(ref && ref.path === expectedPath && Number.isSafeInteger(ref.bytes) && ref.bytes >= 0 &&
    /^[a-f0-9]{64}$/.test(ref.sha256), 'Unexpected evidence reference');
  const bytes = regularBytes(expectedPath);
  need(bytes.length === ref.bytes && sha(bytes) === ref.sha256, 'Pinned evidence changed: ' + expectedPath);
  return bytes;
}

function saveExclusive(folder, name, bytes) {
  const destination = path.join(folder, name);
  need(path.dirname(destination) === folder, 'Output path escaped receipt root');
  const fd = fs.openSync(destination, fs.constants.O_WRONLY | fs.constants.O_CREAT |
    fs.constants.O_EXCL | fs.constants.O_NOFOLLOW, 0o600);
  try { fs.writeFileSync(fd, bytes); fs.fsyncSync(fd); }
  finally { fs.closeSync(fd); }
  return reference(destination);
}

// Same lstat/no-follow SHA-256 traversal and manifest fields as v3 lines 23-42.
// It observes; it never copies, removes xattrs, signs, or opens Chrome.
function manifest(base) {
  const rows = [];
  function visit(relative) {
    const filename = path.join(base, relative);
    const st = fs.lstatSync(filename);
    const row = {relative, mode: st.mode & 0o7777, uid: st.uid, gid: st.gid, dev: st.dev, ino: st.ino};
    if (st.isSymbolicLink()) { row.type = 'symlink'; row.target = fs.readlinkSync(filename); }
    else if (st.isDirectory()) { row.type = 'directory'; }
    else {
      need(st.isFile(), 'Unexpected bundle object: ' + filename);
      row.type = 'file'; row.bytes = st.size;
      const fd = fs.openSync(filename, fs.constants.O_RDONLY | fs.constants.O_NOFOLLOW);
      try {
        const before = fs.fstatSync(fd);
        const digest = crypto.createHash('sha256');
        const chunk = Buffer.alloc(1024 * 1024);
        let count;
        while ((count = fs.readSync(fd, chunk, 0, chunk.length, null)) > 0) digest.update(chunk.subarray(0, count));
        const after = fs.fstatSync(fd);
        need(before.dev === after.dev && before.ino === after.ino && before.size === after.size &&
          before.mtimeMs === after.mtimeMs && before.ino === st.ino,
          'Bundle file mutated while hashing: ' + filename);
        row.sha256 = digest.digest('hex');
      } finally { fs.closeSync(fd); }
    }
    rows.push(row);
    if (row.type === 'directory') for (const child of fs.readdirSync(filename).sort())
      visit(relative ? relative + '/' + child : child);
  }
  visit('');
  return rows;
}

const withoutLocation = rows => rows.map(({dev, ino, ...row}) => row);
const same = (left, right) => JSON.stringify(left) === JSON.stringify(right);

function runCodesign() {
  const args = ['--verify', '--deep', '--strict', '--verbose=4', COPY];
  const started_at = new Date().toISOString();
  const result = spawnSync('/usr/bin/codesign', args, {encoding: null, timeout: 30000,
    maxBuffer: 16 * 1024 * 1024,
    env: {PATH: '/usr/bin:/bin:/usr/sbin:/sbin', LANG: 'en_US.UTF-8', LC_ALL: 'en_US.UTF-8'}});
  return {argv: ['/usr/bin/codesign', ...args], started_at, completed_at: new Date().toISOString(),
    status: result.status, signal: result.signal, error: result.error?.message ?? null,
    stdout: result.stdout ?? Buffer.alloc(0), stderr: result.stderr ?? Buffer.alloc(0)};
}

function receiptRoot(value) {
  need(path.isAbsolute(value) && path.dirname(value) === '/private/tmp' &&
    path.basename(value).startsWith('therese-c17-chrome-recheck-') &&
    fs.realpathSync(value) === value, 'Receipt root must be exact new /private/tmp directory');
  const st = fs.lstatSync(value);
  need(st.isDirectory() && !st.isSymbolicLink() && st.uid === process.getuid() &&
    (st.mode & 0o077) === 0 && fs.readdirSync(value).length === 0,
    'Receipt root must be owned, private, empty, non-symlink');
  return value;
}

function main() {
  need(process.argv.length === 5 && process.argv[2] === '--execute' && process.argv[3] === '--receipt-root',
    'Usage: node recheck-chrome-copy.mjs --execute --receipt-root /private/tmp/therese-c17-chrome-recheck-XXXXXX');
  const out = receiptRoot(process.argv[4]);
  const started_at = new Date().toISOString();
  const result = {schema: SCHEMA, actor: '/root', purpose: 'read_only_pre_GO_chrome_QA_copy_recheck',
    original_receipt: V3, original: ORIGINAL, copy: COPY, started_at, completed_at: null,
    source_current_ref: null, copy_current_ref: null, source_matches_v3: false,
    copy_matches_v3: false, source_copy_byte_mode_uid_gid_links_equal: false,
    no_source_copy_hardlinks: false, strict_codesign: null, passed: false,
    xattrs_rechecked: false, quarantine_presence_claimed: false,
    runtime_admitted: false, FULL: false, release: false, error: null};
  try {
    need(fs.realpathSync(EVIDENCE_ROOT) === EVIDENCE_ROOT &&
      fs.realpathSync(ORIGINAL) === ORIGINAL && fs.realpathSync(COPY) === COPY &&
      !fs.lstatSync(ORIGINAL).isSymbolicLink() && !fs.lstatSync(COPY).isSymbolicLink(),
      'Chrome source/copy root changed or symlinked');
    const prior = JSON.parse(readPinned(V3, V3.path));
    need(prior.schema === 'c17-root-independent-chrome-copy-v1' && prior.passed === true &&
      prior.actor === '/root' && prior.source === ORIGINAL && prior.target === COPY &&
      prior.entries === 1339 && prior.byte_mode_link_equal === true &&
      prior.no_hardlinks_to_source === true && prior.source_unchanged === true &&
      prior.runtime_admitted === false && prior.FULL === false && prior.release === false,
      'Prior real copy receipt not the pinned 1339-entry PASS');
    const sourceBaseline = JSON.parse(readPinned(prior.source_after, EVIDENCE_ROOT + '/v3-source-after.json'));
    const copyBaseline = JSON.parse(readPinned(prior.copy_manifest, EVIDENCE_ROOT + '/v3-copy-after.json'));
    need(Array.isArray(sourceBaseline) && Array.isArray(copyBaseline) &&
      sourceBaseline.length === copyBaseline.length && copyBaseline.length === 1339,
      'Prior complete manifests absent');
    const sourceCurrent = manifest(ORIGINAL);
    const copyCurrent = manifest(COPY);
    // Preserve both actual observations even when a mismatch makes the result red.
    result.source_current_ref = saveExclusive(out, 'source-current.json', Buffer.from(JSON.stringify(sourceCurrent, null, 2) + '\n'));
    result.copy_current_ref = saveExclusive(out, 'copy-current.json', Buffer.from(JSON.stringify(copyCurrent, null, 2) + '\n'));
    result.source_matches_v3 = same(sourceCurrent, sourceBaseline);
    result.copy_matches_v3 = same(copyCurrent, copyBaseline);
    result.source_copy_byte_mode_uid_gid_links_equal = same(withoutLocation(sourceCurrent), withoutLocation(copyCurrent));
    result.no_source_copy_hardlinks = sourceCurrent.length === copyCurrent.length &&
      sourceCurrent.every((row, index) => row.type !== 'file' || row.dev !== copyCurrent[index].dev ||
        row.ino !== copyCurrent[index].ino);
    need(result.source_matches_v3 && result.copy_matches_v3 &&
      result.source_copy_byte_mode_uid_gid_links_equal && result.no_source_copy_hardlinks,
      'Chrome physical tree differs from pinned v3 manifests');
    const strict = runCodesign();
    const stdout = saveExclusive(out, 'strict.stdout', strict.stdout);
    const stderr = saveExclusive(out, 'strict.stderr', strict.stderr);
    result.strict_codesign = {argv: strict.argv, started_at: strict.started_at, completed_at: strict.completed_at,
      status: strict.status, signal: strict.signal, error: strict.error, stdout, stderr};
    const output = Buffer.concat([strict.stdout, Buffer.from('\n'), strict.stderr]);
    need(strict.status === 0 && strict.signal === null && strict.error === null &&
      output.includes(Buffer.from(COPY + ': valid on disk')) &&
      output.includes(Buffer.from(COPY + ': satisfies its Designated Requirement')),
      'Deep strict codesign copy not proven by actual output');
    result.passed = true;
  } catch (error) {
    result.error = {type: error?.name ?? 'Error', message: String(error?.message ?? error)};
  }
  result.completed_at = new Date().toISOString();
  const ref = saveExclusive(out, 'recheck-receipt.json', Buffer.from(JSON.stringify(result, null, 2) + '\n'));
  process.stdout.write(JSON.stringify({passed: result.passed, receipt: ref, original_receipt: V3}) + '\n');
  process.exitCode = result.passed ? 0 : 86;
}

main();
