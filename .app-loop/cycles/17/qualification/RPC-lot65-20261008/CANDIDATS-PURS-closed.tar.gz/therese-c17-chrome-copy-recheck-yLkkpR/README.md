# Recontrôle ponctuel de la copie Chrome QA

Préparation en lecture seule, non exécutée. Ce dossier ne modifie ni `/Applications/Google Chrome.app`, ni la copie QA, ni les anciens reçus. Le script est un successeur de collecte : il reprend le parcours `lstat`/`O_NOFOLLOW`/SHA-256 de `copy-and-verify-v3.mjs` (lignes 23-42), mais n'importe pas ce collecteur car il retire `FinderInfo` et écrit les preuves historiques.

## Contrat d'entrée

- Reçu réel v3 exact : `/private/tmp/therese-c17-chrome-qa-copy-RoZmwsja/v3-receipt.json`, SHA-256 `f97793cb43454051da734685185cb5d4e5b5ffbabc516580287195ef3d32993c`, 17 160 octets.
- App source exacte : `/Applications/Google Chrome.app`. Copie exacte : `/private/tmp/therese-c17-chrome-qa-copy-RoZmwsja/Google Chrome.app`.
- Nouveau dossier de sortie vide, canonique, privé et possédé par l'exécuteur, directement sous `/private/tmp`, nommé `therese-c17-chrome-recheck-*`. Aucun fichier n'y est remplacé.
- Appel explicite `--execute --receipt-root` par le root sous son futur GO d'outil exact. Le JSON du reçu ne prouve pas à lui seul l'identité de l'exécuteur ni l'autorisation d'un lancement Chrome.

Commande future, après revue et avec un chemin réel créé par root :

```text
<NODE_APPROUVÉ> /private/tmp/therese-c17-chrome-copy-recheck-yLkkpR/recheck-chrome-copy.mjs --execute --receipt-root <DOSSIER_PRIVÉ_NEUF>
```

## Vérifications et sorties

Le script relit et rehash le reçu v3 et ses deux manifests pinnés. Il parcourt de nouveau les 1 339 entrées de la source et de la copie, contrôle SHA-256, type, taille, mode, UID/GID, destination des liens et identité physique `dev/ino` du baseline. Il refuse toute entrée ajoutée, perdue ou mutée et tout hardlink fichier source/copie. Il archive les deux manifests actuels même en cas de divergence. Ensuite seulement il appelle directement `/usr/bin/codesign --verify --deep --strict --verbose=4` sur la copie, avec timeout 30 s, sans shell. Les flux stdout/stderr sont sauvegardés séparément. Exit 0 et les deux lignes de validation de la copie sont exigés.

Il crée au plus `source-current.json`, `copy-current.json`, `strict.stdout`, `strict.stderr` et `recheck-receipt.json` dans le nouveau dossier. Un refus précoce peut ne produire que le reçu. Le reçu `c17-root-independent-chrome-copy-recheck-v1` porte les références SHA/bytes, horodatages réels, critères positifs/négatifs, ancien reçu v3 et statut `passed` ; le processus sort avec 0 ou 86. Un contrôle rouge reste brut ; aucune retouche de signature, xattr, application, processus Chrome, profil personnel ou permission n'est permise.

Le contrôle est ponctuel. Les xattrs et l'absence de quarantaine ne sont **pas** mesurés de nouveau : le reçu v3 archive leur état antérieur, et le nouveau reçu dit `xattrs_rechecked:false` / `quarantine_presence_claimed:false`. `runtime_admitted`, `FULL` et `release` restent faux. Root doit relire le reçu daté et les fichiers réellement observés, puis émettre un GO natif distinct lié au SHA de ce reçu. Aucun TTL ou statut Gatekeeper n'est inventé.

Le script n'a pas été exécuté ni soumis à un test natif dans cette préparation. Il appartient à root de relire sa source et de choisir un binaire Node approuvé avant tout essai.
