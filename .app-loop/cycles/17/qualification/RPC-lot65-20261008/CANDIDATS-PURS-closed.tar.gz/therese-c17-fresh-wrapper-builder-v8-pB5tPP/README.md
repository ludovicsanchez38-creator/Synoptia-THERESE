# Builder WRAPPER V8, préparation fermée

Auteur : /root/cycle17_gate_review. Dossier additif, V7 et tous les gels antérieurs immuables.

## Corrections concrètes

1. Le helper chrome_contract.py est dérivé d'une seule constante CHROME. Préimage originale 26e8374a23b7f67a5c45cbc457156bfd15735cd2578ca0fd7990b3df989630db ; helper QA 7922a13bdc239338ea9dedf37bf06ef1c91931b77a5275a2db6007d89a9a42ba, 4118 octets. Le helper QA réel est vérifié avant allocation, chargé par le constructeur pur, puis émis sous ROOT/source/chrome_contract.py. Core17 indique la dérivation, sa préimage, sa définition QA et son diff. Cette sortie constitue toujours l'un des 76 pins, sans prétendre être byte-exacte à l'ancien helper.

Les cinq descriptors doivent satisfaire executable == argv[0] == CHROME == defaults.executable. G1 conserve sa comparaison contre le helper pinné dans source_refs et ajoute une égalité explicite row.executable == CHROME. Les deux Path QA hérités V7 et ce seul prédicat sont dérivés depuis f8e9 ; aucune autre branche G1 ou table FULL n'est changée. Le slot WRAPPER exact sera rempli uniquement par un futur root de préparation autorisé.

2. Le constructeur effectue une relecture physique fraîche des 1339 entrées source et copie, avant allocation puis avant émission du GO de préparation. Les snapshots archivés sont rehashés depuis la vraie preuve root f97793cb. Chaque entrée doit rester présente et de même type, avec mêmes UID/GID/mode/dev/inode, cible de lien, taille et SHA de fichier. Ajouts, retraits, liens hors bundle, hardlinks vers source et changements pendant lecture sont refusés. Les deux observations seront des JSON frais distincts, liés au GO et reçu de construction.

La relecture effective couvre 697 fichiers, 635 dossiers et 7 liens. Elle ne lance pas codesign et ne mesure pas les xattrs actuels. Elle ne transforme pas la preuve de signature historique en nouvelle signature fraîche. Le root doit encore exécuter son recontrôle indépendant et un vrai strict avant son GO natif.

## Périmètre inchangé

Cible : /private/tmp/therese-c17-chrome-qa-copy-RoZmwsja/Google Chrome.app.

Profil c9101b2a et INDEX de profil V7 restent les définitions exactes utilisées. Aucune nouvelle permission, Mach, classe IOKit, réseau, HOME ou port. Web51ff, SQL, flags FULL/caps, délais, argv options Playwright, cwd, source HEAD2d69, 11 sorties originelles, 26 overlays, 17 core et 76 sources sont conservés. Le diff helper supplémentaire est une preuve de dérivation liée par core/GO/reçu, pas un changement du dénominateur des 76 sources.

Les anciens stricts rouges, l'écart provenance, les règles FinderInfo/quarantaine et les résultats runtime antérieurs ne sont pas requalifiés.

## Tests effectivement exécutés

62 cas purs, 0 failure/error/skip, exit0, 7.474 secondes unittest, pins avant/après égaux. Ils reprennent 47 cas V7 et ajoutent 15 cas V8. Les nouveaux cas exécutent les vrais corps helper/G1 admission par namespace ou AST sélectionné, sans importer G1 entier. Les commandes/processus/environnements de ces tests sont des doubles explicitement synthétiques. Les mutations de fichier, mode, lien, UID/GID attendu, hardlink et fichier supplémentaire sont des fixtures privées, jamais l'application source ou QA.

Deux tests relisent les arbres réels en lecture seule ; aucun subprocess/socket/Node/Chrome, build, codesign ou retrait xattr n'est exécuté. proofs/pure-tests-returned-output.txt conserve la sortie renvoyée par exec_command, pas un sink direct inventé. Le retour outil et le reçu sont conservés séparément.

Premier essai : 62 cas, 7 erreurs de fixture, car TemporaryDirectory renvoyait un alias non canonique. La préimage du test et l'observation réelle chunk6ad747 sont conservées sous history/. L'observation est explicitement un résumé et extrait de sortie, pas une prétendue copie complète du stdout. Seule la fixture résout maintenant sa racine ; aucune garde du scanner ou assertion de résultat n'a été réduite.

Commande des mêmes cas :
python3 -I -B /private/tmp/therese-c17-fresh-wrapper-builder-v8-pB5tPP/run_pure.py

## Future préparation, pas lancement

CLI :
python3 -I -B /private/tmp/therese-c17-fresh-wrapper-builder-v8-pB5tPP/build_fresh_wrapper.py --prepare --root <NOUVELLE_RACINE_WRAPPER> --web-profile-ref <REF_JSON_WEB51ff> --chrome-profile-ref <REF_JSON_c9101b2a> --authority-ref <REF_JSON_GO_ROOT_FRAIS>

Ne pas lancer avec des placeholders. Le GO externe exact doit lier ce builder, les profils, sources, registre réel, témoin runner et chrome_qa_copy_ref f97793cb43454051da734685185cb5d4e5b5ffbabc516580287195ef3d32993c/17160. Une telle construction produit seulement les définitions et reçus de préparation. Le vrai recontrôle physique/codesign root et le GO natif exact demeurent distincts.

Aucune racine WRAPPER nouvelle n'a été construite par ce lot. RUNTIME_ENABLED, OS_STARTUP_QUALIFIED, admission FULL et caps restent fermés, release false. Le scan est fini avec recontrôles de stat avant/après, pas un snapshot atomique d'un système de fichiers hostile. La fenêtre après scan demeure une limite, réduite par le recontrôle root avant native.
