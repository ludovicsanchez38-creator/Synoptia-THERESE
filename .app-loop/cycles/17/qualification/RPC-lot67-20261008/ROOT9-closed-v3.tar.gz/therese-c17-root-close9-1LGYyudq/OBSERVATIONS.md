# ROOT9 clos, rouge instrumental conservé

Invocation native principale 4531c3, clôture fb5fb4 exit 86. Résultat c094078b, 2 778 octets : source inchangée, transport fermé, sept ACK sur quinze, six témoins initiaux conformes, septième refus avant la feuille Node. FULL, ronde A/B, density/78 et admission restent faux.

Lecture de clôture principale 315e15 : 1 248 refs, 36 jointures signaux/birth. Reçu 95ad8101, 300 105 octets. Le premier lecteur dérivé (b3fec7) a échoué sur une référence relative d'INDEX V6 historique copié dans V9. Les INDEX V6/V7/V8 sont désormais reconnus comme données historiques exactes, jamais réinterprétés contre le répertoire courant. Aucun pin, résultat, source native ou assertion n'a été modifié. La sortie de cette première erreur vit dans le transcript, aucun prétendu reçu brut n'a été reconstruit.

Message indépendant réellement reçu de /root/shared4_execution : 3 484 occurrences de références, 186 chemins, 70 documents runtime, 37 paires hardlink exactes, plan15/binding cohérent, 76 sources. Dix jointures gate/birth/release exactes, 51 occurrences de signaux jointes aux attributions (21 actions distinctes sur quatre births). Six ACK complete, deux parents code0, témoins XML1/0/1/0, trois témoins et logs corrélés. Septième ACK error/taint sans feuille Node ni birth inventée.

Chrome PID56446 birth1791471012/453073, owner56102 birth1791470968/512200. Cleanup STOP trois fois, TERM, CONT, KILL ; exit -9 et 3,947269 s. stderr a45faf9d, 3 027 octets, sans exception NSBundle visible. Services et Session : 1,033187 et 0,895535 s, aucun résidu/erreur/ambiguïté, deux scans sur les trois ports, handlers restaurés. Nettoyage physique favorable uniquement : clean global false, logstable false, taint true, owned_shutdown false conservés.

Diagnostic système principal d23453 : lecture exacte de la fenêtre 16:50:11 à 16:50:24 heure Paris, reçu 67e6524e, 1 405 octets, 141 événements. Refus ciblés Mach/IOKit/fichiers observés, aucune causalité affirmée et aucune permission ajoutée. La chaîne de causes RPC est encore perdue lors de la publication du refus ; préparation d'un successeur diagnostique distinct avant nouvel essai.
