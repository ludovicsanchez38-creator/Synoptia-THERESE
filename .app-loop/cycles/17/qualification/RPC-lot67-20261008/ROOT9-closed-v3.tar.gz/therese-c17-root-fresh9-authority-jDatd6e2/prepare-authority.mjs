// Préparation documentaire. Le GO effectif reste l'appel externe du constructeur.
import fs from 'node:fs';
import crypto from 'node:crypto';
const out='/private/tmp/therese-c17-root-fresh9-authority-jDatd6e2';
const root='/private/tmp/therese-c17-wrapper-canary-42f8fa9d995e4ba291d179d86ae2b192';
const currentHead='9bbee124e47857c2f5d956ef54f1236e944b74f8';
const head='2d69e30c9c6dd18823ee6102271876003a6a67cc';
const need=(x,m)=>{if(!x)throw Error(m);};
need(fs.realpathSync(out)===out&&fs.lstatSync(out).uid===process.getuid()
  &&(fs.lstatSync(out).mode&0o077)===0
  &&fs.readdirSync(out).sort().join(',')==='V9-REVIEW-OBSERVATION.md,prepare-authority.mjs'
  &&!fs.existsSync(root),'Autorité privée neuve et future racine absente requises');
const ref=p=>{
  const s=fs.lstatSync(p),b=fs.readFileSync(p);
  need(s.isFile()&&!s.isSymbolicLink()&&fs.realpathSync(p)===p&&s.uid===process.getuid(),'Ref non canonique '+p);
  return {path:p,sha256:crypto.createHash('sha256').update(b).digest('hex'),bytes:b.length};
};
const checked=(p,sha,bytes)=>{
  const r=ref(p);need(r.sha256===sha&&r.bytes===bytes,'Entrée divergente '+p);return r;
};
const save=(n,j)=>{fs.writeFileSync(out+'/'+n,JSON.stringify(j,null,2)+'\n',{flag:'wx',mode:0o600});return ref(out+'/'+n);};
const chrome=checked('/private/tmp/therese-c17-fresh-wrapper-builder-v9-1G4jE1/profile/chrome.sb',
  '19808ee2cac3169e9fb8c71c24385bcbb97f924c5ed785f4651817ecaa179b0c',2067);
const runner=checked('/private/tmp/therese-c17-test-runner-boundary-eUIHsp/INDEX.json',
  '771565210b1ab41ca7e5a43c89fa63a034c57872515a698a12161e47adfe11b7',5567);
const registry=save('identity-registry.json',{
  schema:'c17-wrapper-canary-live-identity-registry-v1',round_id:root.split('/').at(-1),head,
  repo_head_observed:currentHead,historical_product_source_instrument_only:true,chrome_profile_ref:chrome,
  runner_boundary_index_ref:runner,actors:[{
    actor:'/root',observed_by:'Actual collaboration.list_agents: root running immediately before this preparation',
    observed_at_utc:new Date().toISOString(),role:'Root orchestrateur; aucun PID futur ou reviewer historique relabellé'
  }],OS_qualified:false,FULL:false,release:false
});
const authority=save('prepare-go.json',{
  schema:'c17-root-fresh-wrapper-preparation-go-v1',status:'go_prepare_only',scope:'WRAPPER_CANARY',actor:'/root',root,head,
  repo_head_observed:currentHead,historical_source_WRAPPER_only_not_current_FULL:true,
  product_source_root:'/private/tmp/therese-c17-wrapper-source-kGvU1hdx/source',origin_kind:'root_tool_call',
  builder_ref:checked('/private/tmp/therese-c17-fresh-wrapper-builder-v9-1G4jE1/build_fresh_wrapper.py',
    '5cadd8e672df1c2632b8a7edb780bbb7a4ba0aec60f0ecd06b0d39a90cd8bd28',70913),
  builder_index_ref:checked('/private/tmp/therese-c17-fresh-wrapper-builder-v9-1G4jE1/INDEX.json',
    'c217e93ab0379c964db7cb28cb6eee922438fb6b02cfa097088cfc97a4f81d37',7933),
  web_profile_ref:checked('/private/tmp/therese-c17-web-root-metadata-POjxSafe/web.sb',
    '51ff2e21500393704ea8709fb9bd177dc1f88793d1e92d09c68be70d905807ff',1780),
  chrome_profile_ref:chrome,runner_boundary_index_ref:runner,identity_registry_ref:registry,
  gpu_observation_ref:checked('/private/tmp/therese-c17-wrapper-canary-ea92e9f2c3a9485a88dc906c302f42ff/proofs/system-profiler-displays.raw',
    '92d6e897ef52659540e9497649283da5bd4ff4c443c5d0d07f50bbb37d5bc4d0',186),
  gpu_observation_historical_only_not_native_qualification:true,
  pure_replay_ref:checked('/private/tmp/therese-c17-root-v9-67-replay-nG1QZwpi/receipt.json',
    '9b6de42adaa8d52a3ccd27c88d392c4c4553aecb40f3e35fb3dcb7d28ed2c3f2',65313),
  chrome_qa_copy_ref:checked('/private/tmp/therese-c17-chrome-qa-copy-RoZmwsja/v3-receipt.json',
    'f97793cb43454051da734685185cb5d4e5b5ffbabc516580287195ef3d32993c',17160),
  chrome_spctl_assessment_ref:checked('/private/tmp/therese-c17-chrome-policy-assess-WyJvs5Z0/receipt.json',
    '92dbaaed5278671635b2a0d35f8cb4362ea99b589f0892a180c512fd48932c44',1346),
  root8_diagnostic_ref:checked('/private/tmp/therese-c17-root8-system-diagnostic-wFhTKOw6/receipt.json',
    'ca8b417a39d68cda55eea22694806590d2c3999eefd0b187c82654725beee05a',1403),
  independent_static_review_ref:ref(out+'/V9-REVIEW-OBSERVATION.md'),independent_static_review_received:true,
  preparation_script_ref:ref(out+'/prepare-authority.mjs'),
  authority_is_exact_next_external_preparation_tool_not_this_JSON:true,native_runtime_GO_still_required:true,FULL:false,release:false
});
console.log(JSON.stringify({root,registry_ref:registry,authority_ref:authority,prepared_only:true,native:false,FULL:false,release:false}));
