// Audit statique root réutilisable : aucun processus enfant ni réseau.
import fs from 'node:fs';
import crypto from 'node:crypto';
import path from 'node:path';
const root=process.argv[2];
const need=(x,m)=>{if(!x)throw Error(m);};
need(/^\/private\/tmp\/therese-c17-wrapper-canary-[a-f0-9]{32}$/.test(root),'Racine WRAPPER exacte requise');
const qa='/private/tmp/therese-c17-wrapper-source-kGvU1hdx/source';
const head='2d69e30c9c6dd18823ee6102271876003a6a67cc';
const ref=p=>{
  const s=fs.lstatSync(p),b=fs.readFileSync(p);
  need(s.isFile()&&!s.isSymbolicLink()&&s.uid===process.getuid()&&fs.realpathSync(p)===p,'Ref non canonique '+p);
  return {path:p,sha256:crypto.createHash('sha256').update(b).digest('hex'),bytes:b.length};
};
const read=p=>JSON.parse(fs.readFileSync(p));
const refs=new Map(),pending=[],historicalObservations=[];
const historicalG1ReceiptPaths=new Set([
  '/private/tmp/therese-c17-g1-26-pure-rgpjt79j/receipt.json',
  '/private/tmp/therese-c17-g1-26-pure-bmy35r8g/receipt.json',
  '/private/tmp/therese-c17-g1-26-pure-we_pel56/receipt.json',
]);
const collect=(x,origin='direct')=>{
  if(Array.isArray(x))x.forEach(y=>collect(y,origin));
  else if(x&&typeof x==='object'){
    if(x.schema==='c17-g1-26-pure-tests-v1'&&historicalG1ReceiptPaths.has(origin)){
      // Ce reçu observe le passé : son contenu est pinné, ses snapshots ne sont
      // pas des exigences sur les mêmes chemins physiques après le successeur.
      need(x.pins_before.length===11&&JSON.stringify(x.pins_before)===JSON.stringify(x.pins_after)
        &&x.pins_unchanged===true&&x.passed===true&&x.native_OS_qualification===false
        &&x.FULL_admission===false,'Reçu historique G1 inattendu '+JSON.stringify({origin,count:x.pins_before?.length,unchanged:x.pins_unchanged,passed:x.passed,native:x.native_OS_qualification,FULL:x.FULL_admission,equal:JSON.stringify(x.pins_before)===JSON.stringify(x.pins_after)}));
      historicalObservations.push({origin,kind:'pure_test_observation',refs:x.pins_before.length});
      for(const [k,v] of Object.entries(x))if(!['pins_before','pins_after'].includes(k))collect(v,origin);
    }else if(typeof x.path==='string'&&x.path.startsWith('/')&&/^[a-f0-9]{64}$/.test(x.sha256)&&Object.keys(x).every(k=>['path','sha256','bytes','git_blob'].includes(k))){
      const old=refs.get(x.path);need(!old||old.sha256===x.sha256,'Pins contradictoires '+x.path+' origine='+origin+' '+JSON.stringify({old,new:x}));
      if(!old){refs.set(x.path,x);pending.push(x);}
    }else Object.values(x).forEach(y=>collect(y,origin));
  }
};
const construction=read(root+'/fresh-wrapper-construction.json');
need(construction.head===head&&construction.root===root&&construction.source_refs_count===76
  &&construction.runtime_executed===false&&construction.G1_imported===false&&construction.FULL===false,'Construction hors préparation');
const table=read(construction.source_refs_ref.path);
need(table.source_refs.length===76&&new Set(table.source_refs.map(x=>x.path)).size===76,'Table76 invalide');
need(construction.deltas.length===6&&construction.runner_boundary_definition_refs.length===7,'Deltas6/preuves7 absents');
collect(construction);collect(table);collect(ref(root+'/fresh-wrapper-construction.json'));
for(const [key,count] of [['base11_ref',11],['support8_ref',8],['overlay26_ref',26]]){
  const j=read(construction[key].path);need(Object.keys(j.outputs).length===count,'Sorties '+key);collect(j);
}
const core=read(construction.core17_ref.path);need(core.copies.length===17,'Core17 absent');
for(const row of core.copies)if(row.derivation==='byte_exact')need(ref(row.input.path).sha256===ref(row.output.path).sha256,'Copie non byte-exacte');
need(construction.builder_ref.sha256==='5cadd8e672df1c2632b8a7edb780bbb7a4ba0aec60f0ecd06b0d39a90cd8bd28','Builder autre que V9');
const authority=read(construction.authority_ref.path);
need(authority.builder_index_ref.sha256==='c217e93ab0379c964db7cb28cb6eee922438fb6b02cfa097088cfc97a4f81d37'
  &&authority.repo_head_observed==='9bbee124e47857c2f5d956ef54f1236e944b74f8'
  &&authority.historical_source_WRAPPER_only_not_current_FULL===true,'Autorité V9 ou périmètre historique divergent');
const helper=core.copies.filter(r=>r.output.path===root+'/source/chrome_contract.py');
need(helper.length===1&&helper[0].derivation==='CHROME_QA_exact_constant_only'
  &&helper[0].input.sha256==='26e8374a23b7f67a5c45cbc457156bfd15735cd2578ca0fd7990b3df989630db'
  &&helper[0].output.sha256==='7922a13bdc239338ea9dedf37bf06ef1c91931b77a5275a2db6007d89a9a42ba'
  &&helper[0].derivation_source_ref.sha256===helper[0].output.sha256
  &&JSON.stringify(helper[0].derivation_diff_ref)===JSON.stringify(construction.chrome_contract_delta_ref),'Helper QA non lié exactement');
need(JSON.stringify(construction.chrome_contract_qa_ref)===JSON.stringify(helper[0].output)
  &&table.source_refs.some(r=>JSON.stringify(r)===JSON.stringify(helper[0].output)),'Helper QA absent des76');
const copyProof=construction.chrome_qa_copy_ref;
need(copyProof.sha256==='f97793cb43454051da734685185cb5d4e5b5ffbabc516580287195ef3d32993c'&&copyProof.bytes===17160,'Autre reçu copie Chrome');
const observations=[construction.chrome_copy_fresh_before_ref,construction.chrome_copy_fresh_after_ref].map(r=>read(r.path));
for(const o of observations)need(o.schema==='c17-chrome-copy-fresh-filesystem-observation-v1'
  &&o.source==='/Applications/Google Chrome.app'&&o.target==='/private/tmp/therese-c17-chrome-qa-copy-RoZmwsja/Google Chrome.app'
  &&o.entries===1339&&o.types.file===697&&o.types.directory===635&&o.types.symlink===7
  &&o.source_manifest_equal===true&&o.copy_manifest_equal===true&&o.all_bytes_modes_UID_GID_links_equal===true
  &&o.source_and_copy_inodes_match_archived_snapshots===true&&o.no_hardlinks_to_source===true
  &&o.codesign_reexecuted===false&&o.xattrs_currently_measured===false&&o.runtime_qualified===false
  &&JSON.stringify(o.root_copy_receipt_ref)===JSON.stringify(copyProof),'Observation physique Chrome invalide');
need(observations[0].source_snapshot_sha256===observations[1].source_snapshot_sha256
  &&observations[0].copy_snapshot_sha256===observations[1].copy_snapshot_sha256
  &&Date.parse(observations[0].observed_at_utc)<=Date.parse(observations[1].observed_at_utc),'Observations Chrome discordantes');
const go=read(construction.root_go_ref.path),auxiliary=read(go.auxiliary_ref.path);
for(const key of ['chrome_contract_qa_ref','chrome_contract_delta_ref','chrome_copy_fresh_before_ref','chrome_copy_fresh_after_ref','chrome_qa_copy_ref'])
  need(JSON.stringify(go[key])===JSON.stringify(construction[key]),'GO non joint '+key);
const executable='/private/tmp/therese-c17-chrome-qa-copy-RoZmwsja/Google Chrome.app/Contents/MacOS/Google Chrome';
need(Object.keys(auxiliary.auxiliary_descriptors).length===5,'Chrome jobs autre que5');
for(const row of Object.values(auxiliary.auxiliary_descriptors)){
  const defaults=read(row.launch_defaults_ref.path);
  need(row.executable===executable&&row.argv[0]===executable&&defaults.executable===executable
    &&JSON.stringify(defaults.argv)===JSON.stringify(row.argv)&&row.port===17594
    &&row.profile.startsWith(root+'/auxiliary/'),'Descripteur/defaults Chrome divergents');
}
const sql=read(construction.sql_contract_ref.path);
need(sql.head===head&&sql.round_id===path.basename(root)&&sql.root_reviewed===false&&sql.root_review_required===true,'Contrat SQL incorrect');
const historical=read(sql.historical_contract_definition.path);
need(JSON.stringify(Object.keys(sql.relations).sort())==='["B1753","B1760"]','Groupes SQL différents');
for(const n of ['B1753','B1760'])need(JSON.stringify(sql.relations[n])===JSON.stringify(historical.relations[n]),'Relations historiques SQL réécrites '+n);
need(Object.keys(sql.source_snapshot).length===36,'SQL sources36 absentes');
for(const [n,s] of Object.entries(sql.source_snapshot))need(ref(qa+'/'+n).sha256===s,'Source SQL changée '+n);
collect(sql);
const manifestPath='/private/tmp/therese-c17-wrapper-source-kGvU1hdx/proofs/qa-source-files.json';
need(ref(manifestPath).sha256==='0904574e2b35b523b8454b33156f595f05a62e21609453a65db59ae516423b89','Manifest QA différent');
const manifest=read(manifestPath);
need(manifest.head===head&&manifest.files.length===3579&&manifest.symlinks.length===0,'Tree3579/symlinks');
need(fs.readFileSync(qa+'/.git/HEAD','utf8').trim()===head,'HEAD physique différent');
for(const r of manifest.files){
  const a=ref(r.path),raw=fs.readFileSync(r.path),n=r.path.slice(qa.length+1),mode=manifest.modes[r.path];
  need(a.sha256===r.sha256&&a.bytes===r.bytes,'Blob physique changé '+n);
  need(crypto.createHash('sha1').update(Buffer.concat([Buffer.from('blob '+raw.length+'\0'),raw])).digest('hex')===r.git_blob,'Git blob différent '+n);
  need(['100644','100755'].includes(mode)&&((fs.statSync(r.path).mode&0o111)!==0)===(mode==='100755'),'Mode Git différent '+n);
}
for(let i=0;i<pending.length;i++){
  need(pending.length<6000,'Références hors borne');
  const r=pending[i],a=ref(r.path);need(a.sha256===r.sha256&&(r.bytes===undefined||a.bytes===r.bytes),'Ref changée '+r.path);
  if(r.path.endsWith('.json')&&r.path!==sql.historical_contract_definition.path)collect(read(r.path),r.path);
}
for(const name of ['binding.json','decision.json','runtime/readiness.json','runtime/pile-reprise.json','runtime/services-running.json','wrapper-canary-result.json'])need(!fs.existsSync(root+'/'+name),'État natif prématuré '+name);
need(ref(root+'/g1/web.sb').sha256==='51ff2e21500393704ea8709fb9bd177dc1f88793d1e92d09c68be70d905807ff'
  &&ref(root+'/g1/chrome.sb').sha256==='19808ee2cac3169e9fb8c71c24385bcbb97f924c5ed785f4651817ecaa179b0c','Profils autres successeurs');
console.log(JSON.stringify({status:'prepared_only_static_verified',root,refs:refs.size,historical_observations:historicalObservations,sources:76,git_tree_files:3579,git_modes:true,git_blobs:true,SQL_sources:36,SQL_relations_unchanged:true,original11:true,deltas:6,witness_copies:7,native:false,FULL:false,release:false}));
