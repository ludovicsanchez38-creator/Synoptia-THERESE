"""Vrais corps AST du composite, doubles déclarés. Jamais G1 complet/OS.

Les 47 cas watchdog sont rejoués sur le composite sans changer leurs
assertions. Seule leur fixture stop reçoit le nouveau scan A/B obligatoire.
"""
from __future__ import annotations

import ast
import copy
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import re
from types import SimpleNamespace as NS
import unittest

ROOT = Path(__file__).resolve().parent.parent
CANDIDATE = ROOT / 'candidate'


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


assembler = module('pure_closed_composite_builder', ROOT / 'assemble_closed.py')
origin = module('pure_original_watchdog_tests', assembler.WATCH / 'tests/test_bootstrap.py')
origin.HERE = CANDIDATE
ab = module('pure_ab_closed_table', CANDIDATE / 'g1/ab_auxiliary_table.py')
need = origin.need
selected = origin.selected


def stop_ports_fixture(trace):
    """Synthetic observation only; no lsof or OS absence qualification."""
    trace.append('two-passes-three-ports-DOUBLE')
    return {'receipt': {'path': '/synthetic/ports3'}, 'result': {
        'ports_absent': [17593, 5173], 'auxiliary_ports_absent': [17594],
        'ports_absence_proved': True, 'port_absence_elapsed_seconds': 0.01}}


class CompositeG1Seams(origin.G1SeamsTests):
    def prepare_stop(self):
        super().prepare_stop()
        self.session._record_ports_absence = lambda phase: stop_ports_fixture(self.trace)

    def test_ports3_and_transport_both_before_final_receipt(self):
        self.prepare_stop()
        row = self.ns.stop(self.session)
        raw = self.saved[row['path']]
        self.assertLess(self.trace.index('transport-close'), self.trace.index('finish-handles'))
        self.assertLess(self.trace.index('two-passes-three-ports-DOUBLE'), self.trace.index('save-session-close-1.json'))
        self.assertEqual(raw['ports_absent'], [17593, 5173])
        self.assertEqual(raw['auxiliary_ports_absent'], [17594])
        self.assertTrue(raw['ports_absence_proved'] and raw['rpc_transport_clean'])

    def test_ports_refusal_cannot_make_close_green(self):
        self.prepare_stop()
        self.session._record_ports_absence = lambda phase: {'receipt': {'path': '/synthetic/ports3'},
            'result': {'ports_absent': [], 'auxiliary_ports_absent': [], 'ports_absence_proved': False,
                       'port_absence_elapsed_seconds': 0.01}}
        raw = self.saved[self.ns.stop(self.session)['path']]
        self.assertFalse(raw['clean'] or raw['session_closed'] or raw['log_stability_proved'])

    def test_existing_taint_never_reset_by_physical_cleanup(self):
        self.prepare_stop()
        self.session.log_stability_tainted = True
        raw = self.saved[self.ns.stop(self.session)['path']]
        self.assertTrue(raw['log_stability_tainted'])
        self.assertFalse(raw['log_stability_proved'])

    def test_transport_error_still_probes_ports_and_cleans_exact_handles(self):
        self.prepare_stop()
        self.session._owned_rpc_bootstrap.close_before_session_receipt = lambda: (_ for _ in ()).throw(OSError('DOUBLE transport write failure'))
        raw = self.saved[self.ns.stop(self.session)['path']]
        self.assertIn('finish-handles', self.trace)
        self.assertIn('two-passes-three-ports-DOUBLE', self.trace)
        self.assertTrue(raw['log_stability_tainted'])
        self.assertFalse(raw['clean'] or raw['log_stability_proved'])


class ReachedAuxiliary(Exception):
    pass


class StartComposition(unittest.TestCase):
    def setUp(self):
        self.fixture = Path(os.environ['C17_PURE_FIXTURE_ROOT']) / ('start-' + self._testMethodName)
        self.fixture.mkdir(mode=0o700)
        self.source = self.fixture / 'source'
        self.source.mkdir()
        self.trace = []
        self.rpc = ast.literal_eval(assembler.closed_assignments((CANDIDATE / 'g1/runtime_session.py').read_text())['RPC_CHILDREN'])
        self.bounds = ast.literal_eval(assembler.closed_assignments((CANDIDATE / 'g1/runtime_session.py').read_text())['STAGE_TIMEOUTS'])
        self.bounds.update({name: row[1] for name, row in self.rpc.items()})
        self.bounds.update({name: 50 for name in ab.NAMES.values()})

    def setup_job(self, job):
        root = self.fixture
        self.job = job
        self.env = {'TEST_DOUBLE_ONLY': job}
        self.cwd, self.stdout, self.stderr = self.source, root / (job + '.stdout'), root / (job + '.stderr')
        role = 'stage-' + job
        timeout = self.bounds[job]
        command = ['/synthetic/node', str(root / (dict(ab.DIRECT_SITES).get(job, 'rpc-source.mjs')))]
        self.actual = {'argv': command, 'role': role, 'mode': 'web', 'timeout_seconds': timeout,
            'env': dict(self.env), 'cwd': str(self.cwd), 'stdout_path': str(self.stdout),
            'stderr_path': str(self.stderr), 'combine_stderr': False,
            'derived_deadline': 'start_monotonic_plus_exact_timeout'}
        self.session = NS(root=root, actor='/root/environment_routes', round_id='synthetic-round',
            round_name='A', head='a' * 40, decision={}, decision_ref={}, binding_ref={},
            closed=False, _handlers_restored=False, close_attempts=0, handles={},
            services_stopped=False, qa_python=Path('/synthetic/python'), product_source_root=self.source,
            _rpc_dispatcher=object(), _stage_admissions={},
            check_round_deadline=lambda **kw: self.trace.append(('frontier',kw)),
            verify_rpc_plan=lambda: self.trace.append('verify-plan'), _released_birth=lambda h: True,
            validate_sources=lambda: self.trace.append('source-check'),
            start_auxiliary_for_job=lambda name: (_ for _ in ()).throw(ReachedAuxiliary(name)))
        self.binding = {'commands': {job: self.actual}, 'rpc_descriptors': {}}
        self.session.binding = self.binding
        request_ref = None
        observed = None
        parent_name = None
        if job in self.rpc:
            parent_name = self.rpc[job][0]
            identity = dict(origin.IDENTITY)
            self.session.handles[parent_name] = {'role': 'stage-' + parent_name,
                'root_identity': identity, 'process': NS(poll=lambda: None)}
            self.session.ledger = NS(attribute=lambda: None,
                info=lambda pid: identity | {'status': 1}, unchanged=lambda before, after: all(after[k] == v for k,v in before.items()))
            self.actual['logical_parent_id'] = parent_name
            descriptor = {'id': job, 'stage_name': job, 'requester_id': parent_name,
                'logical_parent_id': parent_name, 'role': role, 'timeout_seconds': timeout,
                'mode': 'web', 'nonce': 'a' * 32, 'argv': command, 'cwd': str(self.cwd),
                'environment': self.env, 'stdout_path': str(self.stdout), 'stderr_path': str(self.stderr)}
            self.binding['rpc_descriptors'][job] = descriptor
            request_ref = {'path': str(root / 'session-rpc/request' / (job + '-' + descriptor['nonce'] + '.json'))}
            observed = identity
        names = {name: 'aux-chrome-' + name for name in ab.RPC_JOBS}
        # The injected globals are all declared doubles; no OS identity/ref is asserted.
        space = {'Path': Path, 're': re, 'require': need,
            'load_admission': lambda *args,**kw: (self.session.decision,self.binding),
            'STAGE_TIMEOUTS': self.bounds, 'RPC_CHILDREN': self.rpc, 'RPC_REQUESTERS': frozenset(row[0] for row in self.rpc.values()),
            'PERSISTENT': frozenset(('persistent-backend','persistent-vite')),
            'AUXILIARY_NAMES': names, 'AUXILIARY_ALL_NAMES': names | ab.NAMES,
            'NODE_ROOT': Path('/synthetic'), 'CHROME': Path('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'),
            'ab_aux': ab, 'direct_round': NS(DIRECT_PARENTS=frozenset(('calibrate','B1753','B1760','B1753-power'))),
            'full_rpc_binding': NS(parent_metadata=lambda *a,**k: self.trace.append('parent-metadata')),
            'validate_environment': lambda root,env,*a,**k: dict(env),
            'validate_rpc_environment': lambda root,env,*a,**k: dict(env),
            'validate_ab_child_metadata': lambda *a,**k: self.trace.append('ab-metadata'),
            'child_path': lambda root,path: path.resolve(), 'reference': lambda path: {'path':str(path)},
            'read_published_json': lambda *a: {}, 'root_stage_relay': NS(guard=lambda *a: None)}
        # Match source allowlist's NODE_ROOT/bin/node without creating/executing one.
        command[0] = '/synthetic/bin/node'
        self.start = selected(CANDIDATE / 'g1/runtime_session.py',(),space,methods=('start',)).start
        self.call = (self.session,job,role,command)
        self.kw = {'mode':'web','timeout':timeout,'env':self.env,'cwd':self.cwd,'stdout_path':self.stdout,
            'stderr_path':self.stderr,'logical_parent_id':parent_name,'rpc_request_ref':request_ref,
            'rpc_observed_requester':observed}

    def test_all_fourteen_real_start_paths_reach_auxiliary_before_FD(self):
        for job in ab.JOBS:
            with self.subTest(job=job):
                self.setup_job(job)
                with self.assertRaisesRegex(ReachedAuxiliary,re.escape(job)):
                    self.start(*self.call,**self.kw)
                self.assertEqual(self.trace[0],('frontier',{'verify_sources':True}))
                self.assertIn('ab-metadata',self.trace)
                self.assertIn('source-check',self.trace)
                self.trace.clear()

    def test_expired_frontier_blocks_real_start_before_FD_Popen(self):
        self.setup_job('coverage')
        self.session.check_round_deadline=lambda **kw: (_ for _ in ()).throw(TimeoutError('synthetic-expired'))
        with self.assertRaisesRegex(TimeoutError,'synthetic-expired'):
            self.start(*self.call,**self.kw)
        self.assertEqual(self.trace,[])

    def test_command_mismatch_refused_before_auxiliary(self):
        self.setup_job('coverage')
        self.binding['commands']['coverage'] = dict(self.actual,argv=['/synthetic/bin/node','other.mjs'])
        with self.assertRaisesRegex(ValueError,'non exactement revus'):
            self.start(*self.call,**self.kw)
        self.assertNotIn('source-check',self.trace)

    def test_bound_mismatch_refused_before_auxiliary(self):
        self.setup_job('coverage')
        with self.assertRaisesRegex(ValueError,'Borne'):
            self.start(*self.call,**(self.kw|{'timeout':1499}))

    def test_rpc_wrong_birth_refused_before_auxiliary(self):
        self.setup_job(ab.RPC_JOBS[0])
        with self.assertRaisesRegex(ValueError,'Demandeur observé'):
            self.start(*self.call,**(self.kw|{'rpc_observed_requester':origin.IDENTITY|{'start_usec':3}}))


class ExactDefinitions(unittest.TestCase):
    def test_flags_capabilities_tables_closed(self):
        assembler.validate_closed_g1((CANDIDATE/'g1/runtime_session.py').read_text())
        self.assertIs(ast.literal_eval(assembler.closed_assignments((CANDIDATE/'successor/runtime78_core.py').read_text())['RUNTIME_ENABLED']),False)

    def test_reader_and_relay_exact(self):
        self.assertEqual(assembler.ref(CANDIDATE/'g1/root_stage_relay.py')['sha256'],assembler.NEW_RELAY)
        self.assertEqual(assembler.ref(CANDIDATE/'calibration/build-calibrations-c17.py')['sha256'],assembler.NEW_READER)
        coor=(CANDIDATE/'successor/runtime78_coordinator.py').read_text()
        self.assertEqual(ast.literal_eval(assembler.closed_assignments(coor)['CALIBRATION_BUILDER_SHA256']),assembler.NEW_READER)
        self.assertIn(assembler.NEW_RELAY,(CANDIDATE/'g1/runtime_session.py').read_text())

    def test_changed_relay_anchor_rejected(self):
        bad=(assembler.AB/'g1/runtime_session.py').read_text().replace(assembler.OLD_RELAY,'f'*64)
        with self.assertRaisesRegex(ValueError,'Unique source anchor'):
            assembler.compose_g1(bad,(assembler.WATCH/'g1/runtime_session.py').read_text())

    def test_already_changed_reader_anchor_rejected(self):
        source=(assembler.WATCH/'successor/runtime78_coordinator.py').read_text().replace(assembler.OLD_READER,'f'*64)
        with self.assertRaisesRegex(ValueError,'Unique source anchor'):
            assembler.derived(source,'successor/runtime78_coordinator.py',{})

    def test_opened_capability_rejected(self):
        source=(CANDIDATE/'g1/runtime_session.py').read_text().replace('"owned_listener_rpc": False','"owned_listener_rpc": True')
        with self.assertRaisesRegex(ValueError,'Capability opened'):
            assembler.validate_closed_g1(source)

    def test_original_chrome_profile_and_fourteen_descriptors(self):
        self.assertEqual(len(ab.JOBS),14)
        self.assertEqual(assembler.ref(CANDIDATE/'g1/chrome.sb')['sha256'],ab.CHROME_CANDIDATE_SHA256)
        root=Path('/private/tmp/therese-c17-direct-round-a-0123456789ab')
        rows=[ab.expected_row(root,job) for job in ab.JOBS]
        self.assertEqual({r['executable'] for r in rows},{'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'})
        self.assertEqual({r['port'] for r in rows},{17594})
        self.assertEqual(len({r['profile'] for r in rows}),14)

    def test_descriptors_other_job_or_campaign_refused(self):
        root=Path('/private/tmp/therese-c17-direct-round-a-0123456789ab')
        with self.assertRaises(ValueError):ab.expected_row(root,'invented')
        self.assertFalse(ab.scope(root,'B'))

    def test_all_noncollision_ab_methods_byte_equivalent_AST(self):
        before=assembler.methods((assembler.AB/'g1/runtime_session.py').read_text())
        after=assembler.methods((CANDIDATE/'g1/runtime_session.py').read_text())
        for name in before.keys()-{'__init__','start','wait','stop'}:
            with self.subTest(method=name):self.assertEqual(ast.dump(before[name],include_attributes=False),ast.dump(after[name],include_attributes=False))

    def test_stop_services_not_close_transport(self):
        source=assembler.block((CANDIDATE/'g1/runtime_session.py').read_text(),'stop_services')
        self.assertNotIn('_close_owned_rpc_transport',source)
        self.assertIn('_record_ports_absence',source)

    def test_sql_poststop_builder_before_final_session_stop(self):
        source=(CANDIDATE/'successor/runtime78_coordinator.py').read_text()
        self.assertLess(source.index("in_process(root, config, session, 'stop-runtime'"),source.index('index_ref = build_calibrations_after_stop'))
        self.assertLess(source.index('index_ref = build_calibrations_after_stop'),source.index('final_cleanup = session.stop()'))
        strings = [n.value for n in ast.walk(ast.parse((CANDIDATE/'g1/runtime_session.py').read_text()))
                   if isinstance(n, ast.Constant) and isinstance(n.value, str)]
        self.assertIn('sql-calibration.sb', strings)


def selected_class_method(path,cls_name,name,namespace):
    tree=ast.parse(path.read_text());cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name==cls_name)
    fn=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name==name)
    scope=dict(namespace)
    exec(compile(ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[])),str(path),'exec'),scope)
    return scope[name]


class RpcABClosure(unittest.TestCase):
    def setUp(self):
        self.root=Path('/private/tmp/therese-c17-direct-round-a-0123456789ab')
        self.context={'root':str(self.root),'round_id':'c17-direct-round-a-0123456789ab','head':'a'*40,'owner_identity':origin.IDENTITY}
        self.trace=[];self.raws={}
        scope={'Path':Path,'re':re}
        self.p=selected(CANDIDATE/'transport/rpc_protocol.py',('wrapper_scope','ab_scope','auxiliary_metadata_keys'),
            scope|{'CHROME_JOBS':frozenset(ab.RPC_JOBS)})
        self.p.require=need;self.p.CHROME_JOBS=frozenset(ab.RPC_JOBS)
        self.p.checked_json=lambda ref,**kw:self.raws[ref['path']]
        self.p.validate_auxiliary_terminal=lambda *a,**kw:self.trace.append('auxiliary-contradiction')
        self.p.same_identity=lambda a,b:need(a==b,'identity')
        self.p.identity=lambda x:x
        self.p.common=lambda context:{}
        self.p.digest=lambda row:'digest'
        self.p.ACK_SCHEMA='ack-schema'
        self.p.CLEANUP_SECONDS=8
        self.p.finite=lambda x:type(x) in (int,float) and math.isfinite(x)
        self.p.read_reference=lambda *a,**kw:b''

    def normal(self,job):
        child=origin.IDENTITY|{'pid':902,'ppid':origin.IDENTITY['pid']}
        ref={'path':'receipt'};cleanref={'path':'cleanup'};auxref={'path':'auxiliary'}
        out={'path':'stdout'};err={'path':'stderr'}
        row={'id':job,'stage_name':job,'requester_id':'calibrate','logical_parent_id':'calibrate',
            'index':0,'nonce':'nonce','argv':['/synthetic/node'],'cwd':'/synthetic','stdout_path':'stdout','stderr_path':'stderr','source_refs':[]}
        raw={'root_identity':child,'argv':row['argv'],'cwd':row['cwd'],'exit_code':1,'raw_stable':True,
            'timed_out':False,'log_stability_tainted':False,'instrument_error':None,'termination_proved':True,'stdout':out,'stderr':err}
        cleanup={'child_identity':child,'clean':True,'log_stability_proved':True,'remaining_attributed':[],
            'ambiguities':[],'errors':[],'signals':[],'receipt_ref':ref,'auxiliary_terminal_ref':auxref,
            'stage':job,'requester_id':'calibrate','logical_parent_id':'calibrate','termination_proved':True,
            'cleanup_deadline_met':True,'cleanup_elapsed_seconds':0.1}
        ack={'schema':'ack-schema','request_ref':{'path':'request'},'descriptor_digest':'digest','id':job,
            'index':0,'nonce':'nonce','state':'complete','exit_code':1,'tainted':False,'termination_proved':True,
            'log_stability_proved':True,'cleanup_deadline_met':True,'signals':[],'child_identity':child,
            'receipt_ref':ref,'cleanup_ref':cleanref,'auxiliary_terminal_ref':auxref,'stdout_ref':out,'stderr_ref':err,'clean':True}
        self.raws={'receipt':raw,'cleanup':cleanup}
        return row,ack

    def test_client_real_ack_requires_auxiliary_for_five_ab_jobs(self):
        fn=selected_class_method(CANDIDATE/'transport/rpc_client.py','FileRpcTransport','_check_ack',
            {'p':self.p,'os':NS(environ={}), 'RpcInstrumentError':ValueError})
        for job in ab.RPC_JOBS:
            row,ack=self.normal(job)
            fn(NS(root=self.root,context=self.context),ack,row,ack['request_ref'])
        self.assertEqual(self.trace,['auxiliary-contradiction']*5)

    def test_dispatcher_real_terminal_requires_auxiliary_for_five_ab_jobs(self):
        fn=selected_class_method(CANDIDATE/'transport/rpc_dispatcher.py','RpcDispatcher','_validate_terminal',{'p':self.p})
        for job in ab.RPC_JOBS:
            row,ack=self.normal(job)
            fn(NS(root=self.root,context=self.context,adapter=NS(session=NS(binding_ref={'sha256':'f'*64}))),row,ack)
        self.assertEqual(self.trace,['auxiliary-contradiction']*5)

    def test_missing_auxiliary_join_refused_real_client(self):
        fn=selected_class_method(CANDIDATE/'transport/rpc_client.py','FileRpcTransport','_check_ack',
            {'p':self.p,'os':NS(environ={}), 'RpcInstrumentError':ValueError})
        row,ack=self.normal(ab.RPC_JOBS[0]);ack['auxiliary_terminal_ref']={'path':'other'}
        with self.assertRaisesRegex(ValueError,'ACK/cleanup join'):fn(NS(root=self.root,context=self.context),ack,row,ack['request_ref'])

    def test_auxiliary_validator_refusal_not_masked_by_code_one(self):
        fn=selected_class_method(CANDIDATE/'transport/rpc_dispatcher.py','RpcDispatcher','_validate_terminal',{'p':self.p})
        self.p.validate_auxiliary_terminal=lambda *a,**kw:(_ for _ in ()).throw(ValueError('synthetic Chrome discordance'))
        row,ack=self.normal(ab.RPC_JOBS[0])
        with self.assertRaisesRegex(ValueError,'Chrome discordance'):
            fn(NS(root=self.root,context=self.context,adapter=NS(session=NS(binding_ref={'sha256':'f'*64}))),row,ack)

    def test_real_child_environment_requires_ab_metadata(self):
        fn=selected_class_method(CANDIDATE/'transport/rpc_client.py','FileRpcTransport','child_environment',{'p':self.p})
        row={'id':'rpc-all-logs','environment':{'business':'same','C17_AUX_GIT_SNAPSHOT_REF':'pinned','C17_AUX_LOGS_RUN':'fixed'}}
        fake=NS(root=self.root,context=self.context,_next=lambda:row)
        self.assertEqual(fn(fake,{'business':'same'}),row['environment'])
        row['environment'].pop('C17_AUX_LOGS_RUN')
        with self.assertRaisesRegex(ValueError,'metadata absent'):fn(fake,{'business':'same'})


def suite():
    result=unittest.TestSuite()
    # Same 47 baseline assertions, now against derived sources. No 47+47 claim.
    for cls in (origin.BootstrapTests,CompositeG1Seams,origin.StaticAndConsumerTests,origin.WatchdogCostTests,
                StartComposition,ExactDefinitions,RpcABClosure):
        result.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(cls))
    return result
