# Composite FULL C17, définitions fermées

Ce dossier compose les définitions SQL48, A/B80 et watchdog47. Il ne crée
aucune vraie racine A/B, donnée, identité, décision, admission ou preuve native.
Tous les flags, tables et capacités restent fermés. Ce n'est ni une ronde ni
une qualification FULL, et il ne change aucune assertion métier 27/78.

## Changements réels

- G1 conserve les fonctions A/B80. `start` reçoit la frontière watchdog avant
  FD/gate/Popen. `__init__` reçoit seulement son état bootstrap. `wait` conserve
  le tick léger. `stop` ferme le transport possédé avant les handles et le reçu
  final, tout en conservant les deux passes des trois ports 17593/5173/17594.
- Le relais est exactement `9b271297…`. Le lecteur de calibration est
  exactement `fd5256f0…`, avec son pin coordinateur actualisé.
- Deux branches client et une branche dispatcher jusque-là WRAPPER-only sont
  explicitement étendues au prédicat A/B existant. Les contrôles des métadonnées,
  reçus auxiliaires, codes de sortie et taint ne sont pas retirés.
- Les six modules RPC sont matérialisés ensemble et leurs nouveaux SHA figurent
  dans `construction.json`. Quatre fichiers ont une différence fonctionnelle.
  Les préimages et différences intégrales sont conservées.

Chrome garde la définition originale `/Applications/Google Chrome.app`, le
profil `5266a6b0…` et les quatorze jobs A/B. Ce choix reste explicitement non
qualifié. Aucune permission, copie Chrome QA V8 ou réussite WRAPPER n'est
empruntée. Les profils SQL/web/lsof existants sont des définitions, pas des
résultats transposés.

## Vérifications effectuées

La construction mécanique pure a terminé à 0. Les 45 sources sélectionnées
sont inchangées avant/après. Le rejeu sous `pure.sb` a réellement exécuté
71 cas : les 47 mêmes assertions watchdog sur les sources composées et 24 cas
de raccord. Résultat : 0 échec, 0 erreur, 0 saut. Il ne s'agit pas de 47 nouveaux
cas ajoutés au dénominateur historique.

Reçu brut externe :
`/private/tmp/therese-c17-full-composite-tests-EVphNXEe/receipt.json`,
SHA `934b352b0ca265359b2070adfac4dc2018e6f5f16ae7f90f532e2b32b866c95b`.
Les sources hachées sont identiques avant/après ; aucun événement processus,
socket ou import G1 entier n'est observé. Le profil OS interdit fork/réseau et
n'autorise les écritures que dans cette racine de tests distincte du gel.
La garde Python interdit aussi les appels processus/socket/ctypes/signaux et
les imports complets de l'instrumentation. Elle ne remplace pas une mesure
native de l'instrument.

Les vrais corps sélectionnés AST et les doubles explicitement synthétiques
éprouvent l'expiration avant FD/Popen, les quatorze prélaunch auxiliaires A/B,
les discordances argv/borne/birth, la fermeture transport avant reçu, le scan
trois ports, le taint monotone, les pins lecteur/relais et les contrôles RPC
auxiliaires conservant les codes non nuls. Aucun PID, port absent, pair Unix,
processus Chrome ou identité réelle n'est qualifié par ces doubles.

La fixture `candidate/synthetic-fixtures/wait-receipt.json` est une copie
byte-exacte de la définition synthétique watchdog uniquement pour le rejeu du
même corps `wait`. Elle est référencée séparément et n'est pas un reçu runtime.

Pour rejouer dans une sortie neuve après lecture, utiliser le Python physique
et `run-pure.py --output /private/tmp/therese-c17-full-composite-tests-<nonce>`
sous `sandbox-exec -D TEST_ROOT=<même sortie> -f pure.sb`, avec `-I -B` et un
environnement minimal. Le répertoire doit exister et être vide. Ce rejeu est
pur ; aucune admission native n'en découle.

## Prérequis encore absents

1. Le constructeur physique A/B actuel doit émettre checkout/dépendances,
   données, manifestes, contrat API, enveloppes/plan et commandes à partir du
   HEAD réellement choisi. Ce lot livre l'assembleur de définitions, pas ce
   constructeur physique ni ses décisions externes.
2. Le préflight instrumental A/B doit produire les vrais canaris requis par
   `rpc_abi_reader`, même contexte/acteur/round/HEAD, avec pair physique et
   profils/modules exacts. Aucun résultat WRAPPER/Q n'est substituable.
3. La chaîne Chrome A/B originale et les autres profils doivent être admis et
   qualifiés nativement après revue. Les tables/caps restent false/vides.
4. Les consommateurs FULL encore liés au HEAD historique nécessitent un port
   causal explicite sur les sources actuelles, sans renommer les anciennes
   observations ou abaisser les obligations.
5. Deux vraies rondes d'acteurs distincts restent requises, avec six axes de
   calibration frais, 78 preuves runtime, captures/revues, preuves unitaires,
   native et arbitrages de couverture. Aucun plateau déclaratif ni force
   transition ne remplace ces preuves.

`INDEX.json` lie tous les fichiers de ce gel, les définitions d'origine et les
trois bruts de tests externes. Le contrôle statique reconstitue les quatre
différences et refuse toute incohérence de source ou préimage.
