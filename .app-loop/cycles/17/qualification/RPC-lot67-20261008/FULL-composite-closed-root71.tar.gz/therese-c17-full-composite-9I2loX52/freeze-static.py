"""Contrôle de FS/AST et index exclusif, sans importer G1/RPC."""
from __future__ import annotations
import ast
from datetime import UTC, datetime
import difflib
import hashlib
import importlib.util
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
TEST = Path('/private/tmp/therese-c17-full-composite-tests-EVphNXEe')


def ref(path):
    data = Path(path).read_bytes()
    return {'path':str(path),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}


def need(value,message):
    if not value: raise ValueError(message)


def save(path,value):
    with open(path,'x',encoding='utf-8') as stream:
        json.dump(value,stream,ensure_ascii=False,indent=2);stream.write('\n')


def main():
    spec=importlib.util.spec_from_file_location('pure_composite_assembler',HERE/'assemble_closed.py')
    assembler=importlib.util.module_from_spec(spec);spec.loader.exec_module(assembler)
    construction=json.loads((HERE/'construction.json').read_text())
    inputs=json.loads((HERE/'inputs.json').read_text())['sources']
    source_map={r['path']:r for r in inputs}
    checked=[]
    for row in inputs:
        assembler.checked(row);checked.append(row)
    need(construction['sources_before']==construction['sources_after'],'Changed construction input')
    need(construction['source_unchanged'] is True,'Construction sources not unchanged')
    outputs=[]
    for origin in construction['origins']:
        assembler.checked(origin['original']);assembler.checked(origin['preimage'])
        before=Path(origin['preimage']['path']).read_bytes()
        need(before==Path(origin['original']['path']).read_bytes(),'Original/preimage mismatch')
        if origin['candidate'] is not None:
            current=Path(origin['candidate']['path']);assembler.checked(origin['candidate'])
            relative=str(current.relative_to(HERE/'candidate'))
            expected=assembler.derived(before.decode(),relative,source_map).encode()
            need(current.read_bytes()==expected,'Reconstruction mismatch: '+relative)
            need(origin['byte_exact'] is (before==expected),'Byte-exact claim mismatch')
            outputs.append(origin['candidate'])
    need(outputs==construction['outputs'],'Output order/set mismatch')
    for row in construction['diffs']:
        for key in ('before','after','diff'):assembler.checked(row[key])
        relative=str(Path(row['after']['path']).relative_to(HERE/'candidate'))
        origin=next(o for o in construction['origins'] if o['candidate']==row['after'])
        delta=''.join(difflib.unified_diff(Path(row['before']['path']).read_text().splitlines(True),
            Path(row['after']['path']).read_text().splitlines(True),fromfile=origin['original']['path'],
            tofile=row['after']['path'])).encode()
        need(Path(row['diff']['path']).read_bytes()==delta,'Diff not exhaustive: '+relative)
    need(len(construction['diffs'])==4,'Expected four functional files')
    assembler.validate_closed_g1((HERE/'candidate/g1/runtime_session.py').read_text())
    ast_files=[]
    for path in sorted(HERE.rglob('*.py')):
        ast.parse(path.read_text(),filename=str(path));ast_files.append(ref(path))
    fixture=assembler.WATCH/'synthetic-fixtures/wait-receipt.json'
    need((HERE/'candidate/synthetic-fixtures/wait-receipt.json').read_bytes()==fixture.read_bytes(),
         'Synthetic fixture definition changed')
    pure=json.loads((TEST/'receipt.json').read_text())
    need(pure['passed'] is True and pure['tests']==71 and pure['failures']==pure['errors']==pure['skipped']==0
        and pure['sources_unchanged'] is True and pure['forbidden_events']==pure['full_instrument_imports']==[]
        and pure['pins_before']==pure['pins_after'] and pure['instrument_error'] is None,'Pure receipt not qualified')
    for row in pure['pins_after']:assembler.checked(row)
    for key in ('stdout','stderr'):assembler.checked(pure[key])
    indexes=[assembler.SQL/'INDEX.json',assembler.AB/'INDEX.json',assembler.WATCH/'INDEX.json']
    origins=inputs+[ref(p) for p in indexes]+[ref(fixture),ref(assembler.WATCH/'tests/test_bootstrap.py')]
    raw=[ref(TEST/name) for name in ('receipt.json','stdout.log','stderr.log')]
    report={'schema':'c17-closed-full-composite-static-audit-v1','actor':'/root/cycle17_gate_review',
        'observed_at':datetime.now(UTC).isoformat(),'selected_source_count':len(inputs),
        'outputs_count':len(outputs),'functional_diff_count':4,'AST':ast_files,
        'source_current':checked,'preimages_reconstructed':True,'diffs_exhaustive':True,
        'RPC_modules':construction['RPC_modules'],'reader_sha256':assembler.NEW_READER,
        'relay_sha256':assembler.NEW_RELAY,'pure_receipt':ref(TEST/'receipt.json'),
        'pure_tests':71,'original_watchdog_cases_replayed':47,'new_composition_cases':24,
        'native_executed':False,'runtime_admitted':False,'FULL':False,'status':'closed_static_only'}
    save(HERE/'static-audit.json',report)
    files=[ref(p) for p in sorted(HERE.rglob('*')) if p.is_file() and p.name!='INDEX.json']
    index={'schema':'c17-closed-full-composite-index-v1','actor':'/root/cycle17_gate_review',
        'generated_at':datetime.now(UTC).isoformat(),'status':'immutable_closed_preparation',
        'scope':'definitions_and_pure_tests_only','files':files,'origins':origins,'raw_pure':raw,
        'source_indexes_note':'Indexes pinned as origin definitions; only selected 45 source files revalidated here.',
        'construction':ref(HERE/'construction.json'),'static_audit':ref(HERE/'static-audit.json'),
        'RUNTIME_ENABLED':False,'OS_STARTUP_QUALIFIED':False,'CAPABILITIES_admitted':False,
        'ADMISSION_TABLE':{},'WRAPPER_ADMISSION_TABLE':{},'FULL':False}
    save(HERE/'INDEX.json',index)
    print(json.dumps({'index':ref(HERE/'INDEX.json'),'files':len(files),'origins':len(origins),
                     'raw':len(raw),'AST':len(ast_files),'status':'closed_static_only'}))


if __name__=='__main__':main()
