"""Assembleur de définitions FULL fermé. FS/AST seulement, aucun import G1/RPC.

Les candidats d'origine restent intacts. Aucun contexte acteur/round/owner,
manifest QA, décision, admission ou résultat natif n'est fabriqué ici.
"""
from __future__ import annotations

import argparse
import ast
from datetime import UTC, datetime
import difflib
import hashlib
import json
import os
from pathlib import Path

SQL = Path('/private/tmp/therese-c17-full-rpc-sql-reader-cdc3JA')
AB = Path('/private/tmp/therese-c17-ab14-listener-stop-4TFcYl')
WATCH = Path('/private/tmp/therese-c17-full-rpc-watchdog-32QrHc')
LEGACY = Path('/private/tmp/therese-c17-rpc-integration-UctqC8UG')
ROOT = Path(__file__).resolve().parent
MODULES = ('rpc_protocol.py', 'rpc_client.py', 'rpc_dispatcher.py',
           'session_rpc_adapter.py', 'rpc_unix.py', 'rpc_peer.py')
OLD_RELAY = 'c8daab46740661b0fb99cd34912868a328a60a4c034b17aa96a7eb5d53cb1c13'
NEW_RELAY = '9b271297b50d33b5f42d79bca8bf285f530e75660c87dc46e56f1fdf9743903c'
OLD_READER = '008546a0f25ad6a0b002a8320011b5ec6aaf4f8b9d62d22a6e2ff6ab0b97c42f'
NEW_READER = 'fd5256f0d1d8f6b4f086411c6f8977765c702adba4200841cedeac76936cffc9'
START_FRONTIER = '        self.check_round_deadline(verify_sources=True)  # frontière avant FD/gate/Popen ; bornes inchangées.\n'


def need(value, message):
    if not value:
        raise ValueError(message)


def ref(path):
    path = Path(path)
    data = path.read_bytes()
    return {'path': str(path), 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}


def checked(row):
    path = Path(row['path'])
    need(path.is_absolute() and path.resolve(strict=True) == path and not path.is_symlink()
         and path.is_file() and ref(path) == row, 'Input SHA/path/bytes changed: ' + str(path))
    return path


def once(source, old, new):
    need(source.count(old) == 1, 'Unique source anchor changed: ' + old[:100])
    return source.replace(old, new, 1)


def methods(source):
    tree = ast.parse(source)
    classes = [n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'Session']
    need(len(classes) == 1, 'One Session definition required')
    return {n.name: n for n in classes[0].body if isinstance(n, ast.FunctionDef)}


def block(source, name):
    node = methods(source)[name]
    return ''.join(source.splitlines(True)[node.lineno - 1:node.end_lineno])


def replace_methods(source, changes, additions):
    nodes = methods(source)
    lines = source.splitlines(True)
    for name, text in sorted(changes.items(), key=lambda row: nodes[row[0]].lineno, reverse=True):
        node = nodes[name]
        lines[node.lineno - 1:node.end_lineno] = [text]
    merged = ''.join(lines)
    if additions:
        insertion = methods(merged)['start'].lineno - 1
        lines = merged.splitlines(True)
        lines[insertion:insertion] = [''.join('\n' + text + '\n' for text in additions)]
        merged = ''.join(lines)
    ast.parse(merged)
    return merged


def compose_g1(ab_source, watchdog_source):
    start = block(ab_source, 'start')
    need(START_FRONTIER not in start, 'AB start already altered')
    start = once(start, '        require(decision == self.decision and binding == self.binding, "Admission mutable")\n',
                 '        require(decision == self.decision and binding == self.binding, "Admission mutable")\n' + START_FRONTIER)
    stop = block(watchdog_source, 'stop')
    old = '            if self.round_name == "WRAPPER_CANARY":\n'
    need(stop.count(old) == 2, 'Two stop port guards expected')
    stop = stop.replace(old, '            if self.round_name == "WRAPPER_CANARY" or self.round_name in ("A", "B"):\n')
    changes = {'__init__': block(watchdog_source, '__init__'), 'start': start,
               'stop': stop, 'wait': block(watchdog_source, 'wait')}
    added = [block(watchdog_source, name) for name in
             ('attach_owned_rpc_bootstrap', 'check_round_deadline', '_close_owned_rpc_transport')]
    merged = replace_methods(ab_source, changes, added)
    merged = once(merged, '"root_stage_relay.py", "' + OLD_RELAY + '"',
                  '"root_stage_relay.py", "' + NEW_RELAY + '"')
    validate_closed_g1(merged)
    # All noncollision A/B functions remain exact AST, including stop_services,
    # auxiliary lifecycle, worker rendezvous, source admission and Q controls.
    expected = methods(ab_source)
    actual = methods(merged)
    for name in expected.keys() - changes.keys():
        need(ast.dump(expected[name], include_attributes=False) ==
             ast.dump(actual[name], include_attributes=False), 'AB method changed: ' + name)
    return merged


def closed_assignments(source):
    values = {}
    for n in ast.parse(source).body:
        if isinstance(n, ast.Assign):
            for target in n.targets:
                if isinstance(target, ast.Name):
                    values[target.id] = n.value
        elif isinstance(n, ast.AnnAssign) and isinstance(n.target, ast.Name):
            values[n.target.id] = n.value
    return values


def validate_closed_g1(source):
    values = closed_assignments(source)
    for key in ('RUNTIME_ENABLED', 'OS_STARTUP_QUALIFIED', 'AB_CHROME_PROFILE_NATIVE_QUALIFIED'):
        need(ast.literal_eval(values[key]) is False, 'Admission flag opened: ' + key)
    for key in ('ADMISSION_TABLE', 'WRAPPER_ADMISSION_TABLE'):
        need(ast.literal_eval(values[key]) == {}, 'Admission table not empty: ' + key)
    need(all(value is False for value in ast.literal_eval(values['CAPABILITIES']).values()), 'Capability opened')
    need(ast.unparse(values['CHROME']) == "Path('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome')",
         'Chrome A/B original definition changed')


def port_rpc(source, name):
    """Preserve real closure assertions for A/B, not WRAPPER-only suppression."""
    predicate = '(p.wrapper_scope(self.root) or p.ab_scope(self.root, self.context))'
    old = "if p.wrapper_scope(self.root) and row['id'] in p.CHROME_JOBS:"
    new = "if " + predicate + " and row['id'] in p.CHROME_JOBS:"
    source = once(source, old, new)
    if name == 'rpc_client.py':
        source = once(source, 'if p.wrapper_scope(self.root):', 'if ' + predicate + ':')
    ast.parse(source)
    return source


def file_plan():
    mapping = {}
    for folder in ('g1', 'successor', 'transport'):
        for path in sorted((SQL / folder).iterdir()):
            if path.is_file():
                mapping[folder + '/' + path.name] = path
    for name in ('runtime78_coordinator.py', 'g1_bridge.py', 'root_rpc_bootstrap.py'):
        mapping['successor/' + name] = WATCH / 'successor' / name
    mapping['g1/root_stage_relay.py'] = WATCH / 'g1/root_stage_relay.py'
    mapping['g1/runtime_session.py'] = AB / 'g1/runtime_session.py'
    mapping['g1/ab_auxiliary_table.py'] = AB / 'g1/ab_auxiliary_table.py'
    mapping['g1/chrome.sb'] = AB / 'g1/chrome.sb'
    mapping['auxiliary/aux_node.mjs'] = AB / 'auxiliary/aux_node.mjs'
    mapping['calibration/build-calibrations-c17.py'] = AB / 'calibration/build-calibrations-c17.py'
    for name in ('web.sb', 'lsof_gate.py'):
        mapping['g1/' + name] = LEGACY / 'g1-26' / name
    for name in MODULES:
        mapping['transport/' + name] = (AB / 'transport' / name if name in
            ('rpc_protocol.py', 'session_rpc_adapter.py') else LEGACY / 'transport-26/source' / name)
    return mapping


def derived(source, name, inputs):
    if name == 'g1/runtime_session.py':
        return compose_g1(source, checked(inputs[str(WATCH / name)]).read_text())
    if name == 'successor/runtime78_coordinator.py':
        return once(source, "CALIBRATION_BUILDER_SHA256 = '" + OLD_READER + "'",
                     "CALIBRATION_BUILDER_SHA256 = '" + NEW_READER + "'")
    if name in ('transport/rpc_client.py', 'transport/rpc_dispatcher.py'):
        return port_rpc(source, Path(name).name)
    return source


def emit(path, data):
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    return ref(path)


def construct(output, input_manifest):
    output = Path(output)
    need(output.is_absolute() and output.resolve() == output and output.parent == ROOT
         and not output.exists(), 'Only exclusive new candidate under this preparation root')
    plan = file_plan()
    expected = {row['path']: row for row in input_manifest['sources']}
    extras = [SQL / 'g1/runtime_session.py', WATCH / 'g1/runtime_session.py']
    paths = set(plan.values()) | set(extras)
    need(set(expected) == {str(path) for path in paths}, 'Closed input table exact set required')
    before = [ref(checked(expected[str(path)])) for path in sorted(paths)]
    need(ref(WATCH / 'g1/root_stage_relay.py')['sha256'] == NEW_RELAY
         and ref(AB / 'calibration/build-calibrations-c17.py')['sha256'] == NEW_READER,
         'Reader/relay concrete definitions changed')
    output.mkdir(mode=0o700)
    outputs, origins, diffs = [], [], []
    for name, path in sorted(plan.items()):
        raw = checked(expected[str(path)]).read_bytes()
        pre = emit(ROOT / 'preimages' / name, raw)
        original = expected[str(path)]
        target = derived(raw.decode('utf-8'), name, expected).encode('utf-8')
        if name.endswith('.py'):
            ast.parse(target.decode(), filename=str(output / name))
        current = emit(output / name, target)
        outputs.append(current)
        origins.append({'original': original, 'preimage': pre, 'candidate': current,
                        'byte_exact': raw == target})
        if raw != target:
            delta = ''.join(difflib.unified_diff(raw.decode().splitlines(True), target.decode().splitlines(True),
                fromfile=str(path), tofile=str(output / name))).encode()
            diffs.append({'before': pre, 'after': current,
                          'diff': emit(ROOT / 'diffs' / (name.replace('/', '-') + '.diff'), delta)})
    # Both alternative G1 sources remain immutable and explicitly distinct.
    for label, path in (('sql48', SQL / 'g1/runtime_session.py'), ('watchdog47', WATCH / 'g1/runtime_session.py')):
        origins.append({'original': expected[str(path)],
                        'preimage': emit(ROOT / 'preimages' / label / 'runtime_session.py', path.read_bytes()),
                        'candidate': None, 'byte_exact': True, 'instrument_definition_only': True})
    vector = {name: ref(output / 'transport' / name) for name in MODULES}
    need(ref(output / 'g1/root_stage_relay.py')['sha256'] == NEW_RELAY
         and ref(output / 'calibration/build-calibrations-c17.py')['sha256'] == NEW_READER,
         'Output reader/relay mismatch')
    after = [ref(path) for path in sorted(paths)]
    need(before == after, 'Original source changed during mechanical composition')
    return {'schema': 'c17-full-closed-composite-construction-v1', 'actor': '/root/cycle17_gate_review',
        'prepared_at': datetime.now(UTC).isoformat(), 'status': 'closed_definitions_assembled_not_runtime',
        'root': str(output), 'outputs': outputs, 'origins': origins, 'diffs': diffs, 'RPC_modules': vector,
        'sources_before': before, 'sources_after': after, 'source_unchanged': before == after,
        'reader_sha256': NEW_READER, 'relay_sha256': NEW_RELAY,
        'Chrome': '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
        'chrome_profile_sha256': ref(output / 'g1/chrome.sb')['sha256'],
        'RUNTIME_ENABLED': False, 'OS_STARTUP_QUALIFIED': False, 'CAPABILITIES_admitted': False,
        'ADMISSION_TABLE': {}, 'WRAPPER_ADMISSION_TABLE': {}, 'FULL': False,
        'native_executed': False, 'G1_imported': False, 'product_imported': False,
        'source_checkout_created': False, 'root_decision_emitted': False,
        'remaining': ['physical A/B constructor/source checkout/dependencies and actual root decisions',
            'instrument-only current A/B preflight before runtime admission',
            'A/B original Chrome/profile5266 native qualification (no QA-copy V8 inheritance)',
            'current HEAD and FULL consumer definitions explicit causal port',
            'two actual independent rounds/actors and complete evidence/calibration/coverage arbitration']}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--inputs', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    manifest = json.loads(args.inputs.read_text())
    result = construct(args.output, manifest)
    emitted = emit(ROOT / 'construction.json', (json.dumps(result, ensure_ascii=False, indent=2) + '\n').encode())
    print(json.dumps({'status': result['status'], 'construction': emitted}))


if __name__ == '__main__':
    raise SystemExit(main())
