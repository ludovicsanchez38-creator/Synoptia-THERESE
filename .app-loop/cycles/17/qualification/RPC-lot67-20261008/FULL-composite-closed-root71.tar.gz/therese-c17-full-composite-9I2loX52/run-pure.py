"""Rejeu pur sous profil OS externe. Aucun instrument entier importé."""
from __future__ import annotations
import argparse
import ast
from datetime import UTC, datetime
import dis
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import time
import traceback
import unittest

HERE = Path(__file__).resolve().parent
ORIGIN = Path('/private/tmp/therese-c17-full-rpc-watchdog-32QrHc/tests/test_bootstrap.py')
FIXTURE = ORIGIN.parent.parent / 'synthetic-fixtures/wait-receipt.json'
FULL_NAMES = {'runtime_session', 'runtime78_core', 'runtime78_coordinator', 'root_rpc_bootstrap',
              'session_rpc_adapter', 'rpc_protocol', 'rpc_client', 'rpc_dispatcher', 'rpc_unix',
              'rpc_peer', 'app', 'backend'}


def ref(path):
    data = Path(path).read_bytes()
    return {'path': str(path), 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}


def save(path, value):
    with open(path, 'x', encoding='utf-8') as channel:
        json.dump(value, channel, ensure_ascii=False, indent=2)
        channel.write('\n'); channel.flush(); os.fsync(channel.fileno())


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    output = Path(args.output)
    if (not output.is_absolute() or output.resolve(strict=True) != output or
        output.parent != Path('/private/tmp') or not output.name.startswith('therese-c17-full-composite-tests-') or
        any(output.iterdir())):
        raise ValueError('Fresh canonical exclusive output root required')
    for child in ('fixtures', 'home', 'tmp'):
        (output / child).mkdir(mode=0o700)
    os.environ['C17_PURE_FIXTURE_ROOT'] = str(output / 'fixtures')
    os.environ['HOME'] = str(output / 'home')
    os.environ['TMPDIR'] = str(output / 'tmp')
    paths = {p for p in HERE.rglob('*') if p.is_file()}
    paths.update(Path(row['path']) for row in json.loads((HERE / 'inputs.json').read_text())['sources'])
    paths.update((ORIGIN, FIXTURE))
    pins_before = [ref(p) for p in sorted(paths)]
    if (HERE/'candidate/synthetic-fixtures/wait-receipt.json').read_bytes() != FIXTURE.read_bytes():
        raise ValueError('Synthetic fixture definition must remain exact')
    instrument_paths = {str(p) for p in (HERE/'candidate').rglob('*.py')}
    # Only the closed table (Path/regex helpers) is imported as a pure module.
    instrument_paths.remove(str(HERE/'candidate/g1/ab_auxiliary_table.py'))
    rejected = []

    def refuse(event, detail):
        rejected.append({'event': event, 'detail': str(detail)[:300]})
        raise PermissionError('Pure audit guard: ' + event)

    def canonical(path):
        if isinstance(path, int):
            return None
        return Path(os.fsdecode(path)).resolve()

    def writable(path, event):
        resolved = canonical(path)
        if resolved is None or not resolved.is_relative_to(output):
            refuse(event, path)

    def audit(event, values):
        if event.startswith(('subprocess.', 'socket.', 'ctypes.', 'pty.')) or event in {
            'os.system','os.fork','os.forkpty','os.exec','os.posix_spawn','os.spawn',
            'os.kill','os.killpg'}:
            refuse(event, values)
        if event == 'import' and values[0].split('.')[0] in FULL_NAMES:
            refuse(event, values[0])
        if event == 'exec' and values[0].co_filename in instrument_paths:
            # Selected AST definitions contain no top-level import opcode.
            # Reject an accidental whole-module exec, including importlib loads.
            if any(i.opname in {'IMPORT_NAME','IMPORT_FROM','IMPORT_STAR'} for i in dis.get_instructions(values[0])):
                refuse('exec-whole-instrument', values[0].co_filename)
        if event == 'open':
            path, mode, flags = values
            if ((isinstance(mode,str) and any(c in mode for c in 'wax+')) or
                isinstance(flags,int) and flags & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND)):
                writable(path,event)
        elif event in {'os.mkdir','os.remove','os.rmdir','os.chmod','os.chown','os.utime','os.truncate'}:
            writable(values[0],event)
        elif event in {'os.rename','os.link','os.symlink'}:
            writable(values[0],event); writable(values[1],event)

    sys.addaudithook(audit)
    started = datetime.now(UTC).isoformat(); begin = time.monotonic()
    result = None; error = None
    stdout_path, stderr_path = output/'stdout.log', output/'stderr.log'
    with open(stdout_path,'x',encoding='utf-8') as out, open(stderr_path,'x',encoding='utf-8') as err:
        oldout, olderr = sys.stdout, sys.stderr
        sys.stdout, sys.stderr = out, err
        try:
            spec = importlib.util.spec_from_file_location('pure_composite_tests',HERE/'tests/test_composite.py')
            module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
            result = unittest.TextTestRunner(stream=out,verbosity=2).run(module.suite())
        except BaseException as exc:
            error = {'type': type(exc).__name__, 'message': str(exc)}
            traceback.print_exc(file=err)
        finally:
            sys.stdout, sys.stderr = oldout, olderr
            out.flush();err.flush();os.fsync(out.fileno());os.fsync(err.fileno())
    after = [ref(p) for p in sorted(paths)]
    imported = sorted(name for name in sys.modules if name.split('.')[0] in FULL_NAMES)
    receipt = {'schema':'c17-closed-full-composite-pure-tests-v1', 'actor':'/root/cycle17_gate_review',
        'scope':'synthetic_policy_only_no_runtime', 'round_id':None,
        'started_at':started,'completed_at':datetime.now(UTC).isoformat(),
        'elapsed_seconds':time.monotonic()-begin,'tests':result.testsRun if result else 0,
        'failures':len(result.failures) if result else None,'errors':len(result.errors) if result else None,
        'skipped':len(result.skipped) if result else None,'instrument_error':error,
        'stdout':ref(stdout_path),'stderr':ref(stderr_path),'pins_before':pins_before,'pins_after':after,
        'sources_unchanged':pins_before==after,'forbidden_events':rejected,'full_instrument_imports':imported,
        'OS_qualified':False,'runtime_admitted':False,'FULL':False,
        'passed': bool(result and result.wasSuccessful() and not result.skipped and error is None and
                       not rejected and not imported and pins_before==after)}
    save(output/'receipt.json',receipt)
    print(json.dumps({'receipt':ref(output/'receipt.json'),'tests':receipt['tests'],'passed':receipt['passed'],
                      'failures':receipt['failures'],'errors':receipt['errors'],'instrument_error':error}))
    return 0 if receipt['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
