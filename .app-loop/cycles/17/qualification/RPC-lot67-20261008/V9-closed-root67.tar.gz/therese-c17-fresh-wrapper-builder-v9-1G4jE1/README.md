# WRAPPER V9 : hypothèse fermée de lectures de répertoires Chrome

Préparation statique seulement. Aucune racine WRAPPER, Session, Chrome, socket, profil réel ou release n'a été lancé ou modifié par ce lot. V8 et les racines ROOT7/ROOT8 restent byte-exacts.

## Delta unique

La préimage est le profil V8 `c9101b2a…` (1949 octets), copié sous `preimages/chrome-v8.sb`. Le profil candidat `profile/chrome.sb` (`19808ee2…`, 2067 octets) ajoute uniquement :

1. `file-read-metadata` littéral du parent fixe `/private/tmp/therese-c17-chrome-qa-copy-RoZmwsja` ;
2. `file-read-data` littéral du répertoire `/private/tmp` ;
3. `file-read-data` littéral de `(param "QA_ROOT")`, dont la valeur reste liée à la racine WRAPPER fraîche exacte par G1.

Ce ne sont pas des `subpath`. Les droits `file-write*`, Mach, IOKit, réseau, ports et profils HOME n'ont pas changé. Les bornes CDP 5 s, lancement 50 s et nettoyage 8 s sont celles du V8. Le constructeur compare textuellement tout le profil V9 à la dérivation exacte du V8 avant `os.mkdir`, refuse l'ancien pin V8 et ne change ni G1 ni ses 76 sources prévues.

La motivation est le brut ROOT8 PID 48739 : deux refus `file-read-metadata` sur le parent Chrome et deux refus `file-read-data` sur les répertoires QA_ROOT et `/private/tmp`, même thread juste avant l'exception `NSBundle initWithURL: non-file URL argument`. Leur causalité n'est pas encore prouvée. Les refus `/dev/dtracehelper`, `com.apple.logd`, notification center et les événements AMFI ne sont pas transformés en permissions.

## Tests et limites

Commande exécutée : `python3 -I -B /private/tmp/therese-c17-fresh-wrapper-builder-v9-1G4jE1/run_pure.py`. Le premier appel réel a été rouge : 66 tests, 5 échecs, 1 erreur (chunk outil `7c24b6`). `proofs/first-pure-red-observation.json` en conserve un constat condensé, pas une fausse copie intégrale du flux. Les attentes historiques V7→V8 ont été rattachées à la préimage V8. Les cinq nouveaux tests vérifient séparément la dérivation V9, les refus de profils/chemins élargis, l'identité AST des fonctions hors profil et le lien profil→G1/GO/reçu. Aucun garde produit/profil n'a été assoupli pour obtenir le vert.

L'appel réel de référence (chunk `6d4bff`) a fait passer 67 cas purs, 0 échec/erreur/skip, exit 0, pins avant/après égaux ; sortie retournée byte-exacte dans `proofs/pure-tests-final-returned-output.json`. Le vert précédent à 66 cas reste historique dans `proofs/pure-tests-returned-output.json`. Le harnais interdit subprocess, socket et import G1 complet. Il ne compile pas Seatbelt et ne qualifie pas les droits physiques ni Chrome. Les négatifs sont des mutants locaux de texte : mauvais frère du répertoire Chrome, `subpath` QA_ROOT ou `/private/tmp`, littéral absent, Mach et écriture élargis, ancien pin V8, SHA erroné, avant allocation.

`build_fresh_wrapper.py` conserve `--prepare` et l'autorité root externe exacte. Ne pas appeler avec des placeholders ; seul root pourra préparer une nouvelle racine et faire les vérifications natives indépendantes après revue de ce gel. Le HEAD QA historique reste `2d69e30c…` et n'est pas une admission FULL ou le HEAD documentaire courant.
