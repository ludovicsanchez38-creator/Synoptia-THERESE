"""Tests de doubles seulement ; auditguard interdit les appels OS sensibles."""

from __future__ import annotations

import json
import os
import signal
import subprocess
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent))
import controller as c
import native_port

ROOT = Path("/private/tmp/c17-synthetic-only")
BINARY = ROOT / "future/probe"
PLAN = c.Plan(ROOT, BINARY, ROOT / "future", ROOT / "run/stdout.log",
              ROOT / "run/stderr.log", "compiled-alpha", "a" * 32,
              {"HOME": str(ROOT / "home"), "TMPDIR": str(ROOT / "tmp") + "/",
               "PATH": "/usr/bin:/bin"},
              ({"path": str(BINARY), "bytes": 123, "sha256": "b" * 64},))
OWNER = {"pid": 500, "ppid": 1, "uid": 501, "pgid": 500,
         "start_sec": 1700000000, "start_usec": 10, "status": 2,
         "executable": "/opt/homebrew/bin/python3"}
CHILD = {"pid": 501, "ppid": 500, "uid": 501, "pgid": 501,
         "start_sec": 1700000001, "start_usec": 20, "status": 3,
         "executable": str(BINARY)}


def line(row: dict) -> bytes:
    return json.dumps(row, separators=(",", ":")).encode() + b"\n"


class FakePort:
    def __init__(self, waits=(0,), *, child_unknown=False, spawn_failure=False):
        self.t = 0.0
        self.waits = list(waits)
        self.child_unknown = child_unknown
        self.spawn_failure = spawn_failure
        self.owner_reads = self.child_reads = self.source_reads = 0
        self.owner_drift_after = None
        self.child_drift_after = None
        self.source_drift_after = None
        self.source_late_on_second = False
        self.unowned_relation = False
        self.child_pid_mismatch = False
        self.exited = False
        self.exit_code = None
        self.gate_closed = False
        self.sinks_closed = False
        self.release_payload = None
        self.signals = []
        self.wait_calls = 0
        self.ready = line({"schema": c.READY_SCHEMA, "case": PLAN.case,
                           "nonce": PLAN.nonce, **{k: CHILD[k] for k in c.IDENTITY}})
        self.released = line({"schema": c.RELEASED_SCHEMA, "case": PLAN.case,
                              "nonce": PLAN.nonce, "pid": CHILD["pid"],
                              "start_sec": CHILD["start_sec"],
                              "start_usec": CHILD["start_usec"]})
        self.ready_late = False
        self.open_late = False

    def now(self):
        return self.t

    def self_pid(self):
        return OWNER["pid"]

    def read_identity(self, pid):
        if pid == OWNER["pid"]:
            self.owner_reads += 1
            row = OWNER.copy()
            if self.owner_drift_after and self.owner_reads >= self.owner_drift_after:
                row["executable"] = "/private/tmp/changed-owner"
            return row
        if pid == CHILD["pid"]:
            self.child_reads += 1
            if self.child_unknown:
                raise OSError("libproc refusé")
            row = CHILD.copy()
            if self.unowned_relation:
                row["ppid"] = 499
            if self.child_pid_mismatch:
                row["pid"] = 777
                row["pgid"] = 777
            if self.child_drift_after and self.child_reads >= self.child_drift_after:
                row["start_usec"] += 1
            return row
        raise ProcessLookupError(pid)

    def verify_sources(self, refs):
        self.source_reads += 1
        if self.source_late_on_second and self.source_reads == 2:
            self.t = 5.001
        return not self.source_drift_after or self.source_reads < self.source_drift_after

    def open_sinks(self, plan):
        self.sinks_opened = True
        if self.open_late:
            self.t = 6.0
        return ("out", "err")

    def spawn(self, plan, sinks):
        if self.spawn_failure:
            raise OSError("Popen refused before handle")
        self.handle = SimpleNamespace(pid=CHILD["pid"])
        return self.handle

    def read_ready(self, handle, sinks, deadline):
        if self.ready_late:
            self.t = deadline + 0.001
        return self.ready

    def release(self, handle, payload):
        self.release_payload = payload

    def read_gate_released(self, handle, sinks, deadline):
        return self.released

    def close_gate(self, handle):
        self.gate_closed = True

    def poll(self, handle):
        return self.exit_code if self.exited else None

    def wait_until(self, handle, deadline):
        self.wait_calls += 1
        value = self.waits.pop(0) if self.waits else None
        if value is None:
            self.t = deadline
            return None
        self.exited = True
        self.exit_code = value
        return value

    def signal_pid(self, pid, sig):
        self.signals.append((pid, sig))

    def close_sinks(self, sinks):
        self.sinks_closed = True
        return True


class ControllerTests(unittest.TestCase):
    def drive(self, fake):
        # Aucun subprocess, signal, FD ou libproc réel ne peut passer ce garde.
        with patch("subprocess.Popen", side_effect=AssertionError("Popen OS")), \
             patch("os.kill", side_effect=AssertionError("signal OS")), \
             patch("os.open", side_effect=AssertionError("FD OS")), \
             patch("ctypes.CDLL", side_effect=AssertionError("libproc OS")):
            return c._drive(PLAN, fake)

    def test_normal_mock_closes_gate_and_sinks(self):
        fake = FakePort()
        result = self.drive(fake)
        self.assertTrue(result["clean_on_mock"])
        self.assertTrue(fake.gate_closed and fake.sinks_closed)
        self.assertEqual(fake.release_payload, c.release_bytes(PLAN, CHILD))
        self.assertEqual(fake.signals, [])
        self.assertFalse(result["native_measured"])
        self.assertFalse(result["release_authorized"])

    def test_native_path_cannot_activate(self):
        self.assertFalse(c.NATIVE_MEASUREMENT_ENABLED)
        with self.assertRaises(RuntimeError):
            c.activate()
        with self.assertRaises(RuntimeError):
            native_port.NativePort()

    def test_bypassed_port_still_refuses_spawn_and_signal(self):
        unconstructed = object.__new__(native_port.NativePort)
        with patch("subprocess.Popen", side_effect=AssertionError("Popen OS")), \
             patch("os.kill", side_effect=AssertionError("signal OS")):
            with self.assertRaises(ValueError):
                unconstructed.spawn(PLAN, (3, 4))
            with self.assertRaises(ValueError):
                unconstructed.signal_pid(CHILD["pid"], signal.SIGTERM)

    def test_typed_reader_definition_reaches_mocked_library_only(self):
        unconstructed = object.__new__(native_port.NativePort)
        with patch("ctypes.CDLL", side_effect=RuntimeError("libproc interdit")):
            with self.assertRaisesRegex(RuntimeError, "libproc interdit"):
                unconstructed.read_identity(CHILD["pid"])

    def test_command_and_pipe_spec_closed(self):
        self.assertEqual(PLAN.argv(), (str(BINARY), "--reviewed-case", "compiled-alpha",
                                       "--gate-nonce", "a" * 32))
        self.assertEqual(c.release_bytes(PLAN, CHILD),
                         b'{"schema":"c17-seatbelt-composition-release-v1","case":"compiled-alpha","nonce":"'
                         + b"a" * 32 + b'","pid":501,"start_sec":1700000001,"start_usec":20}\n')

    def test_environment_extra_or_unscoped_refused(self):
        from dataclasses import replace

        for altered in ({**PLAN.environment, "DYLD_INSERT_LIBRARIES": "/tmp/x"},
                        {**PLAN.environment, "HOME": "/Users/real"}):
            with self.assertRaises(ValueError):
                replace(PLAN, environment=altered).validate()

    def test_ready_mismatch_refuses_release_then_reaps_autonomous(self):
        fake = FakePort(waits=(86,))
        fake.ready = fake.ready.replace(b"compiled-alpha", b"compiled-beta")
        result = self.drive(fake)
        self.assertIsNone(fake.release_payload)
        self.assertTrue(fake.gate_closed and fake.sinks_closed)
        self.assertEqual(fake.signals, [])
        self.assertFalse(result["clean_on_mock"])

    def test_ready_duplicate_key_refused(self):
        fake = FakePort(waits=(86,))
        fake.ready = fake.ready[:-2] + b',"pid":501}\n'
        self.assertFalse(self.drive(fake)["release_confirmed_on_mock"])

    def test_unknown_birth_never_signalled_and_waits_to_cleanup_bound(self):
        fake = FakePort(waits=(None, 86), child_unknown=True)
        result = self.drive(fake)
        self.assertEqual(fake.signals, [])
        self.assertEqual(fake.wait_calls, 2)
        self.assertLessEqual(fake.t, 8.0)
        self.assertTrue(fake.gate_closed and fake.sinks_closed)
        self.assertFalse(result["termination_proved_on_mock"])

    def test_wrong_parent_candidate_not_adopted_or_signalled(self):
        fake = FakePort(waits=(None, 86))
        fake.unowned_relation = True
        result = self.drive(fake)
        self.assertIsNone(result["child"])
        self.assertIsNone(fake.release_payload)
        self.assertEqual(fake.signals, [])
        self.assertEqual(fake.wait_calls, 2)
        self.assertFalse(result["termination_proved_on_mock"])

    def test_reader_pid_mismatch_not_adopted_or_signalled(self):
        fake = FakePort(waits=(None, 86))
        fake.child_pid_mismatch = True
        result = self.drive(fake)
        self.assertIsNone(result["child"])
        self.assertEqual(fake.signals, [])
        self.assertFalse(result["termination_proved_on_mock"])

    def test_parent_executable_drift_refuses_release_and_signal(self):
        fake = FakePort(waits=(None, 86))
        fake.owner_drift_after = 2
        result = self.drive(fake)
        self.assertIsNone(fake.release_payload)
        self.assertEqual(fake.signals, [])
        self.assertFalse(result["clean_on_mock"])

    def test_child_birth_drift_refuses_release(self):
        fake = FakePort(waits=(86,))
        fake.child_drift_after = 2
        self.assertFalse(self.drive(fake)["release_confirmed_on_mock"])

    def test_source_drift_before_release_refuses(self):
        fake = FakePort(waits=(86,))
        fake.source_drift_after = 2
        self.assertFalse(self.drive(fake)["release_confirmed_on_mock"])

    def test_source_rehash_consumes_gate_refuses_before_write(self):
        fake = FakePort(waits=(86,))
        fake.source_late_on_second = True
        result = self.drive(fake)
        self.assertIsNone(fake.release_payload)
        self.assertFalse(result["release_written_on_mock"])
        self.assertFalse(result["clean_on_mock"])

    def test_source_drift_at_final_rehash_keeps_red(self):
        fake = FakePort()
        fake.source_drift_after = 3
        result = self.drive(fake)
        self.assertTrue(result["release_confirmed_on_mock"])
        self.assertFalse(result["source_refs_unchanged_on_mock"])
        self.assertFalse(result["clean_on_mock"])

    def test_gate_deadline_refuses(self):
        fake = FakePort(waits=(86,))
        fake.ready_late = True
        self.assertFalse(self.drive(fake)["release_confirmed_on_mock"])

    def test_expired_before_spawn_closes_only_sinks(self):
        fake = FakePort()
        fake.open_late = True
        result = self.drive(fake)
        self.assertFalse(hasattr(fake, "handle"))
        self.assertTrue(fake.sinks_closed)
        self.assertFalse(result["termination_proved_on_mock"])

    def test_ack_mismatch_refuses_success(self):
        fake = FakePort(waits=(86,))
        fake.released = fake.released.replace(b"a" * 32, b"b" * 32)
        result = self.drive(fake)
        self.assertTrue(result["release_written_on_mock"])
        self.assertFalse(result["release_confirmed_on_mock"])
        self.assertFalse(result["clean_on_mock"])

    def test_ack_duplicate_key_refused(self):
        fake = FakePort(waits=(86,))
        fake.released = fake.released[:-2] + b',"pid":501}\n'
        self.assertFalse(self.drive(fake)["release_confirmed_on_mock"])

    def test_ack_reordered_keys_refused_even_when_values_equal(self):
        fake = FakePort(waits=(86,))
        fake.released = line(dict(sorted(json.loads(fake.released).items())))
        self.assertFalse(self.drive(fake)["release_confirmed_on_mock"])

    def test_ack_whitespace_refused_even_when_values_equal(self):
        fake = FakePort(waits=(86,))
        fake.released = json.dumps(json.loads(fake.released),
                                   separators=(", ", ": ")).encode() + b"\n"
        self.assertFalse(self.drive(fake)["release_confirmed_on_mock"])

    def test_ack_bool_as_integer_refused_and_exact_one_accepted(self):
        child = {**CHILD, "start_usec": 1}
        exact = {"schema": c.RELEASED_SCHEMA, "case": PLAN.case, "nonce": PLAN.nonce,
                 "pid": child["pid"], "start_sec": child["start_sec"], "start_usec": 1}
        with patch("subprocess.Popen", side_effect=AssertionError("Popen OS")), \
             patch("os.kill", side_effect=AssertionError("signal OS")), \
             patch("ctypes.CDLL", side_effect=AssertionError("libproc OS")):
            c.parse_released(line(exact), PLAN, child)
            with self.assertRaises(ValueError):
                c.parse_released(line({**exact, "start_usec": True}), PLAN, child)

    def test_spawn_failure_never_claims_termination(self):
        fake = FakePort(spawn_failure=True)
        result = self.drive(fake)
        self.assertFalse(result["termination_proved_on_mock"])
        self.assertFalse(result["clean_on_mock"])
        self.assertTrue(fake.sinks_closed)

    def test_raw_nonzero_preserved_red(self):
        fake = FakePort(waits=(86,))
        result = self.drive(fake)
        self.assertEqual(result["returncode"], 86)
        self.assertFalse(result["clean_on_mock"])

    def test_case_timeout_signals_only_attributed_pid(self):
        fake = FakePort(waits=(None, None, 86))
        result = self.drive(fake)
        self.assertEqual(fake.signals, [(CHILD["pid"], signal.SIGTERM)])
        self.assertFalse(result["clean_on_mock"])

    def test_term_ignored_keeps_time_for_rechecked_kill(self):
        fake = FakePort(waits=(None, None, None, 86))
        result = self.drive(fake)
        self.assertEqual(fake.signals, [(CHILD["pid"], signal.SIGTERM),
                                        (CHILD["pid"], signal.SIGKILL)])
        self.assertEqual(fake.t, 11.0)  # KILL wait reaped before deadline13.
        self.assertFalse(result["clean_on_mock"])

    def test_identity_drift_after_timeout_waits_without_signal(self):
        fake = FakePort(waits=(None, None, 86))
        fake.child_drift_after = 3
        result = self.drive(fake)
        self.assertEqual(fake.signals, [])
        self.assertTrue(fake.gate_closed)
        self.assertFalse(result["clean_on_mock"])

    def test_owner_executable_drift_after_timeout_blocks_signal(self):
        fake = FakePort(waits=(None, None, 86))
        fake.owner_drift_after = 3
        result = self.drive(fake)
        self.assertEqual(fake.signals, [])
        self.assertFalse(result["clean_on_mock"])

    def test_unreaped_never_clean(self):
        fake = FakePort(waits=(None, None, None, None))
        result = self.drive(fake)
        self.assertFalse(result["termination_proved_on_mock"])
        self.assertFalse(result["clean_on_mock"])

    def test_stopped_parent_or_child_refused(self):
        for who in (OWNER["pid"], CHILD["pid"]):
            fake = FakePort(waits=(86,))
            original = fake.read_identity

            def stopped(pid, original=original, who=who):
                row = original(pid)
                if pid == who:
                    row["status"] = 4
                return row

            fake.read_identity = stopped
            if who == OWNER["pid"]:
                with self.assertRaises(ValueError):
                    self.drive(fake)  # Refus avant toute allocation/Popen.
            else:
                result = self.drive(fake)
                self.assertFalse(result["release_confirmed_on_mock"])


if __name__ == "__main__":
    unittest.main()
