"""Contrôleur mono-sonde préparé, physiquement désactivé.

`_drive` exerce l'algorithme sur des ports injectés par les tests. Le seul point
d'entrée public `activate` refuse toujours. Aucun port OS n'est construit ici.
"""

from __future__ import annotations

import json
import math
import re
import signal
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Protocol

NATIVE_MEASUREMENT_ENABLED = False
CASES = frozenset(("baseline", "compiled-alpha", "compiled-beta", "source-alpha", "source-beta"))
IDENTITY = ("pid", "ppid", "uid", "pgid", "start_sec", "start_usec")
READY_SCHEMA = "c17-seatbelt-composition-ready-v1"
RELEASE_SCHEMA = "c17-seatbelt-composition-release-v1"
RELEASED_SCHEMA = "c17-seatbelt-composition-gate-released-v1"
READY_KEYS = frozenset(("schema", "case", "nonce", *IDENTITY))
GATE_SECONDS = 5.0
CASE_SECONDS = 5.0
CLEANUP_SECONDS = 8.0
TERM_GRACE_SECONDS = 1.0


def require(ok: bool, reason: str) -> None:
    if not ok:
        raise ValueError(reason)


@dataclass(frozen=True)
class Plan:
    root: Path
    binary: Path
    cwd: Path
    stdout_path: Path
    stderr_path: Path
    case: str
    nonce: str
    environment: dict[str, str]
    source_refs: tuple[dict[str, Any], ...]

    def validate(self) -> None:
        require(self.case in CASES, "cas hors table")
        require(type(self.nonce) is str and re.fullmatch(r"[0-9a-f]{32}", self.nonce) is not None,
                "nonce invalide")
        require(all(isinstance(p, Path) and p.is_absolute() for p in
                    (self.root, self.binary, self.cwd, self.stdout_path, self.stderr_path)),
                "chemins absolus requis")
        require(self.binary.is_relative_to(self.root) and self.cwd.is_relative_to(self.root),
                "binaire/cwd hors QA")
        require(self.stdout_path.is_relative_to(self.root) and self.stderr_path.is_relative_to(self.root)
                and self.stdout_path != self.stderr_path and self.stdout_path.name == "stdout.log"
                and self.stderr_path.name == "stderr.log", "sinks QA distincts")
        require(type(self.environment) is dict and self.environment == {
            "HOME": str(self.root / "home"),
            "TMPDIR": str(self.root / "tmp") + "/",
            "PATH": "/usr/bin:/bin",
        }, "environnement synthétique non fermé")
        require(type(self.source_refs) is tuple and len(self.source_refs) > 0,
                "préimages exactes requises")
        require(any(type(ref) is dict and ref.get("path") == str(self.binary)
                    and type(ref.get("bytes")) is int and type(ref.get("sha256")) is str
                    for ref in self.source_refs), "binaire non épinglé")

    def argv(self) -> tuple[str, ...]:
        self.validate()
        return (str(self.binary), "--reviewed-case", self.case, "--gate-nonce", self.nonce)


def identity(row: dict[str, Any], *, expected_binary: str | None = None) -> tuple[int, ...]:
    require(type(row) is dict and all(type(row.get(k)) is int for k in IDENTITY),
            "naissance libproc incomplète")
    require(row["pid"] > 1 and row["ppid"] > 0 and row["uid"] >= 0 and row["pgid"] > 0
            and row["start_sec"] > 0 and 0 <= row["start_usec"] < 1_000_000,
            "naissance libproc invalide")
    # BSD SRUN=2, SSLEEP=3. SIDL/SSTOP/SZOMB ne sont pas une gate vivante.
    require(type(row.get("status")) is int and row["status"] in (2, 3),
            "statut non vivant/incertain")
    if expected_binary is not None:
        require(row.get("executable") == expected_binary, "exécutable différent")
    return tuple(row[k] for k in IDENTITY)


def parse_ready(raw: bytes, plan: Plan, owner: dict[str, Any], child: dict[str, Any]) -> None:
    require(type(raw) is bytes and len(raw) <= 512 and raw.endswith(b"\n")
            and raw.count(b"\n") == 1, "ready non borné ou incomplet")

    def unique(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for key, value in pairs:
            require(key not in result, "clé ready dupliquée")
            result[key] = value
        return result

    row = json.loads(raw.decode("ascii"), object_pairs_hook=unique)
    require(type(row) is dict and frozenset(row) == READY_KEYS, "schéma ready divergent")
    require(row["schema"] == READY_SCHEMA and row["case"] == plan.case
            and row["nonce"] == plan.nonce, "ready cas/nonce divergent")
    require(all(type(row[k]) is int and row[k] == child[k] for k in IDENTITY),
            "ready naissance divergente")
    require(child["ppid"] == owner["pid"] and child["uid"] == owner["uid"]
            and child["pgid"] == child["pid"], "filiation/UID/PGID divergents")


def release_bytes(plan: Plan, child: dict[str, Any]) -> bytes:
    row = {"schema": RELEASE_SCHEMA, "case": plan.case, "nonce": plan.nonce,
           "pid": child["pid"], "start_sec": child["start_sec"],
           "start_usec": child["start_usec"]}
    return json.dumps(row, separators=(",", ":"), ensure_ascii=True).encode("ascii") + b"\n"


def parse_released(raw: bytes, plan: Plan, child: dict[str, Any]) -> None:
    require(type(raw) is bytes and len(raw) <= 512 and raw.endswith(b"\n")
            and raw.count(b"\n") == 1, "ACK gate incomplet")
    def unique(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
        row: dict[str, Any] = {}
        for key, value in pairs:
            require(key not in row, "ACK gate clé dupliquée")
            row[key] = value
        return row

    row = json.loads(raw.decode("ascii"), object_pairs_hook=unique)
    require(type(row) is dict and frozenset(row) == frozenset(
        ("schema", "case", "nonce", "pid", "start_sec", "start_usec")),
        "ACK gate champs divergents")
    require(all(type(row[k]) is int for k in ("pid", "start_sec", "start_usec")),
            "ACK gate entiers stricts requis")
    expected = {"schema": RELEASED_SCHEMA, "case": plan.case, "nonce": plan.nonce,
                "pid": child["pid"], "start_sec": child["start_sec"],
                "start_usec": child["start_usec"]}
    require(row == expected and raw == json.dumps(expected, separators=(",", ":"),
                                              ensure_ascii=True).encode("ascii") + b"\n",
            "ACK gate octets compacts exacts divergents")


class Port(Protocol):
    def now(self) -> float: ...
    def self_pid(self) -> int: ...
    def read_identity(self, pid: int) -> dict[str, Any]: ...
    def verify_sources(self, refs: tuple[dict[str, Any], ...]) -> bool: ...
    def open_sinks(self, plan: Plan) -> Any: ...
    def spawn(self, plan: Plan, sinks: Any) -> Any: ...
    def read_ready(self, handle: Any, sinks: Any, deadline: float) -> bytes: ...
    def read_gate_released(self, handle: Any, sinks: Any, deadline: float) -> bytes: ...
    def release(self, handle: Any, payload: bytes) -> None: ...
    def close_gate(self, handle: Any) -> None: ...
    def poll(self, handle: Any) -> int | None: ...
    def wait_until(self, handle: Any, deadline: float) -> int | None: ...
    def signal_pid(self, pid: int, sig: signal.Signals) -> None: ...
    def close_sinks(self, sinks: Any) -> bool: ...


def _same_live(port: Port, owner: dict[str, Any], child: dict[str, Any],
               plan: Plan) -> bool:
    """Lecture fraîche avant release ou signal ; erreur = incertitude."""
    try:
        same_owner = identity(port.read_identity(owner["pid"]),
                              expected_binary=owner["executable"]) == identity(owner)
        same_child = identity(port.read_identity(child["pid"]),
                              expected_binary=str(plan.binary)) == identity(child)
        return same_owner and same_child
    except BaseException:
        # Pendant un signal aussi, l'interruption ou une lecture partielle
        # interdit d'adopter le PID comme cible sûre.
        return False


def _drive(plan: Plan, port: Port) -> dict[str, Any]:
    """Chemin de contrôle sur doubles seulement ; aucun port natif constructible."""
    plan.validate()
    started = port.now()
    require(type(started) in (int, float) and math.isfinite(started) and started >= 0,
            "horloge monotone invalide")
    owner = port.read_identity(port.self_pid())
    identity(owner)
    require(type(owner.get("executable")) is str and owner["executable"].startswith("/"),
            "exécutable parent inconnu")
    sinks = handle = child = None
    released = confirmed = gate_closed = reaped = stable = sources_unchanged = False
    returncode: int | None = None
    errors: list[str] = []
    signals: list[str] = []
    try:
        require(port.verify_sources(plan.source_refs), "préimages modifiées avant Popen")
        sinks = port.open_sinks(plan)
        require(port.now() <= started + GATE_SECONDS, "gate expiré avant Popen")
        handle = port.spawn(plan, sinks)
        # Une naissance attribuée est requise AVANT de croire le ready.
        candidate = port.read_identity(handle.pid)
        identity(candidate, expected_binary=str(plan.binary))
        require(candidate["pid"] == handle.pid
                and candidate["ppid"] == owner["pid"] and candidate["uid"] == owner["uid"]
                and candidate["pgid"] == candidate["pid"], "enfant non attribué")
        # Rien dans cleanup ne peut signaler un candidat non attribué.
        child = candidate
        raw = port.read_ready(handle, sinks, started + GATE_SECONDS)
        parse_ready(raw, plan, owner, child)
        require(port.now() <= started + GATE_SECONDS, "gate dépassé")
        require(port.poll(handle) is None and _same_live(port, owner, child, plan),
                "naissance/parent changés avant release")
        require(port.verify_sources(plan.source_refs), "préimages modifiées avant release")
        require(port.now() <= started + GATE_SECONDS,
                "gate expiré après rehash, avant release")
        port.release(handle, release_bytes(plan, child))
        released = True
        parse_released(port.read_gate_released(handle, sinks, started + GATE_SECONDS), plan, child)
        require(port.now() <= started + GATE_SECONDS, "ACK gate hors borne")
        confirmed = True
        port.close_gate(handle)
        gate_closed = True
        returncode = port.wait_until(handle, port.now() + CASE_SECONDS)
        require(returncode is not None, "cas expiré")
        reaped = True
        require(returncode == 0, f"sonde exit {returncode}")
    except (Exception, KeyboardInterrupt, SystemExit) as exc:
        errors.append(f"{type(exc).__name__}:{exc}")
    finally:
        cleanup_start = port.now()
        cleanup_deadline = cleanup_start + CLEANUP_SECONDS
        if handle is not None:
            if not gate_closed:
                try:
                    port.close_gate(handle)
                except Exception as exc:
                    errors.append(f"close_gate:{type(exc).__name__}:{exc}")
            if not reaped:
                try:
                    # L'alarme autonome du C peut sortir sans aucun signal.
                    waited = port.wait_until(handle, min(cleanup_deadline, cleanup_start + GATE_SECONDS))
                    if waited is not None:
                        returncode, reaped = waited, True
                except Exception as exc:
                    errors.append(f"wait_gate:{type(exc).__name__}:{exc}")
            if not reaped and child is not None:
                uncertain = False
                for sig in (signal.SIGTERM, signal.SIGKILL):
                    if port.now() >= cleanup_deadline:
                        break
                    try:
                        polled = port.poll(handle)
                    except BaseException as exc:
                        errors.append(f"poll incertain:{type(exc).__name__}:{exc}")
                        uncertain = True
                        break
                    if polled is not None:
                        try:
                            waited = port.wait_until(handle, cleanup_deadline)
                            if waited is not None:
                                returncode, reaped = waited, True
                        except Exception as exc:
                            errors.append(f"reap sorti:{type(exc).__name__}:{exc}")
                        break
                    if not _same_live(port, owner, child, plan):
                        errors.append("identité incertaine : aucun signal supplémentaire")
                        uncertain = True
                        break
                    try:
                        port.signal_pid(handle.pid, sig)  # Jamais PGID ou process group.
                        signals.append(sig.name)
                        grace_deadline = (min(cleanup_deadline, port.now() + TERM_GRACE_SECONDS)
                                          if sig == signal.SIGTERM else cleanup_deadline)
                        waited = port.wait_until(handle, grace_deadline)
                        if waited is not None:
                            returncode, reaped = waited, True
                            break
                    except Exception as exc:
                        errors.append(f"signal/wait:{type(exc).__name__}:{exc}")
                        break
                if uncertain and not reaped:
                    try:
                        waited = port.wait_until(handle, cleanup_deadline)
                        if waited is not None:
                            returncode, reaped = waited, True
                    except Exception as exc:
                        errors.append(f"wait_uncertain:{type(exc).__name__}:{exc}")
            if not reaped and child is None:
                # Sans naissance, jamais adopter le PID. Continuer l'attente bornée.
                try:
                    waited = port.wait_until(handle, cleanup_deadline)
                    if waited is not None:
                        returncode, reaped = waited, True
                except Exception as exc:
                    errors.append(f"wait_unknown:{type(exc).__name__}:{exc}")
        if sinks is not None:
            try:
                stable = port.close_sinks(sinks)
            except Exception as exc:
                errors.append(f"close_sinks:{type(exc).__name__}:{exc}")
        try:
            sources_unchanged = port.verify_sources(plan.source_refs)
            if not sources_unchanged:
                errors.append("préimages modifiées après fermeture")
        except Exception as exc:
            errors.append(f"rehash final:{type(exc).__name__}:{exc}")
        ended = port.now()
        deadline_met = type(ended) in (int, float) and math.isfinite(ended) and ended <= cleanup_deadline
        if not deadline_met:
            errors.append("cleanup deadline dépassée")
        if handle is not None and not reaped:
            errors.append("enfant non reaped")
    termination_proved = handle is not None and child is not None and reaped
    clean = (termination_proved and stable and sources_unchanged and confirmed
             and returncode == 0 and not errors and not signals and deadline_met)
    return {"schema": "c17-seatbelt-controller-pure-simulation-v1", "case": plan.case,
            "owner": owner, "child": child, "release_written_on_mock": released,
            "release_confirmed_on_mock": confirmed,
            "returncode": returncode, "signals_on_mock": signals, "errors": errors,
            "termination_proved_on_mock": termination_proved, "clean_on_mock": clean,
            "source_refs_unchanged_on_mock": sources_unchanged,
            "cleanup_deadline_met_on_mock": deadline_met,
            "native_measured": False, "release_authorized": False,
            "FULL": False, "Chrome_qualified": False}


def activate(*_args: Any, **_kwargs: Any) -> None:
    raise RuntimeError("Mesure native désactivée ; nouvelle dérivation et GO requis")
