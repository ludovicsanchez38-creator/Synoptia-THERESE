# Contrôleur mono-sonde Seatbelt, désactivé, v3

Successeur du v2 `/private/tmp/therese-c17-seatbelt-controller-v2-eOcvBz/INDEX.json`
SHA-256 `5c21052dfe0ca9f14c72ea8dcaa3042939a400933465ccc212965b3f90520128`.
Le v2 reste une trace non consommable : la revue Gate a trouvé qu'une
naissance non attribuée pouvait rester dans `child` puis être signalée au
cleanup ; l'attente SIGTERM pouvait épuiser toute la fenêtre de 8 s ; un
rehash lent après le premier contrôle de gate pouvait précéder une release
hors borne. V3 affecte `child` seulement après validation de statut,
exécutable, PID du handle, PPID, UID et PGID, réserve 1 s interne à TERM avant KILL avec
relecture d'identité, et recontrôle le temps immédiatement avant l'écriture
sur stdin. Quatre mutants ciblés prouvent ces refus/ordres sur doubles. La
garde d'ACK octet-exact du v2 reste inchangée. Aucune borne n'est prolongée.

Successeur v2 du gel v1 `/private/tmp/therese-c17-seatbelt-controller-SQOoCx/INDEX.json`
SHA-256 `00a90727737f74e3a92c097ae434a652df4fad093fe53a05b2a2ff1dad297270`.
Le v1 reste intact. Sa comparaison d'ACK par dictionnaire pouvait accepter
une permutation de clés, des espaces et, pour un entier attendu égal à 1,
un booléen JSON. Seul `parse_released()` change : entiers de PID/secondes/
microsecondes stricts et ligne entière égale aux octets compacts du C, dans
l'ordre exact des six clés avec LF. Trois mutants nouveaux prouvent les refus,
un témoin `start_usec=1` entier est accepté. Aucun autre corps d'exécution,
source native ou contrat C n'a été modifié.

Ce lot ne lance rien. `controller.activate()` et `native_port.NativePort()`
refusent inconditionnellement ; `NATIVE_MEASUREMENT_ENABLED=false`. Le chemin
`_drive` ne reçoit qu'un port injecté par les tests. Il reste une proposition
de code à revoir et à dériver séparément avant toute mesure diagnostique.

Portée fermée : un binaire C synthétique, un seul enfant direct par session,
un des cinq cas `baseline`, `compiled-alpha`, `compiled-beta`, `source-alpha`,
`source-beta`. `Plan.argv()` exige exactement
`[probe, --reviewed-case, CASE, --gate-nonce, HEX32]`. `Plan` exige un binaire
épinglé, des chemins QA absolus et deux sinks distincts. Le port OS préparé
décrit des créations exclusives `O_EXCL|O_NOFOLLOW` des deux logs, `Popen`
direct avec `stdin=PIPE`, `close_fds=True` et session propre ; aucun FD métier
hérité. Son environnement est exactement `HOME` et `TMPDIR` sous la racine
QA privée plus `PATH=/usr/bin:/bin`, sans `os.environ` ni clé libre. Le lecteur
stdout recroise son inode/UID/type avec le FD O_EXCL détenu ; les références
source comparent stat avant/ouvert/après hors atime. Il est impossible de
construire ce port dans ce gel.

La future sonde C distincte doit émettre une unique ligne `ready-v1` bornée
à 512 octets avec cas, nonce et six champs libproc ; elle attend ensuite sur
FD 0 avant tout témoin, `sandbox_check`, compilation de profil ou application.
Après comparaison de naissance/chemin/statut enfant et parent par libproc,
le contrôleur enverrait une ligne JSON compacte `release-v1` de six clés dans
l'ordre `schema,case,nonce,pid,start_sec,start_usec`, puis attendrait
`gate-released-v1` exact avant de fermer stdin. L'ordre expérimental C après
la barrière doit conserver le refus ambient `sandbox_check` avant la
compilation privée. Les sorties métier historiques, y compris baseline sans
`case_finished` et les codes rouges, ne doivent pas être réinterprétées.

Le lecteur natif préparé porte explicitement les signatures typées
`proc_pidinfo(PROC_PIDTBSDINFO=3)` et `proc_pidpath`, les six champs de birth,
le statut BSD et le chemin exécutable. Seuls `SRUN=2` ou `SSLEEP=3` sont
acceptés pour parent/enfant ; `PROC_FLAG_INEXIT=4`, PID retourné divergent,
stopped, zombie ou lecture partielle refusent.
Chaque release et chaque éventuel signal PID est précédé d'une relecture
parent/enfant. Cette relecture PID n'est pas atomique avec `kill(pid)` ; le
risque de réutilisation entre les deux reste une limite explicite à mesurer,
sans droit de le présenter comme une garantie kernel. Il n'existe jamais de
signal de groupe, d'adoption du PID issu du ready ni de signal si l'identité
est inconnue ou divergente. Le gate est alors fermé et le handle direct
attendu jusqu'à la borne de nettoyage, sans faux `clean`.

Bornes proposées dans le code : gate 5 s depuis le départ, cas 5 s après ACK,
nettoyage 8 s depuis son entrée. Elles ne sont pas prouvées en OS. Le vert
mock exige child attribué, ACK, code brut 0, handle reaped, sinks stables et
aucune erreur ni signal. `native_measured=false`, `release_authorized=false`,
`FULL=false`, `Chrome_qualified=false` sont constants dans le résultat mock.

Tests réellement exécutés avec `/opt/homebrew/bin/python3 -I -B
test_controller.py` : 31 cas PASS. Le garde d'audit interdit pendant `_drive`
`subprocess.Popen`, `os.kill`, `os.open` et `ctypes.CDLL` ; tous les processus,
naissances, refus et temps sont des doubles. Le premier essai `-I` était rouge
sur l'import local, le deuxième sur le test de type `Path`, le troisième sur
deux attentes de fixtures ; ces rouges sont des réparations de tests/source,
pas des mesures C. Aucune compilation C, sonde, service, Chrome ou G1 n'a été
exécuté par ce lot.

La définition C compatible est maintenant figée séparément sous
`/private/tmp/therese-c17-seatbelt-composition-fds-0dUJdL/INDEX.json`
(SHA-256 `df09a6d68abb3b56b7984113f3efe3019725c3aa8fbb91180278d1e170672a7e`).
Son `probe.c` SHA-256 `d9c161e71b6d4323f5d63ad5ddc566099edb1576b1fecaeaa908b5322abb8ca9`
porte ready/release/ACK identiques et refuse encore nativement avec
`NATIVE_MEASUREMENT_ENABLED=false`. Il n'est pas compilé ni mesuré ; le gel
gated précédent `J4B04K` garde son rouge de compilation `closefrom` sous
`-Werror`. Le binaire futur, ses chemins `home/tmp/run`, son identité source
et les sorties restent à créer/pinner/revoir par MAIN, sans consommer une
admission depuis ce dossier. Les 67 tests Shared4 sont statiques et
distincts des 31 mocks de ce contrôleur. Aucune source ROOT15, G1, FULL ou
produit n'a été modifiée.
