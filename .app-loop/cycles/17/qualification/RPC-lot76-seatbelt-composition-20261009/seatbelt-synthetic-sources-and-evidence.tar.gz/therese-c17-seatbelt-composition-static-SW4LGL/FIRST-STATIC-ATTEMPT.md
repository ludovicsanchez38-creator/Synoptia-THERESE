# Premier essai de tests statiques, non concluant

Le 09/10/2026, l'appel via `/usr/bin/python3` a terminé avec code 2 avant la suite. Le shim Apple a invoqué sa résolution Xcode et créé `xcrun_db` dans `/private/tmp/therese-c17-composition-pure-dgFgzU`. Le runner exige une sortie vide et refuse cette sortie devenue non vide. Aucun reçu de tests n'est présent et aucun test n'est compté.

Retours réels de l'outil : chunk `41629e`, session `73733`, puis chunk `06ffe6`, code 2. Les deux lignes retournées sont conservées dans `first-static-returned-output.log`. Ce texte est la sortie combinée rendue par l'outil, pas un sink stdout/stderr direct. Le fichier `xcrun_db` reste intact dans sa sortie originale.

Aucune compilation C/profil Apple ni appel des API sandbox de la sonde n'a eu lieu. La résolution Xcode est un processus auxiliaire réel inattendu ; ce premier essai ne doit pas être résumé comme « zéro processus lancé ». Le rejeu suivant utilise exclusivement l'interpréteur physique UV, sans shim Apple, QA venv ou import G1.
