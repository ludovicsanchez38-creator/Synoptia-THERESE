# Sonde Seatbelt, préparation statique fermée

Acteur auteur : `/root/shared4_execution`. Aucun GO natif, compilation ou autorité n'est émis dans ce dossier. `prepare_static.py --compile` et `--execute` refusent toujours avec code 2. La sonde C porte elle-même `NATIVE_MEASUREMENT_ENABLED = false` : même une future compilation de ces octets ne permettrait pas de mesurer le noyau.

## Objet exact

`probe.c` prépare une mesure mono-processus de deux politiques **valides et distinctes**, après une politique extérieure distincte. Les trois textes SB sont reproduits byte-exact dans les constantes C et vérifiés par les tests Python. Ce sont uniquement des permissions de métadonnées/lecture sur deux fichiers synthétiques privés. Aucun `allow default`, écriture, droit réseau, Mach, IOKit, exec, fork, signal, profil personnel ou chemin système n'est accordé par ces politiques.

La politique extérieure permet A et interdit la lecture de B. Alpha permet B et interdit A. Beta permet A et B. Si l'intersection était réellement appliquée, alpha devrait refuser A et B ; beta devrait conserver A lisible et B refusé. Un remplacement de la politique extérieure serait détecté par B devenu lisible. Un refus de l'API privée reste un rouge diagnostique, jamais une réussite métier. ENOENT et toute autre erreur inattendue ne sont pas assimilés à un refus EPERM/EACCES.

Les seules lectures de la sonde sont les deux témoins au chemin fixé dans le source. Les paramètres SB ne sont jamais pris de l'environnement ou de l'argv. Les profils compilés sont préparés en mémoire avant l'application extérieure. Cela évite d'ajouter des autorisations de lecture de SDK, fichiers SB ou bibliothèques à la politique extérieure. Les bibliothèques/initialiseurs et les contrôles de chemin s'exécuteraient cependant avant cette application : cette phase devra être couverte par la supervision MAIN future, pas assimilée au confinement mesuré.

La sonde refuse un environnement déjà sandboxé avant de tenter sa politique extérieure. Elle n'effectue ni fork ni exec : elle ne mesure donc pas l'héritage d'un enfant G1. Elle ferme les FD >=3 avant les lectures ; les FD 1/2 doivent être deux sinks QA exclusifs réellement vérifiés par MAIN. Leur simple existence n'est pas une preuve.

## Plan futur, non exécutable maintenant

1. MAIN relit code, profils, références d'API et risques. Compiler/SDK, argv, environnement, source et sinks devront être épinglés dans une autorité externe spécifique à la sonde. Aucun objet de ce type n'est fourni ici.
2. Une nouvelle copie et une dérivation exacte de la constante native devront être revues séparément. Ne pas changer ce gel ou ses tests pour le rendre lançable. Aucune autre modification fonctionnelle n'est autorisée par ce plan.
3. Compiler uniquement cette nouvelle copie avec l'outil/SDK réellement épinglés. Le préparateur présent ne peut pas faire cette action. Les déclarations privées et le layout de `sandbox_profile_t` proviennent du code public Chromium main, pas d'un contrat ABI Apple public : une erreur de compilation/lien/ABI reste un rouge à conserver.
4. Avant toute mesure, revoir le raccord à un ledger réel, capture d'identité avant travail, refus d'identité inconnue, sinks directs exclusifs et watchdog. Les bornes proposées sont gate5, cas5, cleanup8 ; aucun mécanisme de fermeture par naissance réelle n'est implémenté dans ce dossier. Le code C n'émet aucun signal et ne possède pas de cleanup prétendument qualifié.
5. Cas fermés proposés : baseline, compiled-alpha, compiled-beta, source-alpha, source-beta. Aucun cas ultérieur n'est lancé automatiquement après un rouge. Les deux cas `source-*` appellent une API privée dans un processus déjà soumis à outer : MAIN devra décider explicitement s'ils sont légitimes/nécessaires. Le commentaire du SDK public sur `sandbox_init` ne prouve pas le comportement de ces API privées.
6. Chaque processus rend uniquement les retours/errno et lectures témoins. Un code 0 ne prouve que les observations locales prévues de ce cas, pas la composition générale, le réseau, les IPC, l'héritage, Chrome ou FULL. Rehash des sources/témoins et preuve réelle de fermeture restent obligatoires dans le futur contrôleur.

Après un refus ou à la fin : arrêter uniquement les identités réellement attribuées via le contrôleur futur, conserver tous les flux/reçus et laisser ce gel intact. Aucun fallback non sandboxé, broker même UID, resandbox forcé, compte système, réseau externe ou permission supplémentaire n'est proposé. Aucun retour arrière ne requiert de modifier Chrome, G1, ROOT15, FULLv4, dépôt ou état.

## Vérifications réellement exécutées

27 tests statiques Python sont PASS, zéro erreur/échec/skip, pins avant/après identiques et zéro tentative via les points d'entrée gardés subprocess/socket/exec/fork/signal/ctypes. Reçu : `/private/tmp/therese-c17-composition-pure-jluYAe/receipt.json`, sortie de tests adjacente. Le Python physique UV3.13.5 est utilisé en `-I -B`, sans QA venv ni import G1.

Ces tests vérifient les sources C comme **texte**, pas comme unité compilée, et comparent les profils exactement ; aucun compilateur C ni compilateur de profil Apple n'a été exécuté. Ils n'observent aucune API sandbox ou propriété du noyau.

Premier essai Apple shim non concluant : voir `FIRST-STATIC-ATTEMPT.md`. La résolution a réellement lancé Xcode/xcrun et créé un `xcrun_db` dans sa sortie privée. La suite n'a pas démarré. Il n'existe pas d'observation exhaustive des éventuelles écritures hors de cette sortie ; ne pas revendiquer « aucun processus/toolchain lancé » pour cet essai.

Commande des seuls tests statiques, dans une sortie privée vide choisie par MAIN :

```
env -i HOME=<SORTIE_PRIVEE_VIDE> TMPDIR=<SORTIE_PRIVEE_VIDE> PATH=/usr/bin:/bin \
/Users/synoptia/.local/share/uv/python/cpython-3.13.5-macos-aarch64-none/bin/python3.13 -I -B \
-c 'import sys; sys.path.insert(0, "/private/tmp/therese-c17-seatbelt-composition-static-SW4LGL"); import run_static_tests; raise SystemExit(run_static_tests.main())' \
<SORTIE_PRIVEE_VIDE>
```

La sortie doit être un dossier canonique vide `/private/tmp/therese-c17-composition-pure-*`. Cette commande n'exécute pas le C et n'autorise aucune compilation ou campagne.

## Provenance et limites

ROOT15 reste rouge a2cb37382bbf4f64de44ab21525e78eccf73ed06c553f1ac2898cbb5a2b0840d ; FULLv4 demeure préparatoire. Aucun fichier de leurs racines n'a été modifié.

Les sources primaires consultées sont Chromium `main`, non appariées au Chrome154 : `seatbelt.cc` lignes14–17/45–54/144–158/179–186 ; `sandbox_serializer.cc` 182–210 ; `chrome_exe_main_mac.cc` 157–169 ; `sandbox_serializer_unittest.cc` 151–175 et 188–191. Le dernier test réapplique des flux tronqués après un flux complet, il ne valide pas l'intersection de deux politiques valides différentes. Le design V2 indique une exception GPU ; ne pas généraliser la phase avant Framework à tous les helpers et GPU du binaire réel.

https://raw.githubusercontent.com/chromium/chromium/main/sandbox/mac/seatbelt.cc
https://raw.githubusercontent.com/chromium/chromium/main/sandbox/mac/sandbox_serializer.cc
https://raw.githubusercontent.com/chromium/chromium/main/chrome/app/chrome_exe_main_mac.cc
https://raw.githubusercontent.com/chromium/chromium/main/sandbox/mac/sandbox_serializer_unittest.cc
https://raw.githubusercontent.com/chromium/chromium/main/sandbox/mac/seatbelt_sandbox_design.md

Le header SDK public local `sandbox.h`, lignes24–26, documente `sandbox_init`, non un contrat de composition des deux API privées. Aucun passage de préparation ou résultat statique ne devient une autorisation actuelle.
