"""Freeze only this static preparation's exact refs. No native authority."""
import json
from pathlib import Path
import prepare_static as p

FILES = ("probe.c", "prepare_static.py", "test_static.py", "run_static_tests.py", "freeze_index.py",
         "README.md", "FIRST-STATIC-ATTEMPT.md", "first-static-returned-output.log",
         "policies/outer.sb", "policies/alpha.sb", "policies/beta.sb",
         "witnesses/a.txt", "witnesses/b.txt")
PURE = Path("/private/tmp/therese-c17-composition-pure-jluYAe")


def main():
    p.static_check()
    receipt = json.loads((PURE / "receipt.json").read_text())
    p.need(receipt["passed"] is True and receipt["tests_run"] == 27 and
           receipt["errors"] == receipt["failures"] == receipt["skips"] == 0 and
           receipt["forbidden_attempts"] == [] and receipt["source_before"] == receipt["source_after"],
           "real static test receipt mismatch")
    for ref in receipt["source_before"]:
        p.need(p.reference(Path(ref["path"])) == ref, "test source pin changed")
    local = [p.reference(p.HERE / name) for name in FILES]
    evidence = [p.reference(PURE / "receipt.json"), p.reference(PURE / "returned-test-output.log")]
    origins = [p.reference(Path("/private/tmp/therese-c17-wrapper-canary-9c1f04187dd24519b220372284a739c9/wrapper-canary-result.json")),
               p.reference(Path("/private/tmp/therese-c17-wrapper-canary-9c1f04187dd24519b220372284a739c9/g1/runtime_session.py")),
               p.reference(Path("/private/tmp/therese-c17-full-physical-builder-v4-Diccb9/INDEX.json")),
               p.reference(Path("/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sandbox.h"))]
    payload = {"schema": "c17-seatbelt-composition-static-index-v1", "actor": "/root/shared4_execution",
               "status": "prepared_only_not_admitted", "files": local, "evidence": evidence, "origin_refs": origins,
               "first_failed_static_output_root": "/private/tmp/therese-c17-composition-pure-dgFgzU",
               "first_failed_static_tool_chunks": ["41629e", "06ffe6"], "first_failed_static_exit_code": 2,
               "first_failed_static_tests_started": False,
               "plan": p.future_plan(), "C_compiled": False, "Apple_profile_compiled": False,
               "kernel_measured": False, "Chrome_started": False, "G1_imported": False,
               "native_admission": None, "RUNTIME": False, "FULL": False, "release": False}
    for ref in local + evidence + origins:
        p.need(p.reference(Path(ref["path"])) == ref, "freeze pin changed")
    target = p.HERE / "INDEX.json"
    with target.open("x") as sink:
        json.dump(payload, sink, indent=2, sort_keys=True); sink.write("\n")
    print(json.dumps(p.reference(target), sort_keys=True))


if __name__ == "__main__":
    raise SystemExit(main())
