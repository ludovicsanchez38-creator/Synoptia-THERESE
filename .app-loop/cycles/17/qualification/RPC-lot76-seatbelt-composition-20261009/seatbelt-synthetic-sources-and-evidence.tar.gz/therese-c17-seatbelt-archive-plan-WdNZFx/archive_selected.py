"""Bounded source/evidence archival. No recursive ref discovery or native action."""
from __future__ import annotations
import argparse
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import tarfile

HERE = Path(__file__).resolve().parent
SELECTED = (
    "/private/tmp/therese-c17-seatbelt-composition-static-SW4LGL/FIRST-STATIC-ATTEMPT.md",
    "/private/tmp/therese-c17-seatbelt-composition-static-SW4LGL/INDEX.json",
    "/private/tmp/therese-c17-seatbelt-composition-static-SW4LGL/README.md",
    "/private/tmp/therese-c17-seatbelt-composition-static-SW4LGL/first-static-returned-output.log",
    "/private/tmp/therese-c17-seatbelt-composition-static-SW4LGL/freeze_index.py",
    "/private/tmp/therese-c17-seatbelt-composition-static-SW4LGL/policies/alpha.sb",
    "/private/tmp/therese-c17-seatbelt-composition-static-SW4LGL/policies/beta.sb",
    "/private/tmp/therese-c17-seatbelt-composition-static-SW4LGL/policies/outer.sb",
    "/private/tmp/therese-c17-seatbelt-composition-static-SW4LGL/prepare_static.py",
    "/private/tmp/therese-c17-seatbelt-composition-static-SW4LGL/probe.c",
    "/private/tmp/therese-c17-seatbelt-composition-static-SW4LGL/run_static_tests.py",
    "/private/tmp/therese-c17-seatbelt-composition-static-SW4LGL/test_static.py",
    "/private/tmp/therese-c17-seatbelt-composition-static-SW4LGL/witnesses/a.txt",
    "/private/tmp/therese-c17-seatbelt-composition-static-SW4LGL/witnesses/b.txt",
    "/private/tmp/therese-c17-seatbelt-gate-static-g307jq/INDEX.json",
    "/private/tmp/therese-c17-seatbelt-gate-static-g307jq/README.md",
    "/private/tmp/therese-c17-seatbelt-gate-static-g307jq/gate_contract.py",
    "/private/tmp/therese-c17-seatbelt-gate-static-g307jq/test_gate_contract.py",
    "/private/tmp/therese-c17-seatbelt-composition-gated-J4B04K/FIRST-FREEZE-REFUSAL.md",
    "/private/tmp/therese-c17-seatbelt-composition-gated-J4B04K/INDEX.json",
    "/private/tmp/therese-c17-seatbelt-composition-gated-J4B04K/README.md",
    "/private/tmp/therese-c17-seatbelt-composition-gated-J4B04K/diffs/prepare_static.py.direct.diff",
    "/private/tmp/therese-c17-seatbelt-composition-gated-J4B04K/diffs/prepare_static.py.inverse.diff",
    "/private/tmp/therese-c17-seatbelt-composition-gated-J4B04K/diffs/probe.c.direct.diff",
    "/private/tmp/therese-c17-seatbelt-composition-gated-J4B04K/diffs/probe.c.inverse.diff",
    "/private/tmp/therese-c17-seatbelt-composition-gated-J4B04K/diffs/run_static_tests.py.direct.diff",
    "/private/tmp/therese-c17-seatbelt-composition-gated-J4B04K/diffs/run_static_tests.py.inverse.diff",
    "/private/tmp/therese-c17-seatbelt-composition-gated-J4B04K/diffs/test_static.py.direct.diff",
    "/private/tmp/therese-c17-seatbelt-composition-gated-J4B04K/diffs/test_static.py.inverse.diff",
    "/private/tmp/therese-c17-seatbelt-composition-gated-J4B04K/freeze_index.py",
    "/private/tmp/therese-c17-seatbelt-composition-gated-J4B04K/gate_fragment.c.inc",
    "/private/tmp/therese-c17-seatbelt-composition-gated-J4B04K/policies/alpha.sb",
    "/private/tmp/therese-c17-seatbelt-composition-gated-J4B04K/policies/beta.sb",
    "/private/tmp/therese-c17-seatbelt-composition-gated-J4B04K/policies/outer.sb",
    "/private/tmp/therese-c17-seatbelt-composition-gated-J4B04K/preimages/freeze_index-before-diff-parser.py",
    "/private/tmp/therese-c17-seatbelt-composition-gated-J4B04K/preimages/policies/alpha.sb",
    "/private/tmp/therese-c17-seatbelt-composition-gated-J4B04K/preimages/policies/beta.sb",
    "/private/tmp/therese-c17-seatbelt-composition-gated-J4B04K/preimages/policies/outer.sb",
    "/private/tmp/therese-c17-seatbelt-composition-gated-J4B04K/preimages/prepare_static.py",
    "/private/tmp/therese-c17-seatbelt-composition-gated-J4B04K/preimages/probe.c",
    "/private/tmp/therese-c17-seatbelt-composition-gated-J4B04K/preimages/run_static_tests.py",
    "/private/tmp/therese-c17-seatbelt-composition-gated-J4B04K/preimages/test_static.py",
    "/private/tmp/therese-c17-seatbelt-composition-gated-J4B04K/preimages/witnesses/a.txt",
    "/private/tmp/therese-c17-seatbelt-composition-gated-J4B04K/preimages/witnesses/b.txt",
    "/private/tmp/therese-c17-seatbelt-composition-gated-J4B04K/prepare_static.py",
    "/private/tmp/therese-c17-seatbelt-composition-gated-J4B04K/probe.c",
    "/private/tmp/therese-c17-seatbelt-composition-gated-J4B04K/run_static_tests.py",
    "/private/tmp/therese-c17-seatbelt-composition-gated-J4B04K/test_static.py",
    "/private/tmp/therese-c17-seatbelt-composition-gated-J4B04K/witnesses/a.txt",
    "/private/tmp/therese-c17-seatbelt-composition-gated-J4B04K/witnesses/b.txt",
    "/private/tmp/therese-c17-seatbelt-composition-fds-0dUJdL/INDEX.json",
    "/private/tmp/therese-c17-seatbelt-composition-fds-0dUJdL/README.md",
    "/private/tmp/therese-c17-seatbelt-composition-fds-0dUJdL/diffs/prepare_static.py.direct.diff",
    "/private/tmp/therese-c17-seatbelt-composition-fds-0dUJdL/diffs/prepare_static.py.inverse.diff",
    "/private/tmp/therese-c17-seatbelt-composition-fds-0dUJdL/diffs/probe.c.direct.diff",
    "/private/tmp/therese-c17-seatbelt-composition-fds-0dUJdL/diffs/probe.c.inverse.diff",
    "/private/tmp/therese-c17-seatbelt-composition-fds-0dUJdL/diffs/run_static_tests.py.direct.diff",
    "/private/tmp/therese-c17-seatbelt-composition-fds-0dUJdL/diffs/run_static_tests.py.inverse.diff",
    "/private/tmp/therese-c17-seatbelt-composition-fds-0dUJdL/diffs/test_static.py.direct.diff",
    "/private/tmp/therese-c17-seatbelt-composition-fds-0dUJdL/diffs/test_static.py.inverse.diff",
    "/private/tmp/therese-c17-seatbelt-composition-fds-0dUJdL/fd_fragment.c.inc",
    "/private/tmp/therese-c17-seatbelt-composition-fds-0dUJdL/freeze_index.py",
    "/private/tmp/therese-c17-seatbelt-composition-fds-0dUJdL/gate_fragment.c.inc",
    "/private/tmp/therese-c17-seatbelt-composition-fds-0dUJdL/policies/alpha.sb",
    "/private/tmp/therese-c17-seatbelt-composition-fds-0dUJdL/policies/beta.sb",
    "/private/tmp/therese-c17-seatbelt-composition-fds-0dUJdL/policies/outer.sb",
    "/private/tmp/therese-c17-seatbelt-composition-fds-0dUJdL/preimages/gate_fragment.c.inc",
    "/private/tmp/therese-c17-seatbelt-composition-fds-0dUJdL/preimages/policies/alpha.sb",
    "/private/tmp/therese-c17-seatbelt-composition-fds-0dUJdL/preimages/policies/beta.sb",
    "/private/tmp/therese-c17-seatbelt-composition-fds-0dUJdL/preimages/policies/outer.sb",
    "/private/tmp/therese-c17-seatbelt-composition-fds-0dUJdL/preimages/prepare_static.py",
    "/private/tmp/therese-c17-seatbelt-composition-fds-0dUJdL/preimages/probe.c",
    "/private/tmp/therese-c17-seatbelt-composition-fds-0dUJdL/preimages/run_static_tests.py",
    "/private/tmp/therese-c17-seatbelt-composition-fds-0dUJdL/preimages/test_static.py",
    "/private/tmp/therese-c17-seatbelt-composition-fds-0dUJdL/preimages/witnesses/a.txt",
    "/private/tmp/therese-c17-seatbelt-composition-fds-0dUJdL/preimages/witnesses/b.txt",
    "/private/tmp/therese-c17-seatbelt-composition-fds-0dUJdL/prepare_static.py",
    "/private/tmp/therese-c17-seatbelt-composition-fds-0dUJdL/probe.c",
    "/private/tmp/therese-c17-seatbelt-composition-fds-0dUJdL/run_static_tests.py",
    "/private/tmp/therese-c17-seatbelt-composition-fds-0dUJdL/test_static.py",
    "/private/tmp/therese-c17-seatbelt-composition-fds-0dUJdL/witnesses/a.txt",
    "/private/tmp/therese-c17-seatbelt-composition-fds-0dUJdL/witnesses/b.txt",
    "/private/tmp/therese-c17-seatbelt-controller-SQOoCx/INDEX.json",
    "/private/tmp/therese-c17-seatbelt-controller-SQOoCx/README.md",
    "/private/tmp/therese-c17-seatbelt-controller-SQOoCx/controller.py",
    "/private/tmp/therese-c17-seatbelt-controller-SQOoCx/native_port.py",
    "/private/tmp/therese-c17-seatbelt-controller-SQOoCx/test_controller.py",
    "/private/tmp/therese-c17-seatbelt-controller-v2-eOcvBz/INDEX.json",
    "/private/tmp/therese-c17-seatbelt-controller-v2-eOcvBz/README.md",
    "/private/tmp/therese-c17-seatbelt-controller-v2-eOcvBz/controller.py",
    "/private/tmp/therese-c17-seatbelt-controller-v2-eOcvBz/diffs/README.md.diff",
    "/private/tmp/therese-c17-seatbelt-controller-v2-eOcvBz/diffs/README.md.inverse",
    "/private/tmp/therese-c17-seatbelt-controller-v2-eOcvBz/diffs/controller.py.diff",
    "/private/tmp/therese-c17-seatbelt-controller-v2-eOcvBz/diffs/controller.py.inverse",
    "/private/tmp/therese-c17-seatbelt-controller-v2-eOcvBz/diffs/test_controller.py.diff",
    "/private/tmp/therese-c17-seatbelt-controller-v2-eOcvBz/diffs/test_controller.py.inverse",
    "/private/tmp/therese-c17-seatbelt-controller-v2-eOcvBz/native_port.py",
    "/private/tmp/therese-c17-seatbelt-controller-v2-eOcvBz/preimages/README.md",
    "/private/tmp/therese-c17-seatbelt-controller-v2-eOcvBz/preimages/controller.py",
    "/private/tmp/therese-c17-seatbelt-controller-v2-eOcvBz/preimages/test_controller.py",
    "/private/tmp/therese-c17-seatbelt-controller-v2-eOcvBz/test_controller.py",
    "/private/tmp/therese-c17-seatbelt-independent-review-uh0VHhL8/INDEX.json",
    "/private/tmp/therese-c17-seatbelt-independent-review-uh0VHhL8/REVIEW.json",
    "/private/tmp/therese-c17-composition-pure-jluYAe/receipt.json",
    "/private/tmp/therese-c17-composition-pure-jluYAe/returned-test-output.log",
    "/private/tmp/therese-c17-composition-pure-aJEHtg/receipt.json",
    "/private/tmp/therese-c17-composition-pure-aJEHtg/returned-test-output.log",
    "/private/tmp/therese-c17-composition-pure-yZeo1X/receipt.json",
    "/private/tmp/therese-c17-composition-pure-yZeo1X/returned-test-output.log",
    "/private/tmp/therese-c17-seatbelt-compile-disabled-a29bPs/compile-failure.json",
    "/private/tmp/therese-c17-seatbelt-controller-v3-9nfpdk/INDEX.json",
    "/private/tmp/therese-c17-seatbelt-controller-v3-9nfpdk/README.md",
    "/private/tmp/therese-c17-seatbelt-controller-v3-9nfpdk/controller.py",
    "/private/tmp/therese-c17-seatbelt-controller-v3-9nfpdk/diffs/README.md.diff",
    "/private/tmp/therese-c17-seatbelt-controller-v3-9nfpdk/diffs/README.md.inverse",
    "/private/tmp/therese-c17-seatbelt-controller-v3-9nfpdk/diffs/controller.py.diff",
    "/private/tmp/therese-c17-seatbelt-controller-v3-9nfpdk/diffs/controller.py.inverse",
    "/private/tmp/therese-c17-seatbelt-controller-v3-9nfpdk/diffs/test_controller.py.diff",
    "/private/tmp/therese-c17-seatbelt-controller-v3-9nfpdk/diffs/test_controller.py.inverse",
    "/private/tmp/therese-c17-seatbelt-controller-v3-9nfpdk/native_port.py",
    "/private/tmp/therese-c17-seatbelt-controller-v3-9nfpdk/preimages/README.md",
    "/private/tmp/therese-c17-seatbelt-controller-v3-9nfpdk/preimages/controller.py",
    "/private/tmp/therese-c17-seatbelt-controller-v3-9nfpdk/preimages/test_controller.py",
    "/private/tmp/therese-c17-seatbelt-controller-v3-9nfpdk/test_controller.py",
    "/private/tmp/therese-c17-controller-v3-independent-review-aj7fDdbf/INDEX.json",
    "/private/tmp/therese-c17-controller-v3-independent-review-aj7fDdbf/REVIEW.json",
    "/private/tmp/therese-c17-composition-pure-main-TUsw7p/receipt.json",
    "/private/tmp/therese-c17-composition-pure-main-TUsw7p/returned-test-output.log",
    "/private/tmp/therese-c17-composition-pure-main-gevGCF/receipt.json",
    "/private/tmp/therese-c17-composition-pure-main-gevGCF/returned-test-output.log",
    "/private/tmp/therese-c17-seatbelt-native-main-FDuCgC/compile-disabled.json",
    "/private/tmp/therese-c17-seatbelt-native-main-FDuCgC/compile-enabled.json",
    "/private/tmp/therese-c17-seatbelt-native-main-FDuCgC/controller-v3-main-pure.json",
    "/private/tmp/therese-c17-seatbelt-native-main-FDuCgC/chrome-qa-static-imports.json",
    "/private/tmp/therese-c17-seatbelt-native-main-FDuCgC/probe-native.c",
    "/private/tmp/therese-c17-seatbelt-archive-plan-WdNZFx/preimages/archive_selected-before-ownfiles.py",
    "/private/tmp/therese-c17-seatbelt-native-main-FDuCgC/ACTIVATION-INDEX.json",
    "/private/tmp/therese-c17-seatbelt-native-main-FDuCgC/ACTIVATION-README.md",
    "/private/tmp/therese-c17-seatbelt-native-main-FDuCgC/NATIVE-SOURCES.json",
    "/private/tmp/therese-c17-seatbelt-native-main-FDuCgC/PREPARATION-RECEIPT.json",
    "/private/tmp/therese-c17-seatbelt-native-main-FDuCgC/SERIES-CLOSURE.json",
    "/private/tmp/therese-c17-seatbelt-native-main-FDuCgC/cases/baseline/result.json",
    "/private/tmp/therese-c17-seatbelt-native-main-FDuCgC/cases/baseline/stderr.log",
    "/private/tmp/therese-c17-seatbelt-native-main-FDuCgC/cases/baseline/stdout.log",
    "/private/tmp/therese-c17-seatbelt-native-main-FDuCgC/cases/baseline/trace.jsonl",
    "/private/tmp/therese-c17-seatbelt-native-main-FDuCgC/cases/compiled-alpha/result.json",
    "/private/tmp/therese-c17-seatbelt-native-main-FDuCgC/cases/compiled-alpha/stderr.log",
    "/private/tmp/therese-c17-seatbelt-native-main-FDuCgC/cases/compiled-alpha/stdout.log",
    "/private/tmp/therese-c17-seatbelt-native-main-FDuCgC/cases/compiled-alpha/trace.jsonl",
    "/private/tmp/therese-c17-seatbelt-native-main-FDuCgC/controller.py",
    "/private/tmp/therese-c17-seatbelt-native-main-FDuCgC/diffs/controller.py.diff",
    "/private/tmp/therese-c17-seatbelt-native-main-FDuCgC/diffs/controller.py.inverse",
    "/private/tmp/therese-c17-seatbelt-native-main-FDuCgC/diffs/native_port.py.diff",
    "/private/tmp/therese-c17-seatbelt-native-main-FDuCgC/diffs/native_port.py.inverse",
    "/private/tmp/therese-c17-seatbelt-native-main-FDuCgC/environment-observation.json",
    "/private/tmp/therese-c17-seatbelt-native-main-FDuCgC/native_main.py",
    "/private/tmp/therese-c17-seatbelt-native-main-FDuCgC/native_port.py",
    "/private/tmp/therese-c17-seatbelt-native-main-FDuCgC/preimages/controller.py",
    "/private/tmp/therese-c17-seatbelt-native-main-FDuCgC/preimages/native_port.py",
    "/private/tmp/therese-c17-seatbelt-activation-independent-review-mmQxVrFl/INDEX.json",
    "/private/tmp/therese-c17-seatbelt-activation-independent-review-mmQxVrFl/REVIEW.json",
    "/private/tmp/therese-c17-seatbelt-baseline-independent-review-yI535RBJ/INDEX.json",
    "/private/tmp/therese-c17-seatbelt-baseline-independent-review-yI535RBJ/REVIEW.json",
    "/private/tmp/therese-c17-seatbelt-compiled-alpha-red-review-AQAYnAQ5/INDEX.json",
    "/private/tmp/therese-c17-seatbelt-compiled-alpha-red-review-AQAYnAQ5/REVIEW.json",
    "/private/tmp/therese-c17-seatbelt-archive-plan-WdNZFx/preimages/archive_selected-before-closure.py",
)
# MAIN supplies literal, closed physical refs after the native run. No default GO.
PENDING = ()
NATIVE_CLOSURE_REF = {
    "path": "/private/tmp/therese-c17-seatbelt-native-main-FDuCgC/SERIES-CLOSURE.json",
    "sha256": "dc3210449490a904a145b66dceb2122ab954a19b1891b92c7a294cd6f2ab525e",
    "bytes": 2749,
}
MAX_FILES = 256
MAX_FILE_BYTES = 2 * 1024 * 1024
MAX_TOTAL_BYTES = 16 * 1024 * 1024


def need(ok, reason):
    if not ok:
        raise ValueError(reason)


def original(path):
    path = Path(path)
    row = path.lstat()
    need(path.is_absolute() and path.resolve(strict=True) == path
         and stat.S_ISREG(row.st_mode) and row.st_nlink == 1
         and row.st_uid == os.getuid(), "not an own canonical exclusive file: " + str(path))
    need(row.st_size <= MAX_FILE_BYTES, "file exceeds archive bound")
    data = path.read_bytes()
    after = path.lstat()
    keys = ("st_dev", "st_ino", "st_mode", "st_nlink", "st_uid", "st_gid",
            "st_size", "st_mtime_ns", "st_ctime_ns")
    need(all(getattr(row, k) == getattr(after, k) for k in keys), "source changed during read")
    member = path.relative_to("/private/tmp").as_posix()
    need(member and not member.startswith("/") and ".." not in Path(member).parts,
         "unsafe member")
    return {"original": str(path), "member": member, "sha256": hashlib.sha256(data).hexdigest(),
            "bytes": len(data), "observed_original_stat": {k: getattr(row, k) for k in keys}}, data


def rows():
    # Only literal SELECTED paths. Never walk directories, JSONs, INDEX refs or symlinks.
    paths = tuple(SELECTED) + (str(HERE / "archive_selected.py"), str(HERE / "README.md"))
    need(len(paths) == len(set(paths)) and len(paths) <= MAX_FILES, "duplicate/too many files")
    records = [original(path)[0] for path in paths]
    need(len({r["member"] for r in records}) == len(records), "duplicate archive names")
    need(sum(r["bytes"] for r in records) <= MAX_TOTAL_BYTES, "archive exceeds total bound")
    if NATIVE_CLOSURE_REF is not None:
        closure_row, data = original(NATIVE_CLOSURE_REF["path"])
        need((closure_row["sha256"], closure_row["bytes"]) ==
             (NATIVE_CLOSURE_REF["sha256"], NATIVE_CLOSURE_REF["bytes"]), "closure pin changed")
        closure = json.loads(data)
        need(closure.get("schema") == "c17-seatbelt-synthetic-series-closure-v1"
             and closure.get("both_direct_handles_reaped") is True
             and closure.get("first_red_stopped_series") is True
             and closure.get("not_executed") == ["compiled-beta", "source-alpha", "source-beta"]
             and closure.get("FULL") is False, "closed two-case scope differs")
        for key, case, code in (("baseline", "baseline", 0), ("compiled_alpha", "compiled-alpha", 86)):
            row = closure[key]
            result = row["result"]
            path = "/private/tmp/therese-c17-seatbelt-native-main-FDuCgC/cases/" + case + "/result.json"
            need(result["path"] == path and row["runner_exit_code"] == code
                 and row["signals"] == [], "two-case closure differs")
            actual, _ = original(path)
            need((actual["sha256"], actual["bytes"]) == (result["sha256"], result["bytes"]),
                 "literal case result pin changed")
    return records


def add_file(tar, row):
    current, data = original(row["original"])
    need(current == row, "file differs from planned physical bytes/stat")
    meta = row["observed_original_stat"]
    info = tarfile.TarInfo(row["member"])
    info.type = tarfile.REGTYPE
    info.mode = stat.S_IMODE(meta["st_mode"])
    info.uid, info.gid = meta["st_uid"], meta["st_gid"]
    info.uname = info.gname = ""  # No passwd/group database query.
    info.size = row["bytes"]
    info.mtime = meta["st_mtime_ns"] / 1_000_000_000
    tar.addfile(info, io.BytesIO(data))


def create(out, records):
    need(not PENDING and NATIVE_CLOSURE_REF is not None,
         "archive remains a plan: final controller/reviews/native closure missing")
    closure, _ = original(NATIVE_CLOSURE_REF["path"])
    need((closure["sha256"], closure["bytes"]) ==
         (NATIVE_CLOSURE_REF["sha256"], NATIVE_CLOSURE_REF["bytes"]), "closure pin changed")
    out = Path(out)
    need(out.parent == Path("/private/tmp") and out.name.startswith("therese-c17-seatbelt-archive-")
         and out.resolve(strict=True) == out and out.is_dir()
         and out.stat().st_uid == os.getuid() and stat.S_IMODE(out.stat().st_mode) == 0o700
         and not any(out.iterdir()), "output must be own empty canonical private directory")
    manifest = {"schema": "c17-seatbelt-selected-archive-manifest-v1",
                "scope": "sources_and_evidence_archival_only", "files": records,
                "native_closure_ref": NATIVE_CLOSURE_REF, "FULL": False,
                "qualification_created_by_archive": False,
                "historical_non_consumable_controllers": ["SQOoCx", "eOcvBz"]}
    manifest_path = out / "MANIFEST.json"
    with manifest_path.open("x") as sink:
        json.dump(manifest, sink, indent=2, sort_keys=True)
        sink.write("\n")
    manifest_row, _ = original(manifest_path)
    manifest_row["member"] = "MANIFEST.json"
    # Real compression time and original observed file mtimes, no normalized fake time.
    archive = out / "seatbelt-synthetic-sources-and-evidence.tar.gz"
    with archive.open("xb") as sink:
        with gzip.GzipFile(fileobj=sink, mode="wb") as compressed:
            with tarfile.open(fileobj=compressed, mode="w", format=tarfile.PAX_FORMAT) as tar:
                for row in records:
                    add_file(tar, row)
                # add_file uses normal physical member; manifest name is set separately.
                m, data = original(manifest_path)
                info = tarfile.TarInfo("MANIFEST.json")
                meta = m["observed_original_stat"]
                info.size, info.mode = m["bytes"], stat.S_IMODE(meta["st_mode"])
                info.uid, info.gid = meta["st_uid"], meta["st_gid"]
                info.mtime = meta["st_mtime_ns"] / 1_000_000_000
                tar.addfile(info, io.BytesIO(data))
    expected = {r["member"]: r for r in records}
    expected["MANIFEST.json"] = manifest_row
    checked = set()
    with tarfile.open(archive, mode="r:gz") as tar:
        for member in tar:
            need(member.isfile() and member.name in expected and member.name not in checked,
                 "unknown, duplicate or non-regular archive member")
            row = expected[member.name]
            need(member.size == row["bytes"], "member size differs")
            raw = tar.extractfile(member)
            need(raw is not None, "member stream unavailable")
            digest = hashlib.sha256()
            while chunk := raw.read(65536):
                digest.update(chunk)
            need(digest.hexdigest() == row["sha256"], "member hash differs")
            checked.add(member.name)
    need(checked == set(expected), "archive member set differs")
    need(rows() == records, "original changed during archive/re-read")
    archived, _ = original(archive)
    receipt = {"schema": "c17-seatbelt-selected-archive-receipt-v1", "archive": archived,
               "manifest": original(manifest_path)[0], "members_verified_without_extraction": len(checked),
               "sources_unchanged": True, "FULL": False, "native_authority_created": False}
    with (out / "archive-receipt.json").open("x") as sink:
        json.dump(receipt, sink, indent=2, sort_keys=True)
        sink.write("\n")
    return receipt


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--plan", action="store_true")
    parser.add_argument("--create", metavar="PRIVATE_EMPTY_OUTPUT")
    args = parser.parse_args(argv)
    need(bool(args.plan) ^ bool(args.create), "choose plan OR create")
    # Refuse before hashing/compression/writes if native selection remains incomplete.
    if args.create:
        need(not PENDING and NATIVE_CLOSURE_REF is not None, "closed native evidence missing; no compression")
    records = rows()
    result = create(args.create, records) if args.create else {
        "schema": "c17-seatbelt-selected-archive-plan-v1", "files": records,
        "files_selected": len(records), "total_bytes": sum(r["bytes"] for r in records),
        "pending": list(PENDING), "archive_emitted": False, "native_closure_ref": NATIVE_CLOSURE_REF,
        "references_followed": False, "FULL": False}
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (ValueError, FileNotFoundError) as error:
        print(json.dumps({"status": "refused", "reason": str(error), "archive_emitted": False}))
        raise SystemExit(2)
