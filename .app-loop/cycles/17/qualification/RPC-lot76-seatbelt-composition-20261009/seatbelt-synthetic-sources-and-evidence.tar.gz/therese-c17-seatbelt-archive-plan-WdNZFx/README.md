# Archive documentaire Seatbelt, plan borné

Un script, une future TAR.GZ. Liste littérale des seuls fichiers propres des
quatre préparations C, gatecontract, contrôleurs v1/v2 historiques, revue
indépendante, trois suites pures et premier rouge de compilation MAIN.
Ajout littéral : contrôleur v3 neuf et sa revue, MAIN67/27, les cinq fichiers
MAIN de compilation/purs/imports/C activé indiqués dans FDuCgC. Les binaires
probe et probe-disabled ne sont jamais sélectionnés. La préimage exacte
du script-plan initial est conservée et sélectionnée.
Les notes/retours du premier shim sont dans le gel statique ; son cache
xcrun_db n'est pas sélectionné. Aucun INDEX JSON n'est traversé pour
ajouter des références, et aucun SDK/G1/binaire/rapport système/personnel
n'est copié. Les références historiques dans les textes restent des pointeurs.

--plan fait uniquement stat/hash des chemins exacts, sans compression.
Sélection finale close sur SERIES-CLOSURE.json dc321044…/2749B, annoncé
par MAIN. Toutes les sources propres de FDuCgC, ses huit bruts/result/trace,
ses revues activation/baseline/rouge sont ajoutés littéralement. Aucune
référence externe n'est suivie. Deux cas seulement : baseline0, puis
compiled-alpha86/inner_api_refused ; trois cas NON exécutés, sans signaux,
deux handles reaped. Le rouge clean=false reste rouge. Le script recroise
uniquement ces deux result.json littéraux avec le reçu fermé, sans graphe.
La préimage du script avant clôture est conservée et sélectionnée.

PENDING est désormais vide et le pin de clôture physique est obligatoire.
--create est réservé à l'action MAIN après lecture de ce delta. L'auteur
n'a appelé que --plan et les gardes purs, jamais la compression. Ce mode
ne lance aucune sonde et ne crée aucune autorité native ou qualification.
Ce plan n'est pas une autorité ni une qualification ; v1/v2 sont conservés
comme historiques NON consommables.

Bornes documentaires :256 fichiers,2MiB/fichier,16MiB au total. Chaque
source est canonique, régulière, possédée par l'UID courant, nlink1,
stat avant/après et SHA/bytes exacts. Aucun glob ni marche récursive.
Compression future MAIN dans un répertoire /private/tmp privé700 vide,
création exclusive, TAR/PAX avec modes/UID/GID/mtimes réellement observés,
pas de date inventée ni lecture passwd/group. MANIFEST généré à ce moment.
Relecture de tous les membres par flux tar.extractfile, sans extraction
sur disque, set exact, hashes/tailles et recheck des sources ; une seule
archive, reçu SHA/taille, pas de suppression d'anciens fichiers.

Commande actuelle uniquement :

    PYTHON_UV_PHYSIQUE -I -B archive_selected.py --plan

Commande d'archivage future MAIN, après revue, dans un dossier privé700 vide :

    PYTHON_UV_PHYSIQUE -I -B archive_selected.py --create /private/tmp/therese-c17-seatbelt-archive-SORTIE_MAIN

Le code --create est un mécanisme d'archivage, pas un lanceur de sonde.
Il n'importe ni libproc/G1/produit et ne compile, signale ou connecte rien.
Aucune compression effective n'a été effectuée par l'auteur.
