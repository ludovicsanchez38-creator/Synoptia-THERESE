"""Run real Python static tests with native/process/network entry points denied."""
import hashlib
import io
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import time
import unittest
from unittest import mock

import prepare_static
import test_static

HERE = Path(__file__).resolve().parent


def refs():
    names = ["probe.c", "prepare_static.py", "test_static.py", "run_static_tests.py", "gate_fragment.c.inc", "fd_fragment.c.inc",
             "policies/outer.sb", "policies/alpha.sb", "policies/beta.sb",
             "witnesses/a.txt", "witnesses/b.txt"]
    return [prepare_static.reference(HERE / name) for name in names]


def main():
    if len(sys.argv) != 2:
        return 2
    out = Path(sys.argv[1])
    if (out.parent != Path("/private/tmp") or not out.name.startswith("therese-c17-composition-pure-")
            or out.resolve(strict=True) != out or not out.is_dir() or any(out.iterdir())):
        return 2
    before = refs()
    attempts = []
    def denied(*args, **kwargs):
        attempts.append("forbidden native/process/network entry point")
        raise AssertionError(attempts[-1])
    guards = [mock.patch.object(subprocess, "Popen", denied), mock.patch.object(subprocess, "run", denied),
              mock.patch.object(subprocess, "call", denied), mock.patch.object(subprocess, "check_output", denied),
              mock.patch.object(os, "system", denied), mock.patch.object(os, "execve", denied),
              mock.patch.object(os, "kill", denied), mock.patch.object(socket, "socket", denied),
              mock.patch.object(socket, "create_connection", denied)]
    for name in ("fork", "posix_spawn", "posix_spawnp"):
        if hasattr(os, name):
            guards.append(mock.patch.object(os, name, denied))
    import ctypes
    guards.append(mock.patch.object(ctypes, "CDLL", denied))
    stream = io.StringIO()
    started = time.monotonic()
    for guard in guards: guard.start()
    try:
        result = unittest.TextTestRunner(stream=stream, verbosity=2).run(
            unittest.defaultTestLoader.loadTestsFromModule(test_static))
    finally:
        for guard in reversed(guards): guard.stop()
    elapsed = time.monotonic() - started
    after = refs()
    output = stream.getvalue().encode()
    with (out / "returned-test-output.log").open("xb") as sink: sink.write(output)
    receipt = {"schema": "c17-seatbelt-static-python-test-receipt-v1",
               "actor": "/root/shared4_execution", "scope": "static_python_tests_only",
               "tests_run": result.testsRun, "failures": len(result.failures), "errors": len(result.errors),
               "skips": len(result.skipped), "elapsed_seconds": elapsed,
               "forbidden_attempts": attempts, "source_before": before, "source_after": after,
               "output_ref": prepare_static.reference(out / "returned-test-output.log"),
               "source_unchanged": before == after,
               "passed": result.wasSuccessful() and not attempts and before == after,
               "C_compiled": False, "Apple_profile_compiled": False, "kernel_measured": False,
               "Chrome_started": False, "G1_imported": False, "FULL": False}
    with (out / "receipt.json").open("x") as sink:
        json.dump(receipt, sink, indent=2, sort_keys=True); sink.write("\n")
    print(json.dumps({key: receipt[key] for key in ("tests_run", "failures", "errors", "passed", "forbidden_attempts")}))
    return 0 if receipt["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
