/* Preparation only. Private API declarations mirror Chromium seatbelt.cc.
 * No fork/exec/network. This source is NOT matched to Google Chrome 154.
 * MAIN must review a separate exact derivation before changing this constant.
 */
#define _DARWIN_C_SOURCE 1 /* SDK declarations, not a policy or API activation. */
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <inttypes.h>
#include <libproc.h>
#include <poll.h>
#include <sys/proc.h>
#include <sys/proc_info.h>
#include <time.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

static const bool NATIVE_MEASUREMENT_ENABLED = false;
static const char QA_ROOT[] = "/private/tmp/therese-c17-seatbelt-composition-fds-0dUJdL";

/* Private APIs: declarations alone provide no support/composition guarantee. */
typedef struct sandbox_params_t sandbox_params_t;
typedef struct { char *builtin; const uint8_t *data; size_t size; } sandbox_profile_t;
extern sandbox_params_t *sandbox_create_params(void);
extern int sandbox_set_param(sandbox_params_t *, const char *, const char *);
extern void sandbox_free_params(sandbox_params_t *);
extern sandbox_profile_t *sandbox_compile_string(const char *, sandbox_params_t *, char **);
extern int sandbox_apply(sandbox_profile_t *);
extern void sandbox_free_profile(sandbox_profile_t *);
extern void sandbox_free_error(char *);
extern int sandbox_init_with_parameters(const char *, uint64_t, const char *const *, char **);
extern int sandbox_check(pid_t, const char *, int, ...);

static const char OUTER[] =
    "(version 1)\n"
    "(deny default)\n"
    "(allow file-read-metadata (literal (param \"WITNESS_A\")) (literal (param \"WITNESS_B\")))\n"
    "(allow file-read-data (literal (param \"WITNESS_A\")))\n";
static const char ALPHA[] =
    "(version 1)\n"
    "(deny default)\n"
    "(allow file-read-metadata (literal (param \"WITNESS_A\")) (literal (param \"WITNESS_B\")))\n"
    "(allow file-read-data (literal (param \"WITNESS_B\")))\n";
static const char BETA[] =
    "(version 1)\n"
    "(deny default)\n"
    "(allow file-read-metadata (literal (param \"WITNESS_A\")) (literal (param \"WITNESS_B\")))\n"
    "(allow file-read-data (literal (param \"WITNESS_A\")) (literal (param \"WITNESS_B\")))\n";

static void json_string(const char *value) {
    putchar('"');
    for (size_t i = 0; value && value[i] && i < 1024; ++i) {
        unsigned char c = (unsigned char)value[i];
        if (c == '"' || c == '\\') { putchar('\\'); putchar(c); }
        else if (c < 0x20) printf("\\u%04x", c);
        else putchar(c);
    }
    putchar('"');
}

/* BEGIN FD_CLEANUP: own PID only, typed SDK rows, fixed capacity. */
#define OWN_FD_CAPACITY 256
static int read_own_fds(struct proc_fdinfo rows[OWN_FD_CAPACITY]) {
    memset(rows, 0, OWN_FD_CAPACITY * sizeof(*rows));
    int bytes = proc_pidinfo(getpid(), PROC_PIDLISTFDS, 0, rows,
                            (int)(OWN_FD_CAPACITY * sizeof(*rows)));
    if (bytes <= 0 || bytes >= (int)(OWN_FD_CAPACITY * sizeof(*rows)) ||
        bytes % (int)sizeof(*rows) != 0) return -1;
    int count = bytes / (int)sizeof(*rows);
    for (int i = 0; i < count; ++i) {
        if (rows[i].proc_fd < 0) return -1;
        for (int j = 0; j < i; ++j)
            if (rows[j].proc_fd == rows[i].proc_fd) return -1;
    }
    return count;
}

static int close_inherited_fds(void) {
    struct proc_fdinfo rows[OWN_FD_CAPACITY];
    int count = read_own_fds(rows);
    if (count < 0) return -1;
    for (int i = 0; i < count; ++i) {
        if (rows[i].proc_fd >= 3 && close(rows[i].proc_fd)) return -1;
        /* No retry on EINTR/other error; never close a parent FD. */
    }
    count = read_own_fds(rows);
    if (count != 3) return -1;
    unsigned present = 0;
    for (int i = 0; i < count; ++i) {
        if (rows[i].proc_fd > 2) return -1;
        present |= 1u << (unsigned)rows[i].proc_fd;
    }
    return present == 7u ? 0 : -1; /* Exactly stdin, stdout and stderr. */
}
/* END FD_CLEANUP */

/* BEGIN FD0_GATE: typed SDK libproc, no fabricated identity. */
#define GATE_LIMIT_NS INT64_C(5000000000)
#define GATE_FRAME_BYTES 512
struct gate_birth {
    uint32_t pid, ppid, uid, pgid;
    uint64_t start_sec, start_usec;
};

static int read_gate_birth(pid_t pid, struct gate_birth *out) {
    struct proc_bsdinfo info;
    memset(&info, 0, sizeof(info));
    int count = proc_pidinfo(pid, PROC_PIDTBSDINFO, 0, &info, (int)sizeof(info));
    if (count != (int)sizeof(info) || info.pbi_pid != (uint32_t)pid ||
        (info.pbi_status != SRUN && info.pbi_status != SSLEEP) ||
        (info.pbi_flags & PROC_FLAG_INEXIT) || info.pbi_pid <= 1 ||
        info.pbi_ppid == 0 || info.pbi_pgid == 0 ||
        info.pbi_start_tvsec == 0 || info.pbi_start_tvusec >= 1000000) return -1;
    *out = (struct gate_birth){info.pbi_pid, info.pbi_ppid, info.pbi_uid,
        info.pbi_pgid, info.pbi_start_tvsec, info.pbi_start_tvusec};
    return 0;
}

static bool same_gate_birth(const struct gate_birth *a, const struct gate_birth *b) {
    return a->pid == b->pid && a->ppid == b->ppid && a->uid == b->uid &&
        a->pgid == b->pgid && a->start_sec == b->start_sec && a->start_usec == b->start_usec;
}

static bool gate_nonce_valid(const char *nonce) {
    if (!nonce || strlen(nonce) != 32) return false;
    for (size_t i = 0; i < 32; ++i)
        if (!((nonce[i] >= '0' && nonce[i] <= '9') ||
              (nonce[i] >= 'a' && nonce[i] <= 'f'))) return false;
    return true;
}

static int64_t gate_now_ns(void) {
    struct timespec now;
    if (clock_gettime(CLOCK_MONOTONIC, &now) || now.tv_sec < 0 ||
        now.tv_sec > (INT64_MAX - GATE_LIMIT_NS) / INT64_C(1000000000)) return -1;
    return (int64_t)now.tv_sec * INT64_C(1000000000) + now.tv_nsec;
}

static int fd0_gate(const char *case_name, const char *nonce) {
    int64_t start = gate_now_ns();
    if (start < 0 || !gate_nonce_valid(nonce)) return -1;
    const int64_t deadline = start + GATE_LIMIT_NS;
    struct stat channel;
    int flags = fcntl(STDIN_FILENO, F_GETFL);
    if (fstat(STDIN_FILENO, &channel) || !S_ISFIFO(channel.st_mode) || flags < 0 ||
        fcntl(STDIN_FILENO, F_SETFL, flags | O_NONBLOCK)) return -1;

    struct gate_birth child, owner, child_now, owner_now;
    if (read_gate_birth(getpid(), &child) || read_gate_birth(getppid(), &owner) ||
        child.pid != (uint32_t)getpid() || child.ppid != (uint32_t)getppid() ||
        child.ppid != owner.pid || child.uid != (uint32_t)getuid() ||
        child.uid != (uint32_t)geteuid() || child.uid != owner.uid ||
        child.pgid != child.pid || child.pgid != (uint32_t)getpgrp()) return -1;

    printf("{\"schema\":\"c17-seatbelt-composition-ready-v1\",\"case\":\"%s\","
           "\"nonce\":\"%s\",\"pid\":%u,\"ppid\":%u,\"uid\":%u,\"pgid\":%u,"
           "\"start_sec\":%" PRIu64 ",\"start_usec\":%" PRIu64 "}\n",
           case_name, nonce, child.pid, child.ppid, child.uid, child.pgid,
           child.start_sec, child.start_usec);
    if (fflush(stdout) || ferror(stdout)) return -1;

    char expected[GATE_FRAME_BYTES], received[GATE_FRAME_BYTES];
    int wanted = snprintf(expected, sizeof(expected),
        "{\"schema\":\"c17-seatbelt-composition-release-v1\",\"case\":\"%s\","
        "\"nonce\":\"%s\",\"pid\":%u,\"start_sec\":%" PRIu64 ",\"start_usec\":%" PRIu64 "}\n",
        case_name, nonce, child.pid, child.start_sec, child.start_usec);
    if (wanted <= 0 || wanted >= GATE_FRAME_BYTES) return -1;
    size_t used = 0;
    for (;;) {
        int64_t now = gate_now_ns();
        if (now < 0 || now >= deadline) return -1;
        int milliseconds = (int)((deadline - now + INT64_C(999999)) / INT64_C(1000000));
        struct pollfd pipe = {STDIN_FILENO, POLLIN, 0};
        int polled = poll(&pipe, 1, milliseconds);
        if (polled < 0 && errno == EINTR) continue;
        now = gate_now_ns();
        if (polled <= 0 || now < 0 || now >= deadline ||
            (pipe.revents & (POLLERR | POLLNVAL))) return -1;
        ssize_t count = read(STDIN_FILENO, received + used, sizeof(received) - used);
        if (count < 0 && (errno == EINTR || errno == EAGAIN)) continue;
        if (count <= 0) return -1; /* EOF never supplies a release. */
        used += (size_t)count;
        if (used >= sizeof(received)) return -1;
        if (memchr(received, '\n', used)) {
            if (used != (size_t)wanted || memcmp(received, expected, used)) return -1;
            /* One closed frame; any already queued additional byte is refused. */
            char extra;
            ssize_t more = read(STDIN_FILENO, &extra, 1);
            if (more != -1 || errno != EAGAIN) return -1;
            break;
        }
    }
    if (close(STDIN_FILENO)) return -1;
    if (read_gate_birth(getpid(), &child_now) || read_gate_birth((pid_t)owner.pid, &owner_now) ||
        !same_gate_birth(&child, &child_now) || !same_gate_birth(&owner, &owner_now) ||
        getppid() != (pid_t)owner.pid) return -1;
    int64_t done = gate_now_ns();
    if (done < 0 || done >= deadline) return -1;
    printf("{\"schema\":\"c17-seatbelt-composition-gate-released-v1\",\"case\":\"%s\","
           "\"nonce\":\"%s\",\"pid\":%u,\"start_sec\":%" PRIu64 ",\"start_usec\":%" PRIu64 "}\n",
           case_name, nonce, child.pid, child.start_sec, child.start_usec);
    if (fflush(stdout) || ferror(stdout)) return -1;
    done = gate_now_ns();
    return done < 0 || done >= deadline ? -1 : 0;
}
/* END FD0_GATE */

static int witness_preflight(const char *path, char expected) {
    struct stat before, after;
    char canonical[PATH_MAX];
    if (!realpath(path, canonical) || strcmp(path, canonical) ||
        lstat(path, &before) || !S_ISREG(before.st_mode) || before.st_nlink != 1 ||
        before.st_uid != getuid()) return -1;
    int fd = open(path, O_RDONLY | O_NOFOLLOW);
    if (fd < 0) return -1;
    char c = 0;
    int result = fstat(fd, &after) || after.st_dev != before.st_dev ||
        after.st_ino != before.st_ino || after.st_size != before.st_size ||
        after.st_nlink != 1 || read(fd, &c, 1) != 1 || c != expected;
    if (close(fd)) result = 1;
    return result ? -1 : 0;
}

enum read_state { READ_OK, READ_DENIED, READ_UNEXPECTED };
static enum read_state probe_read(const char *phase, const char *label, const char *path, char expected) {
    errno = 0;
    int fd = open(path, O_RDONLY | O_NOFOLLOW);
    int open_errno = fd < 0 ? errno : 0;
    char c = 0;
    ssize_t n = -1;
    int read_errno = 0, close_errno = 0;
    if (fd >= 0) {
        errno = 0;
        n = read(fd, &c, 1);
        if (n < 0) read_errno = errno;
        errno = 0;
        if (close(fd)) close_errno = errno;
    }
    printf("{\"event\":\"witness_read\",\"phase\":"); json_string(phase);
    printf(",\"witness\":"); json_string(label);
    printf(",\"open_ok\":%s,\"open_errno\":%d,\"read_count\":%ld,"
           "\"read_errno\":%d,\"close_errno\":%d,\"content_matches\":%s,"
           "\"diagnostic_only\":true,\"native_qualification\":false}\n",
           fd >= 0 ? "true" : "false", open_errno, (long)n, read_errno,
           close_errno, n == 1 && c == expected ? "true" : "false");
    if (fflush(stdout) || ferror(stdout)) return READ_UNEXPECTED;
    if (fd >= 0 && n == 1 && c == expected && !close_errno) return READ_OK;
    if (fd < 0 && (open_errno == EPERM || open_errno == EACCES)) return READ_DENIED;
    return READ_UNEXPECTED; /* Missing/changed witness never stands in for denial. */
}

int main(int argc, char **argv) {
    /* Default compiled candidate remains incapable of measuring the kernel. */
    if (!NATIVE_MEASUREMENT_ENABLED) {
        fputs("prepared_only: compilation/native execution not admitted\n", stderr);
        return 2;
    }
    if (argc != 5 || strcmp(argv[1], "--reviewed-case") ||
        strcmp(argv[3], "--gate-nonce") || !gate_nonce_valid(argv[4]) ||
        (strcmp(argv[2], "baseline") && strcmp(argv[2], "compiled-alpha") &&
         strcmp(argv[2], "compiled-beta") && strcmp(argv[2], "source-alpha") &&
         strcmp(argv[2], "source-beta"))) return 2;

    if (close_inherited_fds()) return 86; /* Keep only FD0/1/2, or refuse. */
    if (fd0_gate(argv[2], argv[4])) {
        fputs("gate refused: no witness/compile/sandbox experiment\n", stderr);
        return 86;
    }

    char canonical[PATH_MAX], a[PATH_MAX], b[PATH_MAX];
    struct stat root_stat;
    if (!realpath(QA_ROOT, canonical) || strcmp(canonical, QA_ROOT) ||
        lstat(QA_ROOT, &root_stat) || !S_ISDIR(root_stat.st_mode) ||
        root_stat.st_uid != getuid() || (root_stat.st_mode & 077) != 0) return 2;
    if (snprintf(a, sizeof(a), "%s/witnesses/a.txt", QA_ROOT) >= (int)sizeof(a) ||
        snprintf(b, sizeof(b), "%s/witnesses/b.txt", QA_ROOT) >= (int)sizeof(b)) return 2;
    if (witness_preflight(a, 'A') || witness_preflight(b, 'B')) return 2;
    /* Refuse an ambient/inherited sandbox rather than replacing it blindly. */
    int ambient = sandbox_check(getpid(), NULL, 0);
    if (ambient != 0) {
        fprintf(stderr, "ambient sandbox/unknown sandbox_check=%d; refused\n", ambient);
        return 2;
    }

    const bool baseline = !strcmp(argv[2], "baseline");
    const bool compiled = !strncmp(argv[2], "compiled-", 9);
    const char *inner = strstr(argv[2], "alpha") ? ALPHA : BETA;
    const char *params[] = {"WITNESS_A", a, "WITNESS_B", b, NULL};
    sandbox_profile_t *compiled_inner = NULL;
    char *error = NULL;
    if (compiled) {
        /* Precompile in memory before outer; no extra library/profile read grants. */
        sandbox_params_t *p = sandbox_create_params();
        if (!p || sandbox_set_param(p, "WITNESS_A", a) || sandbox_set_param(p, "WITNESS_B", b)) return 2;
        compiled_inner = sandbox_compile_string(inner, p, &error);
        sandbox_free_params(p);
        if (!compiled_inner) {
            fputs("private API preparation failed; no measurement\n", stderr);
            if (error) sandbox_free_error(error);
            return 2;
        }
        if (error) { sandbox_free_error(error); error = NULL; }
    }
    if (fflush(NULL) || ferror(stdout) || ferror(stderr)) return 86;
    errno = 0;
    int outer_rc = sandbox_init_with_parameters(OUTER, 0, params, &error);
    int outer_errno = errno;
    printf("{\"event\":\"outer_apply\",\"pid\":%d,\"ppid\":%d,\"uid\":%d,"
           "\"rc\":%d,\"errno\":%d,\"diagnostic_only\":true,\"error\":",
           getpid(), getppid(), getuid(), outer_rc, outer_errno);
    json_string(error); puts("}");
    if (fflush(stdout) || ferror(stdout)) return 86;
    if (error) { sandbox_free_error(error); error = NULL; }
    if (outer_rc != 0) return 86;
    enum read_state before_a = probe_read("outer", "A", a, 'A');
    enum read_state before_b = probe_read("outer", "B", b, 'B');
    if (before_a != READ_OK || before_b != READ_DENIED) {
        fputs("outer witness guard failed; no inner application\n", stderr);
        return 86;
    }
    if (baseline) return 0;

    errno = 0;
    int inner_rc = compiled ? sandbox_apply(compiled_inner) :
        sandbox_init_with_parameters(inner, 0, params, &error);
    int inner_errno = errno;
    printf("{\"event\":\"inner_apply\",\"case\":"); json_string(argv[2]);
    printf(",\"api\":"); json_string(compiled ? "sandbox_apply" : "sandbox_init_with_parameters");
    printf(",\"rc\":%d,\"errno\":%d,\"diagnostic_only\":true,\"error\":", inner_rc, inner_errno);
    json_string(error); puts("}");
    if (fflush(stdout) || ferror(stdout)) return 86;
    if (error) sandbox_free_error(error);
    enum read_state after_a = probe_read("after_inner", "A", a, 'A');
    enum read_state after_b = probe_read("after_inner", "B", b, 'B');
    const bool alpha = strstr(argv[2], "alpha") != NULL;
    const bool intersection = after_b == READ_DENIED &&
        after_a == (alpha ? READ_DENIED : READ_OK);
    const char *observation = after_a == READ_UNEXPECTED || after_b == READ_UNEXPECTED ?
        "witness_instrument_error" : inner_rc != 0 ? "inner_api_refused" :
        after_b == READ_OK ? "outer_denial_not_preserved" :
        (alpha && after_a == READ_OK) ? "inner_restriction_not_observed" :
        "witness_intersection_observed_not_general_proof";
    printf("{\"event\":\"case_finished\",\"observation\":"); json_string(observation);
    puts(",\"inherited_child_measured\":false,\"network_measured\":false,"
         "\"native_qualification\":false,\"FULL\":false}");
    if (fflush(stdout) || ferror(stdout)) return 86;
    if (compiled_inner) sandbox_free_profile(compiled_inner);
    return inner_rc != 0 || !intersection ? 86 : 0;
}
