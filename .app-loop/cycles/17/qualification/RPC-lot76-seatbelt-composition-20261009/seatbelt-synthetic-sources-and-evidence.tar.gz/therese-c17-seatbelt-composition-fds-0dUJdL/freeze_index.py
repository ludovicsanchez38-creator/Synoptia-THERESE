"""Freeze filesystem/text preparation only. No compiler/native authority."""
import json
import re
import hashlib
import stat
from pathlib import Path
import prepare_static as p

OLD = Path("/private/tmp/therese-c17-seatbelt-composition-gated-J4B04K")
PURE = Path("/private/tmp/therese-c17-composition-pure-yZeo1X")
SDK = Path("/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include")
SOURCE_NAMES = ("probe.c", "prepare_static.py", "test_static.py", "run_static_tests.py",
                "policies/outer.sb", "policies/alpha.sb", "policies/beta.sb",
                "witnesses/a.txt", "witnesses/b.txt", "gate_fragment.c.inc")
CHANGED = SOURCE_NAMES[:4]


def sdk_status_observation():
    """One exact root-owned header has existing hardlinks; QA guard unchanged."""
    path = SDK / "sys/proc.h"
    before = path.lstat()
    data = path.read_bytes()
    after = path.lstat()
    p.need(path.resolve(strict=True) == path and stat.S_ISREG(before.st_mode)
           and (before.st_uid, before.st_gid, before.st_mode, before.st_nlink, len(data))
           == (0, 0, 0o100644, 9, 11852), "exact SDK physical metadata changed")
    fields = ("st_dev", "st_ino", "st_mode", "st_nlink", "st_uid", "st_gid",
              "st_size", "st_mtime_ns", "st_ctime_ns")
    p.need(all(getattr(before, k) == getattr(after, k) for k in fields),
           "SDK header changed during read")
    sha = hashlib.sha256(data).hexdigest()
    p.need(sha == "593af71b2740ba6248995691280bcb15f8900d46b1d9868f7345084aa0692949",
           "exact SDK header changed")
    return {"reference": {"path": str(path), "sha256": sha, "bytes": len(data)},
            "physical_stat": {k: getattr(before, k) for k in fields},
            "role": "status_declarations_only_not_QA_asset_or_native_identity",
            "existing_root_owned_hardlinks": 9}


def check_diff(old, new, diff):
    """Apply every exact unified hunk; BSD/difflib may partition differently."""
    rows, source, result = diff.splitlines(True), old.splitlines(True), []
    p.need(len(rows) >= 3 and rows[0].startswith("--- ") and rows[1].startswith("+++ "),
           "diff headers")
    cursor, i = 0, 2
    while i < len(rows):
        match = re.fullmatch(r"@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@\n", rows[i])
        p.need(match is not None, "diff hunk syntax")
        start, before, target_start, after = map(int, (
            match[1], match[2] or "1", match[3], match[4] or "1"))
        start = start - 1 if before else start
        target_start = target_start - 1 if after else target_start
        p.need(cursor <= start <= len(source), "diff hunk ordering")
        result.extend(source[cursor:start])
        cursor = start
        p.need(len(result) == target_start, "diff target offset")
        i += 1
        seen_before = seen_after = 0
        while i < len(rows) and not rows[i].startswith("@@ "):
            line = rows[i]
            p.need(line[:1] in (" ", "-", "+"), "diff row syntax")
            if line[0] in " -":
                p.need(cursor < len(source) and source[cursor] == line[1:],
                       "diff context/deletion not exact")
                cursor += 1
                seen_before += 1
            if line[0] in " +":
                result.append(line[1:])
                seen_after += 1
            i += 1
        p.need((seen_before, seen_after) == (before, after), "diff row counts")
    result.extend(source[cursor:])
    p.need("".join(result) == new, "diff reconstruction not byte-exact")


def main():
    p.static_check()
    old_index_ref = p.reference(OLD / "INDEX.json")
    p.need(old_index_ref["sha256"] == "dfb24d421838cb818099129ccbf22670d0233f17e8b89cacafee3f8bbe40af6d",
           "old frozen INDEX changed")
    old_index = json.loads((OLD / "INDEX.json").read_bytes())
    old_refs = {Path(r["path"]).relative_to(OLD).as_posix(): r for r in old_index["files"]}
    preimages, derivations = [], []
    for name in SOURCE_NAMES:
        origin = p.reference(OLD / name)
        before = p.reference(p.HERE / "preimages" / name)
        after = p.reference(p.HERE / name)
        p.need(origin == old_refs[name], "old source changed")
        p.need((before["sha256"], before["bytes"]) == (origin["sha256"], origin["bytes"]),
               "preimage copy differs")
        preimages.append(before)
        if name in CHANGED:
            direct = p.reference(p.HERE / "diffs" / (name + ".direct.diff"))
            inverse = p.reference(p.HERE / "diffs" / (name + ".inverse.diff"))
            b = (p.HERE / "preimages" / name).read_text()
            a = (p.HERE / name).read_text()
            check_diff(b, a, Path(direct["path"]).read_text())
            check_diff(a, b, Path(inverse["path"]).read_text())
            derivations.append({"before": before, "after": after,
                                "direct": direct, "inverse": inverse})
        else:
            p.need((after["sha256"], after["bytes"]) == (before["sha256"], before["bytes"]),
                   "policy/witness not byte-exact")
    failed = json.loads(Path("/private/tmp/therese-c17-seatbelt-compile-disabled-a29bPs/compile-failure.json").read_bytes())
    p.need(failed["exit_code"] == 1 and failed["probe_executed"] is False
           and failed["source_sha256_before_and_after"] == "a3d7d57544f5216923c044c90cab17d1ba072527e9395781f27e0ab6c0358dc4",
           "MAIN compile-red origin changed")
    receipt = json.loads((PURE / "receipt.json").read_bytes())
    p.need(receipt["passed"] is True and receipt["tests_run"] == 67
           and receipt["failures"] == receipt["errors"] == receipt["skips"] == 0
           and receipt["forbidden_attempts"] == []
           and receipt["source_before"] == receipt["source_after"],
           "actual pure test receipt not exact")
    for ref in receipt["source_before"]:
        p.need(p.reference(Path(ref["path"])) == ref, "tested source changed")
    local = [p.reference(p.HERE / name) for name in
             (*SOURCE_NAMES, "fd_fragment.c.inc", "README.md", "freeze_index.py")]
    evidence = [p.reference(PURE / "receipt.json"), p.reference(PURE / "returned-test-output.log")]
    origins = [old_index_ref,
               p.reference(Path("/private/tmp/therese-c17-seatbelt-compile-disabled-a29bPs/compile-failure.json")),
               p.reference(Path("/private/tmp/therese-c17-seatbelt-gate-static-g307jq/INDEX.json")),
               p.reference(SDK / "libproc.h"), p.reference(SDK / "sys/proc_info.h"),
               p.reference(SDK / "sandbox.h")]
    sdk_status = sdk_status_observation()
    refs = local + preimages + evidence + origins
    refs += [d[k] for d in derivations for k in ("direct", "inverse")]
    for ref in refs:
        p.need(p.reference(Path(ref["path"])) == ref, "freeze ref changed")
    data = {"schema": "c17-seatbelt-composition-fd-static-index-v1",
            "actor": "/root/shared4_execution", "status": "prepared_only_not_admitted",
            "files": local, "preimages": preimages, "derivations": derivations,
            "evidence": evidence, "origin_refs": origins, "plan": p.future_plan(),
            "sdk_status_header_observation": sdk_status,
            "pure_tool_chunk": "a69c8f", "pure_tests": 67,
            "C_compiled": False, "own_C_compilation_attempted": False,
            "origin_MAIN_disabled_C_compilation_attempted": True, "Apple_profile_compiled": False, "libproc_called": False,
            "kernel_measured": False, "Chrome_started": False, "G1_imported": False,
            "native_admission": None, "RUNTIME": False, "FULL": False, "release": False,
            "profile_write_grants_added": [], "old_gel_unchanged": True,
            "proof_scope": "textual sources/mutants only; no C semantic/native proof"}
    p.need(sdk_status_observation() == sdk_status, "SDK final recheck")
    target = p.HERE / "INDEX.json"
    with target.open("x") as sink:
        json.dump(data, sink, indent=2, sort_keys=True)
        sink.write("\n")
    print(json.dumps({"index": p.reference(target), "verified_refs": len(refs)}, sort_keys=True))


if __name__ == "__main__":
    raise SystemExit(main())
