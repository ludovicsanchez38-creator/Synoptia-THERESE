import contextlib
import io
import unittest
from pathlib import Path

import prepare_static as p


class StaticPreparationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.source = (p.HERE / "probe.c").read_text()

    def mutate(self, old, new):
        self.assertEqual(self.source.count(old), 1)
        with self.assertRaises((ValueError, IndexError)):
            p.validate_c(self.source.replace(old, new, 1))

    def invoke(self, argv):
        with contextlib.redirect_stdout(io.StringIO()) as output:
            code = p.main(argv)
        return code, output.getvalue()

    def test_default_refuses(self):
        code, output = self.invoke([])
        self.assertEqual(code, 2)
        self.assertIn('"native_started": false', output)

    def test_compile_refuses_even_with_static_mode(self):
        self.assertEqual(self.invoke(["--compile", "--verify-static"])[0], 2)

    def test_execute_refuses_even_with_plan_mode(self):
        self.assertEqual(self.invoke(["--execute", "--show-future-plan"])[0], 2)

    def test_conflicting_modes_refuse(self):
        self.assertEqual(self.invoke(["--verify-static", "--show-future-plan"])[0], 2)

    def test_static_checks_current_assets_only(self):
        result = p.static_check()
        self.assertEqual(len(result["refs"]), 6)
        self.assertFalse(result["compiled"])
        self.assertFalse(result["native_started"])
        self.assertFalse(result["kernel_composition_proved"])
        self.assertFalse(result["FULL"])

    def test_static_cli(self):
        self.assertEqual(self.invoke(["--verify-static"])[0], 0)

    def test_plan_is_not_execution(self):
        plan = p.future_plan()
        self.assertEqual(plan["cases"], list(p.CASES))
        self.assertEqual(plan["network_grants"], [])
        self.assertFalse(plan["native_constant_currently"])
        self.assertTrue(plan["requires_new_derivation_and_external_main_authority"])
        self.assertTrue(plan["requires_ledger_gate_and_exclusive_sinks_review"])
        self.assertFalse(plan["inherited_child_measured"])
        self.assertFalse(plan["FULL"])

    def test_plan_cli(self):
        self.assertEqual(self.invoke(["--show-future-plan"])[0], 0)

    def test_outer_is_distinct(self):
        self.assertNotEqual(p.POLICIES["outer"], p.POLICIES["alpha"])
        self.assertNotEqual(p.POLICIES["outer"], p.POLICIES["beta"])
        self.assertNotEqual(p.POLICIES["alpha"], p.POLICIES["beta"])

    def test_c_mirrors_three_physical_policies(self):
        for name, expected in p.POLICIES.items():
            self.assertEqual(p.c_policy(self.source, name), expected)

    def test_allow_default_rejected(self):
        for name, text in p.POLICIES.items():
            with self.assertRaises(ValueError):
                p.validate_policy(name, text.replace("deny default", "allow default"))

    def test_network_rule_rejected(self):
        with self.assertRaises(ValueError):
            p.validate_policy("outer", p.POLICIES["outer"] + "(allow network-outbound)\n")

    def test_personal_path_rejected(self):
        with self.assertRaises(ValueError):
            p.validate_policy("alpha", p.POLICIES["alpha"].replace('param "WITNESS_B"', 'subpath "/Users"'))

    def test_write_permission_rejected(self):
        with self.assertRaises(ValueError):
            p.validate_policy("beta", p.POLICIES["beta"] + "(allow file-write*)\n")

    def test_wildcard_exec_and_fork_rejected(self):
        with self.assertRaises(ValueError):
            p.validate_policy("outer", p.POLICIES["outer"] + "(allow process-exec process-fork)\n")

    def test_duplicate_policy_rule_rejected(self):
        with self.assertRaises(ValueError):
            p.validate_policy("outer", p.POLICIES["outer"] + p.POLICIES["outer"])

    def test_unknown_policy_rejected(self):
        with self.assertRaises(ValueError):
            p.validate_policy("free-policy", p.POLICIES["outer"])

    def test_native_toggle_rejected(self):
        self.mutate("NATIVE_MEASUREMENT_ENABLED = false;", "NATIVE_MEASUREMENT_ENABLED = true;")

    def test_root_substitution_rejected(self):
        self.mutate(str(p.HERE), "/private/tmp/other-root")

    def test_ambient_refusal_removal_rejected(self):
        self.mutate("if (ambient != 0)", "if (ambient < 0)")

    def test_outer_guard_relaxation_rejected(self):
        self.mutate("before_a != READ_OK || before_b != READ_DENIED", "before_a != READ_OK")

    def test_inherited_fd_preservation_rejected(self):
        self.mutate("closefrom(3);", "/* descriptors retained */")

    def test_missing_witness_not_denial(self):
        self.mutate("open_errno == EPERM || open_errno == EACCES", "open_errno == ENOENT")

    def test_process_launch_primitive_rejected(self):
        with self.assertRaises(ValueError):
            p.validate_c(self.source + "\nint bad(void) { return system(\"bad\"); }\n")

    def test_network_primitive_rejected(self):
        with self.assertRaises(ValueError):
            p.validate_c(self.source + "\nint bad(void) { return socket(0, 0, 0); }\n")

    def test_c_policy_widening_rejected(self):
        self.mutate('"(allow file-read-data (literal (param \\"WITNESS_B\\")))\\n";',
                    '"(allow file-read-data)\\n";')

    def test_no_compiler_or_runtime_import_in_preparer(self):
        source = (p.HERE / "prepare_static.py").read_text()
        for forbidden in ("import subprocess", "import ctypes", "import socket", "import runtime_session"):
            self.assertNotIn(forbidden, source)


class GateTextTests(unittest.TestCase):
    """Real source text/mutants only: never executes C, libproc or a pipe."""
    @classmethod
    def setUpClass(cls):
        cls.source = (p.HERE / "probe.c").read_text()
        cls.gate = (p.HERE / "gate_fragment.c.inc").read_text().rstrip("\n")

    def reject(self, old, new):
        self.assertEqual(self.source.count(old), 1)
        with self.assertRaises((ValueError, IndexError)):
            p.validate_c(self.source.replace(old, new, 1))

    def test_real_gate_fragment_exact(self):
        self.assertIn(self.gate, self.source)
        p.validate_c(self.source)

    def test_native_guard_before_gate(self):
        main = self.source.split("int main(int argc, char **argv) {", 1)[1]
        self.assertLess(main.index("if (!NATIVE_MEASUREMENT_ENABLED)"), main.index("fd0_gate("))

    def test_closed_nonce_argv(self):
        self.reject('!gate_nonce_valid(argv[4])', 'false')

    def test_nonce_uppercase_mutant(self):
        self.reject("(nonce[i] >= 'a' && nonce[i] <= 'f')", "(nonce[i] >= 'A' && nonce[i] <= 'F')")

    def test_nonce_length_mutant(self):
        self.reject('strlen(nonce) != 32', 'strlen(nonce) != 16')

    def test_fd0_gate_mandatory(self):
        self.reject('if (fd0_gate(argv[2], argv[4])) {', 'if (false) {')

    def test_barrier_before_all_experiments(self):
        self.reject('if (fd0_gate(argv[2], argv[4])) {', 'if (sandbox_check(getpid(), NULL, 0)) {')

    def test_fixed_root_only(self):
        self.reject('static const char QA_ROOT[] = "' + str(p.HERE) + '";',
                    'static const char QA_ROOT[] = "/Users/synoptia/.therese";')

    def test_fd0_fifo_required(self):
        self.reject('!S_ISFIFO(channel.st_mode)', 'false')

    def test_nonblocking_required(self):
        self.reject('flags | O_NONBLOCK', 'flags')

    def test_deadline_fixed_five_seconds(self):
        self.reject('GATE_LIMIT_NS INT64_C(5000000000)', 'GATE_LIMIT_NS INT64_C(10000000000)')

    def test_poll_rechecks_deadline(self):
        self.reject('polled <= 0 || now < 0 || now >= deadline', 'polled <= 0 || now < 0')

    def test_frame_limit_mutant(self):
        self.reject('GATE_FRAME_BYTES 512', 'GATE_FRAME_BYTES 4096')

    def test_eof_refuses(self):
        self.reject('if (count <= 0) return -1;', 'if (count < 0) return -1;')

    def test_exact_frame_not_substring(self):
        self.reject('used != (size_t)wanted || memcmp(received, expected, used)',
                    'used < (size_t)wanted')

    def test_extra_bytes_refuse(self):
        self.reject('if (more != -1 || errno != EAGAIN) return -1;', 'if (false) return -1;')

    def test_typed_sdk_no_local_struct_abi(self):
        self.assertIn('#include <libproc.h>', self.source)
        self.assertIn('#include <sys/proc_info.h>', self.source)
        self.assertIn('struct proc_bsdinfo info;', self.gate)
        self.assertNotIn('struct proc_bsdinfo {', self.source)

    def test_partial_proc_info_refuses(self):
        self.reject('count != (int)sizeof(info)', 'count < 0')

    def test_only_running_sleeping_states(self):
        self.reject('(info.pbi_status != SRUN && info.pbi_status != SSLEEP)',
                    '(info.pbi_status == SZOMB)')

    def test_birth_range_required(self):
        self.reject('info.pbi_start_tvsec == 0 || info.pbi_start_tvusec >= 1000000', 'false')

    def test_all_six_birth_fields_rechecked(self):
        for expression in ('a->pid == b->pid', 'a->ppid == b->ppid', 'a->uid == b->uid',
                           'a->pgid == b->pgid', 'a->start_sec == b->start_sec',
                           'a->start_usec == b->start_usec'):
            with self.subTest(expression=expression):
                self.reject(expression, 'true')

    def test_owner_birth_rechecked(self):
        self.reject('!same_gate_birth(&owner, &owner_now)', 'false')

    def test_owner_relationship_rechecked(self):
        self.reject('getppid() != (pid_t)owner.pid', 'false')

    def test_child_is_new_process_group(self):
        self.reject('child.pgid != child.pid', 'false')

    def test_three_closed_frame_schemas(self):
        for schema in ('ready-v1', 'release-v1', 'gate-released-v1'):
            with self.subTest(schema=schema):
                self.reject('c17-seatbelt-composition-' + schema, 'foreign-schema')

    def test_ambient_before_compile(self):
        main = self.source.split("int main(int argc, char **argv) {", 1)[1]
        self.assertLess(main.index('if (ambient != 0)'), main.index('sandbox_compile_string(inner'))

    def test_output_failure_red(self):
        self.reject('if (fflush(stdout) || ferror(stdout)) return READ_UNEXPECTED;',
                    'fflush(stdout);')
        self.reject('if (fflush(NULL) || ferror(stdout) || ferror(stderr)) return 86;',
                    'fflush(NULL);')
        old = 'if (fflush(stdout) || ferror(stdout)) return 86;'
        self.assertEqual(self.source.count(old), 3)
        for position in range(3):
            chunks = self.source.split(old)
            mutant = old.join(chunks[:position + 1]) + 'fflush(stdout);' + old.join(chunks[position + 1:])
            with self.subTest(output=position), self.assertRaises(ValueError):
                p.validate_c(mutant)

    def test_no_log_permission_added(self):
        for text in p.POLICIES.values():
            self.assertNotIn('file-write', text)


if __name__ == "__main__":
    unittest.main()
