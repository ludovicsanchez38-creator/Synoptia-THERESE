"""Read-only static preparer. It never compiles, launches, or writes authority."""
from __future__ import annotations

import argparse
import ast
import hashlib
import json
import re
import stat
from pathlib import Path

HERE = Path(__file__).resolve().parent
NATIVE_ENABLED = False
CASES = ("baseline", "compiled-alpha", "compiled-beta", "source-alpha", "source-beta")
BASE = ('(version 1)\n(deny default)\n'
        '(allow file-read-metadata (literal (param "WITNESS_A")) (literal (param "WITNESS_B")))\n')
POLICIES = {
    "outer": BASE + '(allow file-read-data (literal (param "WITNESS_A")))\n',
    "alpha": BASE + '(allow file-read-data (literal (param "WITNESS_B")))\n',
    "beta": BASE + '(allow file-read-data (literal (param "WITNESS_A")) (literal (param "WITNESS_B")))\n',
}


def need(ok: bool, reason: str) -> None:
    if not ok:
        raise ValueError(reason)


def reference(path: Path) -> dict:
    row = path.lstat()
    need(stat.S_ISREG(row.st_mode) and row.st_nlink == 1 and path.resolve(strict=True) == path,
         "reference must be canonical regular file without hardlink/symlink")
    data = path.read_bytes()
    after = path.lstat()
    need((row.st_dev, row.st_ino, row.st_size, row.st_mtime_ns) ==
         (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns), "reference changed during read")
    return {"path": str(path), "sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)}


def validate_policy(name: str, text: str) -> None:
    need(name in POLICIES and text == POLICIES[name], "policy differs from closed witness-only model")
    # Exact equality covers every rule, not just substrings or balanced parentheses.


def c_policy(text: str, name: str) -> str:
    matches = re.findall(r"static const char " + name.upper() + r"\[\] =\s*(.*?);", text, re.S)
    need(len(matches) == 1, "C policy anchor absent/duplicate")
    tokens = re.findall(r'"(?:\\.|[^"\\])*"', matches[0])
    need(bool(tokens) and not re.sub(r'"(?:\\.|[^"\\])*"', "", matches[0]).strip(),
         "C policy must consist only of literal strings")
    return "".join(ast.literal_eval(token) for token in tokens)


def validate_c(text: str, root: Path = HERE) -> None:
    need(text.count("static const bool NATIVE_MEASUREMENT_ENABLED = false;") == 1,
         "native measurement must remain physically disabled")
    need(text.count('static const char QA_ROOT[] = "' + str(root) + '";') == 1,
         "fixed synthetic root differs")
    main = text.split("int main(int argc, char **argv) {", 1)[1]
    gate = (root / "gate_fragment.c.inc").read_text().rstrip("\n")
    need(text.count("/* BEGIN FD0_GATE") == text.count("/* END FD0_GATE */") == 1,
         "gate fragment missing/duplicate")
    actual_gate = re.search(r"/\* BEGIN FD0_GATE[\s\S]+?/\* END FD0_GATE \*/", text)
    need(actual_gate is not None and actual_gate.group(0) == gate,
         "typed gate differs from reviewed textual fragment")
    need(main.index("if (!NATIVE_MEASUREMENT_ENABLED)") < main.index("fd0_gate(")
         and main.index("if (close_inherited_fds()) return 86;") < main.index("fd0_gate(")
         and main.index("fd0_gate(") < main.index("witness_preflight(a")
         < main.index("sandbox_check(") < main.index("sandbox_compile_string(inner"),
         "gate/witness/ambient/compile order changed")
    need('argc != 5' in main and 'strcmp(argv[3], "--gate-nonce")' in main
         and '!gate_nonce_valid(argv[4])' in main
         and 'if (fd0_gate(argv[2], argv[4])) {' in main,
         "closed argv or obligatory gate removed")
    need(main.count('return 86;') >= 5 and
         main.count('if (fflush(stdout) || ferror(stdout)) return 86;') == 3 and
         'if (fflush(stdout) || ferror(stdout)) return READ_UNEXPECTED;' in text and
         'if (fflush(NULL) || ferror(stdout) || ferror(stderr)) return 86;' in main,
         "output failure can no longer be silently passed")
    need(main.index("if (!NATIVE_MEASUREMENT_ENABLED)") < main.index("sandbox_check("),
         "default refusal must precede kernel sandbox inspection")
    need("if (ambient != 0)" in main and main.index("if (ambient != 0)") < main.index("sandbox_init_with_parameters(OUTER"),
         "ambient sandbox must refuse before outer application")
    need("if (close_inherited_fds()) return 86;" in main and
         main.index("if (close_inherited_fds()) return 86;") < main.index("witness_preflight(a"),
         "inherited non-log descriptors not closed")
    fd = (root / "fd_fragment.c.inc").read_text().rstrip("\n")
    actual_fd = re.search(r"/\* BEGIN FD_CLEANUP[\s\S]+?/\* END FD_CLEANUP \*/", text)
    need(text.count("/* BEGIN FD_CLEANUP") == text.count("/* END FD_CLEANUP */") == 1
         and actual_fd is not None and actual_fd.group(0) == fd,
         "own FD cleanup differs from reviewed textual fragment")
    need("closefrom(" not in text and "getdtablesize(" not in text and
         "getrlimit(" not in text, "unsupported or incomplete closure shortcut")
    need(main.index("sandbox_compile_string(inner") < main.index("sandbox_init_with_parameters(OUTER"),
         "compiled fixture must be prepared before outer application")
    need(main.index("before_a != READ_OK || before_b != READ_DENIED") < main.index("int inner_rc"),
         "inner API must not precede outer witness guard")
    need("open_errno == EPERM || open_errno == EACCES" in text and "return READ_UNEXPECTED" in text,
         "missing/instrument errors must not become sandbox denials")
    need('"witness_intersection_observed_not_general_proof"' in text,
         "diagnostic scope missing")
    for call in (r"\bfork\s*\(", r"\bexec\w*\s*\(", r"\bsystem\s*\(",
                 r"\bsocket\s*\(", r"\bconnect\s*\(", r"\bkill\s*\("):
        need(re.search(call, text) is None, "process/network/signal primitive forbidden")
    for name in POLICIES:
        validate_policy(name, c_policy(text, name))


def static_check() -> dict:
    probe = HERE / "probe.c"
    before = reference(probe)
    validate_c(probe.read_text())
    refs = [before]
    for name in POLICIES:
        path = HERE / "policies" / (name + ".sb")
        validate_policy(name, path.read_text())
        refs.append(reference(path))
    for name, content in (("a", b"A:synthetic-witness-only\n"), ("b", b"B:synthetic-witness-only\n")):
        path = HERE / "witnesses" / (name + ".txt")
        need(path.read_bytes() == content, "witness content differs")
        refs.append(reference(path))
    need(reference(probe) == before, "C source changed during static checks")
    return {"scope": "static_preparation_only", "refs": refs, "compiled": False,
            "native_started": False, "kernel_composition_proved": False, "FULL": False}


def future_plan() -> dict:
    return {
        "schema": "c17-seatbelt-composition-future-gated-plan-v1",
        "root": str(HERE), "cases": list(CASES),
        "status": "prepared_only_not_authorized",
        "compiler_argv_example_not_executable": [
            "MAIN_PINNED_CLANG_REQUIRED", "-std=c11", "-Wall", "-Wextra", "-Werror",
            str(HERE / "probe.c"), "-lsandbox", "-lproc", "-o", str(HERE / "future/probe")],
        "per_case_argv_after_separate_review_only": [
            str(HERE / "future/probe"), "--reviewed-case", "ONE_CLOSED_CASE",
            "--gate-nonce", "ROOT_GENERATED_HEX32_REQUIRED"],
        "ready_schema": "c17-seatbelt-composition-ready-v1",
        "released_schema": "c17-seatbelt-composition-gate-released-v1",
        "release_schema": "c17-seatbelt-composition-release-v1",
        "release_encoding": "ASCII json compact fixed key order plus LF, stdin kept open until gate-released",
        "gate_frame_max_bytes": 512, "status_allowed": [2, 3],
        "identity_source": "typed SDK proc_pidinfo PROC_PIDTBSDINFO, exact sizeof proc_bsdinfo",
        "parent_recheck_inside_C_prepared": True,
        "witness_and_profiles_byte_exact_to_old_gel": True,
        "log_write_grants": [], "logging_failure_forces_red": True,
        "native_constant_currently": False,
        "requires_new_derivation_and_external_main_authority": True,
        "requires_ledger_gate_and_exclusive_sinks_review": True,
        "outer_distinct_from_explored_profiles": True,
        "proposed_start_gate_seconds": 5, "proposed_case_seconds": 5,
        "proposed_cleanup_seconds": 8, "proposed_max_cases": 5,
        "network_grants": [], "inherited_child_measured": False,
        "RUNTIME": False, "FULL": False,
    }


def main(argv=None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--verify-static", action="store_true")
    parser.add_argument("--show-future-plan", action="store_true")
    parser.add_argument("--compile", action="store_true")
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args(argv)
    if args.compile or args.execute or not (args.verify_static ^ args.show_future_plan):
        print(json.dumps({"status": "refused", "reason": "compilation/native authority absent", "native_started": False}))
        return 2
    print(json.dumps(static_check() if args.verify_static else future_plan(), sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
