# Correction FD Darwin, préparation désactivée

Acteur /root/shared4_execution. Origine gated J4B04K INDEXdfb24d421838cb818099129ccbf22670d0233f17e8b89cacafee3f8bbe40af6d, C a3d7d575. Cette origine, ses55 tests et son rouge MAIN restent immuables.

MAIN a réellement tenté de compiler ce C native=false : c75e34 exit1,
closefrom non déclaré à la ligne234, aucun binaire exécuté. La preuve physique
compile-failure.json d'a29bPs est jointe, sortie combinée de l'outil et non
sinks directs. Le présent auteur n'a exécuté aucun compilateur/shim/API.

## Seul changement fonctionnel C

Remplacer closefrom(3), absent des headers Darwin examinés, par deux snapshots
PROC_PIDLISTFDS du processus propre uniquement. Buffer fixe256 structures
proc_fdinfo du SDK, pas un layout inventé. Retour<=0, saturé>=capacité, octets
non multiples d'une ligne, FD négatif ou doublon : rouge sans gate/expérience.
Fermer seulement les FD>=3, un seul close par FD ; toute erreur, dont EINTR,
est rouge sans retry aveugle. Relire ensuite, exiger exactement les FD0/1/2.
La fermeture ne dépend ni de rlim_cur ni de getdtablesize et n'accède jamais
à des descripteurs du parent. Pas d'extern closefrom aveugle, -Werror inchangé.

La racine synthétique devient ce dossier privé700, autres corps C inchangés.
Le bloc gate est byte-exact, comme les3 profils et2 témoins. Préimages et
quatre paires de diffs directs/inverses sont jointes. fd_fragment.c.inc est
un témoin textuel exact du nouveau bloc, pas une unité compilée.

La preuve primaire XNU main proc_info.c:461-521 montre l'inventaire sous fdlock,
limité à la capacité, et retour en octets. Saturation est refusée même si
la table a exactement256 lignes. Entre snapshots et close, aucune atomicité
générale contre un autre thread/handler n'est prétendue. La sonde n'introduit
aucun thread/fork/exec/signal, mais la stabilité de la vraie table et l'absence
de droits Mach/fileports hérités ne sont pas démontrées par ces tests.
Un refus kernel libproc avant gate reste un refus, sans fallback.

## Contrat conservé

NATIVE_MEASUREMENT_ENABLED=false, premier garde avant FD/libproc/ready.
Préparateur --compile/--execute toujours code2. Aucun GO ni admission émis.
argv fermé CASE cinq valeurs + --gate-nonce HEX32, FD0 PIPE, ready9 clés,
release6 clés exactes ASCII/LF, gate-released6 clés, deadline monotonic5s.
Parent et enfant BSD2/3, naissances recroisées, gate avant témoins puis
ambient-check, compilation éventuelle et outer. Les stdout expérimentaux
vérifient fflush/ferror ; aucune permission d'écriture ajoutée. Les invariants,
ABI exacts et limites du README gated précédent restent applicables.

Gate5/case5/cleanup8 sont des bornes proposées non mesurées. La fermeture FD
précède le chronomètre interne gate ; le watchdog total du contrôleur externe
doit borner aussi cette phase. Sinks/identités/exécutables/libproc/cleanup
réels restent à revoir et mesurer par MAIN. Même une compilation future
réussie native=false ne valide ni le gate actif ni les API sandbox privées.

## Vérifications réellement effectuées

67 tests textuels/mutants PASS via PythonUV physique -I -B sous garde native,
outil a69c8f, reçu /private/tmp/therese-c17-composition-pure-yZeo1X/receipt.json.
55 cas repris et12 nouvelles méthodes,11 pins sources avant/après inchangés,
zéro tentative native gardée. Pas de compilation C/SB, libproc live, G1,
signal, lancement de sonde/Chrome, ni mutation des gels/ROOT15/FULLv4.
Les mutations couvrent proprePID, buffer, saturation, ligne partielle,
FD négatif/doublon, préservation0/1/2, close erreur, relecture et fermeture.

API : libproc.h:96, proc_info.h:672-675 et717-718 ; close déclaré dans
unistd.h:449. Source primaire :
https://raw.githubusercontent.com/apple-oss-distributions/xnu/main/bsd/kern/proc_info.c
Cette source main n'est pas une mesure du noyau courant. L'ABI privée
Chromium n'est toujours pas appariée au Chrome154 ni garantie par Apple.

Pas de preuve d'héritage, Chrome/G1, deux rondes A/B, FULL ou release.
Toute activation/compilation/mesure ultérieure nécessite une dérivation
distincte et l'action MAIN réellement autorisée, jamais ce préparateur.
