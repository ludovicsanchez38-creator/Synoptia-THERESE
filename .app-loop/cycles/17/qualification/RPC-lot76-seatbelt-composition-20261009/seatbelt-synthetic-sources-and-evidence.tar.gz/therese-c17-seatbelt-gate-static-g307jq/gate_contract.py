"""Contrat de forme seulement pour une future barrière mono-sonde.

Ce module n'importe ni libproc, ni G1, ni subprocess. Il ne peut ni libérer
une sonde, ni observer une naissance réelle, ni signaler un processus.
"""

from __future__ import annotations

import re

CASES = frozenset({
    "baseline", "compiled-alpha", "compiled-beta", "source-alpha", "source-beta",
})
IDENTITY = ("pid", "ppid", "uid", "pgid", "start_sec", "start_usec")
READY_SCHEMA = "c17-seatbelt-composition-ready-proposal-v1"
ORDER = (
    "child_identity_checked", "ready_emitted", "owner_birth_checked",
    "release_on_stdin", "witness_preflight", "sandbox_compile_if_needed",
    "sandbox_check", "outer_apply", "outer_witnesses", "inner_apply_if_needed",
    "final_witnesses", "child_reaped",
)


def need(ok: bool, why: str) -> None:
    if not ok:
        raise ValueError(why)


def birth(row: dict) -> tuple[int, ...]:
    need(isinstance(row, dict) and all(type(row.get(k)) is int for k in IDENTITY),
         "birth incomplète")
    need(row["pid"] > 1 and row["ppid"] > 0 and row["pgid"] > 0
         and row["uid"] >= 0 and row["start_sec"] > 0
         and 0 <= row["start_usec"] < 1_000_000, "birth invalide")
    return tuple(row[k] for k in IDENTITY)


def review_shape(*, case: str, nonce: str, owner: dict, child: dict,
                 ready: dict, expected_binary: str) -> dict:
    """Compare des dictionnaires fournis, jamais une observation du noyau."""
    need(case in CASES and type(nonce) is str
         and re.fullmatch(r"[0-9a-f]{32}", nonce) is not None, "cas/nonce")
    own = birth(owner)
    sonde = birth(child)
    need(child["ppid"] == owner["pid"] and child["uid"] == owner["uid"]
         and child["pgid"] == child["pid"] and child["pid"] != owner["pid"],
         "filiation/UID/PGID")
    need(type(child.get("status")) is int and child["status"] != 5,
         "sonde non vivante")
    need(type(expected_binary) is str and expected_binary.startswith("/private/tmp/")
         and child.get("executable") == expected_binary, "binaire exact")
    need(isinstance(ready, dict) and ready.get("schema") == READY_SCHEMA
         and ready.get("case") == case and ready.get("nonce") == nonce,
         "ready cas/nonce/schéma")
    need(all(type(ready.get(k)) is int and ready[k] == child[k] for k in IDENTITY),
         "ready naissance différente")
    need(ready.get("parent_start_sec") == owner["start_sec"]
         and ready.get("parent_start_usec") == owner["start_usec"]
         and ready.get("parent_pid") == owner["pid"]
         and ready.get("parent_uid") == owner["uid"], "ready parent différent")
    return {"shape_valid": True, "live_birth_observed": False,
            "release_authorized": False, "native_qualification": False,
            "owner_birth": own, "child_birth": sonde}


def review_recheck(*, owner: dict, child: dict, owner_now: dict,
                   child_now: dict, expected_binary: str) -> dict:
    """Égalité pure à réévaluer par un futur lecteur AVANT release/signal."""
    need(birth(owner_now) == birth(owner) and birth(child_now) == birth(child),
         "birth changée")
    need(child_now.get("executable") == expected_binary
         and type(child_now.get("status")) is int and child_now["status"] != 5,
         "exécutable ou vie incertaine")
    return {"same_birth_shape": True, "release_authorized": False,
            "signal_authorized": False, "live_birth_observed": False}


def review_order(events: list[str]) -> None:
    """Séquence future proposée, non comparée au C actuel désactivé."""
    need(type(events) is list and tuple(events) == ORDER, "ordre barrière/sandbox")


def activate(*_args: object, **_kwargs: object) -> None:
    raise RuntimeError("Contrat statique non activable : aucun GO ni libproc live")
