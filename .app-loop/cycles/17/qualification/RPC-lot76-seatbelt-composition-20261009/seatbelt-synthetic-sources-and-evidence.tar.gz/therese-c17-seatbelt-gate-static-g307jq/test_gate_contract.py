"""Mutants purs : aucun import G1/Mach, Popen, sandbox ou libproc."""

import unittest

import gate_contract as g

OWNER = {"pid": 500, "ppid": 1, "uid": 501, "pgid": 500,
         "start_sec": 1700000000, "start_usec": 10}
CHILD = {"pid": 501, "ppid": 500, "uid": 501, "pgid": 501,
         "start_sec": 1700000001, "start_usec": 20, "status": 2,
         "executable": "/private/tmp/qa/future/probe"}
READY = {"schema": g.READY_SCHEMA, "case": "compiled-alpha", "nonce": "a" * 32,
         **{key: CHILD[key] for key in g.IDENTITY}, "parent_pid": OWNER["pid"],
         "parent_uid": OWNER["uid"], "parent_start_sec": OWNER["start_sec"],
         "parent_start_usec": OWNER["start_usec"]}


class GateContractTests(unittest.TestCase):
    def review(self, child=CHILD, ready=READY, owner=OWNER, case="compiled-alpha"):
        return g.review_shape(case=case, nonce="a" * 32, owner=owner,
                              child=child, ready=ready,
                              expected_binary="/private/tmp/qa/future/probe")

    def test_shape_only_never_authorizes(self):
        row = self.review()
        self.assertTrue(row["shape_valid"])
        self.assertFalse(row["live_birth_observed"])
        self.assertFalse(row["release_authorized"])
        self.assertFalse(row["native_qualification"])

    def test_birth_pid_reuse_rejected(self):
        with self.assertRaises(ValueError):
            self.review(child={**CHILD, "start_usec": 21})

    def test_zombie_rejected(self):
        with self.assertRaises(ValueError):
            self.review(child={**CHILD, "status": 5})

    def test_wrong_parent_uid_pgid_rejected(self):
        for field, value in (("ppid", 499), ("uid", 502), ("pgid", 500)):
            with self.subTest(field=field), self.assertRaises(ValueError):
                self.review(child={**CHILD, field: value})

    def test_wrong_executable_rejected(self):
        with self.assertRaises(ValueError):
            self.review(child={**CHILD, "executable": "/usr/bin/sandbox-exec"})

    def test_wrong_ready_nonce_or_parent_birth_rejected(self):
        for field, value in (("nonce", "b" * 32), ("parent_start_usec", 11),
                             ("case", "source-beta")):
            with self.subTest(field=field), self.assertRaises(ValueError):
                self.review(ready={**READY, field: value})

    def test_recheck_is_only_shape_and_refuses_reused_pid(self):
        row = g.review_recheck(owner=OWNER, child=CHILD, owner_now=OWNER,
                               child_now=CHILD,
                               expected_binary="/private/tmp/qa/future/probe")
        self.assertFalse(row["release_authorized"])
        self.assertFalse(row["signal_authorized"])
        with self.assertRaises(ValueError):
            g.review_recheck(owner=OWNER, child=CHILD, owner_now=OWNER,
                             child_now={**CHILD, "start_usec": 21},
                             expected_binary="/private/tmp/qa/future/probe")

    def test_unknown_case_rejected(self):
        with self.assertRaises(ValueError):
            self.review(case="free-case")

    def test_gate_precedes_every_experiment(self):
        g.review_order(list(g.ORDER))
        wrong = list(g.ORDER)
        wrong.remove("sandbox_compile_if_needed")
        wrong.insert(1, "sandbox_compile_if_needed")
        with self.assertRaises(ValueError):
            g.review_order(wrong)
        wrong = list(g.ORDER)
        wrong.remove("witness_preflight")
        wrong.insert(1, "witness_preflight")
        with self.assertRaises(ValueError):
            g.review_order(wrong)

    def test_activation_unconditionally_refused(self):
        with self.assertRaises(RuntimeError):
            g.activate()


if __name__ == "__main__":
    unittest.main()
