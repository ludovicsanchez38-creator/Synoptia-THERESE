# Barrière mono-sonde, proposition non activable

Ce lot est séparé du gel Shared4 `SW4LGL` (INDEX SHA-256
`868ddf53ed9b672138f15d46803a3b2ef338665b529dcc1583520e4ea2f81358`).
Il ne modifie ni sa sonde C ni ses trois profils. La constante
`NATIVE_MEASUREMENT_ENABLED=false` de `probe.c:17` reste effective et le
programme actuel sort avec le code 2 avant toute opération Seatbelt.

`gate_contract.py` est un comparateur de formes pour une dérivation future,
pas un lanceur ni un lecteur du noyau. Même quand les dictionnaires
synthétiques concordent, il retourne explicitement
`live_birth_observed=false`, `release_authorized=false` et
`signal_authorized=false` (pour le recheck). `activate()` refuse toujours.
Les dix tests purs ont été exécutés avec
`/opt/homebrew/bin/python3 -B test_gate_contract.py` : sortie `Ran 10 tests`
puis `OK`, code 0, chunk `710130`. Aucun test ne lance la sonde, `sandbox-exec`,
un processus enfant, libproc ou un service.

## Jointure requise avant une mesure, encore absente

1. Préimage et dérivation distinctes de la sonde C : un canal de barrière sur
   stdin FD 0 (`PIPE`, jamais `DEVNULL`) doit être lu avant les deux
   `witness_preflight`, `sandbox_check` et toute compilation/application de
   profil. Le `closefrom(3)` actuel doit préserver FD 0 ; aucune ouverture
   d'autre canal n'est autorisée par ce lot. Ready doit nommer le cas fermé,
   le nonce et la naissance ; la release doit venir du parent après
   observation réelle, jamais du JSON prêt à lire.
2. Un parent futur doit ouvrir deux sinks QA exclusifs distincts pour stdout
   et stderr, lancer exactement le binaire revu et
   `[probe, --reviewed-case, CASE]` avec un des cinq cas. Il doit contrôler
   avec libproc typé les six champs PID/PPID/UID/PGID/start_sec/start_usec,
   le chemin exécutable et le statut, puis recroiser sa propre naissance et
   celle de l'enfant avant release et avant tout signal. Une erreur, lecture
   partielle ou PID réutilisé interdit release/signal et exige une clôture
   incertaine, non un faux succès.
3. Les bornes `gate 5 s`, `case 5 s`, `cleanup 8 s` sont proposées dans le
   plan Shared4, non mesurées. Une future dérivation doit démontrer la
   fermeture de l'unique enfant et les deux sinks, sans adopter un PID non
   attribué. Aucune capacité G1, Chrome, héritage Seatbelt, réseau, FULL ou
   release n'est qualifiée par ce prototype.

Les lecteurs typés déjà disponibles servent de motifs de source, pas de
modules à importer : `g1-26/runtime_session.py` SHA-256 `f8e9daac...`,
couplé au contrôleur G1 ; `mach-register-micro-receive-p0pLSYvc/run_micro.py`
SHA-256 `bdd1efe4...`, couplé au contrat Mach et à son import de haut niveau.
Une extraction minimale, épinglée et revue séparément, est nécessaire.
`review_shape()` ne prouve aucune de ces observations. Son préfixe
`/private/tmp/` est seulement un garde lexical du fixture, jamais une
autorité de chemin pour un lancement.
