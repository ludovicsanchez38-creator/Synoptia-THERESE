# Refus du premier contrôle de diff

Outil048bea, exit1 avant écriture INDEX. freeze_index comparait la segmentation
des hunks BSD diff à celle de difflib. Les deux segmentations valides diffèrent
sur un blanc déplacé dans probe.c ; les sources et les 55 tests n'ont pas changé.

Erreur réelle : ValueError: diff differs from exact source/preimage.
Lecture6227d2 : diff attendu218 lignes, physique219 lignes ; première divergence
à @@ -107,10 +225,17 @@ versus @@ -107,11 +225,18 @@. La préimage du contrôleur
est conservée. Le correctif reconstruit strictement la cible depuis chaque
hunk, vérifie chaque contexte/suppression/compte et l'égalité byte-exact finale.
Ce refus est purement documentaire, pas un essai C ou natif.

Second refus réel47c2a9, exit1 avant INDEX : le vérificateur nlink1 des
sources/QA a refusé sys/proc.h du SDK. Lecture ecfe5e : fichier régulier
canonique UID0/GID0/mode100644,11852B,nlink9. Ce n'est pas un symlink.
Le correctif ne relâche pas reference() : une observation séparée du seul
header système exact lie hash/stat et conserve ce nombre de liens explicite.
