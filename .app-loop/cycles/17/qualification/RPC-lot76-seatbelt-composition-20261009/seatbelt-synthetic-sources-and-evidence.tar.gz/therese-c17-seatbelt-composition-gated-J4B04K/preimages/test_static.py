import contextlib
import io
import unittest
from pathlib import Path

import prepare_static as p


class StaticPreparationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.source = (p.HERE / "probe.c").read_text()

    def mutate(self, old, new):
        self.assertEqual(self.source.count(old), 1)
        with self.assertRaises((ValueError, IndexError)):
            p.validate_c(self.source.replace(old, new, 1))

    def invoke(self, argv):
        with contextlib.redirect_stdout(io.StringIO()) as output:
            code = p.main(argv)
        return code, output.getvalue()

    def test_default_refuses(self):
        code, output = self.invoke([])
        self.assertEqual(code, 2)
        self.assertIn('"native_started": false', output)

    def test_compile_refuses_even_with_static_mode(self):
        self.assertEqual(self.invoke(["--compile", "--verify-static"])[0], 2)

    def test_execute_refuses_even_with_plan_mode(self):
        self.assertEqual(self.invoke(["--execute", "--show-future-plan"])[0], 2)

    def test_conflicting_modes_refuse(self):
        self.assertEqual(self.invoke(["--verify-static", "--show-future-plan"])[0], 2)

    def test_static_checks_current_assets_only(self):
        result = p.static_check()
        self.assertEqual(len(result["refs"]), 6)
        self.assertFalse(result["compiled"])
        self.assertFalse(result["native_started"])
        self.assertFalse(result["kernel_composition_proved"])
        self.assertFalse(result["FULL"])

    def test_static_cli(self):
        self.assertEqual(self.invoke(["--verify-static"])[0], 0)

    def test_plan_is_not_execution(self):
        plan = p.future_plan()
        self.assertEqual(plan["cases"], list(p.CASES))
        self.assertEqual(plan["network_grants"], [])
        self.assertFalse(plan["native_constant_currently"])
        self.assertTrue(plan["requires_new_derivation_and_external_main_authority"])
        self.assertTrue(plan["requires_ledger_gate_and_exclusive_sinks_review"])
        self.assertFalse(plan["inherited_child_measured"])
        self.assertFalse(plan["FULL"])

    def test_plan_cli(self):
        self.assertEqual(self.invoke(["--show-future-plan"])[0], 0)

    def test_outer_is_distinct(self):
        self.assertNotEqual(p.POLICIES["outer"], p.POLICIES["alpha"])
        self.assertNotEqual(p.POLICIES["outer"], p.POLICIES["beta"])
        self.assertNotEqual(p.POLICIES["alpha"], p.POLICIES["beta"])

    def test_c_mirrors_three_physical_policies(self):
        for name, expected in p.POLICIES.items():
            self.assertEqual(p.c_policy(self.source, name), expected)

    def test_allow_default_rejected(self):
        for name, text in p.POLICIES.items():
            with self.assertRaises(ValueError):
                p.validate_policy(name, text.replace("deny default", "allow default"))

    def test_network_rule_rejected(self):
        with self.assertRaises(ValueError):
            p.validate_policy("outer", p.POLICIES["outer"] + "(allow network-outbound)\n")

    def test_personal_path_rejected(self):
        with self.assertRaises(ValueError):
            p.validate_policy("alpha", p.POLICIES["alpha"].replace('param "WITNESS_B"', 'subpath "/Users"'))

    def test_write_permission_rejected(self):
        with self.assertRaises(ValueError):
            p.validate_policy("beta", p.POLICIES["beta"] + "(allow file-write*)\n")

    def test_wildcard_exec_and_fork_rejected(self):
        with self.assertRaises(ValueError):
            p.validate_policy("outer", p.POLICIES["outer"] + "(allow process-exec process-fork)\n")

    def test_duplicate_policy_rule_rejected(self):
        with self.assertRaises(ValueError):
            p.validate_policy("outer", p.POLICIES["outer"] + p.POLICIES["outer"])

    def test_unknown_policy_rejected(self):
        with self.assertRaises(ValueError):
            p.validate_policy("free-policy", p.POLICIES["outer"])

    def test_native_toggle_rejected(self):
        self.mutate("NATIVE_MEASUREMENT_ENABLED = false;", "NATIVE_MEASUREMENT_ENABLED = true;")

    def test_root_substitution_rejected(self):
        self.mutate(str(p.HERE), "/private/tmp/other-root")

    def test_ambient_refusal_removal_rejected(self):
        self.mutate("if (ambient != 0)", "if (ambient < 0)")

    def test_outer_guard_relaxation_rejected(self):
        self.mutate("before_a != READ_OK || before_b != READ_DENIED", "before_a != READ_OK")

    def test_inherited_fd_preservation_rejected(self):
        self.mutate("closefrom(3);", "/* descriptors retained */")

    def test_missing_witness_not_denial(self):
        self.mutate("open_errno == EPERM || open_errno == EACCES", "open_errno == ENOENT")

    def test_process_launch_primitive_rejected(self):
        with self.assertRaises(ValueError):
            p.validate_c(self.source + "\nint bad(void) { return system(\"bad\"); }\n")

    def test_network_primitive_rejected(self):
        with self.assertRaises(ValueError):
            p.validate_c(self.source + "\nint bad(void) { return socket(0, 0, 0); }\n")

    def test_c_policy_widening_rejected(self):
        self.mutate('"(allow file-read-data (literal (param \\"WITNESS_B\\")))\\n";',
                    '"(allow file-read-data)\\n";')

    def test_no_compiler_or_runtime_import_in_preparer(self):
        source = (p.HERE / "prepare_static.py").read_text()
        for forbidden in ("import subprocess", "import ctypes", "import socket", "import runtime_session"):
            self.assertNotIn(forbidden, source)


if __name__ == "__main__":
    unittest.main()
