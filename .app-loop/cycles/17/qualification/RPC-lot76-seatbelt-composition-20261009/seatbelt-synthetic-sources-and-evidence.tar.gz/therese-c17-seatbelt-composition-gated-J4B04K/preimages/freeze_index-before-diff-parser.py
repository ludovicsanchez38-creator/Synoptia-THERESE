"""Freeze filesystem/text preparation only. No compiler/native authority."""
import difflib
import json
from pathlib import Path
import prepare_static as p

OLD = Path("/private/tmp/therese-c17-seatbelt-composition-static-SW4LGL")
PURE = Path("/private/tmp/therese-c17-composition-pure-aJEHtg")
SDK = Path("/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include")
SOURCE_NAMES = ("probe.c", "prepare_static.py", "test_static.py", "run_static_tests.py",
                "policies/outer.sb", "policies/alpha.sb", "policies/beta.sb",
                "witnesses/a.txt", "witnesses/b.txt")
CHANGED = SOURCE_NAMES[:4]


def check_diff(old, new, diff):
    """Compare actual unified-diff hunks, ignoring only tool file-date headers."""
    expected = list(difflib.unified_diff(old.splitlines(True), new.splitlines(True)))[2:]
    actual = diff.splitlines(True)[2:]
    p.need(expected == actual, "diff differs from exact source/preimage")


def main():
    p.static_check()
    old_index_ref = p.reference(OLD / "INDEX.json")
    p.need(old_index_ref["sha256"] == "868ddf53ed9b672138f15d46803a3b2ef338665b529dcc1583520e4ea2f81358",
           "old frozen INDEX changed")
    old_index = json.loads((OLD / "INDEX.json").read_bytes())
    old_refs = {Path(r["path"]).relative_to(OLD).as_posix(): r for r in old_index["files"]}
    preimages, derivations = [], []
    for name in SOURCE_NAMES:
        origin = p.reference(OLD / name)
        before = p.reference(p.HERE / "preimages" / name)
        after = p.reference(p.HERE / name)
        p.need(origin == old_refs[name], "old source changed")
        p.need((before["sha256"], before["bytes"]) == (origin["sha256"], origin["bytes"]),
               "preimage copy differs")
        preimages.append(before)
        if name in CHANGED:
            direct = p.reference(p.HERE / "diffs" / (name + ".direct.diff"))
            inverse = p.reference(p.HERE / "diffs" / (name + ".inverse.diff"))
            b = (p.HERE / "preimages" / name).read_text()
            a = (p.HERE / name).read_text()
            check_diff(b, a, Path(direct["path"]).read_text())
            check_diff(a, b, Path(inverse["path"]).read_text())
            derivations.append({"before": before, "after": after,
                                "direct": direct, "inverse": inverse})
        else:
            p.need((after["sha256"], after["bytes"]) == (before["sha256"], before["bytes"]),
                   "policy/witness not byte-exact")
    receipt = json.loads((PURE / "receipt.json").read_bytes())
    p.need(receipt["passed"] is True and receipt["tests_run"] == 55
           and receipt["failures"] == receipt["errors"] == receipt["skips"] == 0
           and receipt["forbidden_attempts"] == []
           and receipt["source_before"] == receipt["source_after"],
           "actual pure test receipt not exact")
    for ref in receipt["source_before"]:
        p.need(p.reference(Path(ref["path"])) == ref, "tested source changed")
    local = [p.reference(p.HERE / name) for name in
             (*SOURCE_NAMES, "gate_fragment.c.inc", "README.md", "freeze_index.py")]
    evidence = [p.reference(PURE / "receipt.json"), p.reference(PURE / "returned-test-output.log")]
    origins = [old_index_ref,
               p.reference(Path("/private/tmp/therese-c17-seatbelt-gate-static-g307jq/INDEX.json")),
               p.reference(SDK / "libproc.h"), p.reference(SDK / "sys/proc_info.h"),
               p.reference(SDK / "sys/proc.h"), p.reference(SDK / "sandbox.h")]
    refs = local + preimages + evidence + origins
    refs += [d[k] for d in derivations for k in ("direct", "inverse")]
    for ref in refs:
        p.need(p.reference(Path(ref["path"])) == ref, "freeze ref changed")
    data = {"schema": "c17-seatbelt-composition-gated-static-index-v1",
            "actor": "/root/shared4_execution", "status": "prepared_only_not_admitted",
            "files": local, "preimages": preimages, "derivations": derivations,
            "evidence": evidence, "origin_refs": origins, "plan": p.future_plan(),
            "pure_tool_chunk": "2c18c4", "pure_tests": 55,
            "C_compiled": False, "Apple_profile_compiled": False, "libproc_called": False,
            "kernel_measured": False, "Chrome_started": False, "G1_imported": False,
            "native_admission": None, "RUNTIME": False, "FULL": False, "release": False,
            "profile_write_grants_added": [], "old_gel_unchanged": True,
            "proof_scope": "textual sources/mutants only; no C semantic/native proof"}
    target = p.HERE / "INDEX.json"
    with target.open("x") as sink:
        json.dump(data, sink, indent=2, sort_keys=True)
        sink.write("\n")
    print(json.dumps({"index": p.reference(target), "verified_refs": len(refs)}, sort_keys=True))


if __name__ == "__main__":
    raise SystemExit(main())
