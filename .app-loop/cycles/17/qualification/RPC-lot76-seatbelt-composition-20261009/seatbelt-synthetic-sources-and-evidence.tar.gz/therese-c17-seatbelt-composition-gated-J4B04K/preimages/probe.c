/* Preparation only. Private API declarations mirror Chromium seatbelt.cc.
 * No fork/exec/network. This source is NOT matched to Google Chrome 154.
 * MAIN must review a separate exact derivation before changing this constant.
 */
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

static const bool NATIVE_MEASUREMENT_ENABLED = false;
static const char QA_ROOT[] = "/private/tmp/therese-c17-seatbelt-composition-static-SW4LGL";

/* Private APIs: declarations alone provide no support/composition guarantee. */
typedef struct sandbox_params_t sandbox_params_t;
typedef struct { char *builtin; const uint8_t *data; size_t size; } sandbox_profile_t;
extern sandbox_params_t *sandbox_create_params(void);
extern int sandbox_set_param(sandbox_params_t *, const char *, const char *);
extern void sandbox_free_params(sandbox_params_t *);
extern sandbox_profile_t *sandbox_compile_string(const char *, sandbox_params_t *, char **);
extern int sandbox_apply(sandbox_profile_t *);
extern void sandbox_free_profile(sandbox_profile_t *);
extern void sandbox_free_error(char *);
extern int sandbox_init_with_parameters(const char *, uint64_t, const char *const *, char **);
extern int sandbox_check(pid_t, const char *, int, ...);

static const char OUTER[] =
    "(version 1)\n"
    "(deny default)\n"
    "(allow file-read-metadata (literal (param \"WITNESS_A\")) (literal (param \"WITNESS_B\")))\n"
    "(allow file-read-data (literal (param \"WITNESS_A\")))\n";
static const char ALPHA[] =
    "(version 1)\n"
    "(deny default)\n"
    "(allow file-read-metadata (literal (param \"WITNESS_A\")) (literal (param \"WITNESS_B\")))\n"
    "(allow file-read-data (literal (param \"WITNESS_B\")))\n";
static const char BETA[] =
    "(version 1)\n"
    "(deny default)\n"
    "(allow file-read-metadata (literal (param \"WITNESS_A\")) (literal (param \"WITNESS_B\")))\n"
    "(allow file-read-data (literal (param \"WITNESS_A\")) (literal (param \"WITNESS_B\")))\n";

static void json_string(const char *value) {
    putchar('"');
    for (size_t i = 0; value && value[i] && i < 1024; ++i) {
        unsigned char c = (unsigned char)value[i];
        if (c == '"' || c == '\\') { putchar('\\'); putchar(c); }
        else if (c < 0x20) printf("\\u%04x", c);
        else putchar(c);
    }
    putchar('"');
}

static int witness_preflight(const char *path, char expected) {
    struct stat before, after;
    char canonical[PATH_MAX];
    if (!realpath(path, canonical) || strcmp(path, canonical) ||
        lstat(path, &before) || !S_ISREG(before.st_mode) || before.st_nlink != 1 ||
        before.st_uid != getuid()) return -1;
    int fd = open(path, O_RDONLY | O_NOFOLLOW);
    if (fd < 0) return -1;
    char c = 0;
    int result = fstat(fd, &after) || after.st_dev != before.st_dev ||
        after.st_ino != before.st_ino || after.st_size != before.st_size ||
        after.st_nlink != 1 || read(fd, &c, 1) != 1 || c != expected;
    if (close(fd)) result = 1;
    return result ? -1 : 0;
}

enum read_state { READ_OK, READ_DENIED, READ_UNEXPECTED };
static enum read_state probe_read(const char *phase, const char *label, const char *path, char expected) {
    errno = 0;
    int fd = open(path, O_RDONLY | O_NOFOLLOW);
    int open_errno = fd < 0 ? errno : 0;
    char c = 0;
    ssize_t n = -1;
    int read_errno = 0, close_errno = 0;
    if (fd >= 0) {
        errno = 0;
        n = read(fd, &c, 1);
        if (n < 0) read_errno = errno;
        errno = 0;
        if (close(fd)) close_errno = errno;
    }
    printf("{\"event\":\"witness_read\",\"phase\":"); json_string(phase);
    printf(",\"witness\":"); json_string(label);
    printf(",\"open_ok\":%s,\"open_errno\":%d,\"read_count\":%ld,"
           "\"read_errno\":%d,\"close_errno\":%d,\"content_matches\":%s,"
           "\"diagnostic_only\":true,\"native_qualification\":false}\n",
           fd >= 0 ? "true" : "false", open_errno, (long)n, read_errno,
           close_errno, n == 1 && c == expected ? "true" : "false");
    fflush(stdout);
    if (fd >= 0 && n == 1 && c == expected && !close_errno) return READ_OK;
    if (fd < 0 && (open_errno == EPERM || open_errno == EACCES)) return READ_DENIED;
    return READ_UNEXPECTED; /* Missing/changed witness never stands in for denial. */
}

int main(int argc, char **argv) {
    /* Default compiled candidate remains incapable of measuring the kernel. */
    if (!NATIVE_MEASUREMENT_ENABLED) {
        fputs("prepared_only: compilation/native execution not admitted\n", stderr);
        return 2;
    }
    if (argc != 3 || strcmp(argv[1], "--reviewed-case") ||
        (strcmp(argv[2], "baseline") && strcmp(argv[2], "compiled-alpha") &&
         strcmp(argv[2], "compiled-beta") && strcmp(argv[2], "source-alpha") &&
         strcmp(argv[2], "source-beta"))) return 2;

    char canonical[PATH_MAX], a[PATH_MAX], b[PATH_MAX];
    struct stat root_stat;
    if (!realpath(QA_ROOT, canonical) || strcmp(canonical, QA_ROOT) ||
        lstat(QA_ROOT, &root_stat) || !S_ISDIR(root_stat.st_mode) ||
        root_stat.st_uid != getuid() || (root_stat.st_mode & 077) != 0) return 2;
    if (snprintf(a, sizeof(a), "%s/witnesses/a.txt", QA_ROOT) >= (int)sizeof(a) ||
        snprintf(b, sizeof(b), "%s/witnesses/b.txt", QA_ROOT) >= (int)sizeof(b)) return 2;
    closefrom(3); /* No inherited witness, directory, network or broker FD. */
    if (witness_preflight(a, 'A') || witness_preflight(b, 'B')) return 2;
    /* Refuse an ambient/inherited sandbox rather than replacing it blindly. */
    int ambient = sandbox_check(getpid(), NULL, 0);
    if (ambient != 0) {
        fprintf(stderr, "ambient sandbox/unknown sandbox_check=%d; refused\n", ambient);
        return 2;
    }

    const bool baseline = !strcmp(argv[2], "baseline");
    const bool compiled = !strncmp(argv[2], "compiled-", 9);
    const char *inner = strstr(argv[2], "alpha") ? ALPHA : BETA;
    const char *params[] = {"WITNESS_A", a, "WITNESS_B", b, NULL};
    sandbox_profile_t *compiled_inner = NULL;
    char *error = NULL;
    if (compiled) {
        /* Precompile in memory before outer; no extra library/profile read grants. */
        sandbox_params_t *p = sandbox_create_params();
        if (!p || sandbox_set_param(p, "WITNESS_A", a) || sandbox_set_param(p, "WITNESS_B", b)) return 2;
        compiled_inner = sandbox_compile_string(inner, p, &error);
        sandbox_free_params(p);
        if (!compiled_inner) {
            fputs("private API preparation failed; no measurement\n", stderr);
            if (error) sandbox_free_error(error);
            return 2;
        }
        if (error) { sandbox_free_error(error); error = NULL; }
    }
    fflush(NULL);
    errno = 0;
    int outer_rc = sandbox_init_with_parameters(OUTER, 0, params, &error);
    int outer_errno = errno;
    printf("{\"event\":\"outer_apply\",\"pid\":%d,\"ppid\":%d,\"uid\":%d,"
           "\"rc\":%d,\"errno\":%d,\"diagnostic_only\":true,\"error\":",
           getpid(), getppid(), getuid(), outer_rc, outer_errno);
    json_string(error); puts("}"); fflush(stdout);
    if (error) { sandbox_free_error(error); error = NULL; }
    if (outer_rc != 0) return 86;
    enum read_state before_a = probe_read("outer", "A", a, 'A');
    enum read_state before_b = probe_read("outer", "B", b, 'B');
    if (before_a != READ_OK || before_b != READ_DENIED) {
        fputs("outer witness guard failed; no inner application\n", stderr);
        return 86;
    }
    if (baseline) return 0;

    errno = 0;
    int inner_rc = compiled ? sandbox_apply(compiled_inner) :
        sandbox_init_with_parameters(inner, 0, params, &error);
    int inner_errno = errno;
    printf("{\"event\":\"inner_apply\",\"case\":"); json_string(argv[2]);
    printf(",\"api\":"); json_string(compiled ? "sandbox_apply" : "sandbox_init_with_parameters");
    printf(",\"rc\":%d,\"errno\":%d,\"diagnostic_only\":true,\"error\":", inner_rc, inner_errno);
    json_string(error); puts("}"); fflush(stdout);
    if (error) sandbox_free_error(error);
    enum read_state after_a = probe_read("after_inner", "A", a, 'A');
    enum read_state after_b = probe_read("after_inner", "B", b, 'B');
    const bool alpha = strstr(argv[2], "alpha") != NULL;
    const bool intersection = after_b == READ_DENIED &&
        after_a == (alpha ? READ_DENIED : READ_OK);
    const char *observation = after_a == READ_UNEXPECTED || after_b == READ_UNEXPECTED ?
        "witness_instrument_error" : inner_rc != 0 ? "inner_api_refused" :
        after_b == READ_OK ? "outer_denial_not_preserved" :
        (alpha && after_a == READ_OK) ? "inner_restriction_not_observed" :
        "witness_intersection_observed_not_general_proof";
    printf("{\"event\":\"case_finished\",\"observation\":"); json_string(observation);
    puts(",\"inherited_child_measured\":false,\"network_measured\":false,"
         "\"native_qualification\":false,\"FULL\":false}"); fflush(stdout);
    if (compiled_inner) sandbox_free_profile(compiled_inner);
    return inner_rc != 0 || !intersection ? 86 : 0;
}
