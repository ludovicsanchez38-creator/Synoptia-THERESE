# Sonde synthétique, dérivation FD0 préparatoire

Acteur : /root/shared4_execution. Ce gel dérive uniquement la préparation
SW4LGL (INDEX868ddf53) sans la modifier. Le C reste native=false ; son
premier garde retourne2 avant libproc, ready ou toute opération expérimentale.
Le préparateur refuse toujours --compile/--execute. Aucun GO, admission,
binaire, compilation C/SB, contrôleur actif ou résultat natif n'est produit.

## Delta borné

Les préimages de probe.c, préparateur/tests/runner, trois profils et deux
témoins sont copiées exactement. Trois profils et deux témoins demeurent
byte-exacts. Seul le root synthétique du C change vers ce dossier privé700.
Les quatre fichiers modifiés ont des diffs directs et inverses dans diffs/.
gate_fragment.c.inc est la copie exacte du seul bloc de gate, pas un fichier
compilé ni une preuve de sa sémantique C.

La barrière précède même la validation/lecture des témoins et la validation
du root. Ordre proposé si une dérivation native est un jour autorisée :

1. garde native/argv fermés, closefrom(3) conserve uniquement0/1/2 ;
2. vérification FD0 pipe, passage non bloquant, captures typées SDK de
   l'enfant et du parent, étatBSD SRUN2 ou SSLEEP3 uniquement ;
3. ready flush, release exacte reçue avant5s monotonic, fermeture FD0,
   recheck des six champs enfant/parent puis gate-released flush ;
4. root/témoins, ambient sandbox_check et refus si nonzero ;
5. compilation privée en mémoire éventuelle, application outer puis mesures.

La lecture libproc future utilise les headers SDK, struct proc_bsdinfo et
proc_pidinfo(PROC_PIDTBSDINFO), retour exactement sizeof(struct), sans
reconstituer un layout. PID/PPID/UID/PGID/start_sec/start_usec proviennent
de cette lecture, jamais d'un JSON de demande. L'enfant doit être leader
d'un nouveau groupe, parent direct et mêmeUID. Les deux naissances sont
recroisées après la release. Le contrôleur externe doit en plus relire les
exécutables exacts, sa propre naissance et celle de l'enfant avant release
ou signal. Le code C n'émet aucun signal et ne fork/exec/connecte rien.

## ABI fermée, inactive

argv : [BINAIRE_REVU, "--reviewed-case", CASE, "--gate-nonce", HEX32].
CASE : baseline, compiled-alpha, compiled-beta, source-alpha, source-beta.
HEX32 : exactement32 caractères hexadécimaux minuscules, nonce unique produit
par MAIN, jamais PID prévu ni variable d'environnement.

stdout ready : une ligne JSON compacte avec exactement neuf clés dans
l'ordre schema,case,nonce,pid,ppid,uid,pgid,start_sec,start_usec ; schema
c17-seatbelt-composition-ready-v1.

FD0 release : une seule ligneASCII JSON compacte, ordre exact
schema,case,nonce,pid,start_sec,start_usec + LF ; schema
c17-seatbelt-composition-release-v1. La ligne est reconstruite à partir
de la propre birth observée dans C puis comparée byte-exact, pas parsée comme
une autorité. Encodage parent :
json.dumps(row,separators=(',', ':'),ensure_ascii=True).encode('ascii')+b'\n'.
Le parent garde stdin ouvert jusqu'à réception du ACK.

stdout ACK : six mêmes clés/ordre que release avec schema
c17-seatbelt-composition-gate-released-v1 + LF. Le parent vérifie les valeurs.
Aucune sortie expérimentale ne précède cet ACK. Un ACK ne prouve pas un
succès expérimental : une échéance dépassée immédiatement après son flush
rend encore le C rouge sans appliquer de politique.

Frame512 maximum, deadline locale5s, poll et read non bloquants ; EOF avant
ACK, frame incomplète/étrangère/plusieurs frames déjà reçues, taille, erreur
clock/libproc, statut non2/3, birth/filiation différente : refus86, aucune
expérience. Le gate ferme FD0 après la seule frame acceptée. Ce protocole
n'est pas une authentification d'un écrivain hostile avec accès au pipe ;
la possession du pipe et l'autorité externe réelle doivent être contrôlées
par le parent. La borne est coopérative, pas une garantie de préemption
kernel : captures/flush/scheduling restent à mesurer sous un watchdog.

## Observabilité, aucune permission supplémentaire

Chaque sortiestdout expérimentale vérifie fflush/ferror. Un échec de log
retourne86 ou READ_UNEXPECTED ; baseline ne peut pas passer silencieusement.
Les politiques deny-default ne gagnent AUCUN droit d'écriture. Hériter de
FD1/FD2 n'atteste pas une permission de log sous Seatbelt. Le futur parent
doit prouver les deux sinksQA directs exclusifs distincts et leur archivage.
Si le noyau refuse les logs, conserver le rouge ; une dérivation séparée
pour exactement deux cheminsQA de logs requerra revue explicite avant tout
grant. Ce lot ne résout pas la réinitialisation de la sandbox Chromium.

baseline historique retourne0 après ses deux lectures outer, sans event
case_finished. Les chemins rouges peuvent terminer avant cet event. Le
contrôleur ne doit ni fabriquer un event, ni convertir exit86/taint envert.

## Vérifications réelles et limites

55 tests Python textuels/mutants réels PASS, zéro erreur/échec/skip, dix
pins avant/après identiques et zéro tentative via les points d'entrée natifs
gardés. Reçu : /private/tmp/therese-c17-composition-pure-aJEHtg/receipt.json.
Outil2c18c4 exit0 via PythonUV physique -I -B, sans shim/toolchain.
Les27 cas historiques sont rejoués sur cette préparation ;28 nouveaux
méthodes testent les textes réels/garde/frames/naissances et mutants.
Cela ne compile pas C, ne parse pas les politiques avec Apple, ne mesure
aucun libproc/FD/horloge/signal/IPC/Seatbelt. Le comparateur textuel exige
le blocC exact en plus des ancres d'ordre ; il n'est pas un compilateur.

Le premier essai du gelSW4LGL (shim Python déclenchant réellement
xcodebuild/xcrun, suite non démarrée) reste inchangé dans son dossier.
Ce nouveau lot n'efface aucun rouge et ne prétend pas à une absence
exhaustive d'écritures de cet ancien essai.

Préparation suivante : contrôleur séparé Env, identification réelle,
sinks exclusifs, autoritéMAIN spécifique, dérivation exacte native puis
compilation future avec le clang/SDK physiquement épinglés. Les bornes
gate5/case5/cleanup8 restent distinctes et non mesurées. Ne pas importer
G1 ni relabeller ROOT15/FULLv4. Aucune preuve d'héritage, réseau, Chrome154,
G1, A/B, FULL ou release ne découle de cette sonde mono-processus.

## Sources primaires

Headers locaux épinglés dans l'INDEX : libproc.h:96, sys/proc_info.h:59-82
et723-724, sys/proc.h:148-152. Ils établissent types/champs/états, pas une
observation actuelle de processus. sandbox.h public ne documente pas les
API privées de composition.

sys/proc.h est une observation SDK séparée : chemin canonique régulier
root-owned, mode100644 et neuf liens physiques existants. Il ne remplit
pas la règle nlink1 des assets QA ; cette règle reste intacte. Les deux
refus du contrôleur de gel sont conservés dans FIRST-FREEZE-REFUSAL.md.

Chromium main seatbelt.cc:14-17,42-54,144-158,179-186, relu :
https://raw.githubusercontent.com/chromium/chromium/main/sandbox/mac/seatbelt.cc
XNU main, struct publique :
https://raw.githubusercontent.com/apple-oss-distributions/xnu/main/bsd/sys/proc_info.h
Ces déclarations privées ne sont pas un ABI Apple garanti ni un appariement
au Chrome154 installé. Le test serializer tronqué ne démontre pas une
composition de deux politiques valides distinctes. Aucun appel de ces API
n'a été effectué dans ce lot.
