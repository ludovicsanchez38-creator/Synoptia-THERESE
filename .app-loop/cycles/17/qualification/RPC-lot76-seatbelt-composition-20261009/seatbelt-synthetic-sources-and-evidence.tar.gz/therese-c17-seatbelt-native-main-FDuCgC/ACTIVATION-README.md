# Contrôleur natif mono-sonde MAIN, préparation non exécutée par l'auteur

Cette copie est distincte du contrôleur v3 désactivé, dont l'INDEX reste
`/private/tmp/therese-c17-seatbelt-controller-v3-9nfpdk/INDEX.json` SHA-256
`f7097bd71f509b4ff676650bfb6e9ede27603322c9cfa6d819d20c27add8b3db`.
Le C activé et le binaire ont été préparés et compilés par MAIN sous cette
racine ; l'auteur du contrôleur ne les a ni compilés ni exécutés. Aucun
résultat de mesure n'est hérité des 31 tests doubles du v3.

`native_main.py` accepte exactement `--reviewed-case` puis un cas de la table
fermée. L'invocation future envisagée par MAIN est :

`/opt/homebrew/bin/python3 -I -B /private/tmp/therese-c17-seatbelt-native-main-FDuCgC/native_main.py --reviewed-case baseline`

La baseline applique elle aussi la politique OUTER avant ses deux lectures
témoins. Aucun autre cas ne doit être lancé avant lecture de son résultat par
MAIN. Les cas restent `baseline`, `compiled-alpha`, `compiled-beta`,
`source-alpha`, `source-beta`. Le runner refuse toute autre CLI, un second cas
simultané par verrou `flock` sur le manifeste, et la reprise d'un dossier cas
déjà utilisé. `activate()` dans `controller.py` continue de refuser ; seul ce
runner peut appeler `_drive` avec le type exact `NativePort`.

Le manifeste extérieur `NATIVE-SOURCES.json`, hors de sa propre table, ferme
exactement dix fichiers : runner, contrôleur, port, binaire, source C activée,
deux témoins de `0dUJdL` et les trois profils de définition. Les profils
externes sont épinglés pour la provenance ; le C utilise leurs chaînes
embarquées, il ne les lit pas lors de la mesure. Le runner verrouille et
re-hashe la table avant l'import local et le Popen ; ses deux modules locaux
sont compilés depuis les octets ré-hashés, pas réouverts sans contrôle. Les
sources, dont le manifeste, sont recroisées après fermeture. MAIN doit
épingler extérieurement le manifeste et les trois scripts juste avant son
invocation ; le manifeste ne s'auto-authentifie pas.

`Plan.root` et le binaire sont sous `FDuCgC`. Le C garde son QA_ROOT littéral
`0dUJdL` pour les témoins. `HOME=FDuCgC/home`, `TMPDIR=FDuCgC/tmp/` et
`PATH=/usr/bin:/bin` sont l'environnement exact du v3 ; aucun `os.environ`
n'est transmis. La racine, les deux répertoires privés et chaque
`cases/<case>` sont vérifiés canoniques, propriétaire courant, mode 0700.
`cwd`, stdout, stderr, trace et résultat d'un cas sont dans ce dossier cas.
Les deux sinks sont ouverts distinctement en `O_EXCL|O_NOFOLLOW`, mode 0600,
et donnés directement à l'unique enfant. `stdin=PIPE` est la seule barrière.

La trace `trace.jsonl` est propriétaire mode 0600, plafonnée à 128 lignes,
32 768 octets au total et 512 octets par événement. Elle relève appels
libproc, source refs, naissance, ready, release, ACK, attente, éventuels
signaux PID et fermeture. Elle ne journalise pas l'environnement ni des
données personnelles. Une trace saturée ou illisible force un résultat rouge
sans empêcher la fermeture. Le résultat `result.json` est créé exclusivement
en 0600 dans le dossier cas, avec code brut de l'enfant, identité et preuves
de fermeture. `actual_native_IO` désigne seulement le type exact NativePort ;
`native_child_started` sépare une erreur pré-Popen. Aucun code 0 de la sonde
ne démontre Chromium, G1, héritage de sandbox, réseau ou FULL.

Bornes du contrôleur : gate 5 s, cas 5 s, cleanup 8 s, dont 1 s pour TERM
avant relecture/KILL si l'identité reste attribuée. Elles sont coopératives
et non mesurées dans cette copie. Aucun signal de groupe ; identité inconnue
ou divergente interdit le signal. Le risque entre la dernière relecture
libproc et `kill(pid)` n'est pas atomiquement écarté. Une future exécution
requiert revue des sources et supervision externe de MAIN ; aucun lancement
n'a été fait par l'auteur de cette préparation.
