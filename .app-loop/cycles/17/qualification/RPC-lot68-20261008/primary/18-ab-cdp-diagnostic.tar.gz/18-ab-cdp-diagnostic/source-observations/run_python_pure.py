"""No subprocess/socket/ctypes/OS-instrumentation is allowed in this test run."""
from datetime import datetime, timezone
from hashlib import sha256
import importlib.util
import io
import json
from pathlib import Path
import sys
import time
import unittest

BASE = Path(__file__).resolve().parent
OUT = Path(sys.argv[1]).resolve()
assert OUT.parent == Path('/private/tmp') and OUT.name.startswith('therese-c17-ab-direct-cdp-python-')
assert OUT.is_dir() and OUT != BASE
started = datetime.now(timezone.utc).isoformat()
clock = time.monotonic()
denied = []


def guard(event, args):
    if event.startswith(('subprocess.', 'socket.', 'ctypes.')) or event in ('os.fork', 'os.forkpty', 'os.posix_spawn', 'os.system', 'os.kill', 'os.killpg'):
        denied.append(event)
        raise RuntimeError('Forbidden instrumentation: ' + event)


sys.addaudithook(guard)


def refs():
    paths = [BASE / 'render_direct_cdp.py', BASE / 'test_render_direct_cdp.py', Path(__file__).resolve(), BASE / 'INPUTS-COMPLETE.json']
    for row in json.loads((BASE / 'INPUTS-COMPLETE.json').read_text())['files']:
        paths += [Path(row['path']), Path(row['copy'])]
    return [{"path": str(path), "sha256": sha256(path.read_bytes()).hexdigest(), "bytes": path.stat().st_size} for path in paths]


before = refs()
spec = importlib.util.spec_from_file_location('test_renderer_only', BASE / 'test_render_direct_cdp.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
stdout = io.StringIO()
suite = unittest.defaultTestLoader.loadTestsFromTestCase(module.RendererTests)
result = unittest.TextTestRunner(stream=stdout, verbosity=2).run(suite)
after = refs()
with (OUT / 'stdout.log').open('x') as handle:
    handle.write(stdout.getvalue())
with (OUT / 'stderr.log').open('x') as handle:
    handle.write('')
receipt = {"schema": "c17-ab-direct-cdp-python-pure-tests-v1", "scope": "pure_definition_tests_only",
    "actor": "/root/cycle17_gate_review", "round_id": None, "started_at": started,
    "completed_at": datetime.now(timezone.utc).isoformat(), "elapsed_seconds": time.monotonic() - clock,
    "tests": result.testsRun, "failures": len(result.failures), "errors": len(result.errors), "skips": len(result.skipped),
    "denied_events": denied, "pins_before": before, "pins_after": after,
    "pins_unchanged": before == after, "passed": result.wasSuccessful() and before == after and not denied,
    "stdout": {"path": str(OUT / 'stdout.log'), "sha256": sha256((OUT / 'stdout.log').read_bytes()).hexdigest(), "bytes": (OUT / 'stdout.log').stat().st_size},
    "stderr": {"path": str(OUT / 'stderr.log'), "sha256": sha256((OUT / 'stderr.log').read_bytes()).hexdigest(), "bytes": 0},
    "limits": ["Synthetic identity and historical definition fixtures only", "No Session/G1 full import or native execution", "No A/B permission, source checkout, lifecycle, socket or transport qualified"]}
with (OUT / 'receipt.json').open('x') as handle:
    handle.write(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({"tests": receipt['tests'], "passed": receipt['passed'], "receipt": str(OUT / 'receipt.json')}))
raise SystemExit(0 if receipt['passed'] else 1)
