"""Pure definition renderer for nine closed A/B Chrome sites.

No allocation, launch, Session admission, source rebase or Git/lsof port lives
here. Callers must first prepare and pin their own C17 definitions. Historical
definition fixtures used by tests are not runnable A/B inputs or results.
"""
from __future__ import annotations

from hashlib import sha256
from pathlib import PurePosixPath
import re

RUNTIME_ENABLED = False
OS_STARTUP_QUALIFIED = False
ADMISSION_TABLE: dict = {}
CAPABILITIES: dict = {}
ACTORS = frozenset({"/root", "/root/cycle17_gate_review", "/root/environment_routes", "/root/native_policy_review"})
EXPECTED_HELPER_PIN = {"sha256": "64555c1d39590d944bce79a84479bc7deca7d1bdcdfd4552f842651bc307baf3", "bytes": 14247}
TRACE_PATH = "trace-chrome.mjs"
GUARD_PATH = "complements/instruments/p162-garde-get-v3.mjs"
HELPER_PATH = "auxiliary-ports/runtime/aux_node.mjs"
DIRECT_SITES = (
    ("recipe-general", "runtime/recette-c17.mjs"),
    ("recipe-invoices", "runtime/recette-facturation-p160-v2.mjs"),
    ("recipe-crm", "runtime/recette-crm-focus.mjs"),
    ("B1713", "complements/instruments/b1713-clavier-v3.mjs"),
    ("P157-800", "complements/instruments/p157-pipeline-root-oracle.mjs"),
    ("P157-1440", "complements/instruments/p157-pipeline-root-oracle.mjs"),
    ("B1755", "complements/instruments/b1755-garde-v3.mjs"),
    ("P162", "complements/instruments/p162-colonnes-v3.mjs"),
    ("coverage", "runtime/couverture-ecran-c17.mjs"),
)
REQUIRED_PATHS = frozenset(path for _, path in DIRECT_SITES) | {TRACE_PATH, GUARD_PATH}
ANCHOR = "const originalLaunch=chromium.launch.bind(chromium);"
IMPORT = "import {connectOwnedChrome} from './auxiliary-ports/runtime/aux_node.mjs';\n"
REPLACEMENT = "const originalLaunch=options=>connectOwnedChrome(chromium,options);"


def need(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def identity(root: str, actor: str, round_id: str, head: str) -> dict:
    match = re.fullmatch(r"/private/tmp/therese-(c17-direct-round-([ab])-[0-9a-f]{12})", root)
    need(match is not None and str(PurePosixPath(root)) == root, "Exact A/B root required")
    need(round_id == match[1], "Logical round differs from physical root")
    need(isinstance(actor, str) and actor in ACTORS, "Existing exact collaborating actor required")
    need(isinstance(head, str) and re.fullmatch(r"[0-9a-f]{40}", head) is not None,
         "Exact physical HEAD required")
    return {"root": root, "actor": actor, "round_id": round_id,
            "round_name": match[2].upper(), "head": head}


def pin(text: str) -> dict:
    raw = text.encode("utf-8")
    return {"sha256": sha256(raw).hexdigest(), "bytes": len(raw)}


def render(definitions: dict[str, str], source_pins: dict[str, dict], *,
           helper_source: str, helper_pin: dict, root: str, actor: str,
           round_id: str, head: str) -> dict:
    context = identity(root, actor, round_id, head)
    need(set(definitions) == REQUIRED_PATHS and set(source_pins) == REQUIRED_PATHS,
         "Exact eight recipes + trace + P162 guard required")
    for path, source in definitions.items():
        need(isinstance(source, str) and pin(source) == source_pins[path], "Definition SHA/bytes mismatch: " + path)
    need(pin(helper_source) == helper_pin == EXPECTED_HELPER_PIN, "Auxiliary helper SHA/bytes mismatch")
    # This port consumes the already closed A/B helper. It never extends scope.
    for anchor, occurrences in (
        ("export const AB_DIRECT_SITES = Object.freeze({", 1),
        ("context.scope === 'runtime78_exact_round' && AB_JOBS.includes(context.stage)", 2),
        ("return chromium.connectOverCDP(chrome.endpoint, {timeout: 5000});", 1),
        ("export const connectOwnedChrome = (chromium, options) => getAuxiliary().connect(chromium, options);", 1),
    ):
        need(helper_source.count(anchor) == occurrences, "Exact existing helper anchor required")
    trace = definitions[TRACE_PATH]
    need(trace.count(ANCHOR) == 1 and IMPORT not in trace and REPLACEMENT not in trace,
         "Unique pristine trace launch anchor required")
    for anchor in (
        "if(options.channel!=='chrome'||options.headless!==false||options.chromiumSandbox!==true)",
        "const browser=await originalLaunch(options);",
        "trace.launches.push({options,version:browser.version(),at:new Date().toISOString()});",
        "browser.newContext=async(...arguments_)=>{",
        "await context.exposeBinding('__c16ObservedTrustedAction'",
        "for(const type of ['pointerdown','click','keydown','focusin'])",
    ):
        need(trace.count(anchor) == 1, "Trace assertion/decorator missing or ambiguous")
    guard = definitions[GUARD_PATH]
    for anchor in (
        "const realLaunch=chromium.launch.bind(chromium);",
        "browser.newContext=async(options={})=>{journal.contexts++;",
        "{...options,acceptDownloads:false}",
        "process.env.P162_GUARD_PRELOADED='1';",
    ):
        need(guard.count(anchor) == 1, "P162 guard chain changed")
    for path in REQUIRED_PATHS - {TRACE_PATH, GUARD_PATH}:
        need(definitions[path].count("await chromium.launch(") == 1,
             "Exactly one original recipe launch required: " + path)
    output = definitions.copy()
    output[TRACE_PATH] = IMPORT + trace.replace(ANCHOR, REPLACEMENT)
    # Prove reversibility over every byte, not just selected assertion strings.
    restored = output[TRACE_PATH][len(IMPORT):].replace(REPLACEMENT, ANCHOR)
    need(restored == trace, "Trace delta not exactly reversible")
    need(all(output[path] == definitions[path] for path in REQUIRED_PATHS - {TRACE_PATH}),
         "Recipe/GET guard bytes changed")
    return {"schema": "c17-ab-direct-owned-cdp-definition-render-v1", "scope": "preparation_only",
            "identity": context, "direct_jobs": list(dict(DIRECT_SITES)),
            "definitions": output, "output_pins": {name: pin(value) for name, value in output.items()},
            "helper_pin": helper_pin.copy(), "runtime_enabled": False,
            "os_startup_qualified": False, "admission_table": {}, "capabilities": {},
            "changed_paths": [TRACE_PATH], "limits": [
                "No Session/root authority or lifecycle admitted by this definition renderer",
                "Existing Git and lsof calls are unchanged and require a separate bounded port",
                "Chrome original/profile5266 remain proposed and not qualified for A/B",
                "Browser.close disconnects CDP; existing G1 must prove physical Chrome stop",
            ]}
