// Portable V8 pure tests. No product/OS/Session/Playwright module import or socket.
// Source text is supplied byte-exact by the controller; dependency doubles are
// explicit. These tests do not prove physical FS publication/birth/ownership.
export async function runPure({auxiliarySource, traceSource, p162Source}) {
  const cases = [];
  class PureAssertionError extends Error {}
  const check = (ok, message) => {if (!ok) throw new PureAssertionError(message);};
  const clone = x => JSON.parse(JSON.stringify(x));
  const eq = (a, b) => JSON.stringify(a) === JSON.stringify(b);
  const take = (source, start, end) => {
    check(source.split(start).length === 2 && source.split(end).length === 2, 'Unique source anchors');
    return source.slice(source.indexOf(start), source.indexOf(end)).replace(/^export /gm, '');
  };
  const constants = take(auxiliarySource, 'export const JOBS', 'export function regular');
  const environmentBody = take(auxiliarySource, 'export function environmentContext', '\nexport function createAuxiliary');
  const createBody = take(auxiliarySource, 'export function createAuxiliary', '\nlet auxiliary;');
  const args = ['fs', 'checked', 'published', 'gitHead', 'process', 'createHash', 'randomUUID', 'resolve', 'dirname'];
  const compileHelper = new Function(...args, constants + environmentBody + createBody
    + '; return {environmentContext,createAuxiliary,AB_DIRECT_SITES,AB_DIRECT_JOBS};');

  function fixture(stage = 'recipe-general') {
    const root = '/private/tmp/therese-c17-direct-round-a-123456789abc';
    const source = '/private/tmp/therese-c17-source-pure/source';
    const actor = '/root', round_id = 'c17-direct-round-a-123456789abc', head = 'a'.repeat(40);
    const binding = 'b'.repeat(64), decision = 'synthetic-root-decision-not-an-admission';
    const ref = path => ({path, sha256: '0'.repeat(64), bytes: 1});
    const birth = {pid: 901, ppid: 800, uid: 501, pgid: 901, birth_sec: 1, birth_usec: 2};
    const options = {headless: false, channel: 'chrome', chromiumSandbox: true,
      args: ['--disable-background-networking','--disable-component-update','--disable-sync']};
    const name = 'aux-chrome-' + stage;
    const context = {schema: 'c17-ab-auxiliary-context-v1', scope: 'runtime78_exact_round',
      root, actor, round_id, round_name: 'A', head, stage,
      product_source_root: source, source_checkout_ref: ref(root + '/authorization/source-checkout.json'),
      git_snapshot_ref: ref(root + '/authorization/git-snapshot.json'), source_script: null};
    const sites = {
      'recipe-general':'runtime/recette-c17.mjs','recipe-invoices':'runtime/recette-facturation-p160-v2.mjs',
      'recipe-crm':'runtime/recette-crm-focus.mjs',B1713:'complements/instruments/b1713-clavier-v3.mjs',
      'P157-800':'complements/instruments/p157-pipeline-root-oracle.mjs',
      'P157-1440':'complements/instruments/p157-pipeline-root-oracle.mjs',B1755:'complements/instruments/b1755-garde-v3.mjs',
      P162:'complements/instruments/p162-colonnes-v3.mjs',coverage:'runtime/couverture-ecran-c17.mjs',
    };
    context.source_script = sites[stage] ?? null;
    const chrome = {name,port:17594,profile:root+'/auxiliary/'+name+'/profile',original_options:options,
      endpoint:'ws://127.0.0.1:17594/devtools/browser/synthetic-one',start_ref:ref(root+'/auxiliary/'+name+'/start.json')};
    const registry = {schema:'c17-g1-auxiliary-services-v1',scope:context.scope,stage,actor,round_id,head,
      decision_id:decision,binding_sha256:binding,chrome,services:{chrome:{port:17594,birth_identity:birth}}};
    const gate = {pid:birth.pid,ppid:birth.ppid,uid:birth.uid,pgid:birth.pgid,command:['synthetic-chrome']};
    const start = {schema:'c17-g1-auxiliary-start-v1',stage,name,role:'auxiliary-'+name,released:true,
      root_identity:birth,original_options:options,user_data_dir:chrome.profile,endpoint:chrome.endpoint,
      actor,round_id,head,binding_sha256:binding,gated_command:gate.command,
      gate_ref:ref(root+'/auxiliary/'+name+'/gate.json'),release_ref:ref(root+'/auxiliary/'+name+'/release.json')};
    const checkout = {schema:'c17-direct-round-source-checkout-v1',product_source_root:source,head,git_head:head};
    const documents = new Map([
      [root+'/authorization/context.json',context],[context.source_checkout_ref.path,checkout],
      [chrome.start_ref.path,start],[start.gate_ref.path,gate],
      [start.release_ref.path,{gate,identity:birth}],
    ]);
    const environment = {C17_AUX_CONTEXT_REF:JSON.stringify(ref(root+'/authorization/context.json')),
      C17_SESSION_ROOT:root,C17_SESSION_STAGE:stage,C17_SESSION_ACTOR:actor,
      C17_SESSION_ROUND_ID:round_id,C17_SESSION_HEAD:head,C17_SESSION_DECISION_ID:decision,
      C17_SESSION_BINDING_SHA256:binding};
    const proc = {argv:['synthetic-node',root+'/'+context.source_script],env:environment,
      hrtime:{bigint:()=>1000000000n}};
    let tick = 0, sequence = 0, lastRequest = null, requestRef = null, connectCalls = 0;
    const observedRequests = [];
    let mutateResponse = value => value;
    const checked = reference => {
      check(documents.has(reference.path), 'Synthetic reference absent');
      return JSON.stringify(documents.get(reference.path));
    };
    const helper = compileHelper({realpathSync:path=>path},checked,()=>registry,()=>head,proc,
      ()=>{throw new Error('Unexpected hash in isolated dependency test');},()=>String(++sequence).padStart(32,'0'),x=>x,x=>x);
    function parseContext() {return helper.environmentContext(environment);}
    function auxiliary() {
      return helper.createAuxiliary(parseContext(),{
        clock:()=>tick,wallClock:()=>1700000000,pause:async()=>{tick+=.01;},checkedRef:checked,
        referenceOf:path=>ref(path),publishNew:(path,value)=>{lastRequest=value;observedRequests.push(clone(value));requestRef=ref(path);return requestRef;},
        readPublished:()=>{
          const observation={schema:'c17-runtime78-owned-listener-observation-v1',status:'owned',
            actor,round_id,head,qa_root:root,stage,port:17594,journal:root+'/ownership-traces.jsonl',
            root_identity:birth,pid:birth.pid,identity:birth,scans:[{pids:[birth.pid]},{pids:[birth.pid]}]};
          const obsRef=ref(root+'/synthetic-observation.json');documents.set(obsRef.path,observation);
          return mutateResponse({schema:'c17-runtime78-owned-listener-response-v1',status:'owned',
            request:requestRef,observation:obsRef,actor,round_id,head,qa_root:root,stage,port:lastRequest.port});
        },
      });
    }
    const browser = {version:()=> 'synthetic-chrome',newContext:async()=>({})};
    const chromium = {launch:async()=>{throw new Error('Local launch is forbidden');},
      connectOverCDP:async(endpoint,opts)=>{connectCalls++;check(endpoint===chrome.endpoint&&eq(opts,{timeout:5000}),'Exact CDP call');return browser;}};
    return {helper,context,registry,chrome,start,gate,checkout,documents,environment,proc,birth,options,parseContext,auxiliary,chromium,browser,
      observedRequests,connectCount:()=>connectCalls,setTick:value=>{tick=value;},
      responseMutator:func=>{mutateResponse=func;},root};
  }

  async function positive(name, body) {
    try {await body();cases.push({name,expected:'pass',observed:'pass',passed:true});}
    catch(error){cases.push({name,expected:'pass',observed:'error',passed:false,error:String(error)});}
  }
  async function negative(name, body) {
    try {await body();cases.push({name,expected:'refusal',observed:'accepted',passed:false});}
    catch(error){
      const instrument = error instanceof ReferenceError || error instanceof TypeError || error instanceof PureAssertionError;
      cases.push({name,expected:'refusal',observed:instrument?'instrument_error':'refusal',
        passed:!instrument,error:String(error)});
    }
  }

  for(const stage of Object.keys(fixture().helper.AB_DIRECT_SITES)) {
    await positive('actual_helper_exact_site_'+stage,async()=>{
      const f=fixture(stage);await f.auxiliary().connect(f.chromium,f.options);
      check(f.connectCount()===1&&f.observedRequests.length===1,'One fresh owned request before CDP');
      check(f.observedRequests[0].port===17594&&f.observedRequests[0].deadline_seconds===5,'Fixed bounds');
    });
  }
  for(const [name, mutate] of [
    ['missing_context',f=>{delete f.environment.C17_AUX_CONTEXT_REF;}],
    ['wrong_actor',f=>{f.environment.C17_SESSION_ACTOR='/root/fabricated';}],
    ['wrong_round',f=>{f.environment.C17_SESSION_ROUND_ID='c17-direct-round-b-123456789abc';}],
    ['wrong_head',f=>{f.environment.C17_SESSION_HEAD='b'.repeat(40);}],
    ['wrong_stage',f=>{f.environment.C17_SESSION_STAGE='P162';}],
    ['wrong_root',f=>{f.environment.C17_SESSION_ROOT=f.root+'-extra';}],
    ['wrong_source_script',f=>{f.context.source_script='runtime/other.mjs';}],
    ['source_absent_argv',f=>{f.proc.argv=['synthetic-node'];}],
    ['checkout_head_mismatch',f=>{f.checkout.git_head='b'.repeat(40);}],
    ['registry_actor_mismatch',f=>{f.registry.actor='/root/fabricated';}],
    ['registry_binding_mismatch',f=>{f.registry.binding_sha256='c'.repeat(64);}],
    ['registry_decision_mismatch',f=>{f.registry.decision_id='other';}],
  ]) await negative('actual_environment_'+name,async()=>{const f=fixture();mutate(f);f.parseContext();});

  for(const [name, mutate] of [
    ['headless',f=>{f.options.headless=true;}],
    ['channel',f=>{f.options.channel='chromium';}],
    ['sandbox',f=>{f.options.chromiumSandbox=false;}],
    ['arguments',f=>{f.chrome.original_options=clone(f.options);f.options.args.push('--no-sandbox');}],
    ['port',f=>{f.chrome.port=17595;}],
    ['endpoint_port',f=>{f.chrome.endpoint='ws://127.0.0.1:17293/devtools/browser/nonce';f.start.endpoint=f.chrome.endpoint;}],
    ['endpoint_host',f=>{f.chrome.endpoint='ws://example.invalid:17594/devtools/browser/nonce';f.start.endpoint=f.chrome.endpoint;}],
    ['endpoint_credentials',f=>{f.chrome.endpoint='ws://a:b@127.0.0.1:17594/devtools/browser/nonce';f.start.endpoint=f.chrome.endpoint;}],
    ['missing_release',f=>{f.start.released=false;}],
    ['birth_mismatch',f=>{f.start.root_identity=clone(f.birth);f.start.root_identity.birth_usec++;}],
    ['gate_uid',f=>{f.gate.uid++;}],
    ['foreign_response',f=>{f.responseMutator(value=>({...value,actor:'/root/fabricated'}));}],
    ['late_response',f=>{f.responseMutator(value=>{f.setTick(5.001);return value;});}],
  ]) await negative('actual_connect_'+name,async()=>{
    const f=fixture();mutate(f);try {await f.auxiliary().connect(f.chromium,f.options);}
    finally {check(f.connectCount()===0,'Refusal before any CDP');}
  });

  await positive('trace_and_get_decorators_after_actual_cdp',async()=>{
    const f=fixture('P162'),events=[],callbacks={},traceWrites=[];let newContexts=0,bindings=0,initScripts=0,localLaunches=0;
    const requests=[],routes=[];
    const context={exposeBinding:async(name,callback)=>{bindings++;check(name==='__c16ObservedTrustedAction','Trace binding preserved');callbacks.binding=callback;},
      addInitScript:async callback=>{initScripts++;callbacks.init=callback;},
      on:(name,callback)=>{callbacks[name]=callback;},route:async(pattern,handler,options)=>{routes.push({pattern,handler,options});}};
    f.browser.newContext=async options=>{newContexts++;check(options.acceptDownloads===false,'GET download guard preserved');return context;};
    f.chromium.launch=async()=>{localLaunches++;throw new Error('Local launch forbidden');};
    const processDouble={env:{C16_ACTION_TRACE:'/synthetic-action-trace.json'},once:(name,callback)=>{callbacks['process-'+name]=callback;},exitCode:0};
    check(traceSource.startsWith("import {connectOwnedChrome} from './auxiliary-ports/runtime/aux_node.mjs';\n"),'Actual rendered import');
    const traceBody=traceSource.replace(/^import .*;\n/gm,'').replaceAll('import.meta.url',"'file:///synthetic/trace-chrome.mjs'");
    const evaluateTrace=new Function('readFileSync','writeFileSync','join','chromium','connectOwnedChrome','process',traceBody+'; return trace;');
    const config={actor:f.context.actor,round_id:f.context.round_id,head:f.context.head};
    const owned=f.auxiliary();
    const trace=evaluateTrace(()=>JSON.stringify(config),(path,raw)=>traceWrites.push({path,raw}),()=>'',f.chromium,
      (chromium,options)=>owned.connect(chromium,options),processDouble);
    const journalAnchor='const journal={policy:';
    const journal=p162Source.slice(p162Source.indexOf(journalAnchor),p162Source.indexOf('const rawFetch='));
    const chain=p162Source.slice(p162Source.indexOf('const realLaunch=chromium.launch.bind(chromium);'),p162Source.indexOf('assert.equal(journal.blocked.length,0);'));
    check(journal.startsWith(journalAnchor)&&chain.startsWith('const realLaunch='),'GET actual anchors');
    const decorateGet=new Function('chromium',journal+chain+'; return journal;');
    const get=decorateGet(f.chromium);
    const browser=await f.chromium.launch(clone(f.options));
    await browser.newContext({viewport:{width:1440,height:900}});
    check(localLaunches===0&&f.connectCount()===1,'Owned CDP only');
    check(trace.launches.length===1&&eq(trace.launches[0].options,f.options),'Launch options retained in trace');
    check(bindings===1&&initScripts===1&&get.contexts===1&&newContexts===1,'Both nested decorators retained');
    check(routes.length===1&&routes[0].pattern==='**/*','GET route before navigation');
    callbacks.binding({page:{url:()=> 'http://127.0.0.1:5173/demo'}},{type:'click',trusted:true});
    check(trace.events.length===1&&trace.events[0].trusted===true,'Actual trace callback stores action');
    let aborted=0,delegated=0;
    await context.route('**/*',()=>{delegated++;});
    const handler=routes.at(-1).handler;
    await handler({request:()=>({method:()=> 'POST',url:()=> 'http://127.0.0.1:17593/api/clients'}),abort:async()=>{aborted++;}},{});
    check(aborted===1&&delegated===0&&get.blocked.length===1,'POST really rejected by unchanged GET body');
    await handler({request:()=>({method:()=> 'GET',url:()=> 'http://127.0.0.1:17593/api/clients'}),abort:async()=>{aborted++;}},{});
    check(delegated===1&&aborted===1,'Allowed GET delegated');
    callbacks['process-exit']();
    const recorded=JSON.parse(traceWrites[0].raw);
    check(recorded.process_exit_code===0&&recorded.events.length===1&&recorded.status==='observations_collected_not_semantic_verdict','Trace is observation, not success');
  });
  return {schema:'c17-ab-direct-cdp-v8-pure-tests-v1',scope:'pure_dependency_doubles_only',
    actor:'/root/cycle17_gate_review',round_id:null,cases,tests:cases.length,
    passed:cases.every(value=>value.passed),runtime_enabled:false,os_startup_qualified:false,
    limits:['Actual selected source bodies, dependency/FS/publication/birth doubles explicit',
      'No physical source checkout, socket, Chrome, product Node job, Session or native lifecycle executed',
      'No total confinement or A/B admission proved, no WRAPPER success reused']};
}
