import * as fs from 'node:fs';
import {createHash} from 'node:crypto';
import {runPure} from './pure_js_cases.mjs';

const root = new URL('.', import.meta.url).pathname.replace(/\/$/, '');
const out = process.argv[2];
if (!/^\/private\/tmp\/therese-c17-ab-direct-cdp-node-[a-zA-Z0-9]+$/.test(out)
    || fs.realpathSync(out) !== out || out === root) throw new Error('Fresh pure-test output required');
const digest = raw => createHash('sha256').update(raw).digest('hex');
const manifest = JSON.parse(fs.readFileSync(root + '/INPUTS-COMPLETE.json', 'utf8'));
const ref = path => {
  const raw = fs.readFileSync(path), stat = fs.lstatSync(path);
  if (!stat.isFile() || stat.isSymbolicLink()) throw new Error('Regular pure source required');
  return {path,sha256:digest(raw),bytes:raw.length};
};
const inputPaths = manifest.files.map(row => row.copy);
for (const row of manifest.files) {
  const got = ref(row.copy);
  if (got.sha256 !== row.sha256 || got.bytes !== row.bytes) throw new Error('Definition fixture pin changed');
}
const own = ['run_node_pure.mjs','pure_js_cases.mjs','node-pure.sb','render_direct_cdp.py',
  'INPUTS-COMPLETE.json','preview-definition-only/trace-chrome.mjs'].map(path => root + '/' + path);
const pins_before = [...inputPaths, ...own].map(ref);
const started_at = new Date().toISOString(), started = performance.now();
let result;
try {
  result = await runPure({
    auxiliarySource:fs.readFileSync(root+'/preimages-complete/aux_node.mjs','utf8'),
    traceSource:fs.readFileSync(root+'/preview-definition-only/trace-chrome.mjs','utf8'),
    p162Source:fs.readFileSync(root+'/preimages-complete/complements/instruments/p162-garde-get-v3.mjs','utf8'),
  });
} catch (error) {
  result = {schema:'c17-ab-direct-cdp-v8-pure-tests-v1',passed:false,tests:0,cases:[],instrument_error:String(error)};
}
const pins_after = [...inputPaths, ...own].map(ref);
const command = ['/usr/bin/sandbox-exec','-D','DEFINITION_ROOT='+root,'-D','OUTPUT_ROOT='+out,
  '-f',root+'/node-pure.sb',process.execPath,root+'/run_node_pure.mjs',out];
const receipt = {...result,execution_surface:'Node22 builtin URL / selected source bodies / explicit dependency doubles',
  started_at,completed_at:new Date().toISOString(),elapsed_ms:performance.now()-started,
  pins_before,pins_after,pins_unchanged:JSON.stringify(pins_before)===JSON.stringify(pins_after),
  command,environment:{HOME:out,TMPDIR:out,PATH:'/usr/bin:/bin',LANG:'C',LC_ALL:'C'},
  os_policy:'deny default; process-exec only physical Node22; process-fork/network/system-socket denied; writes output only',
  actual_native_lifecycle:false,source_scripts_evaluated_as_modules:false};
receipt.passed = receipt.passed && receipt.pins_unchanged;
fs.writeFileSync(out+'/receipt.json',JSON.stringify(receipt,null,2)+'\n',{flag:'wx',mode:0o600});
console.log(JSON.stringify({tests:receipt.tests,passed:receipt.passed,receipt:out+'/receipt.json',failed:receipt.cases.filter(row=>!row.passed)}));
process.exitCode = receipt.passed ? 0 : 1;
