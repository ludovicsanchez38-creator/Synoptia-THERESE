# Dérivation fermée du profil des tests Node purs

Préparation uniquement. Aucun Node ni test ni service lancé dans ce dossier.
Aucune permission de produit, Chrome, G1 ou A/B n'est créée. Le gel CDP
`a6875329…` et son rouge 134 restent inchangés et physiquement rehashés.

Le seul delta du profil est :

```lisp
(allow file-read-data (literal "/"))
```

Il porte sur le répertoire racine uniquement, sans subpath ni droit ajouté sur
ses descendants. Fork, réseau, socket, Mach lookup et autres exec demeurent
interdits ; les écritures restent limitées à OUTPUT_ROOT et /dev/null comme
dans le profil initial. Node22 physique reste le seul exec permis.

La commande proposée est dans COMMAND-PROPOSED.json. Elle exécuterait le runner
et les définitions au gel CDP original, sous le nouveau profil, avec HOME/TMPDIR
et deux flux dans la sortie fraîche `/private/tmp/therese-c17-ab-direct-cdp-node-PCyIK8wE`.
Cette sortie est encore vide. Le root doit lire et autoriser cette commande
avant tout rejeu ; aucune preuve de réussite n'est anticipée.

Le runner, ses tests et quinze définitions sont préservés byte-exacts dans
source-observations, soit 22 copies au total avec renderer/manifeste/preview.
Les recettes C16 restent des définitions historiques de tests, jamais des
résultats ou inputs A/B courants. Les assertions, options et oracles ne sont
pas modifiés. Le profil rouge est conservé dans preimages/node-pure.sb.

## Diagnostic primaire

Le refus kernel du 8 octobre à 15:15:01.511739 UTC nomme Node PID62155,
thread4674065 et `deny(1) file-read-data /`. Le rapport IPS correspondant
(SHA3bb384c0…, 5 752 octets) porte le même PID/thread, SIGABRT et une pile dyld
ignition_halt/boot_boot/CacheFinder, avant toute frame Node. Les deux flux de
l'essai rouge ont été créés à 15:15:01 UTC. Le journal montre ce PID encore zsh
à .476008, puis le refus Node. Aucun autre processus n'a été investigué.

diagnostic-log-capture.json conserve exactement la chaîne stdout de l'appel
réel b742d9 dans un champ JSON, pas un export original du log store. Le crash
est copié byte-exact. Il n'existe pas de ledger birth ni d'argv non anonymisé
dans l'IPS. Ce diagnostic établit un obstacle de startup, pas une qualification
exhaustive ni la preuve que cette seule règle suffira.

## Provenance du futur reçu

Le runner byte-exact écrit un champ `command` contenant le profil historique
node-pure.sb. Il ne faut pas le présenter comme preuve du profil nouveau.
La future qualification doit lier séparément la commande réellement exécutée,
le nouveau profil rehashé avant/après et le reçu contrôleur root, en conservant
le brut du runner inchangé. Les pins internes du runner couvrent le profil
ancien et ses textes ; ils ne couvrent pas automatiquement ce nouveau profil.

Ce gel conserve cette limite explicitement. Root GO, résultats JS courants et
qualification OS sont absents. Aucun succès WRAPPER n'est repris.
