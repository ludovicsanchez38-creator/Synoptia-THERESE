"""Pure tests of the renderer, historical definition fixtures only."""
import ast
import copy
import hashlib
import json
from pathlib import Path
import unittest

BASE = Path(__file__).resolve().parent


def load_renderer():
    tree = ast.parse((BASE / "render_direct_cdp.py").read_text())
    permitted = {"__future__", "hashlib", "pathlib", "re"}
    for node in tree.body:
        if isinstance(node, ast.ImportFrom):
            assert node.module in permitted
        if isinstance(node, ast.Import):
            assert all(value.name in permitted for value in node.names)
    namespace = {"__name__": "renderer_pure_extracted"}
    exec(compile(tree, str(BASE / "render_direct_cdp.py"), "exec"), namespace)
    return namespace


class RendererTests(unittest.TestCase):
    def setUp(self):
        self.ns = load_renderer()
        rows = json.loads((BASE / "INPUTS-COMPLETE.json").read_text())["files"]
        self.sources = {}
        self.pins = {}
        for row in rows:
            raw = Path(row["copy"]).read_bytes()
            self.assertEqual(raw, Path(row["path"]).read_bytes())
            self.assertEqual(hashlib.sha256(raw).hexdigest(), row["sha256"])
            self.assertEqual(len(raw), row["bytes"])
            self.sources[row["name"]] = raw.decode()
            self.pins[row["name"]] = {"sha256": row["sha256"], "bytes": row["bytes"]}
        self.definitions = {key: self.sources[key] for key in self.ns["REQUIRED_PATHS"]}
        self.arguments = {"helper_source": self.sources["aux_node.mjs"], "helper_pin": self.pins["aux_node.mjs"],
            "root": "/private/tmp/therese-c17-direct-round-a-123456789abc", "actor": "/root",
            "round_id": "c17-direct-round-a-123456789abc", "head": "a" * 40}

    def render(self, definitions=None, pins=None, **kwargs):
        return self.ns["render"](definitions if definitions is not None else self.definitions,
            pins if pins is not None else {key: self.pins[key] for key in self.definitions},
            **(self.arguments | kwargs))

    def test_one_trace_delta_nine_jobs_and_all_unchanged_bytes(self):
        result = self.render()
        self.assertEqual(result["changed_paths"], ["trace-chrome.mjs"])
        self.assertEqual(len(result["direct_jobs"]), 9)
        self.assertEqual(len(result["definitions"]), 10)
        for name in self.definitions.keys() - {"trace-chrome.mjs"}:
            self.assertEqual(result["definitions"][name], self.definitions[name])
        trace = result["definitions"]["trace-chrome.mjs"]
        self.assertEqual(trace, self.ns["IMPORT"] + self.definitions["trace-chrome.mjs"].replace(self.ns["ANCHOR"], self.ns["REPLACEMENT"]))

    def test_round_b_exact_scope(self):
        result = self.render(root="/private/tmp/therese-c17-direct-round-b-123456789abc", round_id="c17-direct-round-b-123456789abc", actor="/root/environment_routes")
        self.assertEqual(result["identity"]["round_name"], "B")

    def test_closed_flags(self):
        result = self.render()
        self.assertIs(result["runtime_enabled"], False)
        self.assertIs(result["os_startup_qualified"], False)
        self.assertEqual(result["admission_table"], {})
        self.assertEqual(result["capabilities"], {})
        self.assertIs(self.ns["RUNTIME_ENABLED"], False)
        self.assertEqual(self.ns["ADMISSION_TABLE"], {})

    def test_wrong_actor(self):
        with self.assertRaisesRegex(ValueError, "actor"):
            self.render(actor="/root/fabricated")

    def test_wrong_round(self):
        with self.assertRaisesRegex(ValueError, "round"):
            self.render(round_id="c17-direct-round-b-123456789abc")

    def test_wrong_head(self):
        with self.assertRaisesRegex(ValueError, "HEAD"):
            self.render(head="not-a-head")

    def test_wrapper_not_ab(self):
        with self.assertRaisesRegex(ValueError, "A/B"):
            self.render(root="/private/tmp/therese-c17-wrapper-canary-123456789abc")

    def test_root_parent_traversal(self):
        with self.assertRaisesRegex(ValueError, "A/B"):
            self.render(root="/private/tmp/./therese-c17-direct-round-a-123456789abc")

    def test_missing_recipe(self):
        definitions = self.definitions.copy()
        definitions.pop("runtime/recette-c17.mjs")
        with self.assertRaisesRegex(ValueError, "eight"):
            self.render(definitions)

    def test_unlisted_recipe(self):
        with self.assertRaisesRegex(ValueError, "eight"):
            self.render(self.definitions | {"other.mjs": "x"})

    def test_source_hash_mismatch(self):
        definitions = self.definitions.copy()
        definitions["runtime/recette-c17.mjs"] += "\n// altered\n"
        with self.assertRaisesRegex(ValueError, "SHA/bytes"):
            self.render(definitions)

    def test_source_size_mismatch(self):
        pins = {key: self.pins[key].copy() for key in self.definitions}
        pins["trace-chrome.mjs"]["bytes"] += 1
        with self.assertRaisesRegex(ValueError, "SHA/bytes"):
            self.render(pins=pins)

    def test_duplicate_trace_anchor_even_repinned(self):
        definitions = self.definitions.copy()
        definitions["trace-chrome.mjs"] += self.ns["ANCHOR"] + "\n"
        pins = {key: self.ns["pin"](value) for key, value in definitions.items()}
        with self.assertRaisesRegex(ValueError, "Unique"):
            self.render(definitions, pins)

    def test_trace_option_guard_missing_even_repinned(self):
        definitions = self.definitions.copy()
        definitions["trace-chrome.mjs"] = definitions["trace-chrome.mjs"].replace("options.headless!==false", "options.headless!==true")
        pins = {key: self.ns["pin"](value) for key, value in definitions.items()}
        with self.assertRaisesRegex(ValueError, "Trace"):
            self.render(definitions, pins)

    def test_helper_mutation_even_repinned(self):
        helper = self.sources["aux_node.mjs"] + "\n// changed\n"
        with self.assertRaisesRegex(ValueError, "helper"):
            self.render(helper_source=helper, helper_pin=self.ns["pin"](helper))

    def test_p162_chain_missing_even_repinned(self):
        definitions = self.definitions.copy()
        definitions[self.ns["GUARD_PATH"]] = definitions[self.ns["GUARD_PATH"]].replace("acceptDownloads:false", "acceptDownloads:true")
        pins = {key: self.ns["pin"](value) for key, value in definitions.items()}
        with self.assertRaisesRegex(ValueError, "P162"):
            self.render(definitions, pins)

    def test_recipe_duplicate_launch_even_repinned(self):
        definitions = self.definitions.copy()
        definitions["runtime/recette-c17.mjs"] += "\nawait chromium.launch({});\n"
        pins = {key: self.ns["pin"](value) for key, value in definitions.items()}
        with self.assertRaisesRegex(ValueError, "one original"):
            self.render(definitions, pins)

    def test_p157_two_widths_one_source_preserved(self):
        result = self.render()
        sites = dict(self.ns["DIRECT_SITES"])
        self.assertEqual(sites["P157-800"], sites["P157-1440"])
        self.assertEqual(result["definitions"][sites["P157-800"]], self.definitions[sites["P157-800"]])

    def test_no_return_code_reclassification(self):
        result = self.render()
        for name in self.definitions.keys() - {"trace-chrome.mjs"}:
            self.assertEqual(result["definitions"][name].count("process.exit"), self.definitions[name].count("process.exit"))
        self.assertNotIn("exitCode", self.ns["REPLACEMENT"])
