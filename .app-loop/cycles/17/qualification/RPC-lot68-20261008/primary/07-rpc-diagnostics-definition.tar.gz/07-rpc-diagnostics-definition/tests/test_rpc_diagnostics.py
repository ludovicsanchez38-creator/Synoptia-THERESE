"""Pure synthetic exceptions and lifecycle doubles, no G1 or OS qualification."""
from __future__ import annotations

from contextlib import contextmanager
import json
import os
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
import unittest

import rpc_diagnostics as diagnostic
import rpc_protocol as p
import rpc_client as client
import rpc_dispatcher as dispatcher
import session_rpc_adapter as adapter


@contextmanager
def attributes(obj, **values):
    previous = {k: getattr(obj, k) for k in values}
    try:
        for k, v in values.items():
            setattr(obj, k, v)
        yield
    finally:
        for k, v in previous.items():
            setattr(obj, k, v)


def causal():
    inner = ValueError("CDP observation failed: synthetic only")
    outer = p.RpcPrelaunchRefused("prelaunch refused: synthetic only")
    outer.__cause__ = inner
    return outer


class DiagnosticTests(unittest.TestCase):
    def assert_bounded(self, value):
        self.assertIsNotNone(diagnostic.validated_exception_diagnostic(value))
        self.assertLessEqual(len(diagnostic._encoded(value)), 16384)
        self.assertLessEqual(len(value["nodes"]), 8)
        for node in value["nodes"]:
            self.assertLessEqual(len(node["message"].encode("utf-8")), 1024)

    def test_simple(self):
        value = diagnostic.exception_diagnostic(ValueError("exact"))
        self.assertEqual(value["nodes"][0]["message"], "exact")
        self.assertEqual(value["nodes"][0]["type"], "ValueError")
        self.assertIs(value["diagnostic_only"], True)
        self.assert_bounded(value)

    def test_explicit_cause(self):
        value = diagnostic.exception_diagnostic(causal())
        self.assertEqual([x["relation"] for x in value["nodes"]], ["outer", "cause"])
        self.assertEqual(value["nodes"][1]["type"], "ValueError")

    def test_implicit_context(self):
        outer = RuntimeError("outer")
        outer.__context__ = ValueError("context")
        self.assertEqual(diagnostic.exception_diagnostic(outer)["nodes"][1]["relation"], "context")

    def test_cause_precedes_context(self):
        outer = causal()
        outer.__context__ = LookupError("ignored context")
        value = diagnostic.exception_diagnostic(outer)
        self.assertEqual(len(value["nodes"]), 2)
        self.assertNotIn("ignored context", diagnostic._encoded(value).decode())

    def test_from_none_suppresses_context(self):
        try:
            try:
                raise ValueError("hidden")
            except ValueError:
                raise RuntimeError("visible") from None
        except RuntimeError as error:
            value = diagnostic.exception_diagnostic(error)
        self.assertEqual(len(value["nodes"]), 1)
        self.assertIs(value["nodes"][0]["suppress_context"], True)

    def test_explicit_cause_despite_suppression(self):
        outer = causal()
        outer.__suppress_context__ = True
        self.assertEqual(len(diagnostic.exception_diagnostic(outer)["nodes"]), 2)

    def test_self_cycle(self):
        outer = RuntimeError("cycle")
        outer.__cause__ = outer
        value = diagnostic.exception_diagnostic(outer)
        self.assertEqual(len(value["nodes"]), 1)
        self.assertIs(value["cycle_detected"], True)

    def test_two_node_context_cycle(self):
        first, second = RuntimeError("first"), ValueError("second")
        first.__context__, second.__context__ = second, first
        value = diagnostic.exception_diagnostic(first)
        self.assertEqual(len(value["nodes"]), 2)
        self.assertIs(value["cycle_detected"], True)

    def chain(self, size, message="chain"):
        current = ValueError(message)
        for _ in range(size - 1):
            outer = RuntimeError(message)
            outer.__cause__ = current
            current = outer
        return current

    def test_depth_limit(self):
        value = diagnostic.exception_diagnostic(self.chain(20))
        self.assertEqual(len(value["nodes"]), 8)
        self.assertIs(value["depth_truncated"], True)
        self.assert_bounded(value)

    def test_exact_depth_not_truncated(self):
        self.assertIs(diagnostic.exception_diagnostic(self.chain(8))["depth_truncated"], False)

    def test_multibyte_utf8_bound(self):
        value = diagnostic.exception_diagnostic(ValueError("é😀" * 1000))
        self.assertIs(value["nodes"][0]["message_truncated"], True)
        self.assert_bounded(value)

    def test_ascii_bound(self):
        value = diagnostic.exception_diagnostic(ValueError("x" * 20000))
        self.assertEqual(len(value["nodes"][0]["message"]), 1024)
        self.assert_bounded(value)

    def test_surrogate_is_serializable(self):
        value = diagnostic.exception_diagnostic(ValueError("bad\ud800text"))
        self.assertEqual(value["nodes"][0]["message"], "bad?text")
        self.assert_bounded(value)

    def test_bad_str_does_not_break_refusal(self):
        class BadStr(Exception):
            def __str__(self):
                raise KeyboardInterrupt("synthetic __str__ failure")
        value = diagnostic.exception_diagnostic(BadStr())
        self.assertEqual(value["nodes"][0]["message"], "<exception message unavailable>")
        self.assert_bounded(value)

    def test_json_escape_budget(self):
        value = diagnostic.exception_diagnostic(self.chain(8, "\x00" * 1024))
        self.assertIs(value["budget_truncated"], True)
        self.assertGreaterEqual(len(value["nodes"]), 1)
        self.assertLess(len(value["nodes"]), 8)
        self.assert_bounded(value)

    def test_non_exception_fallback(self):
        value = diagnostic.exception_diagnostic({"FULL": True})
        self.assertIs(value["serializer_failed"], True)
        self.assertEqual(value["nodes"], [])
        self.assert_bounded(value)

    def test_no_traceback_locals_or_authority_fields(self):
        value = diagnostic.exception_diagnostic(causal())
        self.assertEqual(set(value), diagnostic._KEYS)
        self.assertTrue(all(set(x) == diagnostic._NODE_KEYS for x in value["nodes"]))
        value["FULL"] = True
        self.assertIsNone(diagnostic.validated_exception_diagnostic(value))

    def test_bad_schema_ignored(self):
        value = diagnostic.exception_diagnostic(causal())
        value["schema"] = "authority"
        self.assertIsNone(diagnostic.validated_exception_diagnostic(value))

    def test_bool_index_ignored(self):
        value = diagnostic.exception_diagnostic(causal())
        value["nodes"][0]["index"] = False
        self.assertIsNone(diagnostic.validated_exception_diagnostic(value))

    def test_oversized_remote_message_ignored(self):
        value = diagnostic.exception_diagnostic(causal())
        value["nodes"][0]["message"] = "é" * 1024
        self.assertIsNone(diagnostic.validated_exception_diagnostic(value))

    def test_display_ignores_invalid_diagnostic(self):
        text = diagnostic.exception_record_text({"type": "ValueError", "reason": "legacy", "diagnostic": {"FULL": True}})
        self.assertEqual(json.loads(text), {"type": "ValueError", "reason": "legacy"})

    def test_display_bounded_without_mutating_ack(self):
        error = diagnostic.exception_fields(self.chain(8, "\x00" * 1024))
        before = diagnostic._encoded(error)
        text = diagnostic.exception_record_text(error | {"id": "rpc-synthetic"})
        self.assertLessEqual(len(text.encode("utf-8")), 16384)
        self.assertEqual(diagnostic._encoded(error), before)


class ConsumerTests(unittest.TestCase):
    def setUp(self):
        self.temp = TemporaryDirectory(prefix="synthetic-", dir=os.environ["RPC_CAUSE_FIXTURES"])
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.row = {"id": "rpc-test-pytest-positive", "requester_id": "rpc-all-test_runner", "index": 0,
                    "nonce": "1" * 32, "source_refs": [], "cwd": str(self.root),
                    "stdout_path": str(self.root / "stdout"), "stderr_path": str(self.root / "stderr")}
        self.request_ref = {"path": str(self.root / "request.json"), "sha256": "0" * 64, "bytes": 0}

    def owner_double(self):
        obj = object.__new__(dispatcher.RpcDispatcher)
        obj.root = self.root
        obj.errors, obj.jobs, obj.next_index = [], {}, {}
        obj.enrollments = {self.row["requester_id"]: {"identity": {}}}
        obj.context = {}
        obj.tainted_requesters = set()
        obj._taint = obj.tainted_requesters.add
        obj._authenticate = lambda *args: {"synthetic": True}
        obj.parent_quiescent = lambda name: True
        obj._acks = []
        obj._ack = lambda *args, **kwargs: (obj._acks.append((args, kwargs)) or {"synthetic_ack": True})
        return obj

    def test_real_refuse_body_preserves_cause_and_taint(self):
        obj = self.owner_double()
        obj._refuse(self.row, self.request_ref, causal())
        error = obj.errors[0]
        self.assertEqual(error["phase"], "accept_or_begin_refused")
        self.assertEqual(error["diagnostic"]["nodes"][1]["type"], "ValueError")
        self.assertEqual(obj._acks[0][1]["error"], error)
        self.assertEqual(obj.jobs[self.row["id"]]["state"], "error")
        self.assertIn(self.row["requester_id"], obj.tainted_requesters)

    def test_real_terminal_refusal_body_preserves_cause(self):
        obj = self.owner_double()
        obj.adapter = SimpleNamespace(poll=lambda token: {"state": "complete"})
        def refuse(row, observation):
            raise causal()
        obj._validate_terminal = refuse
        job = {"row": self.row, "request_ref": self.request_ref, "token": "synthetic-token", "abort_reason": None}
        with attributes(p, event_path=lambda *args: self.root / "absent-cancel"):
            obj._poll_job(job)
        self.assertEqual(obj.errors[0]["phase"], "terminal_refusal")
        self.assertEqual(obj._acks[0][1]["error"]["diagnostic"], obj.errors[0]["diagnostic"])
        self.assertEqual(job["state"], "error")

    def test_real_accept_partial_launch_keeps_cleanup_pending_without_ack(self):
        obj = self.owner_double()
        def begin(row, ref):
            error = p.RpcCleanupUncertain("synthetic partial launch", token="known-token")
            error.__cause__ = ValueError("synthetic cleanup refused")
            raise error
        obj.adapter = SimpleNamespace(begin=begin)
        with attributes(p, reference=lambda path: self.request_ref, read_committed=lambda *args: {},
                        validate_request=lambda *args: None, fresh_budget=lambda *args: None,
                        inside=lambda *args, **kwargs: None):
            obj.clock = lambda: 100.0
            obj._accept(self.row, self.root / "request.json")
        job = obj.jobs[self.row["id"]]
        self.assertEqual(job["state"], "cleanup_pending")
        self.assertEqual(job["token"], "known-token")
        self.assertEqual(job["error"]["diagnostic"]["nodes"][1]["type"], "ValueError")
        self.assertEqual(obj._acks, [])

    def test_unknown_requester_not_adopted(self):
        obj = self.owner_double()
        obj.enrollments = {}
        obj.adapter = SimpleNamespace(begin=lambda *args: self.fail("unknown requester launched"))
        with attributes(p, reference=lambda path: self.request_ref):
            obj._accept(self.row, self.root / "request.json")
        self.assertEqual(obj.jobs[self.row["id"]]["state"], "error")
        self.assertEqual(obj.errors[0]["diagnostic"]["nodes"][0]["type"], "RpcInstrumentError")

    def test_real_client_error_body_displays_cause_without_remote_exception_class(self):
        obj = object.__new__(client.FileRpcTransport)
        obj.context = {"actor": "/root", "round_id": "synthetic", "head": "0" * 40, "context_id": "0" * 32}
        ack = p.common(obj.context) | {"schema": p.ACK_SCHEMA, "request_ref": self.request_ref,
            "descriptor_digest": p.digest(self.row), "id": self.row["id"], "index": 0,
            "nonce": self.row["nonce"], "state": "error", "instrument_error": p.exception_fields(causal())}
        with self.assertRaises(p.RpcInstrumentError) as caught:
            obj._check_ack(ack, self.row, self.request_ref)
        self.assertIn("CDP observation failed", str(caught.exception))
        self.assertIsNone(caught.exception.__cause__)

    def test_real_client_invalid_diagnostic_still_refuses(self):
        obj = object.__new__(client.FileRpcTransport)
        obj.context = {"actor": "/root", "round_id": "synthetic", "head": "0" * 40, "context_id": "0" * 32}
        ack = p.common(obj.context) | {"schema": p.ACK_SCHEMA, "request_ref": self.request_ref,
            "descriptor_digest": p.digest(self.row), "id": self.row["id"], "index": 0,
            "nonce": self.row["nonce"], "state": "error", "instrument_error": {"reason": "legacy", "diagnostic": {"FULL": True}}}
        with self.assertRaises(p.RpcInstrumentError) as caught:
            obj._check_ack(ack, self.row, self.request_ref)
        self.assertIn("legacy", str(caught.exception))
        self.assertNotIn("FULL", str(caught.exception))

    def adapter_double(self, *, partial=False):
        obj = object.__new__(adapter.SessionRpcAdapter)
        row = self.row | {"schema": p.DESCRIPTOR_SCHEMA, "stage_name": self.row["id"],
            "logical_parent_id": self.row["requester_id"], "role": "stage-" + self.row["id"],
            "timeout_seconds": 90, "mode": "web", "argv": ["synthetic-python"], "environment": {}}
        self.row = row
        session = SimpleNamespace(handles={}, log_stability_tainted=False, round_name="RPC_CANARY",
            validate_sources=lambda: None, finish=lambda roles: None)
        def start(*args, **kwargs):
            if partial:
                session.handles[row["id"]] = {"process": None, "root_identity": None}
            raise causal()
        session.start = start
        session.binding = {"rpc_descriptors": {row["id"]: row}, "commands": {row["id"]: obj._command_spec(row)}}
        obj.session, obj.root = session, self.root
        obj.protocol = p
        obj.api = {"RPC_CHILDREN": {row["id"]: (row["requester_id"], 90, "web")},
            "reference": lambda path: self.request_ref, "read_published_json": lambda *args: {}}
        obj._observed = {row["requester_id"]: {"synthetic": True}}
        obj._live_requester = lambda *args: None
        obj._check_refs = lambda *args: None
        obj._tokens, obj._seen_nonces = {}, set()
        obj.context, obj.enrollments = {}, {row["requester_id"]: {}}
        return obj

    def test_real_adapter_begin_retains_prelaunch_cause(self):
        obj = self.adapter_double()
        with attributes(p, validate_descriptor=lambda *args: None, event_path=lambda *args: Path(self.request_ref["path"]),
                        validate_request=lambda *args: None, fresh_budget=lambda *args: None):
            with self.assertRaises(p.RpcPrelaunchRefused) as caught:
                obj.begin(self.row, self.request_ref)
        slot = next(iter(obj._tokens.values()))
        self.assertEqual(slot["exception_diagnostic"]["nodes"][1]["message"], "CDP observation failed: synthetic only")
        self.assertIsNone(slot["entry"])
        self.assertIsNotNone(caught.exception.__cause__)
        self.assertIs(obj.session.log_stability_tainted, True)

    def test_real_adapter_begin_retains_partial_handle_without_false_birth(self):
        obj = self.adapter_double(partial=True)
        with attributes(p, validate_descriptor=lambda *args: None, event_path=lambda *args: Path(self.request_ref["path"]),
                        validate_request=lambda *args: None, fresh_budget=lambda *args: None):
            with self.assertRaises(p.RpcCleanupUncertain) as caught:
                obj.begin(self.row, self.request_ref)
        slot = obj._tokens[caught.exception.token]
        self.assertIs(slot["entry"], obj.session.handles[self.row["id"]])
        self.assertIsNone(slot["entry"]["root_identity"])
        self.assertEqual(slot["exception_diagnostic"]["nodes"][1]["type"], "ValueError")

    def test_real_adapter_finish_adds_diagnostic_to_cleanup_and_observation_only(self):
        obj = object.__new__(adapter.SessionRpcAdapter)
        identity = {"pid": 101, "start_sec": 1, "start_usec": 2, "ppid": 100, "uid": 501, "pgid": 101}
        entry = {"name": self.row["id"], "role": "stage-" + self.row["id"], "root_identity": identity,
                 "terminal_receipt_ref": {"synthetic": True}, "folder": self.root}
        raw = {"cleanup": {"clean": True, "remaining_attributed": [], "ambiguities": [], "errors": [], "signals": []},
               "stdout": {"synthetic_stdout": True}, "stderr": {"synthetic_stderr": True},
               "termination_proved": True, "output_archived": True, "output_archive_errors": [],
               "cleanup_deadline_met": True, "cleanup_elapsed_seconds": 0.1, "exit_code": -6}
        saved = []
        obj.session = SimpleNamespace(round_name="RPC_CANARY", log_stability_tainted=False, finish=lambda roles: None)
        obj.root, obj.protocol, obj.context = self.root, p, {}
        obj.api = {"RPC_REQUESTERS": set(), "checked_json_ref": lambda *args: raw,
            "save": lambda root, path, value: saved.append(value), "reference": lambda path: {"synthetic_cleanup": True}}
        slot = {"entry": entry, "name": entry["name"], "requester_id": self.row["requester_id"],
            "logical_parent_id": self.row["requester_id"], "request_ref": self.request_ref,
            "exception_diagnostic": p.exception_diagnostic(causal())}
        result = obj._finish(slot, terminal_state="error:launch_failure")
        self.assertEqual(result["exit_code"], -6)
        self.assertEqual(result["state"], "error")
        self.assertIs(result["tainted"], True)
        self.assertEqual(result["exception_diagnostic"], saved[0]["exception_diagnostic"])
        self.assertNotIn("exception_diagnostic", raw)

    def test_facade_preserves_raw_integer_codes(self):
        import subprocess
        for code in (0, 1, 2, -6):
            fake = SimpleNamespace(capture=lambda *args, code=code, **kwargs:
                subprocess.CompletedProcess(["synthetic-command"], code, "stdout", "stderr"))
            with client.use_transport(fake):
                result = client.capture_nested(["synthetic-command"], cwd=self.root, env={}, timeout=1,
                    stdout_path=self.root / "stdout", stderr_path=self.root / "stderr", label="synthetic")
            self.assertEqual(result.returncode, code)

    def checked_normal_fixture(self):
        obj = object.__new__(client.FileRpcTransport)
        obj.root = self.root
        obj.context = {"actor": "/root", "round_id": "synthetic", "head": "0" * 40, "context_id": "0" * 32}
        identity = {"pid": 101, "start_sec": 1, "start_usec": 2, "ppid": 100, "uid": 501, "pgid": 101}
        receipt_ref, cleanup_ref = {"kind": "synthetic-receipt"}, {"kind": "synthetic-cleanup"}
        ack = p.common(obj.context) | {"schema": p.ACK_SCHEMA, "request_ref": self.request_ref,
            "descriptor_digest": p.digest(self.row), "id": self.row["id"], "index": 0,
            "nonce": self.row["nonce"], "state": "complete", "exit_code": 0,
            "tainted": False, "termination_proved": True, "log_stability_proved": True,
            "cleanup_deadline_met": True, "signals": [], "child_identity": identity,
            "receipt_ref": receipt_ref, "cleanup_ref": cleanup_ref}
        raw = {"root_identity": identity, "exit_code": 0, "raw_stable": True, "timed_out": False,
               "log_stability_tainted": False, "instrument_error": None}
        cleanup = {"child_identity": identity, "clean": True, "log_stability_proved": True,
            "remaining_attributed": [], "ambiguities": [], "errors": [], "signals": [], "receipt_ref": receipt_ref}
        return obj, ack, raw, cleanup

    def test_real_client_normal_codes_include_negative_without_business_success_claim(self):
        obj, ack, raw, cleanup = self.checked_normal_fixture()
        with attributes(p, checked_json=lambda ref, **kwargs:
                        raw if ref == ack["receipt_ref"] else cleanup):
            for code in (-6, 0, 1, 2):
                ack["exit_code"] = raw["exit_code"] = code
                obj._check_ack(ack, self.row, self.request_ref)
                self.assertEqual(raw["exit_code"], code)

    def test_real_client_controller_signal_is_still_refused(self):
        obj, ack, raw, cleanup = self.checked_normal_fixture()
        ack["signals"] = ["SIGTERM"]
        ack["diagnostic"] = p.exception_diagnostic(ValueError("not authority"))
        with attributes(p, checked_json=lambda ref, **kwargs:
                        raw if ref == ack["receipt_ref"] else cleanup):
            with self.assertRaises(p.RpcInstrumentError):
                obj._check_ack(ack, self.row, self.request_ref)


if __name__ == "__main__":
    unittest.main()
