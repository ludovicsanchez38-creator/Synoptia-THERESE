# Observabilité des refus RPC de ROOT9

Statut : préparation fermée, diagnostic seulement. Auteur : /root/shared4_execution.
Aucun ROOT10, G1 entier, processus QA, socket, signal, navigateur, profil ou permission exécuté/modifié.

## Origines et delta

Les quatre préimages sont byte-exactes au transport-26 WRAPPER et aux quatre fichiers physiques ROOT9/source. ORIGINS.json contient les références SHA/bytes et la reconstruction exacte des quatre diffs. Aucune branche A/B du composite n'est utilisée.

Le helper source/rpc_diagnostics.py sérialise l'exception externe, son __cause__ explicite, sinon son __context__ non supprimé. Il conserve __suppress_context__, détecte les cycles, borne la profondeur à 8, chaque message UTF-8 à 1024 octets et le JSON du diagnostic à 16 KiB. Les troncatures et défauts de sérialisation sont signalés. Pas de traceback, locaux, arguments, environnement ni objet d'autorité. Le texte d'affichage client est également borné à 16 KiB. La taille globale d'un ACK conserve le plafond du protocole existant, ce n'est pas le plafond du diagnostic seul.

Les quatre consommateurs ajoutent/transmettent/affichent ces données, sans modifier les assertions de lifecycle, les décisions, l'identité/authentification, les codes bruts 0/1/2/négatifs, les taints, les tokens cleanup_pending ou les règles avant ACK. L'adapter n'altère aucun reçu G1 existant : le diagnostic va dans son résumé séparé et son observation. Toutes les autres fonctions et les constantes top-level ont été comparées par AST, sans import G1.

## Mesure pure réelle

Commande réellement exécutée une fois :
`/usr/bin/python3 -I -B /private/tmp/therese-c17-rpc-cause-observability-NRYrmF/run_pure.py --out /private/tmp/therese-c17-rpc-cause-pure-4DVPWm`

Reçu : /private/tmp/therese-c17-rpc-cause-pure-4DVPWm/receipt.json,
SHA c0ad5d5c47f2351ec50c78ab4fc223b2bdd3aef24545df9b0ccd9fb1a6c078de.
34 tests réellement OK, zéro erreur/échec/skip. stdout/stderr directs exclusifs, source11 avant/après égales, tentative interdite[] et fixtures après nettoyage[]. Les corps des vrais consommateurs sont sélectionnés par AST et exécutés avec doubles explicitement synthétiques. Cela ne qualifie ni OS, ni RPC natif, ni produit, ni FULL. Aucun ancien test n'est relabellé.

## Raccord futur au builder V9, non réalisé ici

Préimage builder : /private/tmp/therese-c17-fresh-wrapper-builder-v9-1G4jE1/build_fresh_wrapper.py.
Créer un successeur distinct, après revue/root GO exact ; ne pas modifier V9 ou ROOT9.

1. Pinner cet INDEX, les cinq sources et quatre diffs avant allocation. Vérifier les quatre anciennes empreintes transport-26, puis dériver les quatre copies source/ (builder lignes 935–937) avec les diffs exacts ; rpc_peer.py et rpc_unix.py restent byte-exacts.
2. Ajouter source/rpc_diagnostics.py à la copie core, à son manifeste et aux source_refs/binding avant import. CORE17 devient CORE18 de manière explicite. Aucun changement aux profils/G1/Chrome/argv/bornes/admission.
3. Les copies actives auxiliary-ports/runtime et auxiliary-ports/complements/instruments contiennent déjà les mêmes préimages client/protocole que ROOT9/source. Y appliquer les deux mêmes deltas diagnostic, ajouter dans chacune rpc_diagnostics.py byte-exact et publier un manifeste dérivé avec les anciennes références + diffs. Le protocole doit trouver ce sibling lors de l'import.
4. Garder intacts les onze fichiers de base et leur manifeste : leurs rpc_client/rpc_protocol historiques f718/11595 sont distincts des copies actives et ne sont pas les préimages de ce lot. Ne pas les remplacer silencieusement, ni élargir le renderer historique deux dépendances sans dérivation revue.
5. Recalculer toutes les empreintes des copies dérivées, metadata/manifestes/descriptors/enveloppes/plan/binding/GO. Table source76 à porter additivement, jamais par omission : trois nouveaux helpers physiques, quatre preuves diff et tous les chemins déjà exigés conservés. Les cardinalités finales doivent être dérivées de la table close réellement émise, pas d'anciens pins ROOT9. Inclure la nouvelle dépendance dans la validation physique avant import, dans chaque dossier qui importe le protocole dérivé.

Ces raccords builder/overlay/manifestes ne sont pas implémentés ni mesurés par ce gel. Le mécanisme n'importe pas de classe d'exception distante et ne confère aucune autorité à ses données. Une exception hostile in-process dont __str__ ne retourne pas n'est pas préemptée : borne de données, pas promesse de hard real-time. Les causes perdues dans les ACK historiques ROOT9 ne sont pas récupérables rétroactivement. ROOT9 demeure RED avec nettoyage physique favorable et taint maintenue.
