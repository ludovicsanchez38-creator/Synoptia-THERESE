"""Doubles/AST/fixtures fichier uniquement. Aucun build, G1, Node ou runtime.

Les fichiers temporaires des cas Emitter ne sont pas des racines WRAPPER_CANARY
construites. Les contrôles de profils ne compilent aucun Seatbelt.
"""
from __future__ import annotations

import ast
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('fresh_wrapper_builder_under_test', HERE / 'build_fresh_wrapper.py')
builder = importlib.util.module_from_spec(spec)
spec.loader.exec_module(builder)
ROOT = Path('/private/tmp/therese-c17-wrapper-canary-builderunittest0001')  # jamais créée par ces tests


class PureBuilderTests(unittest.TestCase):
    def test_runner_events_delta_is_single_exact_parent_addition(self):
        source = (HERE / 'preimages/run_wrapper_canary-a912.py').read_text()
        derived = builder.runner_events_delta(source)
        old = '    for folder in (root / "session-rpc", root / "output", root / "runtime/calibration",\n'
        new = '    for folder in (root / "session-events", root / "session-rpc", root / "output", root / "runtime/calibration",\n'
        self.assertEqual(derived.count(new), 1)
        self.assertEqual(derived.replace(new, old, 1), source)

    def test_runner_events_delta_refuses_reapplication_and_different_anchor(self):
        source = (HERE / 'preimages/run_wrapper_canary-a912.py').read_text()
        with self.assertRaisesRegex(ValueError, 'Table parents QA initiale'):
            builder.runner_events_delta(builder.runner_events_delta(source))
        with self.assertRaisesRegex(ValueError, 'Ancre session-rpc'):
            builder.runner_events_delta(source.replace('for folder in (root / "session-rpc",',
                                                       'for folder in (root / "wrong-channel",', 1))
        with self.assertRaisesRegex(ValueError, 'Fonction parents QA exacte'):
            builder.runner_events_delta(source.replace('def prepare_qa_directories(',
                                                       'def wrong_function(', 1))

    def test_actual_runner_parent_function_old_omits_new_creates_events(self):
        source = (HERE / 'preimages/run_wrapper_canary-a912.py').read_text()
        def selected_function(text):
            node = next(n for n in ast.parse(text).body if isinstance(n, ast.FunctionDef)
                        and n.name == 'prepare_qa_directories')
            return compile(ast.Module(body=[node], type_ignores=[]), '<pure-selected-parent-function>', 'exec')
        for text, expected in ((source, False), (builder.runner_events_delta(source), True)):
            with tempfile.TemporaryDirectory(prefix='therese-c17-builder-v2-unit-', dir='/private/tmp') as directory:
                root = Path(directory)
                profile = root / 'profiles/service'
                paths = {'profile': profile, 'home': profile / 'home', 'tmp': profile / 'tmp',
                         'data': profile / 'data', 'test_data': profile / 'test-data',
                         'logs_data': profile / 'logs-data', 'vite_cache': root / 'runtime/vite-cache'}
                blueprint = SimpleNamespace(exact_root=lambda value: value, paths=lambda value: paths)
                namespace = {'Path': Path, 'blueprint': blueprint, 'require': builder.need}
                exec(selected_function(text), namespace)
                with patch.object(builder.subprocess, 'run', side_effect=AssertionError('OS workload forbidden')):
                    namespace['prepare_qa_directories'](root)
                events = root / 'session-events'
                self.assertEqual(events.is_dir(), expected)
                if expected:
                    self.assertEqual(events.stat().st_mode & 0o777, 0o700)
                    self.assertEqual(list(events.iterdir()), [])
                self.assertTrue((root / 'session-rpc/request').is_dir())
                self.assertFalse((root / 'runtime/calibration/logs-rpc').exists())
                self.assertFalse((root / 'binding.json').exists())
                self.assertFalse((root / 'decision.json').exists())
                self.assertNotIn('runtime_session', sys.modules)

    def test_pth_exact_baseline_rejects_added_removed_or_changed(self):
        raw = (builder.PROOFS / 'python-metadata-result.json').read_bytes()
        pth = {item['path']: item for item in json.loads(raw)['pth']}
        builder.verify_pth_snapshot(pth, raw)
        first = next(iter(pth))
        changes = [dict(pth, **{'/private/tmp/fixture-added.pth': {'path': '/private/tmp/fixture-added.pth', 'sha256': 'a' * 64, 'bytes': 1}}),
                   {key: row for key, row in pth.items() if key != first},
                   dict(pth, **{first: dict(pth[first], sha256='b' * 64)})]
        for mutated in changes:
            with self.assertRaisesRegex(ValueError, 'Ensemble/ref pth exact'):
                builder.verify_pth_snapshot(mutated, raw)
        with self.assertRaisesRegex(ValueError, 'Baseline metadata'):
            builder.verify_pth_snapshot(pth, raw + b' ')

    def test_future_root_accepts_only_absent_exact_root(self):
        with patch.object(Path, 'exists', return_value=False), patch.object(Path, 'is_symlink', return_value=False):
            self.assertEqual(builder.future_root(ROOT), ROOT)
        with self.assertRaisesRegex(ValueError, 'Root neuf'):
            builder.future_root(Path('/Users/synoptia/.therese'))

    def test_future_root_rejects_existing_and_symlink(self):
        with patch.object(Path, 'exists', return_value=True), self.assertRaisesRegex(ValueError, 'Root neuf'):
            builder.future_root(ROOT)
        with patch.object(Path, 'exists', return_value=False), patch.object(Path, 'is_symlink', return_value=True):
            with self.assertRaisesRegex(ValueError, 'Root neuf'):
                builder.future_root(ROOT)

    def test_ast_delta_only_slot_and_unicode_byte_offsets(self):
        source = '"""définition é"""\nFLAG = False\nWRAPPER_ADMISSION_TABLE: dict[str, dict] = {}\n'
        output = builder.assignment_delta(source, 'WRAPPER_ADMISSION_TABLE', {}, builder.wrapper_slot(ROOT))
        self.assertIn('FLAG = False', output)
        value = ast.literal_eval(ast.parse(output).body[-1].value)
        self.assertEqual(value, builder.wrapper_slot(ROOT))

    def test_ast_delta_rejects_prebound_or_duplicate(self):
        with self.assertRaisesRegex(ValueError, 'Ancre AST'):
            builder.assignment_delta('X = {"old": 1}\n', 'X', {}, {'new': 2})
        with self.assertRaisesRegex(ValueError, 'Ancre AST'):
            builder.assignment_delta('X = {}\nX = {}\n', 'X', {}, {'new': 2})

    def test_sql_sha_is_derived_not_old_root_pin(self):
        source = 'SQL_CONTRACT_SHA = "' + builder.OLD_SQL_SHA + '"\nHEAD = "unchanged"\n'
        output = builder.assignment_delta(source, 'SQL_CONTRACT_SHA', builder.OLD_SQL_SHA, 'c' * 64)
        self.assertEqual(ast.literal_eval(ast.parse(output).body[0].value), 'c' * 64)
        self.assertIn('HEAD = "unchanged"', output)

    def test_real_g1_definition_stays_closed_without_import(self):
        raw = (builder.PREP / 'g1-26/runtime_session.py').read_text()
        builder.validate_closed_g1(raw)
        for old, new in (('RUNTIME_ENABLED = False', 'RUNTIME_ENABLED = True'),
                         ('OS_STARTUP_QUALIFIED = False', 'OS_STARTUP_QUALIFIED = True')):
            self.assertEqual(raw.count(old), 1)
            with self.assertRaisesRegex(ValueError, 'Base G1 non fermée'):
                builder.validate_closed_g1(raw.replace(old, new, 1))
        self.assertNotIn('runtime_session', sys.modules)

    def test_emitter_exclusive_regular_file_and_checked_ref(self):
        with tempfile.TemporaryDirectory(prefix='therese-c17-builder-unit-', dir='/private/tmp') as directory:
            emitter = builder.Emitter(Path(directory))
            ref = emitter.write('fixture/raw.txt', b'synthetic fixture\n')
            self.assertEqual(builder.checked(ref), b'synthetic fixture\n')
            with self.assertRaisesRegex(ValueError, 'Sortie déjà'):
                emitter.write('fixture/raw.txt', b'replace forbidden')
            with self.assertRaisesRegex(ValueError, 'Ref modifiée'):
                builder.checked(dict(ref, sha256='a' * 64))

    def test_emitter_rejects_escape_and_symlink_parent(self):
        with tempfile.TemporaryDirectory(prefix='therese-c17-builder-unit-', dir='/private/tmp') as directory:
            root = Path(directory)
            emitter = builder.Emitter(root)
            with self.assertRaisesRegex(ValueError, 'Sortie déjà'):
                emitter.write('../escape.txt', b'fixture')
            (root / 'real').mkdir()
            (root / 'alias').symlink_to(root / 'real', target_is_directory=True)
            with self.assertRaisesRegex(ValueError, 'Parent de sortie alias'):
                emitter.write('alias/fixture.txt', b'fixture')

    def test_web_wrong_sha_refused_before_allocation_or_node(self):
        with patch.object(builder.os, 'mkdir') as mkdir, patch.object(builder.subprocess, 'run') as node:
            with self.assertRaisesRegex(ValueError, 'Seul successor'):
                builder.build(ROOT, web_profile_ref=dict(builder.WEB, sha256='a' * 64), chrome_profile_ref=builder.CHROME_PROFILE, authority_ref={})
            mkdir.assert_not_called()
            node.assert_not_called()

    def test_pin_failure_refused_before_allocation_or_node(self):
        with patch.object(builder, 'checked', return_value=b'fixture'), \
             patch.object(builder, 'checked_chrome_successor', return_value=('before fixture', 'after fixture')), \
             patch.object(builder, 'construction_authority', return_value={}), \
             patch.object(builder, 'validate_indexes', side_effect=ValueError('Index changé fixture')), \
             patch.object(builder.os, 'mkdir') as mkdir, patch.object(builder.subprocess, 'run') as node:
            with self.assertRaisesRegex(ValueError, 'Index changé'):
                builder.build(ROOT, web_profile_ref=builder.WEB, chrome_profile_ref=builder.CHROME_PROFILE, authority_ref={})
            mkdir.assert_not_called()
            node.assert_not_called()

    def test_external_authority_and_actual_registry_are_required(self):
        self_ref = {'path': str(HERE / 'build_fresh_wrapper.py'), 'sha256': 'd' * 64, 'bytes': 1}
        registry_ref = {'path': '/private/tmp/fixture-registry.json', 'sha256': 'a' * 64, 'bytes': 1}
        authority = {'schema': 'c17-root-fresh-wrapper-preparation-go-v1', 'status': 'go_prepare_only',
            'scope': 'WRAPPER_CANARY', 'root': str(ROOT), 'actor': '/root', 'head': builder.HEAD,
            'product_source_root': str(builder.QA), 'web_profile_ref': builder.WEB,
            'chrome_profile_ref': builder.CHROME_PROFILE, 'runner_boundary_index_ref': self_ref,
            'origin_kind': 'root_tool_call', 'builder_ref': self_ref, 'identity_registry_ref': registry_ref,
            'gpu_observation_ref': {'path': '/private/tmp/fixture-gpu.raw', 'sha256': 'b' * 64, 'bytes': 1},
            'chrome_qa_copy_ref': {'path': '/private/tmp/fixture-copy-proof.json', 'sha256': 'c' * 64, 'bytes': 1}}
        registry = {'schema': 'c17-wrapper-canary-live-identity-registry-v1', 'head': builder.HEAD,
            'round_id': ROOT.name, 'chrome_profile_ref': builder.CHROME_PROFILE,
            'runner_boundary_index_ref': self_ref, 'actors': [{'actor': '/root', 'observed_by': 'SYNTHETIC_UNIT_DOUBLE',
                                             'observed_at_utc': '2026-10-08T00:00:00Z'}]}
        with patch.object(builder, 'reference', return_value=self_ref), \
             patch.object(builder, 'json_checked', side_effect=[authority, registry]), \
             patch.object(builder, 'checked', return_value=b'Metal: Supported'), \
             patch.object(builder, 'checked_chrome_qa_copy', return_value={'synthetic_unit_double': True}):
            self.assertEqual(builder.construction_authority(ROOT, {}, builder.WEB, builder.CHROME_PROFILE), authority)
        for changed in (dict(authority, root='/private/tmp/old'), dict(authority, actor='alias'),
                        dict(authority, status='runtime_go'), dict(authority, builder_ref={})):
            with patch.object(builder, 'reference', return_value=self_ref), \
                 patch.object(builder, 'json_checked', return_value=changed):
                with self.assertRaisesRegex(ValueError, 'GO externe'):
                    builder.construction_authority(ROOT, {}, builder.WEB, builder.CHROME_PROFILE)
        with patch.object(builder, 'reference', return_value=self_ref), \
             patch.object(builder, 'json_checked', side_effect=[authority, dict(registry, round_id='old-round')]):
            with self.assertRaisesRegex(ValueError, 'Registre réel neuf'):
                builder.construction_authority(ROOT, {}, builder.WEB, builder.CHROME_PROFILE)

    def test_node_vm_does_not_load_playwright_or_browser(self):
        self.assertNotIn('import(', builder.NODE_DEFAULTS_VM)
        self.assertNotIn('require(', builder.NODE_DEFAULTS_VM)
        self.assertIn('runInContext', builder.NODE_DEFAULTS_VM)
        self.assertIn('chromiumSandbox', (builder.PREP / 'auxiliary/source/chrome_contract.py').read_text())
        document = ast.parse((HERE / 'build_fresh_wrapper.py').read_text())
        imports = [node for node in ast.walk(document) if isinstance(node, (ast.Import, ast.ImportFrom))]
        self.assertFalse(any('runtime_session' in ast.unparse(node) for node in imports))
        self.assertIn("reference(Path(__file__).resolve()) == authority['builder_ref']", (HERE / 'build_fresh_wrapper.py').read_text())

    def test_candidate_index_resolves_only_its_own_relative_refs(self):
        pins, indexes = builder.validate_indexes()
        candidate = builder.CHROME_INDEX
        self.assertIn(candidate, indexes)
        self.assertIn(str(candidate.parent.parent / 'preimages/chrome-rootdomain.sb'), pins)
        self.assertIn(str(candidate.parent / 'chrome.sb'), pins)
        self.assertNotIn(str(builder.PREP / 'README.md'), pins)


class SuccessorV6Tests(unittest.TestCase):
    def test_only_exact_chrome_UI_then_unix_then_rootdomain_successor(self):
        before, after = builder.checked_rootdomain_successor(builder.CHROME_ROOTDOMAIN_PROFILE)
        self.assertEqual(len(after.encode()) - len(before.encode()), 760)
        self.assertEqual(after.count('(allow mach-lookup'), 1)
        self.assertEqual(after.count('(global-name "com.apple.coreservices.launchservicesd")'), 1)
        self.assertEqual(after.count('(global-name "com.apple.windowserver.active")'), 1)
        self.assertEqual(after.count('(allow system-socket (socket-domain AF_UNIX))'), 1)
        self.assertEqual(after.count('(allow network-bind (local unix-socket (subpath (param "TMP_ROOT"))))'), 1)
        self.assertEqual(after.count('(allow iokit-open-user-client (iokit-user-client-class "RootDomainUserClient"))'), 1)
        self.assertNotIn('(allow iokit-open-user-client)', after)
        self.assertNotIn('(allow iokit-open-service', after)
        self.assertNotIn('(allow network-outbound (remote unix-socket', after)
        for field, value in (('sha256', 'a' * 64), ('path', '/private/tmp/wrong/chrome.sb'), ('bytes', 1417)):
            with self.subTest(field=field), self.assertRaisesRegex(ValueError, 'Seul successor Chrome RootDomainUserClient'):
                builder.checked_rootdomain_successor(dict(builder.CHROME_ROOTDOMAIN_PROFILE, **{field: value}))

    def test_chrome_wrong_ref_refused_before_allocation(self):
        with patch.object(builder.os, 'mkdir') as mkdir, patch.object(builder.subprocess, 'run') as node:
            with self.assertRaisesRegex(ValueError, 'Seul successor Chrome V9'):
                builder.build(ROOT, web_profile_ref=builder.WEB,
                    chrome_profile_ref=dict(builder.CHROME_PROFILE, sha256='a' * 64), authority_ref={})
            mkdir.assert_not_called()
            node.assert_not_called()

    def test_chrome_mutated_permission_is_refused(self):
        before = (builder.PREP / 'g1-26/chrome.sb').read_bytes()
        ui = Path(builder.CHROME_UI_PROFILE['path']).read_bytes()
        unix = Path(builder.CHROME_UNIX_PROFILE['path']).read_bytes()
        after = Path(builder.CHROME_ROOTDOMAIN_PROFILE['path']).read_bytes()
        def checked_profile(ref):
            if ref == builder.CHROME_ROOTDOMAIN_PROFILE:
                return after + b'\n(allow network-bind)\n'
            return ui if ref in (builder.CHROME_UI_PROFILE, builder.CHROME_UNIX_PREIMAGE) else unix
        with patch.object(builder, 'regular_bytes', return_value=before), \
             patch.object(builder, 'checked', side_effect=checked_profile):
            with self.assertRaisesRegex(ValueError, 'RootDomainUserClient exact'):
                builder.checked_rootdomain_successor(builder.CHROME_ROOTDOMAIN_PROFILE)

    def test_chrome_wrong_preimage_is_refused(self):
        with patch.object(builder, 'regular_bytes', return_value=b'(deny default)\n'), \
             patch.object(builder, 'checked', return_value=b'fixture'):
            with self.assertRaisesRegex(ValueError, 'Préimage Chrome'):
                builder.checked_rootdomain_successor(builder.CHROME_ROOTDOMAIN_PROFILE)

    def test_unix_preimage_must_be_exact_UI_profile(self):
        before = (builder.PREP / 'g1-26/chrome.sb').read_bytes()
        ui = Path(builder.CHROME_UI_PROFILE['path']).read_bytes()
        unix = Path(builder.CHROME_UNIX_PROFILE['path']).read_bytes()
        after = Path(builder.CHROME_ROOTDOMAIN_PROFILE['path']).read_bytes()
        with patch.object(builder, 'regular_bytes', return_value=before), \
             patch.object(builder, 'checked', side_effect=[ui, unix, after, ui + b' ']):
            with self.assertRaisesRegex(ValueError, 'Préimage Unix différente'):
                builder.checked_rootdomain_successor(builder.CHROME_ROOTDOMAIN_PROFILE)

    def test_rootdomain_preimage_must_be_exact_unix_profile(self):
        before = (builder.PREP / 'g1-26/chrome.sb').read_bytes()
        ui = Path(builder.CHROME_UI_PROFILE['path']).read_bytes()
        unix = Path(builder.CHROME_UNIX_PROFILE['path']).read_bytes()
        after = Path(builder.CHROME_ROOTDOMAIN_PROFILE['path']).read_bytes()
        with patch.object(builder, 'regular_bytes', return_value=before), \
             patch.object(builder, 'checked', side_effect=[ui, unix, after, ui, unix + b' ']):
            with self.assertRaisesRegex(ValueError, 'Préimage RootDomain différente'):
                builder.checked_rootdomain_successor(builder.CHROME_ROOTDOMAIN_PROFILE)

    def source_groups(self):
        def ref(relative):
            return {'path': str(ROOT / relative), 'sha256': 'a' * 64, 'bytes': 1}
        required = ast.literal_eval(next(node.value for node in ast.parse(
            (builder.PREP / 'g1-26/runtime_session.py').read_text()).body
            if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name)
            and node.targets[0].id == 'WRAPPER_INSTRUMENTS'))
        base = [ref(p) for p in required]
        base += [ref('fixture-base-' + str(i)) for i in range(63 - len(base))]
        witness = [ref('authorization/runner-boundary/' + p) for p in builder.WITNESS_FILES]
        deltas = [ref('proofs/fixture-delta-' + str(i) + '.diff') for i in range(6)]
        return base, witness, deltas

    def test_table76_preserves_all63_and_thirteen_additions(self):
        base, witness, deltas = self.source_groups()
        refs = builder.join_sources76(base, witness, deltas)
        self.assertEqual(refs, base + witness + deltas)
        self.assertEqual(len(refs), 76)
        self.assertEqual(len({r['path'] for r in refs}), 76)

    def test_table73_or_duplicate_is_refused(self):
        base, witness, deltas = self.source_groups()
        with self.assertRaisesRegex(ValueError, r'sources63\+7\+6'):
            builder.join_sources76(base, witness, deltas[:3])
        duplicated = list(witness)
        duplicated[0] = base[0]
        with self.assertRaisesRegex(ValueError, 'refs76 divergente/doublonnée'):
            builder.join_sources76(base, duplicated, deltas)

    def test_actual_wrapper_consumer_guards_accept76_without_importing_g1(self):
        base, witness, deltas = self.source_groups()
        refs = builder.join_sources76(base, witness, deltas)
        def selected_guard(path, function_name, literal):
            document = ast.parse(path.read_text())
            function = next(node for node in document.body if isinstance(node, ast.FunctionDef)
                            and node.name == function_name)
            call = next(node for node in ast.walk(function) if isinstance(node, ast.Call)
                        and isinstance(node.func, ast.Name) and node.func.id == 'require'
                        and len(node.args) >= 2 and isinstance(node.args[1], ast.Constant)
                        and node.args[1].value == literal)
            return compile(ast.Expression(call.args[0]), '<pure-actual-consumer-guard>', 'eval')
        require_table = selected_guard(builder.PREP / 'coordinator/run_wrapper_canary.py',
            'read_inputs', 'Références instrument26 absentes/doublonnées')
        env = {'refs': refs, 'refs_data': {'schema': 'c17-wrapper-canary-source-refs-v1'},
               'SOURCE_REFS_SCHEMA': 'c17-wrapper-canary-source-refs-v1'}
        self.assertTrue(eval(require_table, env))
        env['refs'] = refs + [refs[0]]
        self.assertFalse(eval(require_table, env))
        g1 = builder.PREP / 'g1-26/runtime_session.py'
        require_sources = selected_guard(g1, 'load_wrapper_canary_admission',
            'Instruments wrappers manquants/doublons')
        required = tuple(row['path'].removeprefix(str(ROOT) + '/') for row in base[:17])
        env = {'refs': refs, 'root': ROOT, 'WRAPPER_INSTRUMENTS': required,
               'decision': {'instruments': refs}}
        self.assertTrue(eval(require_sources, env))
        env['refs'] = refs[1:]
        self.assertFalse(eval(require_sources, env))
        self.assertNotIn('runtime_session', sys.modules)

    def test_witness_inputs_are_seven_closed_definitions_and_observed_pures(self):
        self.assertEqual(len(builder.WITNESS_FILES), 7)
        self.assertEqual(set(builder.WITNESS_FILES), {
            'source/runner_boundary.py', 'INDEX.json', 'tests/test_runner_boundary.py',
            'proofs/pure-test-receipt.json', 'proofs/returned-output.log',
            'diffs/calibrate-test-runner.py.diff', 'diffs/wrapper_blueprint.py.diff'})
        receipt = json.loads((builder.WITNESS / 'proofs/pure-test-receipt.json').read_text())
        self.assertEqual(receipt['exec_result']['exit_code'], 0)
        self.assertTrue(receipt['pins_unchanged'])
        self.assertFalse(receipt['native_qualification'])

    def test_helper_then_sql_pin_derivations_preserve_other_content(self):
        boundary = builder.load_pure('c17_boundary_pure_unit', builder.WITNESS / 'source/runner_boundary.py')
        original = (builder.PREP / 'coordinator/wrapper_blueprint.py').read_text()
        with_rootdir = boundary.derive_blueprint(original)
        fresh = builder.assignment_delta(with_rootdir, 'SQL_CONTRACT_SHA', builder.OLD_SQL_SHA, 'c' * 64)
        restored = builder.assignment_delta(fresh, 'SQL_CONTRACT_SHA', 'c' * 64, builder.OLD_SQL_SHA)
        # assignment_delta emploie repr : seule la ponctuation des quotes du pin change.
        restored_tree, original_tree = ast.parse(restored), ast.parse(with_rootdir)
        self.assertEqual(ast.dump(restored_tree, include_attributes=False),
                         ast.dump(original_tree, include_attributes=False))
        self.assertEqual(with_rootdir.replace(boundary.BLUEPRINT_AFTER, boundary.BLUEPRINT_BEFORE), original)
        self.assertNotIn('runtime_session', sys.modules)

    def test_new_cli_requires_explicit_chrome_and_closed_authority(self):
        source = (HERE / 'build_fresh_wrapper.py').read_text()
        self.assertIn("parser.add_argument('--chrome-profile-ref', type=json.loads, required=True)", source)
        self.assertIn("body.get('chrome_profile_ref') == chrome_ref", source)
        self.assertIn("registry.get('chrome_profile_ref') == chrome_ref", source)
        self.assertIn("registry.get('runner_boundary_index_ref') == body['runner_boundary_index_ref']", source)
        self.assertIn("chrome_profile_ref=args.chrome_profile_ref", source)

    def test_order_before_allocation_and_final_source76(self):
        document = ast.parse((HERE / 'build_fresh_wrapper.py').read_text())
        function = next(n for n in document.body if isinstance(n, ast.FunctionDef) and n.name == 'build')
        text = ast.unparse(function)
        self.assertLess(text.index('checked_chrome_successor('), text.index('os.mkdir('))
        self.assertLess(text.index('validate_indexes('), text.index('os.mkdir('))
        self.assertLess(text.index('boundary.derive_overlay(overlay)'), text.index('for target, raw in overlay'))
        self.assertLess(text.index('boundary.derive_blueprint(blueprint_base)'), text.index("assignment_delta(blueprint_with_rootdir"))
        self.assertLess(text.index('join_sources76('), text.index("refs_ref = emitter.json('authorization/source-refs.json'"))
        self.assertIn("reference(root / 'g1/chrome.sb')", text)
        self.assertIn("cwd=str(root)", (HERE / 'build_fresh_wrapper.py').read_text())



class ChromeUIV6Tests(unittest.TestCase):
    def test_old_UI_profile_ref_refused_before_any_allocation(self):
        with patch.object(builder.os, 'mkdir') as mkdir, patch.object(builder.subprocess, 'run') as node:
            with self.assertRaisesRegex(ValueError, 'Seul successor Chrome V9'):
                builder.build(ROOT, web_profile_ref=builder.WEB,
                    chrome_profile_ref=builder.CHROME_UI_PROFILE, authority_ref={})
            mkdir.assert_not_called()
            node.assert_not_called()

    def test_old_metadata_only_ref_refused_before_any_allocation(self):
        old = {'path': '/private/tmp/therese-c17-chrome-metadata-only-1ma6wMfU/chrome.sb',
               'sha256': 'c2595ed573acee1f4bdac62ed46a043d1c051d9716545aa88a095a53e1467ec4',
               'bytes': 1194}
        with patch.object(builder.os, 'mkdir') as mkdir, patch.object(builder.subprocess, 'run') as node:
            with self.assertRaisesRegex(ValueError, 'Seul successor Chrome V9'):
                builder.build(ROOT, web_profile_ref=builder.WEB, chrome_profile_ref=old, authority_ref={})
            mkdir.assert_not_called()
            node.assert_not_called()

    def test_old_unix_profile_ref_refused_before_any_allocation(self):
        with patch.object(builder.os, 'mkdir') as mkdir, patch.object(builder.subprocess, 'run') as node:
            with self.assertRaisesRegex(ValueError, 'Seul successor Chrome V9'):
                builder.build(ROOT, web_profile_ref=builder.WEB,
                    chrome_profile_ref=builder.CHROME_UNIX_PROFILE, authority_ref={})
            mkdir.assert_not_called()
            node.assert_not_called()

    def test_UI_arbitrary_mach_or_metadata_permission_refused(self):
        before = (builder.PREP / 'g1-26/chrome.sb').read_bytes()
        ui = Path(builder.CHROME_UI_PROFILE['path']).read_bytes()
        unix = Path(builder.CHROME_UNIX_PROFILE['path']).read_bytes()
        after = Path(builder.CHROME_ROOTDOMAIN_PROFILE['path']).read_bytes()
        for mutant in (ui.replace(b'com.apple.windowserver.active', b'com.apple.other-service'),
                       ui + b'\n(allow file-read-metadata (subpath "/"))\n'):
            with self.subTest(mutant=mutant[-80:]), patch.object(builder, 'regular_bytes', return_value=before), \
                 patch.object(builder, 'checked', side_effect=[mutant, unix, after]):
                with self.assertRaisesRegex(ValueError, 'deux noms Mach'):
                    builder.checked_rootdomain_successor(builder.CHROME_ROOTDOMAIN_PROFILE)

    def test_unix_rights_cannot_expand_or_move_outside_tmp_root(self):
        before = (builder.PREP / 'g1-26/chrome.sb').read_bytes()
        ui = Path(builder.CHROME_UI_PROFILE['path']).read_bytes()
        unix = Path(builder.CHROME_UNIX_PROFILE['path']).read_bytes()
        after = Path(builder.CHROME_ROOTDOMAIN_PROFILE['path']).read_bytes()
        for mutant in (unix.replace(b'(allow network-bind (local unix-socket (subpath (param "TMP_ROOT"))))',
                                     b'(allow network-bind (local unix-socket (subpath (param "HOME_ROOT"))))', 1),
                       unix + b'\n(allow network-outbound (remote unix-socket (subpath "/private/tmp")))\n',
                       unix + b'\n(allow network-bind)\n'):
            def checked_profile(ref):
                if ref == builder.CHROME_UNIX_PROFILE:
                    return mutant
                if ref in (builder.CHROME_UI_PROFILE, builder.CHROME_UNIX_PREIMAGE):
                    return ui
                return after if ref == builder.CHROME_ROOTDOMAIN_PROFILE else unix
            with self.subTest(mutant=mutant[-100:]), patch.object(builder, 'regular_bytes', return_value=before), \
                 patch.object(builder, 'checked', side_effect=checked_profile):
                with self.assertRaisesRegex(ValueError, 'bind Unix local TMP_ROOT'):
                    builder.checked_rootdomain_successor(builder.CHROME_ROOTDOMAIN_PROFILE)

    def test_rootdomain_cannot_be_other_class_or_wildcard(self):
        before = (builder.PREP / 'g1-26/chrome.sb').read_bytes()
        ui = Path(builder.CHROME_UI_PROFILE['path']).read_bytes()
        unix = Path(builder.CHROME_UNIX_PROFILE['path']).read_bytes()
        after = Path(builder.CHROME_ROOTDOMAIN_PROFILE['path']).read_bytes()
        exact = b'(allow iokit-open-user-client (iokit-user-client-class "RootDomainUserClient"))'
        for mutant in (after.replace(exact, b'(allow iokit-open-user-client (iokit-user-client-class "AGXDeviceUserClient"))'),
                       after.replace(exact, b'(allow iokit-open-user-client)'),
                       after + b'\n(allow iokit-open-user-client)\n',
                       after + b'\n(allow iokit-open-service)\n'):
            def checked_profile(ref):
                if ref in (builder.CHROME_UI_PROFILE, builder.CHROME_UNIX_PREIMAGE):
                    return ui
                if ref == builder.CHROME_ROOTDOMAIN_PROFILE:
                    return mutant
                return unix
            with self.subTest(mutant=mutant[-100:]), patch.object(builder, 'regular_bytes', return_value=before), \
                 patch.object(builder, 'checked', side_effect=checked_profile):
                with self.assertRaisesRegex(ValueError, 'RootDomainUserClient exact'):
                    builder.checked_rootdomain_successor(builder.CHROME_ROOTDOMAIN_PROFILE)

    def test_all_nonprofile_functions_byte_or_AST_equivalent_to_v7(self):
        old = ast.parse((HERE / 'preimages/build_fresh_wrapper-v7.py').read_text())
        new = ast.parse((HERE / 'preimages/build_fresh_wrapper-v8.py').read_text())
        old_functions = {n.name: n for n in old.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))}
        new_functions = {n.name: n for n in new.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))}
        self.assertEqual(set(new_functions) - set(old_functions), {
            'chrome_contract_qa_delta', 'g1_chrome_executable_guard', 'chrome_tree_manifest',
            'checked_chrome_manifest', 'verify_chrome_tree_pair', 'verify_chrome_qa_tree'})
        self.assertEqual(set(old_functions) - set(new_functions), set())
        changed = {'chrome_prepare', 'checked_chrome_qa_copy', 'construction_authority', 'build'}
        for name in set(old_functions) - changed:
            with self.subTest(function=name):
                self.assertEqual(ast.dump(old_functions[name], include_attributes=False),
                                 ast.dump(new_functions[name], include_attributes=False))
        def assignments(tree):
            return {n.targets[0].id: ast.dump(n.value, include_attributes=False)
                    for n in tree.body if isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Name)}
        old_values, new_values = assignments(old), assignments(new)
        self.assertEqual(set(new_values) - set(old_values), {
            'G1_QA_PATHS_SHA', 'CHROME_CONTRACT_PREIMAGE_SHA', 'CHROME_CONTRACT_QA_REF'})
        self.assertTrue(all(old_values[k] == new_values[k] for k in old_values))
        self.assertNotIn('runtime_session', sys.modules)



class QACopyV7Tests(unittest.TestCase):
    PROOF = Path('/private/tmp/therese-c17-chrome-qa-copy-RoZmwsja/v3-receipt.json')
    PROOF_REF = {'path': str(PROOF), 'sha256': 'f97793cb43454051da734685185cb5d4e5b5ffbabc516580287195ef3d32993c', 'bytes': 17160}

    def test_profile_changes_exactly_one_subpath_and_no_permission(self):
        before, after = builder.checked_chrome_v8_successor(builder.CHROME_V8_PROFILE)
        old = Path(builder.CHROME_ROOTDOMAIN_PROFILE['path']).read_text()
        self.assertEqual(old.count('(subpath "/Applications/Google Chrome.app")'), 1)
        self.assertEqual(after, old.replace('(subpath "/Applications/Google Chrome.app")',
                          '(subpath "' + str(builder.CHROME_BUNDLE) + '")', 1))
        self.assertNotIn('(subpath "/Applications/Google Chrome.app")', after)
        self.assertEqual(after.count('RootDomainUserClient'), old.count('RootDomainUserClient'))

    def test_profile_rejects_reapplication_or_arbitrary_target_permission(self):
        real = builder.checked
        for mutant in (Path(builder.CHROME_V8_PROFILE['path']).read_bytes() + b'\n(allow network-outbound)\n',
                       Path(builder.CHROME_V8_PROFILE['path']).read_bytes().replace(str(builder.CHROME_BUNDLE).encode(), b'/private/tmp')):
            with self.subTest(mutant=mutant[-80:]), patch.object(builder, 'checked',
                 side_effect=lambda ref, m=mutant: m if ref == builder.CHROME_V8_PROFILE else real(ref)):
                with self.assertRaisesRegex(ValueError, 'seul subpath QA exact'):
                    builder.checked_chrome_v8_successor(builder.CHROME_V8_PROFILE)
        with self.assertRaisesRegex(ValueError, 'Seul successor'):
            builder.checked_chrome_v8_successor(builder.CHROME_ROOTDOMAIN_PROFILE)

    def test_real_g1_two_values_and_all_other_AST_identical(self):
        raw = (HERE / 'preimages/runtime_session-f8e9.py').read_text()
        derived = builder.g1_chrome_copy_delta(raw)
        self.assertEqual(derived.count(str(builder.CHROME)), 1)
        self.assertEqual(derived.count('bundle = Path('), raw.count('bundle = Path('))
        self.assertIn("bundle = Path(" + repr(str(builder.CHROME_BUNDLE)) + ")", derived)
        self.assertIn("CHROME = Path(" + repr(str(builder.CHROME)) + ")", derived)
        restored = derived.replace(repr(str(builder.CHROME)), '"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"', 1)
        restored = restored.replace(repr(str(builder.CHROME_BUNDLE)), '"/Applications/Google Chrome.app"', 1)
        self.assertEqual(restored, raw)
        builder.validate_closed_g1(derived)
        self.assertNotIn('runtime_session', sys.modules)

    def test_g1_refuses_other_preimage_or_reapplication_before_transformation(self):
        raw = (HERE / 'preimages/runtime_session-f8e9.py').read_text()
        for value in (raw + '\n', builder.g1_chrome_copy_delta(raw), raw.replace('OS_STARTUP_QUALIFIED = False','OS_STARTUP_QUALIFIED = True',1)):
            with self.assertRaisesRegex(ValueError, 'Préimage G1 effective'):
                builder.g1_chrome_copy_delta(value)

    def test_g1_slot_remains_exact_single_wrapper_and_other_flags_closed(self):
        raw = builder.g1_chrome_copy_delta((HERE / 'preimages/runtime_session-f8e9.py').read_text())
        derived = builder.assignment_delta(raw, 'WRAPPER_ADMISSION_TABLE', {}, builder.wrapper_slot(ROOT))
        tree = ast.parse(derived)
        values = {}
        for node in tree.body:
            target = node.target if isinstance(node, ast.AnnAssign) else node.targets[0] if isinstance(node, ast.Assign) and len(node.targets)==1 else None
            if isinstance(target,ast.Name) and target.id in {'WRAPPER_ADMISSION_TABLE','ADMISSION_TABLE','RUNTIME_ENABLED','OS_STARTUP_QUALIFIED','CAPABILITIES'}:
                values[target.id] = ast.literal_eval(node.value)
        self.assertEqual(values['WRAPPER_ADMISSION_TABLE'], builder.wrapper_slot(ROOT))
        self.assertEqual(values['ADMISSION_TABLE'], {})
        self.assertFalse(values['RUNTIME_ENABLED'])
        self.assertFalse(values['OS_STARTUP_QUALIFIED'])
        self.assertFalse(any(values['CAPABILITIES'].values()))

    def test_qa_bundle_is_one_fixed_path_and_five_jobs_unchanged(self):
        self.assertEqual(str(builder.CHROME_BUNDLE), '/private/tmp/therese-c17-chrome-qa-copy-RoZmwsja/Google Chrome.app')
        self.assertEqual(builder.CHROME, builder.CHROME_BUNDLE / 'Contents/MacOS/Google Chrome')
        self.assertEqual(builder.FRAMEWORK, builder.CHROME_BUNDLE / 'Contents/Frameworks/Google Chrome Framework.framework/Versions/154.0.8037.99/Google Chrome Framework')
        self.assertEqual(len(builder.JOBS), 5)
        source = (HERE / 'build_fresh_wrapper.py').read_text()
        self.assertNotIn("'bundle_root': '/Applications/Google Chrome.app'",source)
        self.assertIn("'bundle_root': str(CHROME_BUNDLE)",source)

    def test_actual_root_receipt_is_read_only_input_not_signature_execution(self):
        # Preuve réelle root, déjà produite, jamais une signature simulée par ces tests.
        proof = builder.checked_chrome_qa_copy(self.PROOF_REF)
        self.assertEqual(proof['target'], str(builder.CHROME_BUNDLE))
        self.assertTrue(proof['passed'])
        self.assertFalse(proof['runtime_admitted'])
        self.assertFalse(proof['FULL'])
        self.assertFalse(proof['source_copy_xattrs_identical'])
        self.assertTrue(proof['all_non_finderinfo_copy_baseline_attrs_unchanged'])

    def test_receipt_rejects_strict_red_timeout_duplicate_or_other_target(self):
        import copy
        original = json.loads(self.PROOF.read_bytes())
        for kind in ('status','signal','error','args','duplicate'):
            mutant = copy.deepcopy(original)
            call = next(c for c in mutant['calls'] if c['name']=='copy-strict-deep')
            if kind=='status':call['status']=1
            elif kind=='signal':call['signal']='SIGTERM'
            elif kind=='error':call['error']='instrument error'
            elif kind=='args':call['args'][-1]='/Applications/Google Chrome.app'
            else:mutant['calls'].append(copy.deepcopy(call))
            with self.subTest(kind=kind), patch.object(builder,'json_checked',return_value=mutant):
                with self.assertRaisesRegex(ValueError,'Strict profond'):
                    builder.checked_chrome_qa_copy(self.PROOF_REF)

    def test_receipt_rejects_lost_source_quarantine_metadata_or_hardlink(self):
        original=json.loads(self.PROOF.read_bytes())
        for field in ('byte_mode_link_equal','source_unchanged','no_hardlinks_to_source','all_non_finderinfo_copy_baseline_attrs_unchanged','quarantine_preserved'):
            with self.subTest(field=field), patch.object(builder,'json_checked',return_value=dict(original,**{field:False})):
                with self.assertRaisesRegex(ValueError,'Copie QA réelle'):
                    builder.checked_chrome_qa_copy(self.PROOF_REF)
        with patch.object(builder,'json_checked',return_value=dict(original,target='/private/tmp/other/Google Chrome.app')):
            with self.assertRaisesRegex(ValueError,'Copie QA réelle'):
                builder.checked_chrome_qa_copy(self.PROOF_REF)

    def test_proof_is_checked_before_allocation_and_linked_into_physical_refs(self):
        tree=ast.parse((HERE/'build_fresh_wrapper.py').read_text())
        construction=ast.unparse(next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='construction_authority'))
        build=ast.unparse(next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='build'))
        self.assertIn("checked_chrome_qa_copy(body['chrome_qa_copy_ref'])",construction)
        self.assertLess(build.index('construction_authority('),build.index('os.mkdir('))
        self.assertLess(build.index('g1_chrome_copy_delta('),build.index('os.mkdir('))
        self.assertIn("chrome_qa_copy_ref': authority['chrome_qa_copy_ref']",build)
        self.assertNotIn('runtime_session',sys.modules)


class QACopyV8Tests(unittest.TestCase):
    def fixture(self, folder):
        import shutil
        folder = folder.resolve(strict=True)
        source, target = folder / 'source', folder / 'copy'
        for p in (source / 'Contents/Resources', source / 'Contents/Versions/A', source / 'Contents/Versions/B'):
            p.mkdir(parents=True, exist_ok=True)
        (source / 'Contents/Resources/icon.txt').write_text('synthetic icon')
        (source / 'Contents/Versions/A/library.txt').write_text('synthetic A')
        (source / 'Contents/Versions/B/library.txt').write_text('synthetic B')
        (source / 'Contents/Current').symlink_to('Versions/A')
        shutil.copytree(source, target, symlinks=True)
        a, b = builder.chrome_tree_manifest(source), builder.chrome_tree_manifest(target)
        return source, target, a, b

    def test_helper_one_CHROME_constant_and_real_five_descriptors(self):
        old = (HERE / 'preimages/chrome_contract-original.py').read_text()
        new = builder.chrome_contract_qa_delta(old)
        self.assertEqual(new, Path(builder.CHROME_CONTRACT_QA_REF['path']).read_text())
        self.assertEqual(builder.reference(Path(builder.CHROME_CONTRACT_QA_REF['path'])),
                         builder.CHROME_CONTRACT_QA_REF)
        self.assertEqual(new.replace(repr(str(builder.CHROME)),
                         repr('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'), 1), old)
        namespace = {'__name__': 'SYNTHETIC_HELPER_UNIT_NAMESPACE'}
        exec(compile(new, 'actual QA helper pure definition', 'exec'), namespace)
        self.assertEqual(namespace['CHROME'], str(builder.CHROME))
        rows = namespace['plan'](ROOT)['jobs']
        self.assertEqual(set(rows), set(builder.JOBS))
        self.assertTrue(all(row['executable'] == str(builder.CHROME) for row in rows.values()))
        self.assertFalse(namespace['plan'](ROOT)['admission'])

    def test_helper_wrong_preimage_or_reapplication_refused(self):
        old = (HERE / 'preimages/chrome_contract-original.py').read_text()
        for value in (old + '\n', builder.chrome_contract_qa_delta(old), old.replace('CDP_PORT = 17594','CDP_PORT = 17293')):
            with self.subTest(value=value[:80]), self.assertRaisesRegex(ValueError, 'Préimage helper'):
                builder.chrome_contract_qa_delta(value)

    def g1_admission_fixture(self):
        import copy
        raw = builder.g1_chrome_executable_guard(builder.g1_chrome_copy_delta(
            (HERE / 'preimages/runtime_session-f8e9.py').read_text()))
        tree = ast.parse(raw)
        fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'validate_auxiliary_binding')
        helper_ns = {'__name__': 'SYNTHETIC_HELPER_UNIT_NAMESPACE'}
        exec(compile(Path(builder.CHROME_CONTRACT_QA_REF['path']).read_text(), 'actual helper', 'exec'), helper_ns)
        from types import SimpleNamespace
        rows = helper_ns['plan'](ROOT)['jobs']
        defaults = {}
        commands = {}
        for job, row in rows.items():
            argv = [str(builder.CHROME), '--user-data-dir=' + row['profile'], '--remote-debugging-port=17594',
                    '--remote-debugging-address=127.0.0.1']
            row.update(launch_defaults_ref={'fixture_default': job}, argv=argv, env={'SYNTHETIC_ENV': job},
                       cwd=str(ROOT), deadline=50)
            defaults[job] = {'schema': 'c17-wrapper-chrome-launch-defaults-v1',
                             'original_options': copy.deepcopy(row['original_options']),
                             'argv': list(argv), 'executable': str(builder.CHROME)}
            commands[row['name']] = {'argv': argv, 'role': row['role'], 'mode': 'chrome',
                'timeout_seconds': 50, 'env': row['env'], 'cwd': row['cwd'], 'stdout_path': row['stdout'],
                'stderr_path': row['stderr'], 'combine_stderr': False,
                'derived_deadline': 'start_monotonic_plus_exact_timeout'}
        file_refs = [builder.reference(builder.CHROME), builder.reference(builder.FRAMEWORK)]
        manifest = {'schema': 'c17-wrapper-chrome-bundle-files-v1', 'bundle_root': str(builder.CHROME_BUNDLE),
                    'files': file_refs}
        binding = {'auxiliary_descriptors': rows, 'commands': commands, 'actor': '/root',
                   'round_id': ROOT.name, 'chrome_files_ref': {'fixture_manifest': True}}
        ns = {'Path': Path, 'require': builder.need, 'CHROME': builder.CHROME,
            'CHROME_JOBS': builder.JOBS,
            'load_wrapper_helper': lambda *args: SimpleNamespace(plan=helper_ns['plan']),
            'checked_json_ref': lambda ref, root: defaults[ref['fixture_default']] if 'fixture_default' in ref else manifest,
            'validate_environment': lambda *args, **kwargs: None,
            'reference': lambda path: next(ref for ref in file_refs if ref['path'] == str(path))}
        exec(compile(ast.Module(body=[fn], type_ignores=[]), 'actual G1 admission body only', 'exec'), ns)
        return ns['validate_auxiliary_binding'], binding, defaults

    def test_actual_G1_body_accepts_exact_helper_argv_defaults_QA_without_import(self):
        verify, binding, defaults = self.g1_admission_fixture()
        verify(ROOT, binding, builder.HEAD, builder.QA)
        self.assertNotIn('runtime_session', sys.modules)

    def test_actual_G1_body_refuses_descriptor_argv_or_defaults_executable_mismatch(self):
        for field in ('descriptor', 'argv', 'defaults'):
            with self.subTest(field=field):
                verify, binding, defaults = self.g1_admission_fixture()
                job = builder.JOBS[0]
                if field == 'descriptor':
                    binding['auxiliary_descriptors'][job]['executable'] = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
                elif field == 'argv':
                    binding['auxiliary_descriptors'][job]['argv'][0] = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
                else:
                    defaults[job]['executable'] = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
                with self.assertRaises(ValueError):
                    verify(ROOT, binding, builder.HEAD, builder.QA)

    def test_G1_guard_is_exact_predicate_only_and_refuses_reapplication(self):
        old = builder.g1_chrome_copy_delta((HERE / 'preimages/runtime_session-f8e9.py').read_text())
        new = builder.g1_chrome_executable_guard(old)
        self.assertEqual(new.replace('\n                and row["executable"] == str(CHROME)', '', 1), old)
        builder.validate_closed_g1(new)
        for value in (old + '\n', new):
            with self.assertRaisesRegex(ValueError, 'Préimage G1 QA paths'):
                builder.g1_chrome_executable_guard(value)

    def test_chrome_prepare_refuses_old_helper_before_Node(self):
        from types import SimpleNamespace
        ns = {'__name__': 'SYNTHETIC_OLD_HELPER'}
        exec(compile((HERE / 'preimages/chrome_contract-original.py').read_text(), 'old helper pure', 'exec'), ns)
        emitter = SimpleNamespace(root=ROOT, write=lambda *args: {'path': '/private/tmp/SYNTHETIC_GPU'})
        with patch.object(builder, 'reference', return_value={'SYNTHETIC': True}), \
             patch.object(builder, 'checked', return_value=b'Metal: Supported'), \
             patch.object(builder.subprocess, 'run') as node:
            with self.assertRaisesRegex(ValueError, 'Helper/descriptors'):
                builder.chrome_prepare(emitter, SimpleNamespace(plan=ns['plan']), {}, builder.CHROME_QA_COPY_REF)
            node.assert_not_called()

    def test_actual_nonbinary_fixture_tree_is_accepted_then_byte_mutation_refused(self):
        with tempfile.TemporaryDirectory(prefix='v8-unit-tree-') as name:
            a, b, x, y = self.fixture(Path(name))
            result = builder.verify_chrome_tree_pair(a, b, x, y, entries=len(x))
            self.assertTrue(result['all_bytes_modes_UID_GID_links_equal'])
            self.assertFalse(result['codesign_reexecuted'])
            (b / 'Contents/Resources/icon.txt').write_text('changed icon bytes')
            with self.assertRaisesRegex(ValueError, 'Copie Chrome actuelle'):
                builder.verify_chrome_tree_pair(a, b, x, y, entries=len(x))

    def test_nonbinary_mode_mutation_refused(self):
        with tempfile.TemporaryDirectory(prefix='v8-unit-mode-') as name:
            a, b, x, y = self.fixture(Path(name))
            p = b / 'Contents/Resources/icon.txt'
            p.chmod(p.stat().st_mode ^ 0o100)
            with self.assertRaisesRegex(ValueError, 'Copie Chrome actuelle'):
                builder.verify_chrome_tree_pair(a, b, x, y, entries=len(x))

    def test_nonbinary_symlink_target_mutation_refused(self):
        with tempfile.TemporaryDirectory(prefix='v8-unit-link-') as name:
            a, b, x, y = self.fixture(Path(name))
            p = b / 'Contents/Current'
            p.unlink()
            p.symlink_to('Versions/B')
            with self.assertRaisesRegex(ValueError, 'Copie Chrome actuelle'):
                builder.verify_chrome_tree_pair(a, b, x, y, entries=len(x))

    def test_UID_GID_or_inode_archived_mismatch_refused(self):
        import copy
        with tempfile.TemporaryDirectory(prefix='v8-unit-owner-') as name:
            a, b, x, y = self.fixture(Path(name))
            for field in ('uid', 'gid', 'ino'):
                xa, ya = copy.deepcopy(x), copy.deepcopy(y)
                for rows in (xa, ya):
                    next(row for row in rows if row['relative'] == 'Contents/Resources/icon.txt')[field] += 1
                with self.subTest(field=field), self.assertRaisesRegex(ValueError, 'Source Chrome actuelle'):
                    builder.verify_chrome_tree_pair(a, b, xa, ya, entries=len(x))

    def test_extra_missing_duplicate_manifest_entry_or_extra_file_refused(self):
        import copy
        with tempfile.TemporaryDirectory(prefix='v8-unit-entries-') as name:
            a, b, x, y = self.fixture(Path(name))
            for mutated in (y[:-1], y + [copy.deepcopy(y[-1])]):
                with self.assertRaisesRegex(ValueError, 'Nombre manifest'):
                    builder.verify_chrome_tree_pair(a, b, x, mutated, entries=len(x))
            (b / 'unexpected').write_text('unexpected file')
            with self.assertRaisesRegex(ValueError, 'Nombre manifest'):
                builder.verify_chrome_tree_pair(a, b, x, y, entries=len(x))

    def test_hardlink_to_source_refused_even_when_byte_and_modes_match(self):
        import os
        with tempfile.TemporaryDirectory(prefix='v8-unit-hardlink-') as name:
            a, b, x, y = self.fixture(Path(name))
            p = b / 'Contents/Resources/icon.txt'
            p.unlink()
            os.link(a / 'Contents/Resources/icon.txt', p)
            fresh_a, fresh_b = builder.chrome_tree_manifest(a), builder.chrome_tree_manifest(b)
            with self.assertRaisesRegex(ValueError, 'Hardlink Chrome actuel'):
                builder.verify_chrome_tree_pair(a, b, fresh_a, fresh_b, entries=len(x))

    def test_escape_symlink_refused_without_following_data(self):
        with tempfile.TemporaryDirectory(prefix='v8-unit-escape-') as name:
            a, b, x, y = self.fixture(Path(name))
            p = b / 'Contents/Current'
            p.unlink()
            p.symlink_to(a / 'Contents/Versions/A')
            with self.assertRaisesRegex(ValueError, 'Lien Chrome hors bundle'):
                builder.chrome_tree_manifest(b)

    def test_real_root_1339_revalidation_contains_all_types_and_no_codesign(self):
        # Relecture effective, fichiers source/copie existants ; zéro commande OS.
        proof = json.loads(Path(builder.CHROME_QA_COPY_REF['path']).read_bytes())
        result = builder.verify_chrome_qa_tree(proof)
        self.assertEqual(result['entries'], 1339)
        self.assertEqual(result['types'], {'file': 697, 'directory': 635, 'symlink': 7})
        self.assertFalse(result['codesign_reexecuted'])
        self.assertFalse(result['xattrs_currently_measured'])

    def test_fresh_observations_and_derived_helper_linked_before_GO_without_changing_76(self):
        text = ast.unparse(ast.parse((HERE / 'build_fresh_wrapper.py').read_text()))
        self.assertIn("contract_qa = chrome_contract_qa_delta(contract_before)", text)
        self.assertIn("derivation': 'CHROME_QA_exact_constant_only'", text)
        self.assertIn("physical_observations['before']", text)
        self.assertLess(text.index('chrome_copy_after = verify_chrome_qa_tree('), text.index("go_ref = emitter.json('authorization/root-go.json'"))
        self.assertIn("chrome_contract_qa_ref': reference(root / 'source/chrome_contract.py')", text)
        self.assertIn('len(result) == len({ref[\'path\'] for ref in result}) == 76', text)
        self.assertNotIn("source_refs.append(contract_delta_ref)", text)
        self.assertNotIn('runtime_session', sys.modules)


class DirectoryReadsV9Tests(unittest.TestCase):
    def test_profile_pin_and_three_literal_additions_only(self):
        self.assertEqual(builder.reference(Path(builder.CHROME_PROFILE['path'])), builder.CHROME_PROFILE)
        before, after = builder.checked_chrome_successor(builder.CHROME_PROFILE)
        v8 = Path(builder.CHROME_V8_PROFILE['path']).read_text()
        self.assertEqual(before, (builder.PREP / 'g1-26/chrome.sb').read_text())
        self.assertEqual(after, Path(builder.CHROME_PROFILE['path']).read_text())
        expected = v8.replace(
            '(allow file-read-metadata (literal "/") (literal "/Applications") (literal "/private") (literal "/private/tmp"))',
            '(allow file-read-metadata (literal "/") (literal "/Applications") (literal "/private") (literal "/private/tmp")\n'
            '  (literal "/private/tmp/therese-c17-chrome-qa-copy-RoZmwsja"))', 1)
        expected = expected.replace('(allow file-read-data (literal "/"))',
            '(allow file-read-data (literal "/") (literal "/private/tmp")\n'
            '  (literal (param "QA_ROOT")))', 1)
        self.assertEqual(after, expected)
        self.assertNotIn('(subpath "/private/tmp")', after)
        self.assertNotIn('(subpath (param "QA_ROOT"))', after)
        self.assertEqual(after.count('iokit-user-client-class "RootDomainUserClient"'), v8.count('iokit-user-client-class "RootDomainUserClient"'))
        self.assertEqual(after.count('(local ip "localhost:17594")'), v8.count('(local ip "localhost:17594")'))

    def test_profile_rejects_wrong_sibling_broad_data_and_extra_mach(self):
        original = Path(builder.CHROME_PROFILE['path']).read_bytes()
        mutations = [
            original.replace(b'therese-c17-chrome-qa-copy-RoZmwsja"))', b'therese-c17-chrome-qa-copy-other"))', 1),
            original.replace(b'(literal "/private/tmp/therese-c17-chrome-qa-copy-RoZmwsja"))',
                             b'(subpath "/private/tmp/therese-c17-chrome-qa-copy-RoZmwsja"))', 1),
            original.replace(b'(allow file-read-data (literal "/") (literal "/private/tmp")\n  (literal (param "QA_ROOT")))',
                             b'(allow file-read-data (literal "/") (literal "/private/tmp")\n  (subpath (param "QA_ROOT")))', 1),
            original.replace(b'(literal "/private/tmp")\n  (literal (param "QA_ROOT")))', b'(subpath "/private/tmp")\n  (literal (param "QA_ROOT")))', 1),
            original.replace(b'(allow file-read-data (literal "/") (literal "/private/tmp")', b'(allow file-read-data (literal "/")', 1),
            original + b'\n(allow mach-lookup (global-name "com.apple.logd"))\n',
            original + b'\n(allow file-write* (subpath "/private/tmp"))\n',
        ]
        actual_checked = builder.checked
        for index, mutant in enumerate(mutations):
            self.assertNotEqual(mutant, original)
            with self.subTest(index=index), patch.object(builder, 'checked', side_effect=lambda ref, data=mutant: data if ref == builder.CHROME_PROFILE else actual_checked(ref)):
                with self.assertRaisesRegex(ValueError, 'trois lectures littérales'):
                    builder.checked_chrome_successor(builder.CHROME_PROFILE)

    def test_old_profile_or_pin_mutation_refused_before_allocation(self):
        with self.assertRaisesRegex(ValueError, 'Seul successor Chrome V9'):
            builder.checked_chrome_successor(builder.CHROME_V8_PROFILE)
        wrong = dict(builder.CHROME_PROFILE, sha256='a' * 64)
        with patch.object(builder.os, 'mkdir', side_effect=AssertionError('allocation forbidden')):
            with self.assertRaisesRegex(ValueError, 'Seul successor Chrome V9'):
                builder.build(ROOT, web_profile_ref=builder.WEB, chrome_profile_ref=builder.CHROME_V8_PROFILE, authority_ref={})
            with self.assertRaisesRegex(ValueError, 'Seul successor Chrome V9'):
                builder.build(ROOT, web_profile_ref=builder.WEB, chrome_profile_ref=wrong, authority_ref={})

    def test_no_other_builder_function_changed_from_v8(self):
        old = ast.parse((HERE / 'preimages/build_fresh_wrapper-v8.py').read_text())
        new = ast.parse((HERE / 'build_fresh_wrapper.py').read_text())
        old_functions = {n.name: n for n in old.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))}
        new_functions = {n.name: n for n in new.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))}
        self.assertEqual(set(new_functions) - set(old_functions), {'checked_chrome_v8_successor'})
        self.assertEqual(set(old_functions) - set(new_functions), set())
        for name in set(old_functions) - {'checked_chrome_successor'}:
            with self.subTest(function=name):
                self.assertEqual(ast.dump(old_functions[name], include_attributes=False),
                                 ast.dump(new_functions[name], include_attributes=False))

    def test_builder_links_same_profile_to_g1_go_and_receipt(self):
        source = (HERE / 'build_fresh_wrapper.py').read_text()
        self.assertIn('chrome_before, chrome_after = checked_chrome_successor(chrome_profile_ref)', source)
        self.assertLess(source.index('checked_chrome_successor(chrome_profile_ref)'), source.index('os.mkdir(root, 0o700)'))
        self.assertIn("else checked(chrome_profile_ref) if name == 'chrome.sb'", source)
        self.assertIn("'chrome_profile_ref': chrome_profile_ref", source)
        self.assertIn("'chrome_profile_ref': reference(root / 'g1/chrome.sb')", source)
        self.assertNotIn('runtime_session', sys.modules)


if __name__ == '__main__':
    unittest.main(verbosity=2)
