#!/usr/bin/env python3
"""Gel sélectif V10 : diffs et références, sans construction ni import G1."""
from __future__ import annotations

from datetime import UTC, datetime
import difflib
from hashlib import sha256
import json
import os
from pathlib import Path


HERE = Path(__file__).resolve().parent
V9 = Path('/private/tmp/therese-c17-fresh-wrapper-builder-v9-1G4jE1')
OBS = Path('/private/tmp/therese-c17-rpc-cause-observability-NRYrmF')
V9_INDEX_SHA = 'c217e93ab0379c964db7cb28cb6eee922438fb6b02cfa097088cfc97a4f81d37'
OBS_INDEX_SHA = '604e4e02062dd37cafbf9e67b2545b7697bad70a7aeac2825598cefaa63d7596'
DIFFS = {
    'build_fresh_wrapper.py': 'builder-v9-v10.diff',
    'test_build_fresh_wrapper.py': 'tests-v9-v10.diff',
    'run_pure.py': 'runner-v9-v10.diff',
}


def ref(path: Path) -> dict:
    raw = path.read_bytes()
    return {'path': str(path), 'sha256': sha256(raw).hexdigest(), 'bytes': len(raw)}


def new(path: Path, raw: bytes) -> None:
    fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(raw)


def main() -> None:
    os.umask(0o077)
    assert HERE.parent == Path('/private/tmp') and HERE.name.startswith('therese-c17-fresh-wrapper-builder-v10-')
    assert ref(V9 / 'INDEX.json')['sha256'] == V9_INDEX_SHA
    assert ref(OBS / 'INDEX.json')['sha256'] == OBS_INDEX_SHA
    assert (HERE / 'preimages/INDEX-v9.json').read_bytes() == (V9 / 'INDEX.json').read_bytes()
    assert (HERE / 'profile/chrome.sb').read_bytes() == (V9 / 'profile/chrome.sb').read_bytes()
    for filename, diffname in DIFFS.items():
        before = (V9 / filename).read_text().splitlines(True)
        after = (HERE / filename).read_text().splitlines(True)
        assert (HERE / 'preimages' / (filename.removesuffix('.py') + '-v9.py')).read_text().splitlines(True) == before
        diff = ''.join(difflib.unified_diff(before, after,
                                           fromfile='preimages/' + filename,
                                           tofile='candidate/' + filename)).encode()
        assert diff
        new(HERE / 'diffs' / diffname, diff)
    receipt = json.loads((HERE / 'proofs/pure-test-receipt.json').read_bytes())
    assert (receipt['schema'] == 'c17-wrapper-builder-v10-pure-tests-v1'
            and receipt['tests_run'] == 71 and receipt['failures'] == 0
            and receipt['errors'] == 0 and receipt['skips'] == 0
            and receipt['pins_unchanged'] is True and receipt['forbidden_attempts'] == []
            and receipt['native_executed'] is False and receipt['build_executed'] is False)
    for filename in ('build_fresh_wrapper.py', 'test_build_fresh_wrapper.py', 'run_pure.py', 'profile/chrome.sb'):
        key = str(HERE / filename)
        assert receipt['source_after'][key] == ref(HERE / filename)['sha256']
    selected = [HERE / name for name in (
        'build_fresh_wrapper.py', 'test_build_fresh_wrapper.py', 'run_pure.py',
        'index-v10.py', 'README.md', 'profile/chrome.sb',
        'preimages/build_fresh_wrapper-v9.py', 'preimages/test_build_fresh_wrapper-v9.py',
        'preimages/run_pure-v9.py', 'preimages/INDEX-v9.json', 'preimages/chrome-v9.sb',
        'diffs/builder-v9-v10.diff', 'diffs/tests-v9-v10.diff',
        'diffs/runner-v9-v10.diff', 'proofs/pure-test-receipt.json')]
    external = [V9 / 'INDEX.json', OBS / 'INDEX.json',
                OBS / 'ORIGINS.json', OBS / 'source/rpc_diagnostics.py']
    for name in ('rpc_protocol.py', 'rpc_client.py', 'rpc_dispatcher.py', 'session_rpc_adapter.py'):
        external += [OBS / 'preimages' / name, OBS / 'source' / name,
                     OBS / 'diffs' / (name + '.diff')]
    index = {
        'schema': 'c17-wrapper-builder-v10-diagnostic-preparation-index-v1',
        'status': 'prepared_static_plus_71_pure_tests_no_native',
        'actor': '/root/environment_routes',
        'observed_at': datetime.now(UTC).isoformat(),
        'scope': 'WRAPPER_CANARY_diagnostic_only',
        'historical_wrapper_head': '2d69e30c9c6dd18823ee6102271876003a6a67cc',
        'current_AB_source_head_not_used': '19979e8a5ea9bd8e886d35d54793b3d1a560cd77',
        'local_refs': [ref(p) for p in selected],
        'external_origin_refs': [ref(p) for p in external],
        'source_cardinality': {'previous_physical_refs': 76, 'new_helper_physical_copies': 3,
                               'candidate_physical_refs': 79, 'core_copies': 18,
                               'overlay_outputs': 28, 'overlay_scripts': 19},
        'new_helper_destinations': ['source/rpc_diagnostics.py',
                                    'auxiliary-ports/runtime/rpc_diagnostics.py',
                                    'auxiliary-ports/complements/instruments/rpc_diagnostics.py'],
        'limits': ['No native construction or WRAPPER root created by this lot',
                   'No A/B composite, FULL admission, runtime, product test, service, browser, or release',
                   'First provisional pure test red was an inherited V8-only AST inventory; final 71 are green',
                   'A future root checker must explicitly accept and rehash 79 physical refs, core18 and overlay28',
                   'Historical ROOT9 exception cause cannot be reconstructed from its old ACK'],
    }
    raw = (json.dumps(index, ensure_ascii=False, sort_keys=True, indent=2) + '\n').encode()
    new(HERE / 'INDEX.json', raw)
    print(json.dumps({'index': str(HERE / 'INDEX.json'), 'sha256': sha256(raw).hexdigest(),
                      'local_refs': len(index['local_refs']),
                      'external_refs': len(index['external_origin_refs'])}))


if __name__ == '__main__':
    main()
