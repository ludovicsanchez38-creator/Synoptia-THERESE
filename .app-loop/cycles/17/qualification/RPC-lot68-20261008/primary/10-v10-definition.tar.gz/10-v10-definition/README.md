# WRAPPER V10 : diagnostic RPC uniquement

Statut : constructeur de préparation seulement, non exécuté sur une racine QA.
Auteur : `/root/environment_routes`. Les gels V9, ROOT9, transport-26 et
observabilité restent inchangés. Aucune admission G1, aucun navigateur,
service, port, produit, A/B, FULL ou release n'a été lancé par ce lot.

Le HEAD `2d69e30c9c6dd18823ee6102271876003a6a67cc` dans ce constructeur
est celui du WRAPPER historique. La source QA A/B fraîche au HEAD
`19979e8a5ea9bd8e886d35d54793b3d1a560cd77` n'est pas rebaptisée en
WRAPPER et n'est pas consommée ici.

## Delta exact

Le builder vérifie avant `os.mkdir` le gel diagnostic `604e4e…`, ses quatre
préimages ROOT9/transport-26, leurs quatre candidats et leurs diffs
reconstruits. Il dérive ensuite les copies actives, sans modifier les onze
sorties historiques :

- `source/` : quatre RPC dérivés, `rpc_peer.py` et `rpc_unix.py` inchangés,
  plus `rpc_diagnostics.py` épinglé ; le core passe de 17 à 18 copies.
- `auxiliary-ports/runtime/` et
  `auxiliary-ports/complements/instruments/` : chacun porte le protocole et
  client dérivés ainsi que son helper frère exact ; overlay 26 à 28 sorties,
  17 à 19 scripts.
- Les 76 chemins physiques précédents restent présents. Les trois helpers
  réellement copiés ajoutent trois refs : 79 refs de source physique,
  toutes rehashées avant le GO de construction. Les quatre nouveaux diffs et
  leurs préimages sont conservés en `proofs/` et référencés séparément ; ils
  ne sont pas présentés comme du code exécutable.

Le profil Chrome V9 est copié byte-exact (SHA `19808ee2…`) ; les permissions,
ports, délais 5/50/8, tables, commandes, oracles, flags FULL et admission
restent ceux du V9. Aucune cause ROOT9 n'est rétroactivement reconstruite.
L'affichage des exceptions est seulement une donnée bornée, sans promesse de
préemption de `__str__` hostile.

## Contrôles purs

71 tests réussis, zéro erreur et événement runtime interdit : voir
`proofs/pure-test-receipt.json`. Ils vérifient les quatre origines/diffs,
les copies overlay réelles prévues, le refus d'absence ou mutation de chaque
helper, la table 79, l'ordre avant allocation et le profil inchangé. Le
premier rejeu provisoire était rouge sur un test AST héritant de l'inventaire
V8 (il ne permettait pas les trois fonctions V10) ; ce test compare maintenant
la préimage V9 et garde le reste des fonctions inchangées. Ce rouge n'était
ni natif ni un échec produit.

## Usage futur fermé

Le CLI exige `--prepare` et trois références exactes (`--web-profile-ref`,
`--chrome-profile-ref`, `--authority-ref`) avec un nouveau root WRAPPER et
une autorité outil root distincte. Aucune invocation de construction ou
runtime n'est incluse dans ce gel. Un contrôleur externe devra adapter ses
assertions 76/core17/overlay26 à 79/core18/overlay28 avant toute nouvelle
préparation, puis recontrôler les 79 refs réellement émises. Ce gel seul ne
vaut aucun GO natif.
