#!/usr/bin/env python3
"""Audit final lecture seule du clone QA et des dépendances COW.

Seuls trois reçus JSON sont créés avec O_EXCL. Aucun import produit ni build.
"""
from __future__ import annotations

from datetime import UTC, datetime
import filecmp
import importlib.util
import json
import os
from pathlib import Path
import stat
import subprocess


ROOT = Path(__file__).resolve().parent.parent
PROOFS = ROOT / "proofs"
SOURCE = ROOT / "source"
OLD = Path("/private/tmp/therese-c17-wrapper-source-kGvU1hdx/source")
REPOSITORY = Path("/Users/synoptia/Desktop/Dev Synoptia/Synoptia-THERESE-c15-codex")
EXPECTED = "19979e8a5ea9bd8e886d35d54793b3d1a560cd77"
GIT = "/Applications/Xcode.app/Contents/Developer/usr/bin/git"
GIT_ENV = {"PATH": "/usr/bin:/bin", "LANG": "C", "LC_ALL": "C",
           "GIT_CONFIG_NOSYSTEM": "1", "GIT_CONFIG_GLOBAL": "/dev/null",
           "GIT_OPTIONAL_LOCKS": "0", "TMPDIR": str(PROOFS / "tmp"),
           "HOME": str(PROOFS / "home"), "CFFIXED_USER_HOME": str(PROOFS / "home"),
           "DEVELOPER_DIR": "/Applications/Xcode.app/Contents/Developer"}


def producer_module():
    spec = importlib.util.spec_from_file_location(
        "qa_calibration_round_producer", PROOFS / "calibration_round_producer.py")
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


P = producer_module()


def need(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def git(folder: Path, *args: str) -> bytes:
    child = subprocess.run([GIT, "-C", str(folder), *args], cwd=folder,
                           env=GIT_ENV, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                           timeout=45, check=False)
    need(child.returncode == 0 and child.stderr == b"",
         f"Git command failed: {args!r}, rc={child.returncode}, stderr={child.stderr[:400]!r}")
    return child.stdout


def compare_tree(before: Path, after: Path) -> dict:
    need(before.is_dir() and after.is_dir(), "Dependency tree missing")
    counts = {"regular_files": 0, "directories": 0, "symlinks": 0,
              "symlink_mode_differences": 0, "bytes_compared": 0,
              "hardlinks_in_new": 0}

    def walk(a: Path, b: Path) -> None:
        am, bm = a.lstat(), b.lstat()
        need(stat.S_ISDIR(am.st_mode) and stat.S_ISDIR(bm.st_mode), "Directory type mismatch")
        need(stat.S_IMODE(am.st_mode) == stat.S_IMODE(bm.st_mode), f"Directory mode mismatch: {b}")
        counts["directories"] += 1
        a_names = set(os.listdir(a))
        b_names = set(os.listdir(b))
        need(a_names == b_names, f"Dependency names differ: {b}, {sorted(a_names ^ b_names)[:8]}")
        for name in sorted(a_names):
            src, dst = a / name, b / name
            s, d = src.lstat(), dst.lstat()
            need(stat.S_IFMT(s.st_mode) == stat.S_IFMT(d.st_mode), f"File type mismatch: {dst}")
            if stat.S_ISDIR(s.st_mode):
                need(stat.S_IMODE(s.st_mode) == stat.S_IMODE(d.st_mode), f"Directory mode mismatch: {dst}")
                walk(src, dst)
            elif stat.S_ISLNK(s.st_mode):
                need(os.readlink(src) == os.readlink(dst), f"Symlink differs: {dst}")
                counts["symlinks"] += 1
                if stat.S_IMODE(s.st_mode) != stat.S_IMODE(d.st_mode):
                    counts["symlink_mode_differences"] += 1
            elif stat.S_ISREG(s.st_mode):
                need(stat.S_IMODE(s.st_mode) == stat.S_IMODE(d.st_mode), f"File mode mismatch: {dst}")
                need(s.st_size == d.st_size and filecmp.cmp(src, dst, shallow=False),
                     f"File content differs: {dst}")
                need(d.st_nlink == 1, f"Hardlinked dependency file: {dst}")
                counts["regular_files"] += 1
                counts["bytes_compared"] += d.st_size
            else:
                raise ValueError(f"Unsupported dependency file type: {dst}")

    walk(before, after)
    return counts


def main() -> None:
    os.umask(0o077)
    need(ROOT.parent == Path("/private/tmp")
         and ROOT.name.startswith("therese-c17-direct-source-")
         and ROOT.resolve(strict=True) == ROOT and SOURCE.resolve(strict=True) == SOURCE,
         "Fresh QA root identity mismatch")
    need(SOURCE.joinpath(".git/HEAD").read_bytes() == (EXPECTED + "\n").encode(),
         "Detached HEAD differs")
    capture = json.loads((PROOFS / "git-capture-receipt.json").read_text())
    manifest = json.loads((PROOFS / "qa-source-files.json").read_text())
    need(capture["status"] == "PASS" and manifest["head"] == EXPECTED
         and manifest["product_source_root"] == str(SOURCE), "Captured source differs")
    need(git(REPOSITORY, "rev-parse", "--verify", "HEAD") == (EXPECTED + "\n").encode(),
         "Repository HEAD changed during preparation")
    need(git(SOURCE, "status", "--porcelain=v1", "-z") == b"", "Fresh QA checkout dirty")
    fresh, tree, commit = P.verified_source_payload(
        SOURCE, EXPECTED, capture=lambda folder, args: git(folder, *args))
    need(fresh["files"] == manifest["files"] and fresh["modes"] == manifest["modes"]
         and fresh["symlinks"] == manifest["symlinks"], "Captured Git rows changed")
    need(tree == (PROOFS / "qa-tree.raw").read_bytes()
         and commit == (PROOFS / "qa-commit.raw").read_bytes(), "Captured Git objects changed")
    P.verify_manifest_files(SOURCE, manifest)
    need(git(SOURCE, "status", "--porcelain=v1", "-z") == b"", "QA checkout dirty after audit")
    no_link = 0
    for row in manifest["files"]:
        target = Path(row["path"])
        if target.is_symlink():
            continue
        need(target.lstat().st_nlink == 1, f"Tracked file hardlinked: {target}")
        no_link += 1
    git_objects = 0
    for path in SOURCE.joinpath(".git/objects").rglob("*"):
        if path.is_file() and not path.is_symlink():
            need(path.lstat().st_nlink == 1, f"Git object hardlinked: {path}")
            git_objects += 1

    roots = [
        ("python-site-packages", OLD / ".venv-conforme/lib/python3.13/site-packages",
         SOURCE / ".venv-conforme/lib/python3.13/site-packages"),
        ("node-root", OLD / "node_modules", SOURCE / "node_modules"),
        ("node-frontend", OLD / "src/frontend/node_modules", SOURCE / "src/frontend/node_modules"),
    ]
    copied = []
    for label, old, new in roots:
        copied.append({"label": label, "source": str(old), "target": str(new),
                       "comparison": compare_tree(old, new)})
    need(git(REPOSITORY, "rev-parse", "--verify", "HEAD") == (EXPECTED + "\n").encode(),
         "Repository HEAD changed during final audit")

    git_receipt = {"schema": "c17-fresh-git-final-audit-v1", "status": "PASS",
                   "observed_at": datetime.now(UTC).isoformat(), "head": EXPECTED,
                   "tracked_files": len(manifest["files"]), "tracked_regular_not_hardlinked": no_link,
                   "git_object_files_not_hardlinked": git_objects,
                   "source_manifest_ref": P.reference(PROOFS / "qa-source-files.json"),
                   "capture_ref": P.reference(PROOFS / "git-capture-receipt.json"),
                   "method": "Fresh Git rev-parse/cat-file/ls-tree, exact manifest and raw comparison, status clean"}
    dependency_receipt = {"schema": "c17-fresh-dependency-copy-audit-v1", "status": "PASS",
                          "observed_at": datetime.now(UTC).isoformat(), "head": EXPECTED,
                          "comparisons": copied,
                          "method": "Recursive byte, regular/directory mode, symlink-text comparison and new-file nlink=1; symlink mode deltas counted"}
    P.write_new(PROOFS / "git-final-audit.json", P.json_bytes(git_receipt))
    P.write_new(PROOFS / "dependency-byte-audit.json", P.json_bytes(dependency_receipt))
    print(json.dumps({"status": "PASS", "head": EXPECTED,
                      "tracked_files": len(manifest["files"]),
                      "dependency_files": sum(row["comparison"]["regular_files"] for row in copied),
                      "dependency_bytes": sum(row["comparison"]["bytes_compared"] for row in copied)}))


if __name__ == "__main__":
    main()
