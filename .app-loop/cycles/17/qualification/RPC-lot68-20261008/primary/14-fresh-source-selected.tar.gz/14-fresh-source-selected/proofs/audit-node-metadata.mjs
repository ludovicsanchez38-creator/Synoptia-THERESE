import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const root = '/private/tmp/therese-c17-direct-source-F4KirwuR';
const qa = path.join(root, 'source');
const expectedHead = '19979e8a5ea9bd8e886d35d54793b3d1a560cd77';
const hash = (file) => crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const writeNew = (file, value) => {
  const fd = fs.openSync(file, fs.constants.O_CREAT | fs.constants.O_EXCL | fs.constants.O_WRONLY | fs.constants.O_NOFOLLOW, 0o600);
  try { fs.writeFileSync(fd, JSON.stringify(value, null, 2) + '\n'); }
  finally { fs.closeSync(fd); }
};

if (fs.realpathSync(root) !== root || fs.realpathSync(qa) !== qa) throw new Error('QA root is not canonical');
if (fs.readFileSync(path.join(qa, '.git', 'HEAD'), 'utf8') !== `${expectedHead}\n`) throw new Error('Detached HEAD mismatch');
const captured = JSON.parse(fs.readFileSync(path.join(root, 'proofs', 'git-capture-receipt.json'), 'utf8'));
if (captured.status !== 'PASS' || captured.head !== expectedHead) throw new Error('Git capture mismatch');

const proofs = [];
for (const dir of [qa, path.join(qa, 'src', 'frontend')]) {
  const lockFile = path.join(dir, 'package-lock.json');
  const lock = JSON.parse(fs.readFileSync(lockFile, 'utf8'));
  let installed = 0;
  let missingOptional = 0;
  const errors = [];
  for (const [name, entry] of Object.entries(lock.packages)) {
    if (!name || !name.includes('node_modules/')) continue;
    const packageFile = path.join(dir, name, 'package.json');
    if (!fs.existsSync(packageFile)) {
      if (entry.optional) missingOptional++;
      else errors.push({name, missing: true});
      continue;
    }
    const actual = JSON.parse(fs.readFileSync(packageFile, 'utf8')).version;
    installed++;
    if (actual !== entry.version) errors.push({name, actual, locked: entry.version});
  }
  if (errors.length) throw new Error(JSON.stringify(errors));
  proofs.push({root: dir, installed, missing_optional: missingOptional,
    mismatches: errors, lock_sha256: hash(lockFile)});
}
const receipt = {schema: 'c17-fresh-node-metadata-audit-v1', status: 'PASS',
  head: expectedHead, proofs,
  method: 'Read-only lock and package JSON audit; no package import, build, runtime, or socket',
  limits: ['No product runtime qualification', 'Copied dependency tree equality checked separately']};
writeNew(path.join(root, 'proofs', 'node-metadata-result.json'), receipt);
process.stdout.write(JSON.stringify({status: receipt.status, head: expectedHead,
  packages: proofs.map(({installed, missing_optional}) => ({installed, missing_optional}))}) + '\n');
