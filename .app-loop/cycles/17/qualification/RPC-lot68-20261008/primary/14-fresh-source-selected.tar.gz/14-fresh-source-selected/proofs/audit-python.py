#!/usr/bin/env python3
"""Audit physique UV/metadata du seul checkout QA, sans import produit."""
from __future__ import annotations

from datetime import UTC, datetime
import hashlib
import importlib.util
import importlib.metadata
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tomllib

ROOT = Path(__file__).resolve().parent.parent
QA = ROOT / "source"
OUT = ROOT / "proofs"
spec = importlib.util.spec_from_file_location("calibration_round_producer_definition", OUT / "calibration_round_producer.py")
assert spec is not None and spec.loader is not None
producer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(producer)
SITE = QA / ".venv-conforme/lib/python3.13/site-packages"
EXPECTED = "19979e8a5ea9bd8e886d35d54793b3d1a560cd77"
PYTHON = Path("/Users/synoptia/.local/share/uv/python/cpython-3.13.5-macos-aarch64-none/bin/python3.13")
UV = Path("/opt/homebrew/bin/uv")


def norm(name: str) -> str:
    return re.sub(r"[-_.]+", "-", name).lower()


def main() -> None:
    os.umask(0o077)
    producer.need(Path(sys.executable).resolve(strict=True) == PYTHON.resolve(strict=True),
                  "Auditeur pas sous Python 3.13.5 physique")
    producer.need((QA / ".git/HEAD").read_bytes() == (EXPECTED + "\n").encode()
                  and (OUT / "qa-head.stdout").read_bytes() == (EXPECTED + "\n").encode(),
                  "HEAD QA non détaché ou capture différente")
    producer.need((OUT / "qa-status.stdout").read_bytes() == b"", "Checkout source non propre")
    producer.need((QA / ".venv-conforme/bin/activate").read_text().find(str(QA / ".venv-conforme")) >= 0,
                  "Venv activation copiée d'un autre checkout")
    for target in (OUT / "uv-graph-check.stdout", OUT / "uv-graph-check.stderr",
                   OUT / "python-metadata-result.json", OUT / "uv-graph-check-receipt.json"):
        producer.need(not target.exists(), "Audit Python existant : aucun remplacement")
    env = {"PATH": "/opt/homebrew/bin:/usr/bin:/bin", "HOME": str(OUT / "uv-home"),
           "CFFIXED_USER_HOME": str(OUT / "uv-home"), "TMPDIR": str(OUT / "uv-tmp"),
           "LANG": "C", "LC_ALL": "C", "UV_CACHE_DIR": str(OUT / "uv-cache"),
           "UV_PROJECT_ENVIRONMENT": str(QA / ".venv-conforme"),
           "UV_PYTHON_DOWNLOADS": "never", "UV_KEYRING_PROVIDER": "disabled",
           "UV_LINK_MODE": "copy", "UV_NO_PROGRESS": "1",
           "PYTHONDONTWRITEBYTECODE": "1", "PYTHONNOUSERSITE": "1"}
    argv = [str(UV), "sync", "--frozen", "--offline", "--check", "--dev",
            "--no-install-project", "--no-build", "--python", str(PYTHON),
            "--no-python-downloads"]
    started = datetime.now(UTC).isoformat()
    out_fd = os.open(OUT / "uv-graph-check.stdout", os.O_CREAT | os.O_EXCL | os.O_WRONLY | os.O_NOFOLLOW, 0o600)
    err_fd = os.open(OUT / "uv-graph-check.stderr", os.O_CREAT | os.O_EXCL | os.O_WRONLY | os.O_NOFOLLOW, 0o600)
    with os.fdopen(out_fd, "wb") as stdout, os.fdopen(err_fd, "wb") as stderr:
        child = subprocess.run(argv, cwd=QA, env=env, stdout=stdout, stderr=stderr, timeout=300, check=False)
        stdout.flush(); os.fsync(stdout.fileno())
        stderr.flush(); os.fsync(stderr.fileno())
    receipt = {"schema": "c17-direct-source-uv-frozen-check-v1",
               "started_at": started, "completed_at": datetime.now(UTC).isoformat(),
               "actor": "/root/environment_routes", "source": str(QA), "head": EXPECTED,
               "argv": argv, "cwd": str(QA), "environment": env,
               "exit_code": child.returncode,
               "stdout": producer.reference(OUT / "uv-graph-check.stdout"),
               "stderr": producer.reference(OUT / "uv-graph-check.stderr"),
               "no_product_import": True, "runtime_started": False}
    producer.write_new(OUT / "uv-graph-check-receipt.json", producer.json_bytes(receipt))
    producer.need(child.returncode == 0, "UV frozen/offline check rouge, bruts conservés")
    lock = tomllib.loads((QA / "uv.lock").read_text())
    versions: dict[str, set[str]] = {}
    for package in lock["package"]:
        versions.setdefault(norm(package["name"]), set()).add(package["version"])
    rows: list[dict] = []
    errors: list[dict] = []
    for dist in importlib.metadata.distributions(path=[str(SITE)]):
        name = dist.metadata.get("Name")
        row = {"name": name, "version": dist.version, "metadata_path": str(dist._path)}
        rows.append(row)
        if not name or dist.version not in versions.get(norm(name), set()) or not Path(row["metadata_path"]).is_relative_to(SITE):
            errors.append(row)
    producer.need(rows and not errors, "Distributions Python hors lock/venv")
    pth = [producer.reference(p) for p in sorted(SITE.glob("*.pth"))]
    producer.need(all("therese-c17-wrapper-source-" not in p.read_text()
                      and "/Users/synoptia/Desktop" not in p.read_text() for p in SITE.glob("*.pth")),
                  "Chemin Python étranger dans .pth")
    producer.need(not any(name == "app" or name.startswith("app.") for name in sys.modules),
                  "Module produit importé par audit")
    result = {"schema": "c17-fresh-python-metadata-audit-v1", "status": "PASS",
              "qa_source": str(QA), "head": EXPECTED,
              "physical_audit_python": sys.executable,
              "qa_python": str(QA / ".venv-conforme/bin/python"),
              "installed_count": len(rows), "mismatches": errors,
              "packages": sorted(rows, key=lambda x: x["name"] or ""),
              "lock": producer.reference(QA / "uv.lock"), "pth": pth,
              "uv_graph_check_stdout": receipt["stdout"],
              "uv_graph_check_stderr": receipt["stderr"],
              "graph_check_exit_observed_by_root": child.returncode,
              "method": "fresh venv activation plus copied QA package payloads, read-only metadata and actual UV frozen/offline --check",
              "limits": ["No product import", "No runtime qualification", "Dependencies copied COW from prior QA then rechecked"]}
    producer.write_new(OUT / "python-metadata-result.json", producer.json_bytes(result))
    print(json.dumps({"status": "PASS", "head": EXPECTED, "distributions": len(rows),
                      "uv_receipt": str(OUT / "uv-graph-check-receipt.json"),
                      "audit": str(OUT / "python-metadata-result.json")}))


if __name__ == "__main__":
    main()
