#!/usr/bin/env python3
"""Index sélectif des preuves de source QA, sans archiver les dépendances."""
from __future__ import annotations

from datetime import UTC, datetime
from hashlib import sha256
import json
import os
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
PROOFS = ROOT / "proofs"
SOURCE = ROOT / "source"
HEAD = "19979e8a5ea9bd8e886d35d54793b3d1a560cd77"
FILES = (
    "proofs/capture-source.py",
    "proofs/audit-python.py",
    "proofs/audit-node-metadata.mjs",
    "proofs/final-audit.py",
    "proofs/index-preparation.py",
    "proofs/calibration_round_producer.py",
    "proofs/git-capture-receipt.json",
    "proofs/git-final-audit.json",
    "proofs/qa-head.stdout",
    "proofs/qa-tree.raw",
    "proofs/qa-commit.raw",
    "proofs/qa-status.stdout",
    "proofs/qa-source-files.json",
    "proofs/uv-graph-check.stdout",
    "proofs/uv-graph-check.stderr",
    "proofs/uv-graph-check-receipt.json",
    "proofs/python-metadata-result.json",
    "proofs/node-metadata-result.json",
    "proofs/dependency-byte-audit.json",
    "source/.git/HEAD",
    "source/pyproject.toml",
    "source/uv.lock",
    "source/package-lock.json",
    "source/src/frontend/package-lock.json",
)


def ref(name: str) -> dict:
    path = ROOT / name
    raw = path.read_bytes()
    return {"path": str(path), "sha256": sha256(raw).hexdigest(), "bytes": len(raw)}


def main() -> None:
    os.umask(0o077)
    assert ROOT.parent == Path("/private/tmp") and ROOT.name.startswith("therese-c17-direct-source-")
    git = json.loads((PROOFS / "git-final-audit.json").read_text())
    dep = json.loads((PROOFS / "dependency-byte-audit.json").read_text())
    py = json.loads((PROOFS / "python-metadata-result.json").read_text())
    node = json.loads((PROOFS / "node-metadata-result.json").read_text())
    uv = json.loads((PROOFS / "uv-graph-check-receipt.json").read_text())
    assert all(item["status"] == "PASS" for item in (git, dep, py, node))
    assert uv["exit_code"] == 0 and uv["head"] == HEAD
    assert SOURCE.joinpath(".git/HEAD").read_text() == HEAD + "\n"
    assert all(not (PROOFS / name).is_symlink() for name in ("qa-source-files.json", "git-final-audit.json"))
    index = {
        "schema": "c17-direct-fresh-source-preparation-index-v1",
        "status": "prepared_source_only",
        "observed_at": datetime.now(UTC).isoformat(),
        "actor": "/root/environment_routes",
        "head_at_capture_and_final_audit": HEAD,
        "repository": "/Users/synoptia/Desktop/Dev Synoptia/Synoptia-THERESE-c15-codex",
        "qa_root": str(ROOT),
        "qa_source": str(SOURCE),
        "tracked_files": git["tracked_files"],
        "python_distributions": py["installed_count"],
        "node_packages": [{"root": p["root"], "installed": p["installed"],
                           "missing_optional": p["missing_optional"]} for p in node["proofs"]],
        "dependency_byte_comparison": [r["comparison"] | {"label": r["label"]}
                                       for r in dep["comparisons"]],
        "commands": [
            "git -c init.templateDir=/dev/null clone --no-hardlinks --no-checkout --no-tags <repository> <qa_source>",
            "git -c core.hooksPath=/dev/null checkout --detach " + HEAD,
            "uv venv --python <physical Python 3.13.5> <qa_source>/.venv-conforme",
            "cp -cR <verified old QA site-packages/.> <fresh venv site-packages/>",
            "cp -cR <verified old QA root node_modules> <fresh QA root node_modules>",
            "cp -cR <verified old QA frontend node_modules> <fresh QA frontend node_modules>",
            "uv sync --frozen --offline --check --dev --no-install-project --no-build --python <physical Python 3.13.5> --no-python-downloads",
            "<physical Python 3.13.5> -I -B proofs/final-audit.py",
            "<Node 22.19.0> proofs/audit-node-metadata.mjs",
        ],
        "selected_refs": [ref(name) for name in FILES],
        "limits": [
            "No A/B round root, G1 admission, browser, server, port, product test, or release created",
            "The clone contains historical tracked archive files as source blobs, not adopted results",
            "The first COW venv copy is preserved under proofs/venv-cow-copy-pre-fresh; it was not used as the active venv",
            "COW changes symlink mode bits for 26 Node .bin links; symlink text, regular-file bytes and modes, and directory modes match",
            "Node optional dependencies absent per lock remain 1 root and 86 frontend, as in the verified prior QA",
            "The prior QA dependency files are compared byte-exactly, but this source preparation is not product runtime qualification",
            "A future A/B preparer must recheck that live repository HEAD still equals this captured HEAD before use",
        ],
    }
    raw = (json.dumps(index, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode()
    fd = os.open(PROOFS / "INDEX.json", os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, "wb") as stream:
        stream.write(raw)
    print(json.dumps({"status": index["status"], "index": str(PROOFS / "INDEX.json"),
                      "refs": len(index["selected_refs"]), "sha256": sha256(raw).hexdigest()}))


if __name__ == "__main__":
    main()
