"""Préimage exacte du runner avant son seul import stdlib AST autorisé."""
import hashlib
import json
from pathlib import Path
HERE = Path(__file__).resolve().parent
source = HERE / 'run-pure.py'
receipt = json.loads(Path('/private/tmp/therese-c17-worker-context-tests-9oEazR9W/receipt.json').read_text())
expected = next(row for row in receipt['pins_after'] if row['path'] == str(source))
raw = source.read_bytes()
if len(raw) != expected['bytes'] or hashlib.sha256(raw).hexdigest() != expected['sha256']:
    raise ValueError('Runner must equal first actual 38 observation')
with (HERE / 'preimages/run-pure-first-38.py').open('xb') as stream:
    stream.write(raw)
