"""Jointures pures des trois workers ; aucune autorité ou mesure OS créée."""
from __future__ import annotations

import json
from pathlib import PurePosixPath
import re

PHASES = {
    'bind-current-context-contract': (),
    'eight-logs-review': ('stop_execution', 'service_cleanup'),
    'package78': ('mapping', 'visual', 'apple', 'semantic', 'logs', 'calibrations'),
}
OUTPUTS = {
    'bind-current-context-contract': 'complements/contrats-normalises-proposes.json',
    'eight-logs-review': 'eight-logs-review.json',
    'package78': 'runtime78-package/package78.json',
}
REQUEST_SCHEMA = 'c17-runtime78-sql-worker-request-v2'


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def reference(value: dict) -> dict:
    require(isinstance(value, dict) and isinstance(value.get('path'), str)
        and value['path'].startswith('/') and '..' not in PurePosixPath(value['path']).parts
        and isinstance(value.get('sha256'), str)
        and re.fullmatch(r'[0-9a-f]{64}', value['sha256']) is not None, 'Référence exacte absente')
    if 'bytes' in value:
        require(type(value['bytes']) is int and value['bytes'] >= 0, 'Taille référence invalide')
    return value


def validate_request(record: dict, phase: str, config: dict) -> None:
    require(phase in PHASES and record.get('schema') == REQUEST_SCHEMA
        and record.get('stage_id') == phase and record.get('mode') == 'sql', 'Autre worker/mode/schéma')
    require(all(record.get(k) == config[k] for k in ('actor', 'round_id', 'head', 'root')), 'Requête autre ronde/acteur/HEAD/racine')
    require(record.get('runtime_admitted') is False and type(record.get('qualified')) is int and record['qualified'] == 0,
        'Une requête ne crée pas son admission/qualification')
    require(record.get('expected_head') == config['head'], 'HEAD attendu worker absent/différent')
    source = PurePosixPath(record.get('product_source_root', ''))
    require(source.is_absolute() and source.is_relative_to(PurePosixPath('/private/tmp'))
        and '..' not in source.parts and config.get('python') == str(source / '.venv-conforme/bin/python'),
        'Source/interpréteur worker hors QA exacte')
    require(record.get('source_checkout', {}).get('path') == str(PurePosixPath(config['root']) / 'authorization/source-checkout.json'),
        'Checkout physique A/B absent de la requête')
    for key in ('runtime_decision', 'phase_decision', 'read_view', 'configuration', 'worker_source',
                'session_binding', 'source_checkout'):
        reference(record.get(key))
    payload = record.get('payload')
    require(isinstance(payload, dict) and set(payload) == set(PHASES[phase]), 'Payload manquant/supplémentaire')
    for value in payload.values():
        reference(value)


def parse_stdout(data: bytes, phase: str, config: dict, request_ref: dict) -> dict:
    result = json.loads(data.decode('utf-8'))
    require(result.get('schema') == 'c17-runtime78-sql-worker-result-v1' and result.get('stage_id') == phase
        and all(result.get(k) == config[k] for k in ('actor', 'round_id', 'head')),
        'Résultat autre étape/identité')
    require(result.get('request') == request_ref and type(result.get('qualified')) is int and result['qualified'] == 0,
        'Résultat autre requête ou qualification inventée')
    reference(result.get('output')); reference(result.get('worker_receipt'))
    require(result['output']['path'] == str(PurePosixPath(config['root']) / OUTPUTS[phase]), 'Autre sortie worker')
    require(result['worker_receipt']['path'] == str(PurePosixPath(config['root']) / 'ledger' / phase / 'worker-receipt.json'),
        'Autre reçu worker')
    return result
