"""Trois littéraux Q pour le seul builder post-stop, dérivés par G1 parent.

Aucune autorité ne provient du payload enfant. ``checked_json_ref`` est injecté
par runtime_session et doit vérifier owner, chemin canonique, SHA et taille.
Ce module est pur sauf les contrôles de fichiers locaux en lecture seule.
"""
from __future__ import annotations

from pathlib import Path
import re
from typing import Callable


STAGE = "build-calibrations-v3"
REQUEST = "authorization/calibration-builder-request.json"
META_SLOTS = 16
HEX64 = re.compile(r"[0-9a-f]{64}\Z")


def need(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def exact_ref(value: dict, q_root: Path, checked_json_ref: Callable) -> tuple[Path, dict]:
    need(isinstance(value, dict) and isinstance(value.get("path"), str)
         and HEX64.fullmatch(value.get("sha256", "")) is not None,
         "Référence Q SHA absente")
    path = Path(value["path"])
    need(path.is_absolute() and path != q_root and path.is_relative_to(q_root)
         and path.resolve(strict=True) == path and not path.is_symlink(),
         "Référence Q hors qualification/canonique")
    body = checked_json_ref(value, q_root)
    need(isinstance(body, dict), "Référence Q non JSON objet")
    return path, body


def bind_literals(*, root: Path, q_root: Path, stage: str, role: str, mode: str,
                  command: list[str], qa_python: Path, product_source_root: Path,
                  actor: str, round_id: str, round_name: str, head: str,
                  decision_ref: dict, binding_ref: dict, binding: dict,
                  stage_record: dict | None, expected_command: dict,
                  checked_json_ref: Callable) -> dict[str, str]:
    """Rehash les trois vraies décisions Q avant les paramètres sandbox-exec.

    Appeler seulement après la validation de Session.start du stage-binding
    tardif, avant sandbox()/tout FD/Popen. Ne valide pas à lui seul le GO humain.
    """
    need(stage == STAGE and role == "stage-" + STAGE and mode == "sql"
         and round_name in ("A", "B"), "Littéraux Q interdits hors builder A/B SQL")
    need(root.is_absolute() and root.resolve(strict=True) == root
         and q_root.is_absolute() and q_root.resolve(strict=True) == q_root
         and product_source_root.is_absolute()
         and product_source_root.resolve(strict=True) == product_source_root,
         "Racines Q/QA non canoniques")
    request_path = root / REQUEST
    need(isinstance(command, list) and len(command) == 6
         and command == [str(qa_python), str(root / "build-calibrations-v3.py"),
                     "--request", str(request_path), "--request-sha256", command[-1]]
         and HEX64.fullmatch(command[-1]) is not None,
         "Builder argv/entrée request non exacts")
    need(isinstance(stage_record, dict) and stage_record.get("schema") ==
         "c17-runtime78-session-stage-registration-v1"
         and stage_record.get("stage_id") == STAGE
         and stage_record.get("command") == expected_command
         and expected_command.get("argv") == command
         and expected_command.get("mode") == "sql"
         and expected_command.get("role") == role
         and expected_command.get("timeout_seconds") == 120,
         "Builder sans binding tardif exact/borne120")
    stage_binding_ref, stage_decision_ref, origin_ref = (
        stage_record.get(key) for key in ("stage_binding", "stage_decision", "stage_origin"))
    _, stage_binding = exact_ref(stage_binding_ref, q_root, checked_json_ref)
    _, stage_decision = exact_ref(stage_decision_ref, q_root, checked_json_ref)
    _, origin = exact_ref(origin_ref, q_root, checked_json_ref)
    need(stage_binding.get("schema") == "c17-runtime78-stage-binding-v1"
         and stage_binding.get("stage_id") == STAGE
         and stage_binding.get("initial_binding") == binding_ref
         and stage_binding.get("command") == expected_command
         and stage_decision.get("schema") == "c17-runtime78-stage-go-v1"
         and stage_decision.get("stage_id") == STAGE
         and stage_decision.get("stage_binding") == stage_binding_ref
         and stage_decision.get("root_review_origin") == origin_ref
         and stage_decision.get("provided_by") == "/root"
         and origin.get("schema") == "c17-runtime78-root-tool-review-origin-v1"
         and origin.get("provided_by") == "/root"
         and origin.get("origin_kind") == "actual_root_tool_review",
         "Relais stage-binding/root origin non concordant")
    for row in (stage_binding, stage_decision, origin):
        need(all(row.get(key) == expected for key, expected in
                 (("actor", actor), ("round_id", round_id), ("round_name", round_name),
                  ("head", head), ("qa_root", str(root)))),
             "Origine stage d'une autre ronde")
    need(stage_record.get("stage_origin") == origin_ref
         and stage_record.get("stage_decision") == stage_decision_ref,
         "Enregistrement stage différent")
    request_ref = {"path": str(request_path), "sha256": command[-1]}
    request = checked_json_ref(request_ref, root)
    need(request.get("schema") == "c17-calibration-builder-request-v2"
         and request.get("root") == str(root)
         and request.get("qa_source") == str(product_source_root)
         and all(request.get(key) == expected for key, expected in
                 (("actor", actor), ("round_id", round_id), ("head", head))),
         "Demande builder QA/acteur/HEAD différente")
    refs = request.get("g1_authority")
    need(isinstance(refs, dict) and set(refs) == {"successor", "admission", "binding"}
         and refs["admission"] == decision_ref and refs["binding"] == binding_ref,
         "Trois refs G1 non liées à la Session")
    successor_path, successor = exact_ref(refs["successor"], q_root, checked_json_ref)
    admission_path, admission = exact_ref(refs["admission"], q_root, checked_json_ref)
    binding_path, binding_body = exact_ref(refs["binding"], q_root, checked_json_ref)
    plan = binding.get("planned_decisions", {}).get("successor")
    need(isinstance(plan, dict) and plan ==
         {"path": str(successor_path), "decision_id": successor.get("decision_id")},
         "Successor non prévu par le binding initial")
    need(binding_body == binding and admission.get("schema") ==
         "c17-runtime78-session-root-go-v1"
         and admission.get("binding") == binding_ref
         and successor.get("schema") == "c17-runtime78-successor-admission-v1"
         and successor.get("provided_by") == "/root"
         and successor.get("phase") == "runtime"
         and successor.get("session_decision") == decision_ref
         and successor.get("session_binding") == binding_ref,
         "Décisions G1/successor/Session non reliées")
    for body in (successor, admission, binding_body):
        need(all(body.get(key) == expected for key, expected in
                 (("actor", actor), ("round_id", round_id), ("round_name", round_name),
                  ("head", head), ("qa_root", str(root)))),
             "Décision Q autre ronde/HEAD")
    files = {"Q_SUCCESSOR": successor_path, "Q_ADMISSION": admission_path,
             "Q_BINDING": binding_path}
    ancestors = sorted({parent for path in files.values() for parent in path.parents},
                       key=lambda p: (len(p.parts), str(p)))
    need(len(ancestors) <= META_SLOTS, "Profondeur Q hors table metadata bornée")
    for parent in ancestors:
        need(parent.resolve(strict=True) == parent and parent.is_dir(),
             "Ancêtre Q non canonique")
    result = {key: str(path) for key, path in files.items()}
    result.update({f"Q_META_{index:02d}": str(ancestors[index]) if index < len(ancestors)
                   else "/dev/null" for index in range(META_SLOTS)})
    return result
