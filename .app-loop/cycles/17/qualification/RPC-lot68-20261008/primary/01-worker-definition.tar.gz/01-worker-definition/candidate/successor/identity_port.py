"""Sept remplacements textuels exacts, définition v2 uniquement."""
from __future__ import annotations

import json
from pathlib import Path


def port_identity_v2(text: str, anchors: dict) -> str:
    if anchors['schema'] != 'c17-runtime78-identity-v2-seven-exact-anchors-v1' or len(anchors['anchors']) != 7:
        raise ValueError('Les sept ancres exactes sont requises')
    for anchor in anchors['anchors']:
        if text.count(anchor['before']) != 1:
            raise ValueError('Ancre identité absente/non unique : ' + anchor['label'])
        text = text.replace(anchor['before'], anchor['after'], 1)
    return text


def render_identity_v2(text: str) -> str:
    anchors = json.loads(Path(__file__).with_name('identity-anchors.json').read_text())
    return port_identity_v2(text, anchors)
