"""Jointures du plan root 15 et des quatre parents, sans admission ni I/O libre."""
from __future__ import annotations

import json
from pathlib import Path

import direct_round_admission as direct
import full_rpc_contract as contract
import coordinator_rpc_relay as relay


def command(row):
    return {'argv': row['argv'], 'role': row['role'], 'mode': row['mode'],
            'timeout_seconds': row['timeout_seconds'], 'env': row['environment'],
            'cwd': row['cwd'], 'stdout_path': row['stdout_path'], 'stderr_path': row['stderr_path'],
            'combine_stderr': False, 'derived_deadline': 'start_monotonic_plus_exact_timeout',
            'logical_parent_id': row['logical_parent_id']}


def plan_binding(binding, root, ident, *, reader=direct.checked_json):
    """Relit la table publiée par root ; aucun PID/birth futur n'est accepté ici.

    L'identité owner du contexte doit encore être confrontée au vrai ledger par
    attach_rpc_dispatcher. Ces données seules ne qualifient ni peer ni runtime.
    """
    root = Path(root)
    plan_ref, context_ref = binding.get('rpc_plan_ref'), binding.get('rpc_context_ref')
    direct.need(type(plan_ref) is dict and plan_ref.get('path') == str(root / 'session-rpc/plan.json')
        and type(context_ref) is dict and context_ref.get('path') == str(root / 'session-rpc/context.json'),
        'Deux refs physiques plan/contexte RPC absentes')
    plan, context = reader(plan_ref, (root,)), reader(context_ref, (root,))
    direct.need(plan.get('schema') == contract.PLAN_SCHEMA and context.get('root') == str(root)
        and all(context.get(key) == ident[key] == plan.get(key) for key in ('actor', 'round_id', 'head'))
        and context.get('context_id') == plan.get('context_id'), 'Plan/contexte d’une autre identité A/B')
    rows = plan.get('descriptors')
    names = ['rpc-' + label for label in contract.SITE_SPECS]
    direct.need(type(rows) is list and len(rows) == 15 and [row.get('id') for row in rows] == names
        and len({row.get('nonce') for row in rows}) == 15,
        'Table fermée 15/ordre/nonces RPC divergente')
    table = {row['id']: row for row in rows}
    direct.need(binding.get('rpc_descriptors') == table, 'Descriptors binding/plan divergents')
    for label, (parent, index, mode, bound) in contract.SITE_SPECS.items():
        row = table['rpc-' + label]
        direct.need(row.get('stage_name') == row['id'] and row.get('label') == label
            and row.get('index') == index and row.get('requester_id') == parent
            and row.get('logical_parent_id') == parent and row.get('mode') == mode
            and row.get('timeout_seconds') == bound and row.get('role') == 'stage-' + row['id']
            and row.get('context_id') == context['context_id'], 'Ligne RPC différente du site réel')
        direct.need(binding.get('commands', {}).get(row['id']) == command(row),
            'Commande RPC binding différente du descriptor complet')
    direct.need('calibrate' in binding.get('commands', {})
        and not direct.SQL_PARENTS.intersection(binding.get('commands', {}))
        and direct.SQL_PARENTS <= set(binding.get('stage_plans', {})),
        'Calibrate initial ou trois parents SQL tardifs non préservés')
    return {'plan': plan, 'context': context, 'descriptors': table}


def parent_metadata(root, binding, stage, env, *, expected_head, reader=direct.checked_json):
    """Deux ajouts exacts, uniquement sur les quatre parents directs A/B."""
    direct.need(stage in direct.DIRECT_PARENTS, 'Métadonnées RPC sur autre étape directe')
    envelope_ref = json.loads(env.get('C17_RPC_CONTEXT_REF', 'null'))
    git_ref = json.loads(env.get('C17_AUX_GIT_SNAPSHOT_REF', 'null'))
    root = Path(root)
    direct.need(type(envelope_ref) is dict
        and envelope_ref.get('path') == str(root / 'session-rpc/envelope' / (stage + '.json'))
        and type(git_ref) is dict and git_ref == binding.get('git_snapshot_ref')
        and git_ref.get('path') == str(root / 'authorization/git-snapshot.json'),
        'Refs parent hors enveloppe exacte/snapshot prélié')
    envelope = reader(envelope_ref, (root,))
    context = envelope.get('context', {})
    direct.need(envelope.get('schema') == contract.ENVELOPE_SCHEMA
        and envelope.get('requester_id') == stage
        and envelope.get('descriptor_plan_path') == str(root / 'session-rpc/plan.json')
        and envelope.get('enrollment_path') == str(root / 'session-rpc/enrollment' / (stage + '.json'))
        and context.get('head') == expected_head and context.get('root') == str(root)
        and all(context.get(key) == binding.get(key) for key in ('actor', 'round_id', 'head')),
        'Enveloppe parent étrangère')
    snapshot = reader(git_ref, (root,))
    direct.need(snapshot.get('head') == expected_head, 'Snapshot parent autre HEAD')
    return {'envelope_ref': envelope_ref, 'git_ref': git_ref}


def coordinator_parent(stage, spec, *, blueprint, bundle, git_ref, reviewed):
    """Appelé avant comparaison ou livraison du binding, jamais après launch."""
    return relay.requester_spec(stage, spec, blueprint, bundle, git_ref=git_ref,
        reviewed_contract_ref=reviewed.get('contract') if stage in direct.SQL_PARENTS else None)


def initial_parent_bindings(binding, initial_specs, *, blueprint, bundle, git_ref):
    """Les trois CLI SQL ne sont pas inventées avant la revue courante.

    Cette garde ferme le calibrate avant binding initial ; les trois autres
    passent coordinator_parent au moment de leur livraison tardive réelle.
    """
    direct.need(type(initial_specs) is dict and set(initial_specs) == {'calibrate'},
        'Aucun spec SQL futur ne peut être scellé au début de la ronde')
    expected = coordinator_parent('calibrate', initial_specs['calibrate'],
        blueprint=blueprint, bundle=bundle, git_ref=git_ref, reviewed={})
    direct.need(binding.get('commands', {}).get('calibrate') == expected
        and not direct.SQL_PARENTS.intersection(binding.get('commands', {}))
        and direct.SQL_PARENTS <= set(binding.get('stage_plans', {})),
        'Calibrate non validé avant binding ou SQL prélié prématurément')
    return expected
