"""Raccord de schémas pur. Aucune observation OS ou approbation n'est créée.

Ces fonctions contrôlent des faits fournis par la vraie Session. Les données
MockSession des futurs tests sont des fixtures déclarées, jamais des reçus.
"""
from __future__ import annotations

import json
from pathlib import Path

NAMES = {'persistent-backend': 'backend', 'persistent-vite': 'vite', 'readiness': 'start-runtime'}
IDENTITY_FIELDS = ('pid', 'start_sec', 'start_usec', 'ppid', 'uid', 'pgid')


def require(value: bool, reason: str) -> None:
    if not value:
        raise ValueError(reason)


def runtime_scope(raw: dict, config: dict) -> None:
    require(config.get('campaign') in ('A', 'B')
            and raw.get('round_name') == config['campaign']
            and raw.get('execution_scope') == 'runtime78_exact_round'
            and raw.get('qa_root') == config.get('root'),
            'Portée runtime A/B exacte absente ; canari/portée étrangère refusé')


def name_role(logical: str) -> tuple[str, str]:
    name = NAMES.get(logical, logical)
    role = {'backend': 'persistent-backend', 'vite': 'persistent-vite'}.get(name, 'stage-' + name)
    return name, role


def identity(value: dict) -> dict:
    require(isinstance(value, dict) and all(isinstance(value.get(k), int) and not isinstance(value[k], bool)
            for k in IDENTITY_FIELDS), 'Identité réelle six champs Darwin absente')
    require(value['pid'] > 0 and value['start_sec'] > 0 and 0 <= value['start_usec'] < 1_000_000
            and value['uid'] >= 0 and value['ppid'] > 0 and value['pgid'] > 0, 'Identité Darwin invalide')
    return value


def binding_spec(logical: str, argv: list[str], mode: str, timeout: float,
                 env: dict[str, str], cwd: str, stdout: str, stderr: str | None,
                 combined: bool) -> dict:
    name, role = name_role(logical)
    require(isinstance(timeout, (float, int)) and not isinstance(timeout, bool) and 0 < timeout <= 1500,
            'Borne exacte manquante/hors plafond1500')
    require(combined == (name in ('backend', 'vite')), 'Log combiné hors des deux services')
    if combined:
        stderr = stdout
    require(isinstance(stdout, str) and isinstance(stderr, str), 'Sinks directs manquants')
    require(combined or stdout != stderr, 'Canaux d’étape doivent rester distincts')
    return {'argv': argv, 'role': role, 'mode': mode, 'timeout_seconds': timeout, 'env': env,
            'cwd': cwd, 'stdout_path': stdout, 'stderr_path': stderr, 'combine_stderr': combined,
            'derived_deadline': 'start_monotonic_plus_exact_timeout'}


def start(session, logical: str, spec: dict):
    name, role = name_role(logical)
    require(spec['role'] == role, 'Rôle binding différent du nom G1')
    return session.start(name, role, spec['argv'], mode=spec['mode'], timeout=spec['timeout_seconds'],
        env=spec['env'], cwd=Path(spec['cwd']), stdout_path=Path(spec['stdout_path']),
        stderr_path=Path(spec['stderr_path']), combine_stderr=spec['combine_stderr'])


def verify_decision_links(successor_ref: dict, successor: dict, session_ref: dict,
                          session: dict, binding_ref: dict, binding: dict, config: dict) -> None:
    require(successor['schema'] == 'c17-runtime78-successor-admission-v1'
            and session['schema'] == 'c17-runtime78-session-root-go-v1', 'Deux décisions distinctes exactes requises')
    require(successor_ref['path'] != session_ref['path'], 'Une décision ne peut changer de schéma')
    for key, expected in (('actor', config['actor']), ('round_id', config['round_id']),
                          ('round_name', config['campaign']), ('head', config['head']), ('qa_root', config['root'])):
        require(successor.get(key) == session.get(key) == binding.get(key) == expected,
                'Décisions/binding étrangers : ' + key)
    require(successor['session_decision'] == session_ref and successor['session_binding'] == binding_ref
            and session['binding'] == binding_ref, 'Chaîne décision/binding différente')
    require('root_decision' not in binding, 'Ancienne référence inverse avec SHA crée un cycle')
    require(binding['planned_decisions'] == {
        'successor': {'path': successor_ref['path'], 'decision_id': successor['decision_id']},
        'session': {'path': session_ref['path'], 'decision_id': session['decision_id']}},
        'Paths/ids planifiés différents (aucun SHA inverse dans binding)')


def verify_stage_binding_links(delivery: dict, stage_binding: dict, stage_decision: dict,
                               logical: str, spec: dict, config: dict, initial_ref: dict,
                               initial: dict) -> None:
    """Jointure pure. La vraie origine/autorité reste à vérifier par Session/root.

    Le binding d'étape est figé après production des références courantes.
    Il pointe vers l'initial SHA ; la décision pointe vers le binding d'étape.
    Le binding d'étape ne pointe jamais vers le SHA futur de sa décision.
    """
    name, _ = name_role(logical)
    require(stage_binding['schema'] == 'c17-runtime78-stage-binding-v1'
            and stage_decision['schema'] == 'c17-runtime78-stage-go-v1', 'Schémas admission d’étape absents')
    for item in (stage_binding, stage_decision):
        for key, expected in (('actor', config['actor']), ('round_id', config['round_id']),
                              ('round_name', config['campaign']), ('head', config['head']), ('qa_root', config['root'])):
            require(item.get(key) == expected, 'Étape d’une autre identité : ' + key)
        require(item.get('initial_binding') == initial_ref and item.get('stage_id') == name,
                'Étape non liée au binding initial/nom G1 exact')
    require(stage_binding['command'] == spec, 'Commande d’étape pas exactement celle des références réellement produites')
    require(stage_decision.get('provided_by') == '/root' and stage_decision['stage_binding'] == delivery['binding']
            and stage_decision['root_review_origin'] == delivery['origin'], 'Décision/origine d’étape non exacte')
    require('decision_ref' not in stage_binding, 'SHA inverse interdit dans binding d’étape')
    planned = initial['stage_plans'][name]
    require(planned.get('timeout_seconds') == spec['timeout_seconds'], 'Borne d’étape différente du plan initial')
    require(stage_binding['planned_decision'] == planned['decision'] == {
        'path': delivery['decision']['path'], 'decision_id': stage_decision['decision_id']}
        and delivery['binding']['path'] == planned['binding_path'], 'Autre path/id planifié d’étape')


def effective_environment(spec: dict, raw: dict, config: dict, session_ref: dict,
                          session_decision: dict, binding_ref: dict, module_ref: dict) -> dict:
    measured = raw.get('started_monotonic')
    require(isinstance(measured, (float, int)) and not isinstance(measured, bool) and measured > 0,
            'Vraie mesure start_monotonic absente ; aucun défaut inventé')
    deadline = measured + spec['timeout_seconds']
    name = raw['stage_id']
    return spec['env'] | {'QA_ROOT': config['root'],
        'C17_RUNTIME_MODULE_DIR': str(Path(module_ref['path']).parent),
        'C17_SESSION_ACTOR': config['actor'], 'C17_SESSION_ROUND_ID': config['round_id'],
        'C17_SESSION_HEAD': config['head'], 'C17_SESSION_STAGE': name,
        'C17_SESSION_ROOT': config['root'], 'C17_SESSION_EVENTS': str(Path(config['root']) / 'session-events'),
        'C17_SESSION_DECISION_ID': session_decision['decision_id'],
        'C17_SESSION_BINDING_SHA256': binding_ref['sha256'], 'C17_SESSION_ROUND_NAME': config['campaign'],
        'C17_SESSION_DECISION_REF': json.dumps(session_ref, sort_keys=True),
        'C17_SESSION_BINDING_REF': json.dumps(binding_ref, sort_keys=True),
        'C17_SESSION_OUTER_DEADLINE_MONOTONIC': str(deadline)}


def verify_stage(raw: dict, logical: str, spec: dict, config: dict, expected_env: dict) -> None:
    runtime_scope(raw, config)
    name, role = name_role(logical)
    require('instrument_error' in raw and 'exit_code' in raw, 'Champs de verdict réels absents')
    require(raw.get('released') is True, 'Workload non libéré : aucun succès runtime')
    identity(raw.get('root_identity'))
    require(raw.get('role') == role and raw.get('stage_id') == name and raw.get('argv') == spec['argv']
            and raw.get('cwd') == spec['cwd'], 'Reçu autre commande/nom/rôle/cwd')
    require(all(raw.get(k) == config[k] for k in ('actor', 'round_id', 'head')), 'Autre acteur/ronde/HEAD')
    require(raw.get('environment') == expected_env and raw.get('timeout_seconds') == spec['timeout_seconds']
            and raw.get('outer_deadline_monotonic') == raw['started_monotonic'] + spec['timeout_seconds'],
            'Env/deadline effectif non exact')
    require(raw.get('cleanup_deadline_met') is True and raw.get('cleanup_taint') == [],
            'Deadline cleanup/taint réel absent ; aucun True/[] de secours')
    require(raw.get('instrument_error') is None and raw.get('timed_out') is False
            and raw.get('raw_stable') is True and raw.get('log_stability_proved') is True
            and type(raw.get('exit_code')) is int and raw['exit_code'] == 0,
            'Erreur instrument/timeout/stabilité/exit non vert')
    for channel in ('stdout', 'stderr'):
        require(raw[channel]['path'] == spec[channel + '_path'], 'Sink réellement observé différent')


def verify_services(observed: dict, config: dict) -> dict:
    runtime_scope(observed, config)
    require(observed.get('schema') == 'c17-runtime78-owned-services-observation-v1'
            and all(observed.get(k) == config[k] for k in ('actor', 'round_id', 'head')), 'Autre observation services')
    for name in ('backend', 'vite'):
        identity(observed[name]['identity'])
        require(isinstance(observed[name]['start_receipt'], dict), 'Vrai reçu d’admission service absent')
    return observed


def verify_shutdown(raw: dict, config: dict, *, final: bool) -> None:
    runtime_scope(raw, config)
    require(all(raw.get(k) == config[k] for k in ('actor', 'round_id', 'head')),
            'Cleanup d’une autre identité réelle')
    require('cleanup_error' in raw, 'Champ cleanup_error réel absent')
    require(raw.get('schema') == ('c17-runtime78-owned-session-close-v1' if final
            else 'c17-runtime78-owned-service-stop-v1'), 'Schéma shutdown différent')
    require(raw.get('session_closed' if final else 'services_stopped') is True
            and raw.get('clean') is True and raw.get('cleanup_error') is None
            and raw.get('log_stability_tainted') is False and raw.get('log_stability_proved') is True,
            'Shutdown/non-stabilité/taint réel refusé')
    if final:
        require(raw.get('rpc_transport_closed') is True and raw.get('rpc_transport_quiescent') is True
                and raw.get('rpc_transport_clean') is True and raw.get('rpc_transport_error') is None
                and isinstance(raw.get('rpc_transport_receipt'), dict),
                'Transport RPC final non fermé/quiescent/stable avant reçu Session')
    cleanup = raw.get('cleanup')
    require(isinstance(cleanup, dict) and cleanup.get('clean') is True
            and cleanup.get('remaining_attributed') == cleanup.get('ambiguities') == cleanup.get('errors') == [],
            'Cleanup/ambiguïtés/erreurs/restants non prouvés vides')
    require(raw.get('launched_services') == ['backend', 'vite'] and raw.get('unlaunched_handles') == [],
            'Lancement réel des deux services non prouvé')
    require(raw.get('ports_absence_proved') is True and raw.get('ports_absent') == [17593, 5173]
            and isinstance(raw.get('ports_absence_receipt'), dict), 'Preuve fraîche ports-absents absente')
    # Cette fonction ne remplit aucun champ manquant, ne lance aucun diagnostic,
    # ne prouve pas les faits kernel et ne réécrit jamais le raw.
