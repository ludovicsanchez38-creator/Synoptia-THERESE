"""Port density45 : mêmes fixtures/borne/absence de rejeu, custody renforcée.

Définition source : round-B4-preserve/run.py seed_density(), SHA fichier
75e8e7b914d4c1510cd258e6f65c607d0582d66605a5a6040145e0b338588000.
Aucune donnée historique n'est une fixture de la ronde future.
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import urllib.request

import runtime78_core as core

MINIMUMS = {'contact': 10, 'discovery': 5, 'proposition': 5, 'signature': 5,
            'delivery': 5, 'active': 5, 'lost': 5, 'archive': 5}


def seed_density(root: Path, decision_ref: dict) -> dict:
    config, decision, api = core.worker_context(root, decision_ref)
    stack = core.stack_profile(config, root, running=True)
    auth = {'network_policy': 'loopback_owned_backend_only', 'token_saved': False}
    journal = root / 'density-contact-journal.jsonl'
    checkpoint_path = root / 'density-fixtures.json'
    core.need(not journal.exists() and not journal.is_symlink() and not checkpoint_path.exists()
              and not checkpoint_path.is_symlink(), 'Journal/checkpoint existant : aucun POST rejoué')
    core.inside(root, journal)
    fd = os.open(journal, os.O_CREAT | os.O_EXCL | os.O_WRONLY | os.O_NOFOLLOW, 0o600)
    fixtures: list[dict] = []
    checkpoint_sha = None
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))

    def ownership() -> None:
        for port in (17593, 5173):
            api.request_owned_listener_observation(root, stack, port, root / 'ownership-density.jsonl',
                stage_id='density', deadline=5)

    def checkpoint(status: str) -> None:
        nonlocal checkpoint_sha
        data = {'cycle': 17, 'actor': config['actor'], 'round_id': config['round_id'], 'head': core.HEAD,
            'data_dir': stack['data_dir'], 'updated_at': core.now(), 'status': status,
            'minimums': MINIMUMS, 'fixtures': fixtures, 'journal': str(journal), 'guard': auth,
            'scope': 'Fixture synthetique de densite seulement ; aucune observation UI ou preuve de geometrie'}
        if checkpoint_sha is None:
            core.save_new(root, checkpoint_path, data)
            checkpoint_sha = core.sha(checkpoint_path)
        else:
            checkpoint_sha = core.rewrite_owned(root, checkpoint_path, checkpoint_sha, data)

    with os.fdopen(fd, 'w', encoding='utf-8') as stream:
        identity = os.fstat(stream.fileno())

        def event(data: dict) -> None:
            named = journal.lstat()
            core.need((named.st_dev, named.st_ino) == (identity.st_dev, identity.st_ino), 'Journal remplacé')
            data = {**data, 'actor': config['actor'], 'round_id': config['round_id'], 'at': core.now()}
            stream.write(json.dumps(data, ensure_ascii=False) + '\n')
            stream.flush()
            os.fsync(stream.fileno())

        ownership()
        with opener.open('http://127.0.0.1:17593/api/auth/token', timeout=5) as response:
            token = json.load(response)['token']
        checkpoint('creating_synthetic_fixtures')
        for stage, count in MINIMUMS.items():
            for i in range(count):
                body = {'first_name': f'Densite B {stage} {i+1} nom long controle',
                    'company': 'Organisation synthetique de controle des cartes et des colonnes', 'stage': stage}
                request = urllib.request.Request('http://127.0.0.1:17593/api/crm/contacts', data=json.dumps(body).encode(),
                    headers={'content-type': 'application/json', 'X-Therese-Token': token}, method='POST')
                ownership()
                key = f'{stage}/{i+1}'
                event({'event': 'before_POST', 'fixture_key': key, 'method': 'POST', 'url': request.full_url,
                    'request_synthetic': body, 'timeout_seconds': 60, 'authorization_header_saved': False})
                try:
                    with opener.open(request, timeout=60) as response:
                        created = json.load(response)
                        record = {'request': body, 'id': created['id'], 'status': response.status, 'fixture_key': key}
                        fixtures.append(record)
                        event({'event': 'response', 'fixture_key': key, 'status': response.status,
                            'id': created['id'], 'response_synthetic': created})
                        checkpoint('creating_synthetic_fixtures')
                except BaseException as error:
                    event({'event': 'request_failed_no_retry', 'fixture_key': key, 'error': str(error),
                        'POST_result_may_be_unknown': True})
                    checkpoint('failed_stop_no_POST_retry')
                    raise
        checkpoint('synthetic_fixtures_complete')
    core.qa_sources_unchanged(config)
    return core.ref(checkpoint_path)


def main() -> int:
    if not core.RUNTIME_ENABLED:
        return core.closed_main()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root', type=Path)
    parser.add_argument('--decision', type=Path, required=True)
    parser.add_argument('--decision-sha256', required=True)
    args = parser.parse_args()
    result = seed_density(args.root, {'path': str(args.decision), 'sha256': args.decision_sha256})
    print(json.dumps(result, ensure_ascii=False))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
