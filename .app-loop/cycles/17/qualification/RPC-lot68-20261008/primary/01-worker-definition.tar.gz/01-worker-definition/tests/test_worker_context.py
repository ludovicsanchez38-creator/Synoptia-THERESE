"""Vrais corps AST, identité logique synthétique et fichiers QA de test.

Aucun vrai root A/B, décision Q, processus, HTTP ou import G1. Les références
Q sont des noms logiques de doubles, joints à des fichiers exclusivement dans
la sortie de tests. Les contrôles bytes/blobs/modes utilisent les vrais corps.
"""
from __future__ import annotations
import ast
import copy
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import time
from types import SimpleNamespace as NS
import unittest

HERE = Path(__file__).resolve().parent.parent
SUCCESSOR = HERE / 'candidate/successor'
Q = Path('/Users/synoptia/Desktop/Dev Synoptia/Synoptia-THERESE-c15-codex/.app-loop/cycles/17/qualification')


def selected(path, names, space):
    tree = ast.parse(path.read_text(), filename=str(path))
    rows = [row for row in tree.body if isinstance(row, (ast.FunctionDef, ast.ClassDef)) and row.name in names]
    if {row.name for row in rows} != set(names):
        raise ValueError('Unique selected definitions required')
    for row in rows:
        if any(isinstance(node, (ast.Import, ast.ImportFrom)) for node in ast.walk(row)):
            raise ValueError('No import inside selected policy body')
    exec(compile(ast.fix_missing_locations(ast.Module(body=rows, type_ignores=[])), str(path), 'exec'), space)
    return space


def digest(data):
    return hashlib.sha256(data).hexdigest()


def row(path):
    raw = path.read_bytes()
    return {'path': str(path), 'sha256': digest(raw), 'bytes': len(raw)}


class WorkerContext(unittest.TestCase):
    def setUp(self):
        self.folder = Path(os.environ['C17_PURE_FIXTURE_ROOT']) / self._testMethodName
        self.folder.mkdir(mode=0o700)
        self.root = Path('/private/tmp/therese-c17-direct-round-a-0123456789ab')
        self.round_id = 'c17-direct-round-a-0123456789ab'
        self.actor = '/root/environment_routes'
        self.trace = []
        self.source = self.folder / 'therese-c17-synthetic-source/source'
        (self.source / '.git').mkdir(mode=0o700, parents=True)
        product = self.source / 'src/backend/synthetic_policy.py'
        product.parent.mkdir(mode=0o700, parents=True)
        product.write_bytes(b'# SYNTHETIC TEST SOURCE, NOT PRODUCT\n')
        product.chmod(0o600)
        commit = b'tree ' + b'a' * 40 + b'\n\nSYNTHETIC TEST COMMIT\n'
        self.head = hashlib.sha1(b'commit ' + str(len(commit)).encode() + b'\0' + commit).hexdigest()
        (self.source / '.git/HEAD').write_text(self.head + '\n')
        raw = product.read_bytes()
        blob = hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
        tree = b'100644 blob ' + blob.encode() + b'\tsrc/backend/synthetic_policy.py\0'
        self.mapping = {}
        self.config = {'cycle': 17, 'actor': self.actor, 'round_id': self.round_id,
            'campaign': 'A', 'head': self.head, 'root': str(self.root),
            'python': str(self.source / '.venv-conforme/bin/python'),
            'frontend_qa': str(self.source / 'src/frontend'),
            'frontend_dependencies': str(self.source / 'src/frontend/node_modules'),
            'playwright_dependencies': str(self.source / 'node_modules'),
            'product_sources': {'src/backend/synthetic_policy.py': digest(raw)}, 'frontend_qa_sources': {}}
        head_ref = row(self.source / '.git/HEAD')
        commit_ref = self.emit('authorization/git-commit.raw', commit)
        tree_ref = self.emit('authorization/git-tree.raw', tree)
        self.manifest = {'schema': 'c17-root-fresh-git-source-manifest-v1', 'status': 'PASS',
            'head': self.head, 'product_source_root': str(self.source), 'git_head_ref': head_ref,
            'git_tree_verified': True, 'git_commit_ref': commit_ref, 'git_tree_ref': tree_ref,
            'files': [row(product) | {'git_blob': blob}], 'modes': {str(product): '100644'}}
        manifest_ref = self.emit_json('authorization/source-files.json', self.manifest)
        ident = {'actor': self.actor, 'round_id': self.round_id, 'round_name': 'A',
                 'head': self.head, 'qa_root': str(self.root)}
        self.checkout = ident | {'schema': 'c17-direct-round-source-checkout-v1',
            'git_head': self.head, 'git_tree_verified': True, 'product_source_root': str(self.source),
            'git_head_ref': head_ref, 'source_manifest_ref': manifest_ref}
        self.binding = ident | {'prepared_config_ref': self.emit_json('prepared-config.json', self.config),
            'source_checkout_ref': self.emit_json('authorization/source-checkout.json', self.checkout),
            'source_manifest_ref': manifest_ref, 'product_source_root': str(self.source),
            'qa_python': self.config['python']}
        self.binding_path = self.folder / 'synthetic-authority-binding.json'
        self.binding_path.write_text(json.dumps(self.binding, sort_keys=True))
        self.binding_ref = row(self.binding_path) | {'path': str(Q / 'SYNTHETIC-TEST-NOT-AUTHORITY/binding.json')}
        self.mapping[self.binding_ref['path']] = self.binding_path
        self.env = {'QA_ROOT': str(self.root), 'C17_SESSION_ROOT': str(self.root),
            'C17_SESSION_ACTOR': self.actor, 'C17_SESSION_ROUND_ID': self.round_id,
            'C17_SESSION_ROUND_NAME': 'A', 'C17_SESSION_HEAD': self.head,
            'C17_SESSION_BINDING_REF': json.dumps(self.binding_ref, sort_keys=True),
            'C17_SESSION_BINDING_SHA256': self.binding_ref['sha256']}
        direct_space = {'Path': Path, 'hashlib': hashlib, 'json': json, 're': re, 'stat': stat, 'os': os,
            'ROUND': re.compile(r'therese-(c17-direct-round-([ab])-[0-9a-f]{12})')}
        selected(SUCCESSOR / 'direct_round_admission.py',
            ('need', 'identity', 'checked_bytes', 'checked_json', 'tree_rows', 'verify_files', 'source_context'), direct_space)
        self.direct = direct_space

        def mapped_bytes(reference, roots):
            physical = self.mapping.get(reference['path'], Path(reference['path']))
            physical_roots = tuple(self.folder if Path(base) == self.root else Path(base) for base in roots)
            return self.direct['checked_bytes'](dict(reference, path=str(physical)), physical_roots)

        def context(root, binding, **kw):
            self.trace.append('source-context')
            return self.direct['source_context'](root, binding, **kw,
                reader=lambda reference, roots: json.loads(mapped_bytes(reference, roots)),
                bytes_reader=mapped_bytes, files_verifier=self.direct['verify_files'])

        def checked(reference):
            self.trace.append('checked-binding')
            if reference['path'] not in self.mapping or not Path(reference['path']).is_relative_to(Q):
                raise ValueError('Synthetic checked binding unknown/outside Q')
            physical = self.mapping[reference['path']]
            self.direct['checked_bytes'](dict(reference, path=str(physical)), (self.folder,))
            return physical

        def load(path):
            physical = self.mapping.get(str(path), Path(path))
            return json.loads(physical.read_bytes())

        def root_double(root):
            # No actual A/B root is allocated. The real logical identity/body
            # below validates its exact names; filesystem custody is not claimed.
            if root != self.root:
                raise ValueError('Synthetic round root mismatch')
            return root

        class ClosedPreparation(ValueError):
            pass

        def admission(*args, **kw):
            self.trace.append('admission')
            raise ClosedPreparation('Synthetic reach: runtime remains physically closed')

        def forbidden_import(*args):
            self.trace.append('import')
            raise AssertionError('Full capability import forbidden in pure tests')

        self.space = {'Path': Path, 'json': json, 're': re, 'os': NS(environ=self.env),
            'Q': Q, 'HEAD': None, 'QA_SOURCE': None, 'PYTHON': None,
            '_DIRECT_CONTEXT': None, '_DIRECT_BINDING': None, '_DIRECT_BINDING_REF': None,
            'RUNTIME_ENABLED': False, 'SQL_READ_VIEW': None, 'SESSION_ABI': 'c17-runtime78-session-api-v1',
            'ClosedPreparation': ClosedPreparation, 'load': load, 'checked': checked,
            'round_root': root_double, 'admission': admission, 'import_admitted': forbidden_import,
            'direct_round': NS(source_context=context, identity=self.direct['identity']),
            'sha': lambda path: digest(Path(path).read_bytes())}
        selected(SUCCESSOR / 'runtime78_core.py',
            ('need', 'configure_direct_round', 'config_identity', 'qa_sources_unchanged', 'worker_context'), self.space)

    def emit(self, relative, raw):
        target = self.folder / relative
        target.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        target.write_bytes(raw)
        logical = self.root / relative
        self.mapping[str(logical)] = target
        return row(target) | {'path': str(logical)}

    def emit_json(self, relative, value):
        return self.emit(relative, json.dumps(value, sort_keys=True).encode())

    def repin_binding(self):
        self.binding_path.write_text(json.dumps(self.binding, sort_keys=True))
        self.binding_ref.update({key: value for key, value in row(self.binding_path).items() if key != 'path'})
        self.env['C17_SESSION_BINDING_REF'] = json.dumps(self.binding_ref, sort_keys=True)
        self.env['C17_SESSION_BINDING_SHA256'] = self.binding_ref['sha256']

    def context(self):
        return self.space['worker_context'](self.root, {'path': '/SYNTHETIC-ONLY/decision'})

    def reject_before_admission(self):
        with self.assertRaises((ValueError, TypeError, KeyError)):
            self.context()
        self.assertNotIn('admission', self.trace)
        self.assertNotIn('import', self.trace)

    def test_fresh_child_configures_real_context_before_still_closed_admission(self):
        self.assertIsNone(self.space['_DIRECT_CONTEXT'])
        with self.assertRaisesRegex(self.space['ClosedPreparation'], 'physically closed'):
            self.context()
        self.assertEqual(self.trace, ['checked-binding', 'source-context', 'admission'])
        self.assertEqual(self.space['HEAD'], self.head)
        self.assertEqual(self.space['QA_SOURCE'], self.source)
        self.assertEqual(self.space['_DIRECT_CONTEXT']['config'], self.config)
        self.assertEqual(self.space['_DIRECT_BINDING_REF'], self.binding_ref)
        self.assertIs(self.space['RUNTIME_ENABLED'], False)

    def test_missing_binding_ref(self):
        self.env.pop('C17_SESSION_BINDING_REF'); self.reject_before_admission()

    def test_missing_head(self):
        self.env.pop('C17_SESSION_HEAD'); self.reject_before_admission()

    def test_malformed_head(self):
        self.env['C17_SESSION_HEAD'] = 'HEAD'; self.reject_before_admission()

    def test_head_different_from_config(self):
        self.env['C17_SESSION_HEAD'] = 'f' * 40; self.reject_before_admission()

    def test_binding_json_non_object(self):
        self.env['C17_SESSION_BINDING_REF'] = '[]'; self.reject_before_admission()

    def test_binding_json_malformed(self):
        self.env['C17_SESSION_BINDING_REF'] = '{'; self.reject_before_admission()

    def test_binding_sha_injection_mismatch(self):
        self.env['C17_SESSION_BINDING_SHA256'] = 'f' * 64; self.reject_before_admission()

    def test_binding_missing_bytes(self):
        reference = dict(self.binding_ref); reference.pop('bytes')
        self.env['C17_SESSION_BINDING_REF'] = json.dumps(reference); self.reject_before_admission()

    def test_binding_boolean_bytes(self):
        self.env['C17_SESSION_BINDING_REF'] = json.dumps(dict(self.binding_ref, bytes=True)); self.reject_before_admission()

    def test_binding_extra_key(self):
        self.env['C17_SESSION_BINDING_REF'] = json.dumps(dict(self.binding_ref, approved=True)); self.reject_before_admission()

    def test_binding_changed_bytes_after_pin(self):
        self.binding_path.write_text(self.binding_path.read_text() + '\n'); self.reject_before_admission()

    def test_binding_unknown_authority_path(self):
        self.env['C17_SESSION_BINDING_REF'] = json.dumps(dict(self.binding_ref, path=str(Q / 'unknown.json')))
        self.reject_before_admission()

    def test_binding_wrong_actor_rehashed(self):
        self.binding['actor'] = '/root'; self.repin_binding(); self.reject_before_admission()

    def test_binding_wrong_round_rehashed(self):
        self.binding['round_id'] = 'c17-direct-round-a-ffffffffffff'; self.repin_binding(); self.reject_before_admission()

    def test_binding_wrong_head_rehashed(self):
        self.binding['head'] = 'f' * 40; self.repin_binding(); self.reject_before_admission()

    def test_binding_other_config_path_rehashed(self):
        self.binding['prepared_config_ref']['path'] = str(self.root / 'other-config.json')
        self.repin_binding(); self.reject_before_admission()

    def test_config_changed_after_pin(self):
        path = self.mapping[str(self.root / 'prepared-config.json')]
        config = json.loads(path.read_text()); config['python'] = '/SYNTHETIC-NOT-QA/python'
        path.write_text(json.dumps(config)); self.reject_before_admission()

    def test_config_actor_mismatch(self):
        self.env['C17_SESSION_ACTOR'] = '/root'; self.reject_before_admission()

    def test_config_round_mismatch(self):
        self.env['C17_SESSION_ROUND_ID'] = 'c17-direct-round-a-ffffffffffff'; self.reject_before_admission()

    def test_config_campaign_mismatch(self):
        self.env['C17_SESSION_ROUND_NAME'] = 'B'; self.reject_before_admission()

    def test_injected_root_mismatch(self):
        self.env['C17_SESSION_ROOT'] = '/private/tmp/other'; self.reject_before_admission()

    def test_injected_QA_ROOT_mismatch(self):
        self.env['QA_ROOT'] = '/private/tmp/other'; self.reject_before_admission()

    def test_missing_actor(self):
        self.env.pop('C17_SESSION_ACTOR'); self.reject_before_admission()

    def test_missing_campaign(self):
        self.env.pop('C17_SESSION_ROUND_NAME'); self.reject_before_admission()

    def test_detached_head_changed(self):
        (self.source / '.git/HEAD').write_text('f' * 40 + '\n'); self.reject_before_admission()

    def test_product_source_changed(self):
        (self.source / 'src/backend/synthetic_policy.py').write_bytes(b'# MUTANT\n'); self.reject_before_admission()

    def test_product_mode_changed(self):
        (self.source / 'src/backend/synthetic_policy.py').chmod(0o700); self.reject_before_admission()

    def test_listener_API_guard_preserved_after_context_source_and_admission(self):
        self.space['admission'] = lambda *a, **kw: self.trace.append('admission-double') or {'session': {'module': {}}}
        self.space['import_admitted'] = lambda *a: self.trace.append('mock-import') or NS(API_SCHEMA='wrong-schema')
        with self.assertRaisesRegex(ValueError, 'API de rendezvous'):
            self.context()
        self.assertEqual(self.trace, ['checked-binding', 'source-context', 'admission-double', 'mock-import'])

    def test_source_check_preserved_after_admission_before_API_import(self):
        def synthetic_admission(*a, **kw):
            self.trace.append('admission-double')
            (self.source / 'src/backend/synthetic_policy.py').write_bytes(b'# MUTANT AFTER ADMISSION\n')
            return {'session': {'module': {}}}
        self.space['admission'] = synthetic_admission
        with self.assertRaisesRegex(ValueError, 'Copies QA différentes'):
            self.context()
        self.assertNotIn('import', self.trace)

    def assert_worker_refuses_before_effect(self, filename, name):
        self.env.pop('C17_SESSION_BINDING_REF')
        def effect(*args, **kw):
            self.trace.append('forbidden-effect')
            raise AssertionError('HTTP/POST/FD/stack must not be reached')
        core = NS(worker_context=self.space['worker_context'], stack_profile=effect)
        space = {'Path': Path, 'core': core, 'os': NS(environ=self.env, open=effect),
                 'urllib': NS(request=NS(build_opener=effect)), 'g1_bridge': NS(identity=effect)}
        selected(SUCCESSOR / filename, (name,), space)
        with self.assertRaisesRegex(ValueError, 'Binding/HEAD injectés'):
            space[name](self.root, {'path': '/SYNTHETIC/decision'})
        self.assertNotIn('forbidden-effect', self.trace)
        self.assertNotIn('import', self.trace)

    def test_real_readiness_body_refuses_before_HTTP_or_POST(self):
        self.assert_worker_refuses_before_effect('readiness_owned.py', 'readiness')

    def test_real_density_body_refuses_before_FD_or_HTTP_or_POST(self):
        self.assert_worker_refuses_before_effect('density_owned.py', 'seed_density')


class StaticClosure(unittest.TestCase):
    def test_only_worker_context_AST_changed(self):
        before = ast.parse((HERE / 'preimages/runtime78_core.py').read_text())
        after = ast.parse((SUCCESSOR / 'runtime78_core.py').read_text())
        before.body = [r for r in before.body if not isinstance(r, ast.FunctionDef) or r.name != 'worker_context']
        after.body = [r for r in after.body if not isinstance(r, ast.FunctionDef) or r.name != 'worker_context']
        self.assertEqual(ast.dump(before, include_attributes=False), ast.dump(after, include_attributes=False))

    def test_existing_worker_tail_assertions_byte_exact(self):
        before = (HERE / 'preimages/runtime78_core.py').read_text()
        after = (SUCCESSOR / 'runtime78_core.py').read_text()
        marker = '    config_identity(config, root)\n    decision = admission(decision_ref'
        self.assertEqual(before[before.index(marker):], after[after.index(marker):])

    def test_both_workers_are_byte_exact(self):
        data = json.loads((HERE / 'preparation.json').read_text())
        for name in ('readiness_owned.py', 'density_owned.py'):
            relation = next(r for r in data['copies'] if r['original']['path'].endswith('/' + name))
            self.assertEqual(Path(relation['original']['path']).read_bytes(), Path(relation['copy']['path']).read_bytes())

    def test_every_non_core_candidate_is_exact_original(self):
        for relation in json.loads((HERE / 'preparation.json').read_text())['copies']:
            if not relation['copy']['path'].endswith(('/runtime78_core.py', '/runtime_session.py')):
                self.assertEqual(Path(relation['original']['path']).read_bytes(), Path(relation['copy']['path']).read_bytes())

    def test_all_runtime_flags_capabilities_admission_tables_closed(self):
        for directory in ('g1', 'successor'):
            for path in (HERE / 'candidate' / directory).glob('*.py'):
                for node in ast.parse(path.read_text()).body:
                    targets = node.targets if isinstance(node, ast.Assign) else [node.target] if isinstance(node, ast.AnnAssign) else []
                    for target in targets:
                        if not isinstance(target, ast.Name):
                            continue
                        if target.id in ('RUNTIME_ENABLED', 'OS_STARTUP_QUALIFIED', 'AB_AUXILIARY_QUALIFIED'):
                            self.assertIs(ast.literal_eval(node.value), False, str(path))
                        elif target.id in ('ADMISSION_TABLE', 'WRAPPER_ADMISSION_TABLE'):
                            self.assertEqual(ast.literal_eval(node.value), {}, str(path))
                        elif target.id == 'CAPABILITIES':
                            self.assertTrue(all(value is False for value in ast.literal_eval(node.value).values()))

    def test_no_existing_obligation_or_bound_changed(self):
        for name in ('runtime_bounds.py', 'g1_bridge.py', 'runtime78_coordinator.py', 'sql_worker.py', 'rpc_abi_reader.py'):
            self.assertEqual((SUCCESSOR / name).read_bytes(),
                (Path('/private/tmp/therese-c17-full-composite-9I2loX52/candidate/successor') / name).read_bytes())

    def test_G1_only_uuid_import_added_all_other_AST_exact(self):
        before = ast.parse((HERE / 'preimages/runtime_session.py').read_text())
        after = ast.parse((HERE / 'candidate/g1/runtime_session.py').read_text())
        nodes = [node for node in after.body if isinstance(node, ast.Import)
                 and len(node.names) == 1 and node.names[0].name == 'uuid' and node.names[0].asname is None]
        self.assertEqual(len(nodes), 1)
        after.body.remove(nodes[0])
        self.assertEqual(ast.dump(before, include_attributes=False), ast.dump(after, include_attributes=False))


class ListenerNonce(unittest.TestCase):
    def test_real_export_resolves_source_import_and_generates_distinct_request_nonces(self):
        root = Path(os.environ['C17_PURE_FIXTURE_ROOT']) / 'therese-c17-wrapper-canary-synthetic_nonce'
        root.mkdir(mode=0o700)
        (root / 'session-events').mkdir(mode=0o700)
        api = HERE / 'candidate/g1/runtime_session.py'
        tree = ast.parse(api.read_text(), filename=str(api))
        import_node = [node for node in tree.body if isinstance(node, ast.Import)
            and len(node.names) == 1 and node.names[0].name == 'uuid' and node.names[0].asname is None]
        self.assertEqual(len(import_node), 1)
        actor, round_id, head = '/SYNTHETIC/requester', 'SYNTHETIC-NOT-A-ROUND', 'a' * 40
        env = {'C17_SESSION_HEAD': head, 'C17_SESSION_ROUND_NAME': 'WRAPPER_CANARY',
            'C17_SESSION_STAGE': 'start-runtime', 'C17_SESSION_ROOT': str(root),
            'C17_SESSION_EVENTS': str(root / 'session-events'), 'C17_SESSION_ACTOR': actor,
            'C17_SESSION_ROUND_ID': round_id, 'C17_SESSION_DECISION_REF': '{}',
            'C17_SESSION_BINDING_REF': '{}', 'C17_SESSION_DECISION_ID': 'SYNTHETIC-ONLY',
            'C17_SESSION_BINDING_SHA256': 'b' * 64}
        captured = []

        class CapturedRequest(Exception):
            pass

        def require(value, reason):
            if not value:
                raise ValueError(reason)

        def publish(qa_root, path, payload):
            self.assertEqual(qa_root, root)
            self.assertTrue(path.is_relative_to(root / 'session-events'))
            with path.open('x', encoding='utf-8') as stream:
                json.dump(payload, stream, sort_keys=True)
            captured.append({'path': path, 'payload': json.loads(path.read_text())})
            raise CapturedRequest('Pure interception before waiting for any owning Session')

        space = {'Path': Path, 'os': NS(environ=env), 're': re, 'json': json, 'time': time,
            'PORTS': (17593, 5173), 'WRAPPER_PATTERN': re.compile(r'therese-c17-wrapper-canary-[a-z0-9_]{8,64}\Z'),
            'ab_aux': NS(scope=lambda *a: False), 'require': require,
            'load_admission': lambda *a, **kw: ({'head': head}, {'head': head}),
            'PUBLICATION_PROTOCOL': 'exclusive-pending-fsync-hardlink-v1', 'publish_json': publish}
        # Exec precisely the newly added stdlib import, never G1's module body.
        exec(compile(ast.fix_missing_locations(ast.Module(body=import_node, type_ignores=[])), str(api), 'exec'), space)
        self.assertEqual(space['uuid'].__name__, 'uuid')
        selected(api, ('request_owned_listener_observation',), space)
        stack = {'backend': {'pid': 123, 'birth_identity': {'pid': 123, 'synthetic_only': True}}}
        for _ in range(2):
            with self.assertRaises(CapturedRequest):
                space['request_owned_listener_observation'](root, stack, 17593,
                    root / 'ownership-traces.jsonl', stage_id='start-runtime', deadline=5)
        self.assertEqual(len(captured), 2)
        self.assertNotEqual(captured[0]['path'], captured[1]['path'])
        for item in captured:
            nonce = item['path'].name.removeprefix('listener-request-start-runtime-').removesuffix('.json')
            self.assertRegex(nonce, r'^[a-f0-9]{32}$')
            self.assertEqual(item['payload']['schema'], 'c17-runtime78-owned-listener-request-v1')
            self.assertEqual(item['payload']['deadline_seconds'], 5)
            self.assertEqual(item['payload']['actor'], actor)
            self.assertEqual(item['payload']['expected_root_identity'], stack['backend']['birth_identity'])


def suite():
    return unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromTestCase(cls)
                              for cls in (WorkerContext, StaticClosure, ListenerNonce))
