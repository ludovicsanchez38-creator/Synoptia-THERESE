"""Bootstrap root RPC A/B proposé. Import inerte ; aucune porte/capacité ouverte.

Seul un futur core/G1 admis peut appeler bootstrap. Les six modules sont
chargés de références physiques exactes avant factory Unix ; les tests
sélectionnent les vrais corps AST avec doubles synthétiques. Aucune table,
birth, décision, enveloppe ou admission future n'est fabriquée ici.
"""
from __future__ import annotations

import importlib.util
import math
from pathlib import Path
import sys
import time

MODULES = ("rpc_protocol.py", "rpc_client.py", "rpc_dispatcher.py",
           "session_rpc_adapter.py", "rpc_unix.py", "rpc_peer.py")
LOAD_ORDER = ("rpc_protocol.py", "rpc_peer.py", "rpc_client.py",
              "session_rpc_adapter.py", "rpc_dispatcher.py", "rpc_unix.py")
CLOSE_SCHEMA = "c17-runtime78-root-rpc-transport-close-v1"
CLEANUP_SECONDS = 8
EOF_SECONDS = 5
TERMINAL = frozenset(("complete", "error", "timeout"))


class RoundDeadlineExceeded(RuntimeError):
    """Deadline globale Python dépassée : instrument rouge, pas oracle métier."""


def need(condition, message):
    if not condition:
        raise ValueError(message)


def modules_exact(core, session, refs):
    need(type(refs) is dict and set(refs) == set(MODULES), "Six modules RPC exacts requis")
    paths = []
    for name, ref in refs.items():
        path = core.checked(ref, root=session.root)
        need(path.name == name and ref in session.binding["source_refs"],
             "Module RPC absent du binding initial : " + name)
        paths.append(path)
    need(len(set(paths)) == 6, "Module RPC dupliqué")
    return refs


def load_modules(core, session, refs):
    """Chargeur root explicite, aucun fallback sys.path/ancien cache RPC."""
    modules_exact(core, session, refs)
    names = {name: Path(name).stem for name in MODULES}
    need(not any(name in sys.modules for name in names.values()), "Module RPC déjà chargé : refus de mélange")
    loaded = {}
    try:
        for filename in LOAD_ORDER:
            path = core.checked(refs[filename], root=session.root)
            spec = importlib.util.spec_from_file_location(names[filename], path)
            need(spec is not None and spec.loader is not None, "Module RPC non chargeable")
            module = importlib.util.module_from_spec(spec)
            sys.modules[names[filename]] = module  # classes visibles pour les pins G1 attach.
            loaded[filename] = module
            spec.loader.exec_module(module)
            need(core.ref(path) == refs[filename], "Module RPC changé pendant import")
        modules_exact(core, session, refs)
        protocol = loaded["rpc_protocol.py"]
        need(loaded["rpc_dispatcher.py"].p is protocol and loaded["rpc_unix.py"].p is protocol
             and loaded["rpc_client.py"].p is protocol
             and loaded["rpc_unix.py"].rpc_peer is loaded["rpc_peer.py"],
             "Modules RPC chargés avec dépendance étrangère")
        return loaded
    except BaseException:
        for filename, module in loaded.items():
            if sys.modules.get(names[filename]) is module:
                del sys.modules[names[filename]]
        raise


def validate_bootstrap(core, g1, session, decision, config):
    need(core.RUNTIME_ENABLED and g1.RUNTIME_ENABLED and g1.OS_STARTUP_QUALIFIED
         and bool(g1.ADMISSION_TABLE), "Bootstrap FULL fermé : admission/startup root absents")
    need(g1._ACTIVE_SESSION is session and not session.closed and not session.handles
         and not session.log_stability_tainted, "Bootstrap hors Session vivante avant premier launch")
    core.config_identity(config, session.root)
    need(session.round_name == config["campaign"] in ("A", "B")
         and all(getattr(session, key) == config[key] for key in ("actor", "round_id", "head"))
         and session.binding.get("qa_root") == str(session.root)
         and session.binding.get("round_name") == config["campaign"]
         and session.binding.get("head") == config["head"], "Bootstrap autre identité physique A/B/HEAD")
    own = core.ref(Path(__file__).resolve())
    need(decision.get("rpc", {}).get("bootstrap") == own
         and session.binding.get("rpc_bootstrap_ref") == own
         and own in session.binding["source_refs"], "Bootstrap effectif non prélié/root-revu")
    core.checked(own, root=session.root)
    need(callable(getattr(session, "attach_owned_rpc_bootstrap", None)),
         "G1 ne possède pas la clôture RPC obligatoire")
    linked = core.rpc_abi.validate(decision, session.binding, config, session.root,
        checked=core.checked, load=core.load,
        effective_reader_ref=core.ref(core.HERE / "rpc_abi_reader.py"))
    return own, linked


class OwnedRpcBootstrap:
    """Même root/ledger que Session ; poll non bloquant via G1.wait.

    Le watchdog réutilise exactement le deadline monotonic du contexte root.
    C'est un contrôle coopératif aux frontières/ticks, pas une interruption
    hard-real-time d'une opération in-process bloquante.
    """
    def __init__(self, core, session, modules, source_ref, linked):
        self.core, self.session, self.modules = core, session, modules
        self.source_ref = source_ref
        self.root = session.root
        self.protocol = modules["rpc_protocol.py"]
        self.context = linked["context"]
        self.context_digest = self.protocol.digest(self.context)
        self.deadline_monotonic = self.context["deadline_monotonic"]
        self.clock = time.monotonic
        self.sleep = time.sleep
        need(type(self.deadline_monotonic) in (int, float)
             and math.isfinite(self.deadline_monotonic) and self.deadline_monotonic > 0,
             "Deadline global root absent/non fini")
        self.dispatcher = None
        self.server = None
        self.close_attempts = 0
        self._physical_result = None
        self._close_ref = None

    def validate_sources(self):
        self.core.checked(self.source_ref, root=self.root)
        need(self.core.ref(Path(__file__).resolve()) == self.source_ref,
             "Bootstrap changé pendant la ronde")
        self.session.validate_sources()
        need(self.protocol.digest(self.context) == self.context_digest
             and self.context["deadline_monotonic"] == self.deadline_monotonic,
             "Contexte/deadline RPC mutable")
        self.protocol.same_identity(self.session.parent_phase_identity(), self.context["owner_identity"])
        self.session.verify_rpc_plan()

    def check_deadline(self):
        try:
            # Tick coopératif léger : aucun fichier, owner kernel ou plan relu.
            # Les contrôles complets restent obligatoires aux frontières.
            need(type(self.deadline_monotonic) in (int, float)
                 and math.isfinite(self.deadline_monotonic) and self.deadline_monotonic > 0
                 and self.context["deadline_monotonic"] == self.deadline_monotonic,
                 "Contexte/deadline RPC mutable")
            now = self.clock()
            need(type(now) in (int, float) and math.isfinite(now) and now > 0,
                 "Horloge root Python non finie")
            if now >= self.deadline_monotonic:
                raise RoundDeadlineExceeded("Deadline globale root atteinte : cleanup seulement")
        except BaseException:
            self.session.log_stability_tainted = True
            raise

    def check_boundary(self):
        """Rehash/birth/plan exacts avant ET après le contrôle de deadline.

        Aucun cache/TTL. Une vérification longue dépassant l'échéance refuse
        aussi l'action, au contrôle final, sans annoncer de préemption dure.
        """
        try:
            self.check_deadline()
            self.validate_sources()
            self.check_deadline()
        except BaseException:
            self.session.log_stability_tainted = True
            raise

    def _physical_close(self):
        """Pas de nouvelle admission ; abort tous requesters puis drainage borné."""
        errors = []
        cleanup_start = self.clock()  # inclut les abort/finish, pas seulement les ticks ensuite.
        self.session.log_stability_tainted |= bool(self.dispatcher.errors)
        for requester in sorted({row["requester_id"] for row in self.dispatcher.descriptors}):
            if not self.dispatcher.parent_quiescent(requester):
                self.session.log_stability_tainted = True
                if self.clock() >= cleanup_start + CLEANUP_SECONDS:
                    errors.append({"phase": "abort", "reason": "cleanup8 expired before next requester"})
                    break
                try:
                    self.dispatcher.abort_parent(requester, "final_transport_close")
                except BaseException as error:
                    errors.append({"phase": "abort", "requester": requester,
                                   "type": type(error).__name__, "reason": str(error)})
        try:
            while any(job["state"] not in TERMINAL for job in self.dispatcher.jobs.values()):
                if self.clock() >= cleanup_start + CLEANUP_SECONDS:
                    errors.append({"phase": "rpc_cleanup", "reason": "cleanup8 expired"})
                    break
                try:
                    # Ne pas rappeler poll(), qui accepterait de nouvelles requêtes.
                    ordered = sorted(self.dispatcher.jobs.values(),
                        key=lambda job: len(self.dispatcher._descendants(job["row"]["id"])))
                    for job in ordered:
                        if job["state"] not in TERMINAL and job.get("token") is not None:
                            self.dispatcher._poll_job(job)
                    self.server.pump()
                except BaseException as error:
                    errors.append({"phase": "rpc_cleanup", "type": type(error).__name__, "reason": str(error)})
                    break  # Session.stop nettoie encore ses vrais handles après cette fermeture.
                self.sleep(0.01)
            pending = sorted(key for key, job in self.dispatcher.jobs.items() if job["state"] not in TERMINAL)
            cleanup_elapsed = self.clock() - cleanup_start
            eof_start = self.clock()
            snapshot = self.server.pump()
            while (not snapshot["errors"] and snapshot["active"] != 0
                   and self.clock() < eof_start + EOF_SECONDS):
                self.sleep(0.01)
                snapshot = self.server.pump()  # aucune _accept de demande après finalisation.
            eof_elapsed = self.clock() - eof_start
            need(type(snapshot.get("active")) is int and snapshot["active"] >= 0
                 and type(snapshot.get("errors")) is list, "Snapshot transport actif/erreurs invalide")
            errors.extend({"phase": "transport", **item} for item in snapshot["errors"])
            if snapshot["active"] != 0:
                errors.append({"phase": "transport", "reason": "client EOF unproved before close5"})
            need(snapshot.get("synthetic_peer") is False and snapshot.get("OS_qualified") is False
                 and snapshot.get("FULL") is False, "Transport synthétique/instrument autoqualifié")
        except BaseException as error:
            pending = sorted(key for key, job in self.dispatcher.jobs.items() if job["state"] not in TERMINAL)
            cleanup_elapsed = self.clock() - cleanup_start
            eof_elapsed = None
            snapshot = {"active": None, "errors": [], "synthetic_peer": None}
            errors.append({"phase": "closure", "type": type(error).__name__, "reason": str(error)})
        finally:
            try:
                self.server.close()  # fermeture administrative même rouge, ne signifie pas EOF observé.
            except BaseException as error:
                errors.append({"phase": "server_close", "type": type(error).__name__, "reason": str(error)})
        complete = set(self.dispatcher.jobs) == set(self.session.binding["rpc_descriptors"]) and all(
            job["state"] == "complete" for job in self.dispatcher.jobs.values())
        closed = self.server.closed is True
        quiescent = pending == [] and snapshot["active"] == 0
        normal = (closed and quiescent and complete and not errors and not self.dispatcher.errors
                  and not self.dispatcher.tainted_requesters and not self.session.log_stability_tainted
                  and 0 <= cleanup_elapsed <= CLEANUP_SECONDS
                  and eof_elapsed is not None and 0 <= eof_elapsed <= EOF_SECONDS)
        if not normal:
            self.session.log_stability_tainted = True
        return {"closed": closed, "quiescent": quiescent, "normal_closure": normal,
            "pending_jobs": pending, "completed_all_15": complete,
            "jobs": {key: {"state": value["state"], "request_ref": value.get("request_ref"),
                           "ack_ref": value.get("ack_ref")} for key, value in self.dispatcher.jobs.items()},
            "dispatcher_errors": list(self.dispatcher.errors),
            "tainted_requesters": sorted(self.dispatcher.tainted_requesters),
            "pre_close_transport": snapshot, "errors": errors,
            "cleanup_elapsed_seconds": cleanup_elapsed, "cleanup_bound_seconds": CLEANUP_SECONDS,
            "client_eof_elapsed_seconds": eof_elapsed, "client_eof_bound_seconds": EOF_SECONDS,
            "administrative_close_not_eof_proof": True}

    def close_before_session_receipt(self):
        # En cas de save refusé, réessai = reçu nouveau ; aucun stream/socket rouvert.
        self.close_attempts += 1
        try:
            self.validate_sources()
            if self._physical_result is None:
                self._physical_result = self._physical_close()
            result = self._physical_result | {
                "schema": CLOSE_SCHEMA, "actor": self.session.actor,
                "round_id": self.session.round_id, "round_name": self.session.round_name,
                "head": self.session.head, "qa_root": str(self.root),
                "execution_scope": "runtime78_exact_round", "binding": self.session.binding_ref,
                "context_ref": self.session.binding["rpc_context_ref"],
                "plan_ref": self.session.binding["rpc_plan_ref"], "source": self.source_ref,
                "owner_identity": self.session.parent_phase_identity(),
                "attempt": self.close_attempts, "before_final_session_receipt": True,
                "deadline_monotonic": self.deadline_monotonic,
                "cooperative_watchdog_only": True, "OS_qualified": False, "FULL": False,
                "tainted": self.session.log_stability_tainted}
            if result["tainted"]:
                result["normal_closure"] = False
            path = self.root / "ledger" / ("rpc-transport-close-" + str(self.close_attempts) + ".json")
            self.core.save_new(self.root, path, result)
            self._close_ref = self.core.ref(path)
            return self._close_ref
        except BaseException:
            self.session.log_stability_tainted = True
            # Source/ref/receipt échec ne doit pas laisser le socket ouvert.
            if self.server is not None and not self.server.closed:
                self.server.close()
            raise


def bootstrap(core, g1, session, decision, config):
    own, linked = validate_bootstrap(core, g1, session, decision, config)
    for relative in ("session-events", "session-rpc/request", "session-rpc/ack",
                     "session-rpc/cancel", "session-rpc/enrollment"):
        path = core.inside(session.root, session.root / relative)
        need(path.is_dir() and not path.is_symlink(), "Canal QA root non préparé : " + relative)
    modules = load_modules(core, session, decision["rpc"]["modules"])
    p = modules["rpc_protocol.py"]
    p.same_identity(session.parent_phase_identity(), linked["context"]["owner_identity"])
    state = OwnedRpcBootstrap(core, session, modules, own, linked)
    state.check_boundary()
    api = {name: getattr(g1, name) for name in ("RPC_REQUESTERS", "RPC_CHILDREN", "SOURCE", "HERE",
        "reference", "read_published_json", "checked_json_ref", "save")}
    api["_ACTIVE_SESSION"] = g1._ACTIVE_SESSION
    adapter = modules["session_rpc_adapter.py"].SessionRpcAdapter(session, api, protocol=p,
        context=linked["context"], enrollments={})
    dispatcher = modules["rpc_dispatcher.py"].RpcDispatcher(session.root, linked["context"],
        linked["plan"]["descriptors"], {}, adapter)
    state.dispatcher = dispatcher
    try:
        state.server = modules["rpc_unix.py"].create_server(session.root, linked["context"],
            linked["plan"]["descriptors"], session.ledger)
        dispatcher.attach_transport(state.server)
        session.attach_rpc_dispatcher(dispatcher)
        session.attach_owned_rpc_bootstrap(state)
        state.check_boundary()
        return state
    except BaseException:
        session.log_stability_tainted = True
        if state.server is not None:
            state.server.close()
        raise


def validate_close(core, session, ref):
    result = core.load(core.checked(ref, root=session.root))
    need(result.get("schema") == CLOSE_SCHEMA and result.get("execution_scope") == "runtime78_exact_round"
         and all(result.get(key) == getattr(session, key) for key in ("actor", "round_id", "round_name", "head"))
         and result.get("qa_root") == str(session.root) and result.get("binding") == session.binding_ref
         and result.get("context_ref") == session.binding["rpc_context_ref"]
         and result.get("plan_ref") == session.binding["rpc_plan_ref"]
         and result.get("source") == session.binding["rpc_bootstrap_ref"]
         and result.get("closed") is True and result.get("quiescent") is True
         and result.get("normal_closure") is True and result.get("completed_all_15") is True
         and result.get("tainted") is False and result.get("errors") == result.get("dispatcher_errors") == []
         and result.get("pending_jobs") == result.get("tainted_requesters") == []
         and result.get("before_final_session_receipt") is True
         and result.get("pre_close_transport", {}).get("active") == 0
         and result["pre_close_transport"].get("errors") == []
         and result["pre_close_transport"].get("synthetic_peer") is False
         and type(result.get("cleanup_elapsed_seconds")) in (int, float)
         and math.isfinite(result["cleanup_elapsed_seconds"])
         and 0 <= result["cleanup_elapsed_seconds"] <= CLEANUP_SECONDS
         and type(result.get("client_eof_elapsed_seconds")) in (int, float)
         and math.isfinite(result["client_eof_elapsed_seconds"])
         and 0 <= result["client_eof_elapsed_seconds"] <= EOF_SECONDS
         and result.get("OS_qualified") is False and result.get("FULL") is False,
         "Clôture complète RPC/EOF/15 jobs non prouvée")
    need(type(result.get("jobs")) is dict and set(result["jobs"]) == set(session.binding["rpc_descriptors"]),
         "Table jobs RPC finale différente des quinze descriptors")
    for key, job in result["jobs"].items():
        need(job.get("state") == "complete", "Job RPC final non normal")
        for name in ("request_ref", "ack_ref"):
            core.checked(job[name], root=session.root)
        ack = core.load(core.checked(job["ack_ref"], root=session.root))
        need(ack.get("id") == key and ack.get("state") == "complete"
             and ack.get("request_ref") == job["request_ref"]
             and all(ack.get(name) == getattr(session, name) for name in ("actor", "round_id", "head"))
             and type(ack.get("exit_code")) is int and ack.get("instrument_error") is None
             and ack.get("tainted") is False and ack.get("termination_proved") is True
             and ack.get("log_stability_proved") is True and ack.get("signals") == [],
             "ACK final normal/exit brut/jointures divergents")
        for name in ("receipt_ref", "cleanup_ref", "stdout_ref", "stderr_ref"):
            core.checked(ack[name], root=session.root)
        if ack.get("auxiliary_terminal_ref") is not None:
            core.checked(ack["auxiliary_terminal_ref"], root=session.root)
    core.checked(result["source"], root=session.root)
    core.checked(result["context_ref"], root=session.root)
    core.checked(result["plan_ref"], root=session.root)
    return result
