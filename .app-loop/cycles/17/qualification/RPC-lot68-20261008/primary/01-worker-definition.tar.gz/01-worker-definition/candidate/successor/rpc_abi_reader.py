"""Lecteur du contrat RPC A/B. Aucun import G1 ni autorité créée par JSON.

Les références sont relues par le core effectif (ou sa vue SQL exacte). Les
obligations sont des exigences de raccord, jamais des capacités activées.
"""
from __future__ import annotations

from pathlib import Path

import full_rpc_contract as sites
import full_rpc_parent_binding as parent

SCHEMA = 'c17-runtime78-root-owned-rpc-abi-v1'
REFERENCE_SCHEMA = 'c17-runtime78-root-owned-rpc-reference-v1'
MODULES = ('rpc_protocol.py', 'rpc_client.py', 'rpc_dispatcher.py',
           'session_rpc_adapter.py', 'rpc_unix.py', 'rpc_peer.py')
OBLIGATIONS = (
    'requester_enrolled_before_release', 'kernel_peer_observed_outside_payload',
    'exact_request_bytes_bound_to_live_peer', 'peer_birth_rechecked_before_after',
    'closed_descriptors_before_launch', 'root_argv_env_cwd_sinks_bounds_only',
    'root_birth_reserved_before_child_release', 'nonblocking_dispatch_no_nested_wait',
    'normal_exit_integer_preserved', 'timeout_and_taint_never_business_green',
    'descendants_closed_before_parent_ack', 'partial_launch_uncertain_no_ack',
    'cleanup_and_stable_direct_streams_before_ack', 'chrome_closed_before_leaf_ack',
    'connection_kept_until_client_post_ack_close', 'unexpected_transport_error_taints_owner',
)


def need(condition, message):
    if not condition:
        raise ValueError(message)


def definition(reader_ref):
    """Définition fermée ; aucun champ runtime_enabled/capability=True."""
    return {'schema': SCHEMA, 'reader': reader_ref, 'modules': list(MODULES),
        'publication_protocol': 'exclusive-pending-fsync-hardlink-v1',
        'context_schema': 'c17-g5-root-rpc-context-v1',
        'descriptor_schema': 'c17-g5-root-rpc-descriptor-v1',
        'request_schema': sites.RENDER_SCHEMA, 'ack_schema': 'c17-g5-root-rpc-ack-v1',
        'envelope_schema': sites.ENVELOPE_SCHEMA, 'plan_schema': sites.PLAN_SCHEMA,
        'site_specs': {label: list(spec) for label, spec in sites.SITE_SPECS.items()},
        'descriptor_count': 15, 'sink_count': 30, 'requesters': sorted(sites.REQUESTERS),
        'direct_parents': sorted(sites.DIRECT_PARENTS),
        'late_sql_parents': ['B1753', 'B1753-power', 'B1760'],
        'capture_seconds': 5, 'cleanup_seconds': 8, 'obligations': list(OBLIGATIONS),
        'runtime_admitted': False, 'qualified': 0}


def references(decision):
    """Ensemble exact à copier dans la vue SQL, sans explorer d'autres chemins."""
    rpc = decision.get('rpc')
    need(type(rpc) is dict and rpc.get('schema') == REFERENCE_SCHEMA
         and type(rpc.get('modules')) is dict and set(rpc['modules']) == set(MODULES),
         'Bloc RPC exact absent ; ancien nested_capture refusé')
    return [rpc[key] for key in ('reader', 'contract', 'plan', 'context')] + [rpc['modules'][key] for key in MODULES]


def validate(decision, binding, config, root, *, checked, load, effective_reader_ref):
    """Vérifie les pins et les jointures ; le GO externe reste hors de ce lecteur.

    Les canaris doivent être de la vraie ronde A/B future. Les reçus WRAPPER,
    inert, synthetic ou historiques ne peuvent pas satisfaire cette exigence.
    """
    references(decision)
    root = Path(root)
    rpc = decision['rpc']
    need(rpc['reader'] == effective_reader_ref, 'Lecteur RPC effectif autre SHA')
    checked(rpc['reader'])
    need(load(checked(rpc['contract'])) == definition(effective_reader_ref), 'Contrat RPC différent des exigences fermées')
    source_refs = binding.get('source_refs', [])
    need(rpc['reader'] in source_refs and rpc['contract'] in source_refs,
         'Lecteur/contrat RPC absents du binding initial')
    for name, ref in rpc['modules'].items():
        need(Path(ref['path']).name == name and Path(ref['path']).is_relative_to(root)
             and ref in source_refs, 'Module RPC hors ronde/pin initial : ' + name)
        checked(ref)
    need(len({ref['path'] for ref in rpc['modules'].values()}) == len(MODULES), 'Module RPC dupliqué')
    need(rpc['plan'] == binding.get('rpc_plan_ref') and rpc['context'] == binding.get('rpc_context_ref'),
         'Plan/contexte RPC non liés au binding initial')
    ident = {'actor': config['actor'], 'round_id': config['round_id'], 'head': config['head']}
    linked = parent.plan_binding(binding, root, ident, reader=lambda ref, roots: load(checked(ref)))
    canaries = load(checked(decision['fresh_OS_canaries']))
    need(canaries.get('execution_scope') == 'runtime78_exact_round'
         and canaries.get('round_name') == config['campaign'] in ('A', 'B')
         and canaries.get('qa_root') == str(root)
         and all(canaries.get(key) == config[key] for key in ('actor', 'round_id', 'head'))
         and canaries.get('status') == 'passed' and canaries.get('instrument_error') is None
         and canaries.get('cleanup') == [] and canaries.get('profiles') == binding.get('profiles')
         and canaries.get('fresh_lock_import_checks') is True,
         'Canaris physiques exacts A/B absents ; scope WRAPPER non transposable')
    proof = canaries.get('rpc')
    need(type(proof) is dict and proof.get('modules') == rpc['modules']
         and proof.get('plan') == rpc['plan'] and proof.get('context') == rpc['context']
         and proof.get('peer_method') == 'unix_stream_LOCAL_PEERPID_plus_birth_rechecks'
         and proof.get('synthetic_peer') is False and proof.get('instrument_error') is None
         and proof.get('required_obligations') == list(OBLIGATIONS),
         'Calibrage RPC courant/peer kernel non fourni pour ces définitions')
    evidence = proof.get('evidence')
    need(type(evidence) is list and bool(evidence), 'Bruts calibrage RPC absents')
    for ref in evidence:
        need(Path(ref['path']).is_relative_to(root), 'Brut calibrage RPC hors ronde')
        checked(ref)
    return linked
