"""Rejeu pur sous garde OS et audit Python, aucun instrument complet importé."""
from __future__ import annotations
import argparse
from datetime import UTC, datetime
import dis
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import time
import traceback
import unittest

HERE = Path(__file__).resolve().parent
FULL_NAMES = {'runtime_session', 'runtime78_core', 'runtime78_coordinator', 'root_rpc_bootstrap',
    'session_rpc_adapter', 'rpc_protocol', 'rpc_client', 'rpc_dispatcher', 'rpc_unix',
    'rpc_peer', 'app', 'backend', 'readiness_owned', 'density_owned'}


def ref(path):
    data = Path(path).read_bytes()
    return {'path': str(path), 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}


def save(path, value):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n'); stream.flush(); os.fsync(stream.fileno())


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', required=True, type=Path)
    output = parser.parse_args().output
    if (not output.is_absolute() or output.resolve(strict=True) != output or output.parent != Path('/private/tmp')
        or not output.name.startswith('therese-c17-worker-context-tests-') or any(output.iterdir())):
        raise ValueError('Fresh exclusive canonical test output required')
    for name in ('fixtures', 'home', 'tmp'):
        (output / name).mkdir(mode=0o700)
    os.environ['C17_PURE_FIXTURE_ROOT'] = str(output / 'fixtures')
    os.environ['HOME'] = str(output / 'home')
    os.environ['TMPDIR'] = str(output / 'tmp')
    paths = {p for p in HERE.rglob('*') if p.is_file()}
    prep = json.loads((HERE / 'preparation.json').read_text())
    paths.update(Path(row['path']) for row in prep['sources_before'])
    paths.add(Path(prep['base_index']['path']))
    before = [ref(path) for path in sorted(paths)]
    instruments = {str(path) for path in (HERE / 'candidate').rglob('*.py')}
    rejected = []
    extracted_stdlib_imports = []

    def refuse(event, detail):
        rejected.append({'event': event, 'detail': str(detail)[:300]})
        raise PermissionError('Pure audit guard: ' + event)

    def writable(path, event):
        if isinstance(path, int) or not Path(os.fsdecode(path)).resolve().is_relative_to(output):
            refuse(event, path)

    def audit(event, values):
        if event.startswith(('subprocess.', 'socket.', 'ctypes.', 'pty.')) or event in {
            'os.system', 'os.fork', 'os.forkpty', 'os.exec', 'os.posix_spawn', 'os.spawn', 'os.kill', 'os.killpg'}:
            refuse(event, values)
        if event == 'import' and values[0].split('.')[0] in FULL_NAMES:
            refuse(event, values[0])
        if event == 'exec' and values[0].co_filename in instruments:
            imports = [row for row in dis.get_instructions(values[0])
                       if row.opname in {'IMPORT_NAME', 'IMPORT_FROM', 'IMPORT_STAR'}]
            if imports:
                # One exact source import node is tested, not a whole module.
                allowed = (values[0].co_filename == str(HERE / 'candidate/g1/runtime_session.py')
                    and values[0].co_names == ('uuid',) and len(imports) == 1
                    and imports[0].opname == 'IMPORT_NAME' and imports[0].argval == 'uuid')
                if not allowed:
                    refuse('exec-whole-instrument', values[0].co_filename)
                extracted_stdlib_imports.append({'source': values[0].co_filename, 'module': 'uuid'})
        if event == 'open':
            path, mode, flags = values
            if ((isinstance(mode, str) and any(c in mode for c in 'wax+')) or isinstance(flags, int)
                and flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND)):
                writable(path, event)
        elif event in {'os.mkdir', 'os.remove', 'os.rmdir', 'os.chmod', 'os.chown', 'os.utime', 'os.truncate'}:
            writable(values[0], event)
        elif event in {'os.rename', 'os.link', 'os.symlink'}:
            writable(values[0], event); writable(values[1], event)

    sys.addaudithook(audit)
    started = datetime.now(UTC).isoformat(); begin = time.monotonic()
    result = None; error = None
    stdout, stderr = output / 'stdout.log', output / 'stderr.log'
    with stdout.open('x', encoding='utf-8') as out, stderr.open('x', encoding='utf-8') as err:
        oldout, olderr = sys.stdout, sys.stderr
        sys.stdout, sys.stderr = out, err
        try:
            spec = importlib.util.spec_from_file_location('pure_worker_context_tests', HERE / 'tests/test_worker_context.py')
            module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
            result = unittest.TextTestRunner(stream=out, verbosity=2).run(module.suite())
        except BaseException as exc:
            error = {'type': type(exc).__name__, 'message': str(exc)}
            traceback.print_exc(file=err)
        finally:
            sys.stdout, sys.stderr = oldout, olderr
            out.flush(); err.flush(); os.fsync(out.fileno()); os.fsync(err.fileno())
    after = [ref(path) for path in sorted(paths)]
    imported = sorted(name for name in sys.modules if name.split('.')[0] in FULL_NAMES)
    receipt = {'schema': 'c17-closed-worker-context-pure-tests-v1', 'actor': '/root/cycle17_gate_review',
        'scope': 'synthetic_AST_policy_and_QA_fixture_bytes_only', 'round_id': None,
        'started_at': started, 'completed_at': datetime.now(UTC).isoformat(),
        'elapsed_seconds': time.monotonic() - begin, 'tests': result.testsRun if result else 0,
        'failures': len(result.failures) if result else None, 'errors': len(result.errors) if result else None,
        'skipped': len(result.skipped) if result else None, 'instrument_error': error,
        'stdout': ref(stdout), 'stderr': ref(stderr), 'pins_before': before, 'pins_after': after,
        'sources_unchanged': before == after, 'forbidden_events': rejected, 'full_instrument_imports': imported,
        'extracted_stdlib_imports': extracted_stdlib_imports,
        'RUNTIME_ENABLED': False, 'OS_STARTUP_QUALIFIED': False, 'FULL': False, 'round_created': False,
        'passed': bool(result and result.wasSuccessful() and not result.skipped and error is None
            and not rejected and not imported and before == after)}
    save(output / 'receipt.json', receipt)
    print(json.dumps({'receipt': ref(output / 'receipt.json'), 'tests': receipt['tests'], 'passed': receipt['passed'],
        'failures': receipt['failures'], 'errors': receipt['errors'], 'instrument_error': error}))
    return 0 if receipt['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
