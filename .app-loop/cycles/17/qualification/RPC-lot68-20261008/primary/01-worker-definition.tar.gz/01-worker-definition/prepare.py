"""Copie mécanique exclusive de définitions, sans import d'instrument."""
from __future__ import annotations
from datetime import UTC, datetime
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
BASE = Path('/private/tmp/therese-c17-full-composite-9I2loX52')
BASE_SHA = '0f7b28ca587b81bbdb128cb58a37c07be0e15e5295fffc1e69d33ded0317f1b2'
EXTRA = Path('/private/tmp/therese-c17-rpc-integration-UctqC8UG/successor')
EXPECTED = {
    'readiness_owned.py': ('bd2d074c9d22b683d249ce358ef5b2c0912b1a6aabd54f31d5248ed521e4e010', 3851),
    'density_owned.py': ('55e76f6d1bcc035fcd3443aaffd682509abab785b42a06bd369312d56c5a884c', 5433),
    'frozen-inputs.json': ('a711827ead616b360f504a146a994baf38eb4bf29a2dc50698474b3b4c72ae1f', 15982),
    'identity-anchors.json': ('46862c6eb95fd63dfcdd32efc4be220db48aea396030f064771258b9964a92b6', 6400),
    'identity_port.py': ('319a0950fb9170d1dc1642a5c13529bcefd510ad00434a9462460477841bfe5f', 806),
    'API-CONTRACT.json': ('58e0bc1d6c2429bb1093d9aad3069217c4e13556de5ca875f998985a24931ab3', 10359),
}


def ref(path):
    data = Path(path).read_bytes()
    return {'path': str(path), 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}


def need(value, reason):
    if not value:
        raise ValueError(reason)


def checked(row):
    need(ref(Path(row['path'])) == row, 'SHA/taille divergents: ' + row['path'])


def copy_new(source, destination):
    destination.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    with destination.open('xb') as stream:
        stream.write(source.read_bytes())
    need(source.read_bytes() == destination.read_bytes(), 'Copie non byte-exacte')
    return {'original': ref(source), 'copy': ref(destination), 'byte_exact': True}


def save(path, value):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')


def main():
    need(ref(BASE / 'INDEX.json')['sha256'] == BASE_SHA, 'Index composite différent')
    index = json.loads((BASE / 'INDEX.json').read_text())
    selected = [row for row in index['files'] if Path(row['path']).is_relative_to(BASE / 'candidate')]
    sources = list(selected)
    for name, (digest, size) in EXPECTED.items():
        sources.append({'path': str(EXTRA / name), 'sha256': digest, 'bytes': size})
    for row in sources:
        checked(row)
    copies = []
    for row in selected:
        source = Path(row['path'])
        copies.append(copy_new(source, HERE / 'candidate' / source.relative_to(BASE / 'candidate')))
    for name in EXPECTED:
        destination = (HERE / 'definitions/historical-API-CONTRACT.json' if name == 'API-CONTRACT.json'
                       else HERE / 'candidate/successor' / name)
        copies.append(copy_new(EXTRA / name, destination))
    preimage = copy_new(BASE / 'candidate/successor/runtime78_core.py',
                        HERE / 'preimages/runtime78_core.py')
    for row in sources:
        checked(row)
    save(HERE / 'preparation.json', {'schema': 'c17-closed-worker-context-preparation-v1',
        'actor': '/root/cycle17_gate_review', 'observed_at': datetime.now(UTC).isoformat(),
        'base_index': ref(BASE / 'INDEX.json'), 'sources_before': sources, 'sources_after': sources,
        'copies': copies, 'core_preimage': preimage, 'RUNTIME_ENABLED': False,
        'runtime_admitted': False, 'FULL': False, 'round_created': False})
    print(json.dumps({'preparation': ref(HERE / 'preparation.json'), 'source_count': len(sources),
                      'copies': len(copies), 'status': 'closed_definitions_only'}))


if __name__ == '__main__':
    main()
