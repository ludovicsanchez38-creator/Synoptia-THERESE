"""Trois opérations métier existantes, exclusivement dans un futur enfant G1 SQL.

RUNTIME_ENABLED reste False. Aucun Popen, import de G1/libproc, réseau ni
fallback parent. La commande admise doit épingler la requête réellement créée.
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path

import current_contract
import package78
import runtime78_core as core
import sql_protocol as protocol
import sql_read_view


def consumed_references(phase: str, payload: dict, runtime_decision_ref: dict,
                        phase_decision_ref: dict) -> list[dict]:
    """Liste bornée aux lectures existantes, pas une exploration des provenances.

    En particulier une carte d'origine est lue, mais son source_log privé
    n'est ni ouvert ni copié : admission/review_actor n'en lit pas les octets.
    """
    references = [runtime_decision_ref, phase_decision_ref, core.ref(core.TABLE), core.ref(core.ADAPTER),
                  core.ref(current_contract.DEFINITION), *payload.values()]
    for decision_ref in (runtime_decision_ref, phase_decision_ref):
        decision = core.load(core.checked(decision_ref))
        references.extend(decision[k] for k in ('identity_registry', 'root_review_origin', 'successor_index'))
        index = core.load(core.checked(decision['successor_index']))
        references.extend(index['files'])
        registry = core.load(core.checked(decision['identity_registry']))
        for row in registry['actors']:
            origin = dict(row['origin'])
            origin['path'] = str(core.canonical_reference_path(core.REPO / origin['path']))
            references.append(origin)
        references.extend(decision['session'][k] for k in ('module', 'contract'))
        references.extend(core.rpc_abi.references(decision))
        references.append(decision['session_binding'])
        references.append(decision['fresh_OS_canaries'])
        canaries = core.load(core.checked(decision['fresh_OS_canaries']))
        references.extend(canaries['rpc']['evidence'])
        if decision.get('round_name') == 'B':
            references.append(decision['prior_A_shutdown'])
    if phase == 'eight-logs-review':
        cleanup = core.load(core.checked(payload['service_cleanup']))
        references.append(cleanup['ports_absence_receipt'])
    elif phase == 'package78':
        visual = core.load(core.checked(payload['visual']))
        references.extend(item['source'] for item in visual['captures_actually_inspected'])
        apple = core.load(core.checked(payload['apple']))
        references.extend(item['pdf'] for item in apple['documents'])
        semantic = core.load(core.checked(payload['semantic']))
        for row in semantic['obligations']:
            references.extend(row['inspected'])
        logs = core.load(core.checked(payload['logs']))
        references.extend(logs['files'])
        for reference in core.load(core.checked(payload['calibrations']))['calibrations']:
            references.append(reference)
            record = core.load(core.checked(reference))
            references.extend(record[k] for k in ('calibration_execution', 'evidence'))
            references.extend(record['version_provenance'].values())
    return references


def prepare_request(root: Path, config: dict, phase: str, payload: dict,
                    runtime_decision_ref: dict, phase_decision_ref: dict) -> dict:
    """Parent uniquement après revue réelle ; aucun SHA futur dans l'initial."""
    core.need(core.RUNTIME_ENABLED and core.SQL_READ_VIEW is None, 'Préparation runtime fermée/non parent')
    core.need(phase in protocol.PHASES and set(payload) == set(protocol.PHASES[phase]), 'Autre phase/payload')
    core.config_identity(config, root)
    core.sources_unchanged(config)
    core.admission(runtime_decision_ref, 'runtime', config=config, root=root)
    core.admission(phase_decision_ref, 'package-review' if phase == 'package78' else 'runtime', config=config, root=root)
    core.need(core._DIRECT_BINDING_REF is not None and core._DIRECT_CONTEXT is not None,
              'Binding/contexte A/B physiques absents du parent SQL')
    runtime = core.load(core.checked(runtime_decision_ref))
    core.need(runtime['session_binding'] == core._DIRECT_BINDING_REF, 'Requête worker autre binding initial')
    seeds = consumed_references(phase, payload, runtime_decision_ref, phase_decision_ref)
    seeds += [core._DIRECT_BINDING_REF, core._DIRECT_CONTEXT['source_checkout_ref']]
    view_ref = sql_read_view.build_parent_view(core, root, config, phase, seeds)
    path = root / 'sql-inputs' / phase / 'request.json'
    record = {'schema': 'c17-runtime78-sql-worker-request-v2',
        **{k: config[k] for k in ('actor', 'round_id', 'head', 'root')},
        'stage_id': phase, 'mode': 'sql', 'payload': payload,
        'runtime_decision': runtime_decision_ref, 'phase_decision': phase_decision_ref,
        'read_view': view_ref, 'session_binding': dict(core._DIRECT_BINDING_REF),
        'source_checkout': core._DIRECT_CONTEXT['source_checkout_ref'],
        'expected_head': core.HEAD, 'product_source_root': str(core.QA_SOURCE),
        'configuration': core.ref(root / 'prepared-config.json'),
        'worker_source': core.ref(root / 'runtime78-successor/sql_worker.py'),
        'runtime_admitted': False, 'qualified': 0}
    protocol.validate_request(record, phase, config)
    core.save_atomic_new(root, path, record)
    return core.ref(path)


def operate(phase: str, root: Path, config: dict, request: dict, phase_decision: dict) -> dict:
    """Les fonctions et assertions métier restent les mêmes ; seul leur I/O change."""
    payload = request['payload']
    if phase == 'bind-current-context-contract':
        return current_contract.render_contract(root, config, phase_decision)
    if phase == 'eight-logs-review':
        result = package78.scan_eight(root, config, payload['stop_execution'], payload['service_cleanup'])
        core.need(result['no_matches'], 'Erreur présente dans un des huit logs réels')
        return result
    core.need(phase == 'package78', 'Opération hors des trois workers SQL')
    return package78.assemble(root, request['phase_decision'],
        mapping_ref=payload['mapping'], visual_ref=payload['visual'], apple_ref=payload['apple'],
        semantic_ref=payload['semantic'], logs_ref=payload['logs'], calibrations_ref=payload['calibrations'])


def run(root: Path, phase: str, request_ref: dict) -> dict:
    core.need(core.RUNTIME_ENABLED, 'Worker SQL fermé sans nouveau GO exact')
    config = core.load(core.round_root(root) / 'prepared-config.json')
    request = core.load(core.checked(request_ref, root=root))
    protocol.validate_request(request, phase, config)
    core.need(os.environ.get('C17_SESSION_STAGE') == phase
        and os.environ.get('C17_SESSION_ACTOR') == config['actor']
        and os.environ.get('C17_SESSION_ROUND_ID') == config['round_id']
        and os.environ.get('C17_SESSION_HEAD') == request['expected_head']
        and os.environ.get('C17_SESSION_BINDING_SHA256') == request['session_binding']['sha256']
        and json.loads(os.environ.get('C17_SESSION_BINDING_REF', 'null')) == request['session_binding']
        and os.environ.get('C17_SESSION_ROOT') == str(root)
        and os.environ.get('C17_SESSION_ROUND_NAME') == config['campaign']
        and 'THERESE_DB_PLAINTEXT' not in os.environ, 'Contexte effectif SQL différent ; aucune autorité créée par ces chaînes')
    core.need(request['configuration'] == core.ref(root / 'prepared-config.json')
        and request['worker_source'] == core.ref(Path(__file__)), 'Configuration/worker autre SHA réel')
    view_ref = request['read_view']
    manifest = core.load(core.checked(view_ref, root=root))
    core.need(manifest['stage_id'] == phase, 'Vue de lectures d’une autre étape')
    view = sql_read_view.ReadView(root, manifest, config, source_root=Path(request['product_source_root']), module_root=core.HERE)
    core.need(core.SQL_READ_VIEW is None, 'Vue SQL déjà installée')
    core.SQL_READ_VIEW = view
    try:
        core.configure_direct_round(root, request['session_binding'], expected_head=request['expected_head'])
        core.config_identity(config, root)
        core.need(request['source_checkout'] == core._DIRECT_CONTEXT['source_checkout_ref']
            and request['product_source_root'] == str(core.QA_SOURCE), 'Checkout/source request non liés au binding effectif')
        started = core.now()
        before = core.sources_unchanged(config)
        core.admission(request['runtime_decision'], 'runtime', config=config, root=root)
        phase_decision = core.admission(request['phase_decision'],
            'package-review' if phase == 'package78' else 'runtime', config=config, root=root)
        for value in request['payload'].values():
            core.checked(value, root=root if phase == 'eight-logs-review' else None)
        output_data = operate(phase, root, config, request, phase_decision)
        after = core.sources_unchanged(config)
        core.need(before == after and request['worker_source'] == core.ref(Path(__file__)), 'Sources worker modifiées')
        copies = view.audit()
        output_path = root / protocol.OUTPUTS[phase]
        core.save_atomic_new(root, output_path, output_data)
        output_ref = core.ref(output_path)
        receipt_path = root / 'ledger' / phase / 'worker-receipt.json'
        core.save_atomic_new(root, receipt_path, {
            'schema': 'c17-runtime78-sql-worker-receipt-v1',
            **{k: config[k] for k in ('actor', 'round_id', 'head', 'root')},
            'stage_id': phase, 'mode': 'sql', 'request': request_ref, 'read_view': view_ref,
            'read_copies_actually_rehashed': copies, 'runtime_decision': request['runtime_decision'],
            'phase_decision': request['phase_decision'], 'worker_source': core.ref(Path(__file__)),
            'configuration': request['configuration'], 'inputs': request['payload'], 'output': output_ref,
            'session_binding': request['session_binding'], 'source_checkout': request['source_checkout'],
            'expected_head': request['expected_head'],
            'started_at': started, 'completed_at': core.now(), 'source_check_before': before,
            'source_check_after': after, 'source_check_scope': 'QA copies plus parent-live checks in Session envelope; no child git claim',
            'qualified': 0, 'state_mutated': False, 'Session_receipt_required_for_OS_and_birth': True})
        result = {'schema': 'c17-runtime78-sql-worker-result-v1',
            **{k: config[k] for k in ('actor', 'round_id', 'head')}, 'stage_id': phase,
            'request': request_ref, 'output': output_ref, 'worker_receipt': core.ref(receipt_path), 'qualified': 0}
        print(json.dumps(result, ensure_ascii=False), flush=True)
        return result
    finally:
        core.SQL_READ_VIEW = None


def main() -> int:
    if not core.RUNTIME_ENABLED:
        return core.closed_main()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('phase', choices=tuple(protocol.PHASES))
    parser.add_argument('root', type=Path)
    parser.add_argument('--request', required=True)
    parser.add_argument('--request-sha256', required=True)
    args = parser.parse_args()
    run(args.root, args.phase, {'path': args.request, 'sha256': args.request_sha256})
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
