"""Copies de lecture QA, liées aux vrais originaux contrôlés par le parent.

La vue ne crée aucune admission. Le SHA de sa requête doit appartenir à la
commande exactement admise par la Session réelle. Aucun ancien résultat n'est
transformé ; les références originales restent dans les données métier.
"""
from __future__ import annotations

import hashlib
import os
from pathlib import Path
import stat

import sql_protocol as protocol


class ReadView:
    def __init__(self, root: Path, manifest: dict, config: dict, *, source_root: Path, module_root: Path):
        protocol.require(manifest.get('schema') == 'c17-runtime78-sql-read-copies-v1'
            and all(manifest.get(k) == config[k] for k in ('actor', 'round_id', 'head', 'root')),
            'Vue autre ronde/acteur/HEAD/racine')
        self.root, self.allowed = root, (root, source_root, module_root)
        self.rows = {}
        for row in manifest['copies']:
            origin, copy = protocol.reference(row['origin']), protocol.reference(row['copy'])
            protocol.require(origin['path'] not in self.rows and origin['sha256'] == copy['sha256']
                and origin.get('bytes') == copy.get('bytes') and origin.get('bytes') is not None,
                'Copie dupliquée/non byte-exacte/non bornée')
            self.rows[origin['path']] = row
            self.checked(origin)

    def has_origin(self, path: Path) -> bool:
        return str(path) in self.rows

    def checked(self, reference: dict) -> Path:
        protocol.reference(reference)
        row = self.rows[reference['path']]
        protocol.require(reference['sha256'] == row['origin']['sha256'], 'Référence différente de l’origine copiée')
        copy = Path(row['copy']['path'])
        protocol.require(copy.is_relative_to(self.root / 'sql-inputs') and copy.resolve(strict=True) == copy
            and all(not p.is_symlink() for p in (copy, *copy.parents) if p.is_relative_to(self.root)),
            'Copie hors QA ou redirigée')
        metadata = copy.stat()
        protocol.require(stat.S_ISREG(metadata.st_mode) and metadata.st_uid == os.getuid(), 'Copie non régulière/non propre')
        data = copy.read_bytes()
        protocol.require(len(data) == row['origin']['bytes'] == row['copy']['bytes']
            and hashlib.sha256(data).hexdigest() == row['origin']['sha256'], 'Octets de la copie changés')
        if 'bytes' in reference:
            protocol.require(reference['bytes'] == len(data), 'Taille de la référence différente')
        return copy

    def read_path(self, path: Path) -> Path:
        if self.has_origin(path):
            return self.checked(self.rows[str(path)]['origin'])
        protocol.require(path.is_absolute() and any(path.is_relative_to(base) for base in self.allowed),
            'Lecture SQL hors QA sans copie exacte admise')
        protocol.require(path.resolve(strict=True) == path and not path.is_symlink(), 'Lecture QA redirigée')
        return path

    def audit(self) -> list[dict]:
        for row in self.rows.values():
            self.checked(row['origin'])
        return list(self.rows.values())


def build_parent_view(core, root: Path, config: dict, phase: str, references: list[dict]) -> dict:
    """Future préparation parent sous sa vraie admission, jamais depuis l'enfant.

    Les refs effectivement consommées sont toutes contrôlées par checked. Les seules
    définitions historiques admissibles sont les SHA de frozen-inputs actuel.
    Aucun chemin inconnu ni copie de statut historique n'est accepté par défaut.
    """
    core.need(core.RUNTIME_ENABLED and core.SQL_READ_VIEW is None, 'Copies de lecture réservées au parent réellement admis')
    queue, seen, copies, total = list(references), {}, [], 0
    while queue:
        reference = dict(queue.pop(0))
        path = Path(reference['path'])
        if not path.is_absolute():
            path = core.canonical_reference_path(core.REPO / path)
            reference['path'] = str(path)
        key = str(path)
        if key in seen:
            core.need(seen[key] == reference['sha256'], 'Même origine avec deux SHA')
            continue
        actual = core.checked(reference, definition_only=True)
        data = actual.read_bytes()
        core.need('bytes' not in reference or reference['bytes'] == len(data), 'Taille originale différente')
        seen[key] = reference['sha256']; total += len(data)
        core.need(len(seen) <= 20000 and total <= 128 * 1024 * 1024, 'Vue de lecture trop volumineuse : instrument, pas assertion produit')
        if not actual.is_relative_to(root) and not actual.is_relative_to(core.QA_SOURCE) and not actual.is_relative_to(core.HERE):
            copy = root / 'sql-inputs' / phase / 'copies' / (hashlib.sha256(key.encode()).hexdigest() + actual.suffix)
            core.write_atomic_new(root, copy, data)
            core.need(core.sha(actual) == reference['sha256'] == core.sha(copy), 'Origine changée pendant copie')
            copies.append({'origin': reference | {'bytes': len(data)}, 'copy': core.ref(copy) | {'bytes': len(data)},
                'scope': 'exact_read_copy_not_new_result_or_authority'})
    manifest = {'schema': 'c17-runtime78-sql-read-copies-v1', 'stage_id': phase,
        **{k: config[k] for k in ('actor', 'round_id', 'head', 'root')},
        'copies': copies, 'parent_origins_checked': [dict(path=k, sha256=v) for k, v in seen.items()],
        'parent_source_check': core.sources_unchanged(config), 'runtime_admitted': False, 'qualified': 0}
    path = root / 'sql-inputs' / phase / 'read-view.json'
    core.save_atomic_new(root, path, manifest)
    return core.ref(path)


def verify_parent_view(core, root: Path, reference: dict) -> dict:
    """Rehash parent après worker : ni vieux SHA ni assertion d'origine inventée."""
    core.need(core.SQL_READ_VIEW is None, 'Réaudit des origines réservé au parent')
    record = core.load(core.checked(reference, root=root))
    for original in record['parent_origins_checked']:
        core.checked(original, definition_only=True)
    for row in record['copies']:
        core.checked(row['origin'], definition_only=True)
        copy = core.checked(row['copy'], root=root)
        core.need(copy.stat().st_size == row['origin']['bytes'] == row['copy']['bytes'], 'Taille copie changée après worker')
    return record
