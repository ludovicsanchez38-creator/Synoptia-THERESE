"""Blueprint pure A/B des quinze enfants RÉELS, dérivée du témoin rootdir corrigé.

Aucune Session ni admission ni publication. Les corps enfants gardent bornes,
cwd/env complets et codes métier dans leurs wrappers, non interprétés ici.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re

import full_rpc_contract as contract

NODE_ROOT = Path("/Users/synoptia/.nvm/versions/node/v22.19.0")
NODE = NODE_ROOT / "bin/node"

def need(ok: bool, reason: str) -> None:
    if not ok:
        raise ValueError(reason)


def ref_text(reference: dict) -> str:
    need(type(reference) is dict and set(reference) == {"path", "sha256", "bytes"}
         and type(reference["path"]) is str and Path(reference["path"]).is_absolute()
         and re.fullmatch(r"[a-f0-9]{64}", reference["sha256"]) is not None
         and type(reference["bytes"]) is int and reference["bytes"] > 0,
         "Référence root SHA/bytes absente")
    return json.dumps(reference, sort_keys=True)


class FullRpcBlueprint:
    def __init__(self, config: dict, checkout: dict, stack: dict, *, expected_head: str):
        self.identity = contract.exact_source_config(config, checkout, stack, expected_head=expected_head)
        self.source = Path(self.identity["product_source_root"])
        self.python = Path(self.identity["qa_python"])
        self.front = self.source / "src/frontend"

    def exact_root(self, root: Path) -> Path:
        root = Path(root)
        need(root.is_absolute() and root.parent == Path("/private/tmp")
             and str(root) == self.identity["root"],
             "Racine A/B différente du contexte explicite")
        return root


    def paths(self, root: Path) -> dict[str, Path]:
        root = self.exact_root(root)
        profile = Path(self.identity["profile"])
        return {"root": root, "profile": profile, "home": profile / "home",
                "tmp": profile / "tmp", "data": profile / "data",
                "test_data": profile / "test-data", "logs_data": profile / "logs-data",
                "overlay": root / "auxiliary-ports", "runtime": root / "runtime",
                "front": self.front, "source": self.source,
                "vite_config": root / "runtime/vite.runtime.config.mjs",
                "vite_canonical": root / "runtime/vite.canonique.mjs",
                "vite_cache": root / "runtime/vite-cache",
                "git_snapshot": root / "authorization/git-snapshot.json",
                "playwright_unused": root / "auxiliary/playwright-unused",
                "logs_run": root / "runtime/calibration/logs-rpc"}


    def auxiliary_metadata(self, root: Path, *, git_ref: dict,
                           chrome_context_refs: dict[str, dict]) -> dict[str, dict[str, str]]:
        """Les huit ajouts exacts du transport, jamais hérités d'un env libre."""
        git = ref_text(git_ref)
        jobs = ("rpc-all-runtime_ui-visual_capture-network_capture", "rpc-screen-negative",
                "rpc-screen-positive-visual", "rpc-screen-positive-network", "rpc-screen-restored")
        need(set(chrome_context_refs) == set(jobs), "Cinq contextes Chrome préémis absents")
        result = {"rpc-all-test_runner": {"C17_AUX_GIT_SNAPSHOT_REF": git},
                  "rpc-all-logs": {"C17_AUX_GIT_SNAPSHOT_REF": git,
                                   "C17_AUX_LOGS_RUN": str(self.paths(root)["logs_run"])},
                  "rpc-all-screen_coverage": {"C17_AUX_GIT_SNAPSHOT_REF": git}}
        for job in jobs:
            result[job] = {"C17_AUX_CONTEXT_REF": ref_text(chrome_context_refs[job])}
        result[jobs[0]]["C17_AUX_GIT_SNAPSHOT_REF"] = git
        return result


    def web_environment(self, root: Path, *, data_dir: Path | None = None) -> dict[str, str]:
        p = self.paths(root)
        chosen = data_dir or p["data"]
        need(chosen in (p["data"], p["test_data"]), "Profil web non jetable/fermé")
        return {"PATH": str(NODE_ROOT / "bin") + ":/usr/bin:/bin:/usr/sbin:/sbin:/opt/homebrew/bin",
            "HOME": str(p["home"]), "CFFIXED_USER_HOME": str(p["home"]),
            "TMPDIR": str(p["profile"]), "LANG": "en_US.UTF-8", "LC_ALL": "en_US.UTF-8",
            "PYTHONPATH": str(p["overlay"] / "runtime") + ":" + str(self.source) + ":" + str(self.source / "src/backend"),
            "PYTHONUNBUFFERED": "1", "PYTHONDONTWRITEBYTECODE": "1", "PYTHONNOUSERSITE": "1",
            "THERESE_DATA_DIR": str(chosen), "DATA_DIR": str(chosen),
            "DB_PATH": str(chosen / "therese.db"), "QDRANT_PATH": str(chosen / "qdrant"),
            "PORT": "17593", "HOST": "127.0.0.1", "VITE_THERESE_BACKEND_PORT": "17593",
            "PYTHON_KEYRING_BACKEND": "keyring.backends.null.Keyring", "THERESE_DB_PLAINTEXT": "1",
            "THERESE_SKIP_SERVICES": "1", "HF_HUB_OFFLINE": "1", "TRANSFORMERS_OFFLINE": "1",
            "THERESE_SONDE_CATALOGUE": "off", "OLLAMA_BASE_URL": "http://127.0.0.1:9",
            "PLAYWRIGHT_BROWSERS_PATH": str(p["playwright_unused"])}


    def sql_child_environment(self, root: Path, group: str) -> dict[str, str]:
        need(group in ("B1753", "B1760", "B1753-power"), "Groupe SQL hors table")
        alloc = contract.expected_allocations(root)
        label = "sql-" + group.lower()
        profile, out = Path(alloc[label + "-profile"]), Path(alloc[label + "-output"])
        copy = profile / "checkout"
        selectors = (["tests/test_actions_traitement.py::TestLaRouteHistoriqueEstCanonique::test_delete_passe_par_le_traitement_durable",
                      ".c16_instruments/test_b1753_frontiere_suivante.py::test_frontiere_suivante_ne_recoit_aucune_tache_du_temoin"]
                     if group != "B1760" else ["tests/test_b1760_echeance_mentions.py"])
        return {"PATH": "/usr/bin:/bin:/usr/sbin:/sbin:/opt/homebrew/bin",
            "HOME": str(profile / "home"), "TMPDIR": str(profile / "tmp"), "LANG": "en_US.UTF-8",
            "THERESE_ENV": "test", "THERESE_DATA_DIR": str(profile / "data"),
            "THERESE_SKIP_SERVICES": "1", "THERESE_DB_KEY": "ad" * 32,
            "PYTHON_KEYRING_BACKEND": "keyring.backends.null.Keyring",
            "PYTHONDONTWRITEBYTECODE": "1", "HF_HUB_OFFLINE": "1", "TRANSFORMERS_OFFLINE": "1",
            "OLLAMA_BASE_URL": "http://127.0.0.1:9", "THERESE_SONDE_CATALOGUE": "off",
            "C16_COPY": str(copy), "C16_GROUP": "B1753" if group == "B1753-power" else group,
            "C16_ACTOR": self.identity["actor"], "C16_ROUND_ID": self.identity["round_id"],
            "C16_EXECUTION_HEAD": self.identity["head"], "C16_SELECTORS": json.dumps(selectors),
            "C16_XML": str(out / "harness.xml"),
            "C16_MODULE_RECEIPT": str(out / "modules-executes.json"),
            "ENQUETE_REPO": str(copy), "ENQUETE_TRACE": str(out / "frontieres.jsonl"),
            "ENQUETE_MODE": "controle", "B1760_PREUVES": str(out / "exports")}


    def row(self, root: Path, context: dict, label: str, *, argv: list[str], cwd: Path,
            environment: dict[str, str], stdout: Path, stderr: Path, source_refs: list[dict]) -> dict:
        requester, index, mode, bound = contract.SITE_SPECS[label]
        name = "rpc-" + label
        return {"schema": "c17-g5-root-rpc-descriptor-v1", "id": name,
            "stage_name": name, "context_id": context["context_id"],
            "requester_id": requester, "logical_parent_id": requester, "index": index,
            "nonce": hashlib.sha256((root.name + ":" + label).encode()).hexdigest()[:32],
            "source_refs": source_refs, "argv": argv, "cwd": str(cwd),
            "environment": environment, "stdout_path": str(stdout), "stderr_path": str(stderr),
            "timeout_seconds": bound, "mode": mode, "label": label, "role": "stage-" + name}


    def descriptors(self, root: Path, context: dict, envelopes: dict, *,
                    metadata_by_job: dict[str, dict[str, str]],
                    source_refs: list[dict]) -> list[dict]:
        """Reconstruit les quinze arguments écrits par les cinq wrappers, sans les lancer."""
        p, alloc = self.paths(root), contract.expected_allocations(root)
        need(set(metadata_by_job) == {
            "rpc-all-test_runner", "rpc-all-logs",
            "rpc-all-runtime_ui-visual_capture-network_capture", "rpc-all-screen_coverage",
            "rpc-screen-negative", "rpc-screen-positive-visual",
            "rpc-screen-positive-network", "rpc-screen-restored"},
            "Métadonnées auxiliaires huit jobs hors table")
        base = self.web_environment(root)
        def with_metadata(label: str, env: dict[str, str]) -> dict[str, str]:
            additions = metadata_by_job.get("rpc-" + label, {})
            need(type(additions) is dict and all(type(k) is str and type(v) is str
                 and k not in env for k, v in additions.items()),
                 "Métadonnées auxiliaires non exactes pour " + label)
            return dict(env, **additions)
        result = []
        all_out = Path(alloc["all"])
        all_commands = {
            "all-test_runner": [str(self.python), str(p["overlay"] / "runtime/calibrate-test-runner.py")],
            "all-logs": [str(self.python), str(p["runtime"] / "calibrate-logs.py")],
            "all-runtime_ui-visual_capture-network_capture": [str(NODE), str(p["overlay"] / "runtime/calibrate-browser.mjs")],
            "all-screen_coverage": [str(self.python), str(p["overlay"] / "runtime/calibrate-screen.py")],
        }
        for label, argv in all_commands.items():
            name = label[4:]
            env = with_metadata(label, base)
            if label in ("all-test_runner", "all-screen_coverage"):
                env["C17_RPC_CONTEXT_REF"] = ref_text(envelopes["rpc-" + label])
            result.append(self.row(root, context, label, argv=argv, cwd=p["profile"],
                environment=env, stdout=all_out / (name + ".stdout"),
                stderr=all_out / (name + ".stderr"), source_refs=source_refs))
        test_out = Path(alloc["test-runner"])
        for tool in ("pytest", "vitest"):
            for variant in ("positive", "negative"):
                label = "test-" + tool + "-" + variant
                xml = test_out / (tool + "-" + variant + ".xml")
                env = self.web_environment(root, data_dir=p["test_data"])
                if variant == "positive":
                    env["C17_TEST_RUNNER_DEFECT"] = "1"
                if tool == "pytest":
                    argv = [str(self.python), "-m", "pytest", "--noconftest",
                            "--rootdir=" + str(test_out), str(test_out / "test_temoin_c17.py"), "--junitxml=" + str(xml),
                            "-p", "no:cacheprovider"]
                else:
                    argv = [str(self.front / "node_modules/.bin/vitest"), "run", "--config",
                            str(test_out / "vitest.runtime.config.mjs"), "--reporter=junit",
                            "--outputFile=" + str(xml)]
                result.append(self.row(root, context, label, argv=argv,
                    cwd=self.source if tool == "pytest" else self.front, environment=env,
                    stdout=test_out / (tool + "-" + variant + ".stdout"),
                    stderr=test_out / (tool + "-" + variant + ".stderr"), source_refs=source_refs))
        screen_out = Path(alloc["screen"])
        for label in ("screen-negative", "screen-positive-visual", "screen-positive-network", "screen-restored"):
            short = label.removeprefix("screen-")
            env = with_metadata(label, base)
            if short in ("positive-visual", "positive-network"):
                env["C17_SCREEN_WITNESS"] = short.removeprefix("positive-")
            argv = [str(NODE), str(screen_out / "couverture-ecran-calibree.mjs"),
                    "--base", "http://127.0.0.1:5173/?port=17593",
                    "--expected-data-dir", str(p["data"]), "--sortie", str(screen_out / short),
                    "--ecrans", "accueil", "--largeurs", "1440", "--themes", "light"]
            result.append(self.row(root, context, label, argv=argv, cwd=self.source,
                environment=env, stdout=screen_out / (short + ".stdout"),
                stderr=screen_out / (short + ".stderr"), source_refs=source_refs))
        for group in ("B1753", "B1760", "B1753-power"):
            label = "sql-" + group.lower()
            profile = Path(alloc[label + "-profile"])
            out = Path(alloc[label + "-output"])
            result.append(self.row(root, context, label,
                argv=[str(self.python), str(out / "bootstrap-prive.py")],
                cwd=profile / "checkout", environment=self.sql_child_environment(root, group),
                stdout=out / "harness.stdout", stderr=out / "harness.stderr",
                source_refs=source_refs))
        need([item["label"] for item in result] == list(contract.SITE_SPECS),
             "Ordre/quantité des quinze RPC changé")
        return result


    def rpc_commands(self, items: list[dict]) -> dict[str, dict]:
        commands = {}
        for item in items:
            commands[item["id"]] = {"argv": item["argv"], "role": item["role"],
                "mode": item["mode"], "timeout_seconds": item["timeout_seconds"],
                "env": item["environment"], "cwd": item["cwd"],
                "stdout_path": item["stdout_path"], "stderr_path": item["stderr_path"],
                "combine_stderr": False, "derived_deadline": "start_monotonic_plus_exact_timeout",
                "logical_parent_id": item["logical_parent_id"]}
        need(len(commands) == 15, "Quinze commandes RPC non distinctes")
        return commands
