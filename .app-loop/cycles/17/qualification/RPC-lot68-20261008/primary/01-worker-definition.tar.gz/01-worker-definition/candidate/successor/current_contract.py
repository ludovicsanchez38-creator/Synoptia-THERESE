"""Contrat frais C17 : assertions historiques, sources courantes strictes."""
from __future__ import annotations

import copy
from pathlib import Path

import runtime78_core as core

DEFINITION = core.REPO / '.app-loop/cycles/16/direct-mac/round-B4-preserve/complements/contrats-normalises-proposes.json'
DEFINITION_SHA = 'b9c29e9dbfd6fbfec0ff8fc41f4b079e539ab6d6c067dd0797b54a5bfad8f382'


def render_contract(root: Path, config: dict, decision: dict) -> dict:
    core.config_identity(config, root)
    core.sources_unchanged(config)
    core.need(core.sha(DEFINITION) == DEFINITION_SHA, 'Définition du contrat différente')
    source = core.load(DEFINITION)
    stack = core.stack_profile(config, root, running=True)
    manifest = root / 'runtime/pile-reprise.json'
    preserved = root / 'runtime/pile-reprise-running-preserved.json'
    core.need(core.read_path(preserved).read_bytes() == core.read_path(manifest).read_bytes(), 'Vraie copie running byte-exact absente')
    need_sources = source['source_snapshot']
    core.need(set(need_sources) <= set(config['product_sources']), 'Sources du contrat hors inventaire HEAD')
    source_root = core.QA_SOURCE if core.SQL_READ_VIEW is not None else core.REPO
    snapshots = {name: core.sha(source_root / name) for name in need_sources}
    core.need(all(snapshots[name] == config['product_sources'][name] for name in snapshots), 'Contrat source différent de HEAD/config')
    data = copy.deepcopy(source)
    # Les assertions/relations historiques sont des définitions, pas des
    # résultats. Les métadonnées opératives de chaque ligne sont fraîches.
    contracts = []
    for historical in source['contracts']:
        row = copy.deepcopy(historical)
        core.need(historical['current_execution_actor'] is None and historical['current_round_id'] is None
                  and historical['current_raw_receipt'] is None, 'Ancien résultat courant interdit')
        row.update({'status': 'prepared_not_executed', 'prepared_by': config['actor'], 'target_head': core.HEAD,
            'current_execution_actor': None, 'current_round_id': None, 'current_raw_receipt': None,
            'current_sources': [{'path': entry['path'], 'sha256': snapshots[entry['path']]}
                                for entry in historical['current_sources']]})
        core.need(row['original_definition_unchanged'] == historical['original_definition_unchanged']
                  and row['current_relations_required'] == historical['current_relations_required'], 'Delta assertion/relation interdit')
        contracts.append(row)
    data.update({'schema': 'c17-seven-runtime-preparation-v1', 'cycle': 17,
        'prepared_by': config['actor'], 'head': core.HEAD, 'prepared_round_id': config['round_id'],
        'status': 'prepared_for_current_running_round_not_qualified', 'source_snapshot': snapshots,
        'identity_registry': decision['identity_registry'], 'runtime_manifest': core.ref(manifest),
        'helper_v3': core.ref(root / 'runtime/couverture-ecran-c17.mjs'),
        'identity_provenance_limit': 'Origines collaboration exactes fournies et relues par root avant allocation.',
        'definition_origin': {'path': str(DEFINITION), 'sha256': DEFINITION_SHA, 'current': False, 'definition_only': True},
        'historical_current_sha_not_reused': True, 'contracts': contracts,
        'running_copy': core.ref(preserved), 'root_review_required': True, 'plateau_accepted': False})
    core.need(all(data[key] == source[key] for key in ('relations', 'groups')), 'Delta métier interdit')
    core.need(data['source_snapshot']['src/backend/app/config.py'] == config['product_sources']['src/backend/app/config.py'],
              'Ancien SHA a640 interdit comme source courante')
    core.need(stack['status'] == 'running', 'Contrat hors runtime courant')
    return data


def write_contract(root: Path, config: dict, decision: dict) -> dict:
    path = root / 'complements/contrats-normalises-proposes.json'
    core.save_new(root, path, render_contract(root, config, decision))
    return core.ref(path)


def require_review(root: Path, config: dict, reference: dict, contract: dict) -> dict:
    decision = core.admission(reference, 'contract-review', config=config, root=root)
    core.need(decision['reviewed_refs']['contract'] == contract and core.checked(contract).is_relative_to(root),
              'Revue root ne porte pas le contrat exact courant')
    core.need(decision['reviewed_refs']['running_copy'] == core.ref(root / 'runtime/pile-reprise-running-preserved.json'),
              'Revue root ne porte pas la vraie copie running')
    return decision
