"""Assemblage C17 obligatoire : aucune qualification et aucun ancien verdict."""
from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path
import re

import runtime78_core as core
import g1_bridge


def iso(value: str) -> datetime:
    parsed = datetime.fromisoformat(value.replace('Z', '+00:00'))
    core.need(parsed.tzinfo is not None, 'Horodatage sans fuseau')
    return parsed


def same_round(record: dict, config: dict) -> None:
    core.need(record['actor'] == config['actor'] and record['round_id'] == config['round_id']
              and record['head'] == core.HEAD, 'Résultat d’une autre ronde/acteur/HEAD')


def review_actor(record: dict, config: dict, registry: dict) -> str:
    actor = record.get('review_actor', record.get('actor'))
    core.need(actor in core.ACTORS and actor != config['actor'], 'Relecteur réel distinct obligatoire')
    rows = [row for row in registry['actors'] if row['actor'] == actor]
    core.need(len(rows) == 1 and registry['schema'] == 'c17-identity-registry-v1', 'Relecteur absent/dupliqué')
    origin = dict(rows[0]['origin'])
    origin['path'] = str(core.canonical_reference_path(core.REPO / origin['path']))
    observed = core.load(core.checked(origin))
    core.need(observed['provided_by'] == '/root' and observed['actor'] == actor
              and observed['origin_kind'] == 'collaboration_tool_call', 'Origine réelle non attestée')
    core.need(record['execution_actor'] == config['actor'] and record['round_id'] == config['round_id']
              and record['head'] == core.HEAD, 'Revue étrangère')
    core.need('actor' not in record or record['actor'] == actor, 'Acteurs de revue contradictoires')
    return actor


def scan_eight(root: Path, config: dict, stop_ref: dict, cleanup_ref: dict) -> dict:
    same_round(config, config)
    stop = core.load(core.checked(stop_ref, root=root))
    same_round(stop, config)
    cleanup = core.load(core.checked(cleanup_ref, root=root))
    core.need(stop['exit_code'] == 0 and stop['kind'] == 'in_process_owned_phase', 'Vrai arrêt in-process vert requis')
    g1_bridge.verify_shutdown(cleanup, config, final=False)
    core.checked(cleanup['ports_absence_receipt'], root=root)
    files = []
    for relative in core.EIGHT_LOGS:
        path = core.inside(root, root / relative)
        core.checked(core.ref(path), root=root)
        before = core.sha(path)
        lines = path.read_text().splitlines()
        matches = [{'line': i + 1, 'text': line} for i, line in enumerate(lines) if re.search(core.LOG_PATTERN, line)]
        core.need(core.sha(path) == before, 'Log en mutation pendant scan')
        files.append({**core.ref(path), 'lines': len(lines), 'matches': matches,
            'warning_count': sum(bool(re.search(r'\bWARNING\b', line)) for line in lines)})
    return {'schema': 'c17-runtime78-eight-logs-review-v1', 'actor': config['actor'], 'round_id': config['round_id'],
        'head': core.HEAD, 'actual_scan_at': core.now(), 'pattern': core.LOG_PATTERN,
        'no_matches': all(row['matches'] == [] for row in files), 'files': files,
        'stop_execution': stop_ref, 'cleanup': cleanup_ref, 'old_warning_counts_not_imported': True}


def validate_calibrations(root: Path, config: dict, reference: dict, started: datetime, stopped: datetime) -> None:
    index = core.load(core.checked(reference, root=root))
    same_round(index, config)
    names = {'test_runner', 'logs', 'runtime_ui', 'visual_capture', 'network_capture', 'screen_coverage'}
    records = [core.load(core.checked(item, root=root)) for item in index['calibrations']]
    core.need(len(records) == 6 and {row['instrument'] for row in records} == names, 'Six calibrations exactes requises')
    for row in records:
        same_round(row, config)
        execution = core.load(core.checked(row['calibration_execution'], root=root))
        same_round(execution, config)
        core.need(row['runtime_revision'] == 'v3' and execution['exit_code'] == 0
                  and row['observed_at'] == execution['completed_at'], 'Calibration/completion non réelle')
        actual = iso(row['observed_at'])
        expiry = iso(row['expires_at'])
        core.need(started <= actual <= stopped and expiry > datetime.now(UTC)
                  and (expiry - actual).total_seconds() == 43200, 'Calibration hors ronde/TTL différent ou expiré')
        evidence = core.load(core.checked(row['evidence'], root=root))
        core.need(evidence['status'] == 'passed' and evidence['head'] == core.HEAD
                  and row['positive_control'] == row['negative_control'] == 'pass' and row['tool_version'], 'Contrôles absents/non verts')
        for version in row['version_provenance'].values():
            core.checked(version)


def assemble(root: Path, decision_ref: dict, *, mapping_ref: dict, visual_ref: dict,
             apple_ref: dict, semantic_ref: dict, logs_ref: dict, calibrations_ref: dict) -> dict:
    core.need(core.RUNTIME_ENABLED, 'Assemblage de ronde fermé dans ce lot statique')
    config = core.load(core.round_root(root) / 'prepared-config.json')
    core.config_identity(config, root)
    decision = core.admission(decision_ref, 'package-review', config=config, root=root)
    for key, value in [('mapping', mapping_ref), ('visual', visual_ref), ('apple', apple_ref),
                       ('semantic', semantic_ref), ('logs', logs_ref), ('calibrations', calibrations_ref)]:
        core.need(decision['reviewed_refs'][key] == value, 'Décision root ne porte pas la référence actuelle : ' + key)
    core.sources_unchanged(config)
    table = core.load(core.checked({'path': str(core.TABLE), 'sha256': core.TABLE_SHA}))
    requirements = {row['obligation_id']: row for row in table['rows']}
    mapping = core.load(core.checked(mapping_ref, root=root))
    same_round(mapping, config)
    rows = {row['obligation_id']: row for row in mapping['rows']}
    core.need(len(mapping['rows']) == len(rows) == 78 and set(rows) == set(requirements), 'Mapping autre que78')
    for oid, row in rows.items():
        required = requirements[oid]
        core.need(row['assertions_unchanged'] == required['assertions'] and row['domain'] == required['domain']
            and row['kind'] == required['kind'] and row['historical_definition_unchanged'] == required['historical_definition_only'], 'Assertion/table modifiée : ' + oid)
    start_ref = core.ref(root / 'ledger/start-runtime/execution.json')
    stop_ref = core.ref(root / 'ledger/stop-runtime/execution.json')
    start = core.load(core.checked(start_ref, root=root))
    stop = core.load(core.checked(stop_ref, root=root))
    for item in (start, stop):
        same_round(item, config)
        core.need(item['exit_code'] == 0 and item['instrument_error'] is None, 'Start/stop rouge ou erreur instrument')
    stopped_manifest = core.load(root / 'runtime/pile-reprise.json')
    running_ref = core.ref(root / 'runtime/pile-reprise-running-preserved.json')
    running = core.load(core.checked(running_ref, root=root))
    core.need(running['status'] == 'running' and stopped_manifest['status'] == 'stopped'
              and running['head_at_start'] == stopped_manifest['head_at_start'] == core.HEAD, 'Manifestes réels running/stopped absents')
    core.need(core.load(core.checked(start['stdout'], root=root)) ==
        {'status': 'running', 'head': core.HEAD, 'data_dir': running['data_dir']}, 'Vrai stdout startup incorrect')
    started, ended = iso(start['completed_at']), iso(stop['started_at'])
    core.need(started <= ended <= iso(stop['completed_at']), 'Chronologie impossible')
    contexts = [core.ref(root / 'complements/runs' / stage / 'contexte-execution.json') for stage in core.UI_CONTEXTS]
    for reference in contexts:
        context = core.load(core.checked(reference, root=root))
        same_round(context, config)
        core.need(context['runtime_manifest'] == {'path': str(root / 'runtime/pile-reprise.json'), 'sha256': running_ref['sha256']}
                  and started <= iso(context['started_at']) < ended, 'Contexte hors vrai manifeste actif')
    validate_calibrations(root, config, calibrations_ref, started, ended)
    logs = core.load(core.checked(logs_ref, root=root))
    same_round(logs, config)
    core.need(logs['no_matches'] is True and logs['pattern'] == core.LOG_PATTERN
              and {row['path'] for row in logs['files']} == {str(root / p) for p in core.EIGHT_LOGS}
              and len(logs['files']) == 8, 'Revue huit logs absente/inexacte')
    for row in logs['files']:
        path = core.checked(row, root=root)
        lines = path.read_text().splitlines()
        matches = [{'line': i + 1, 'text': line} for i, line in enumerate(lines) if re.search(core.LOG_PATTERN, line)]
        core.need(row['matches'] == matches == [] and row['lines'] == len(lines)
                  and row['warning_count'] == sum(bool(re.search(r'\bWARNING\b', line)) for line in lines), 'Scan logs inexact')
    registry = core.load(core.checked(decision['identity_registry']))
    visual = core.load(core.checked(visual_ref))
    apple = core.load(core.checked(apple_ref))
    semantic = core.load(core.checked(semantic_ref))
    for review in (visual, apple, semantic):
        review_actor(review, config, registry)
    coverage_ref = core.ref(root / 'coverage/rapport.json')
    coverage = core.load(coverage_ref['path'])
    core.need(visual['status'] == 'reviewed-with-explicit-scope' and visual['capture_count'] == 84
              and len(visual['captures_actually_inspected']) == 84 and visual['new_visual_regression_observed'] is False
              and visual['raw_coverage'] == coverage_ref, 'Revue réelle84 obligatoire')
    captures = [item['source'] for item in visual['captures_actually_inspected']]
    core.need(len({item['path'] for item in captures}) == 84, 'Captures relues dupliquées')
    for item in captures:
        core.checked(item, root=root)
    arbitration = visual['arbitrations']
    core.need(len({row['id'] for row in arbitration}) == len(arbitration)
              and {row['id'] for row in arbitration} == {row['id'] for row in coverage['anomalies']}, 'Arbitrage incomplet/dupliqué')
    allowed = {'false-positive-in-observed-horizontal-scroller', 'consistent-with-idempotent-current-date-action-not-general-calendar-proof'}
    core.need(all(row['decision'] in allowed and row['reason'] for row in arbitration), 'Arbitrage autre contrat')
    species = next(row['complete_species_index'] for row in rows.values() if row['domain'] == 'B1760')
    core.need(len(species) == 10 and len({item['nodeid'] for item in species}) == 10, 'Dix espèces réelles requises')
    core.need(apple['status'] == 'reviewed-with-explicit-scope' and apple['pdf_count'] == apple['pages_count'] == 10
              and apple['source_export_hashes_unchanged_after_render'] is True and len(apple['documents']) == 10, 'Apple10PDF/10pages obligatoire')
    documents = apple['documents']
    core.need({doc['pdf']['sha256'] for doc in documents} == {item['pdf']['sha256'] for item in species}
              and len({doc['pdf']['path'] for doc in documents}) == 10, 'Revue autre PDF/dupliquée')
    for doc in documents:
        core.checked(doc['pdf'], root=root)
        core.need(doc['page_count'] == 1 and doc['pages_actually_inspected'] == [1]
                  and doc['visual_defects'] == [] and doc['uuid_nodeid_join'] == 'pass', 'PDF/page/jointure non relus')
    core.need(semantic['schema'] == 'c17-runtime78-independent-review-v1', 'Revue78 schéma incorrect')
    semantic_rows = {row['obligation_id']: row for row in semantic['obligations']}
    core.need(len(semantic['obligations']) == len(semantic_rows) == 78 and set(semantic_rows) == set(rows), 'Revue78 incomplète')
    for oid, review in semantic_rows.items():
        core.need(review['verdict'] == 'qualified' and review['reason'] and review['source_anchors']
                  and review['raw_assertion_map'] and review['assertions_reviewed'] == requirements[oid]['assertions'], 'Revue assertion précise absente : ' + oid)
        for item in review['inspected']:
            core.checked(item)
        for binding in rows[oid]['bindings']:
            core.need(binding['raw'] in review['inspected'] and binding['execution']['execution'] in review['inspected'], 'Brut/exécution exacts non relus : ' + oid)
    # Assemblage uniquement. Le consommateur STRICT inchangé reste un autre GO.
    package = {'schema': 'c17-runtime78-package-v1', 'cycle': 17, 'actor': config['actor'], 'round_id': config['round_id'],
        'head': core.HEAD, 'qa_root': str(root), 'built_at': core.now(), 'closed_table': core.ref(core.TABLE),
        'adapter_source': core.ref(core.ADAPTER), 'constructor_source': core.ref(Path(__file__)), 'mapping': mapping_ref,
        'configuration': core.ref(root / 'prepared-config.json'), 'start_execution': start_ref, 'stop_execution': stop_ref,
        'stopped_manifest': core.ref(root / 'runtime/pile-reprise.json'), 'running_manifest': running_ref,
        'manifest_contexts': contexts, 'coverage_report': coverage_ref,
        'coverage_instrument': core.ref(root / 'runtime/couverture-ecran-c17.mjs'),
        'calibrations': calibrations_ref, 'raw_log_review': logs_ref, 'independent_review': semantic_ref,
        'visual_review': visual_ref, 'Apple_review': apple_ref,
        'origin_attempts_not_qualified': mapping['prior_attempts_not_qualified'],
        'scope': '78 obligations uniquement ; pas natif/shared/unités/FULL/ronde qualifiée/état',
        'limits': ['P160 exige son unité exacte globale, non produite ici.',
            'B1755 : HTML synthétique headed Chrome, pas workflow applicatif complet.',
            'B1738 : focus programmatique ; P159 : fixture synthétique.',
            'Warning counts seulement ceux des huit flux réellement relus.',
            'Identités/revues fournies par leurs vrais acteurs, pas authentifiées par une simple chaîne JSON.'],
        'qualified_receipts': 0, 'state_mutated': False, 'plateau_produced': False}
    return package


def save_package(root: Path, package: dict) -> dict:
    path = root / 'runtime78-package/package78.json'
    core.save_new(root, path, package)
    return core.ref(path)
