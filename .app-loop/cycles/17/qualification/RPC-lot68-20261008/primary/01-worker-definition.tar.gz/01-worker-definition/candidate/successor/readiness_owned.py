"""Readiness sans lancement/arrêt legacy. CLI actuellement fermée."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import time
import urllib.request

import runtime78_core as core
import g1_bridge


def readiness(root: Path, decision_ref: dict) -> dict:
    config, decision, api = core.worker_context(root, decision_ref)
    stack = core.stack_profile(config, root)
    core.need(stack['status'] == 'starting' and stack['head_at_start'] == core.HEAD, 'Pile non starting')
    for role in ('backend', 'vite'):
        core.need(stack[role].get('birth_identity') and stack[role].get('pid'), 'Birth service absente')
        g1_bridge.identity(stack[role]['birth_identity'])
        core.need(stack[role]['birth_identity']['pid'] == stack[role]['pid'], 'PID/birth service différents')
    stage = os.environ.get('C17_SESSION_STAGE')
    core.need(stage == 'start-runtime', 'Readiness doit rester lié au nom G1 réel')
    journal = root / 'ownership-traces.jsonl'
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))

    def request(path: str, *, token: str | None = None, method: str = 'GET') -> dict:
        # Capacité G1 obligatoire : birth/UID/PGID/lsof frais, pas seulement PID.
        api.request_owned_listener_observation(root, stack, 17593, journal, stage_id=stage, deadline=5)
        headers = {'X-Therese-Token': token} if token else {}
        req = urllib.request.Request('http://127.0.0.1:17593' + path, method=method, headers=headers)
        with opener.open(req, timeout=3) as response:
            return json.load(response)

    deadline = time.monotonic() + 50  # borne de la définition conservée.
    while time.monotonic() < deadline:
        try:
            offline = request('/__couverture/offline')
            core.need(offline == {'version': 1, 'network_policy': 'loopback-only', 'offline': True}, 'Attestation hors ligne incorrecte')
            token = request('/api/auth/token')['token']
            stats = request('/api/config/stats', token=token)
            core.need(Path(stats['data_dir']).resolve() == Path(stack['data_dir']).resolve(), 'Autre dossier de données')
            core.need(Path(stats['db_path']).resolve().is_relative_to(Path(stack['data_dir']).resolve()), 'DB hors QA')
            request('/api/config/onboarding-complete', token=token, method='POST')
            api.request_owned_listener_observation(root, stack, 5173, journal, stage_id=stage, deadline=5)
            with opener.open('http://127.0.0.1:5173/', timeout=3) as response:
                core.need(response.status == 200, 'Vite ne sert pas le frontend QA')
            core.qa_sources_unchanged(config)
            stack.update({'verified_data_dir': stats['data_dir'], 'verified_db_path': stats['db_path'],
                          'onboarding_completed': True, 'status': 'running', 'started_at': core.now()})
            path = root / 'runtime/pile-reprise.json'
            core.rewrite_owned(root, path, core.sha(path), stack)
            result = {'status': 'running', 'head': core.HEAD, 'data_dir': stack['data_dir']}
            print(json.dumps(result))  # stdout exact exigé par adapter78.
            return result
        except (OSError, KeyError):
            time.sleep(0.5)
    raise ValueError('Pile non prête dans le délai de 50 secondes')


def main() -> int:
    if not core.RUNTIME_ENABLED:
        return core.closed_main()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root', type=Path)
    parser.add_argument('--decision', required=True)
    parser.add_argument('--decision-sha256', required=True)
    args = parser.parse_args()
    readiness(args.root, {'path': args.decision, 'sha256': args.decision_sha256})
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
