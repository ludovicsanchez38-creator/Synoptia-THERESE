"""Raccord pur au coordinator existant, sans créer de Session ou de binding.

La table des quinze enfants précède les commandes SQL parents produites après
la vraie revue. Les API de publication/auth/lifecycle ne sont PAS portées ici.
"""
from __future__ import annotations

from copy import deepcopy
import hashlib
import json
from pathlib import Path

import full_rpc_contract as contract
from full_rpc_blueprint import FullRpcBlueprint, ref_text


def build_bundle(blueprint: FullRpcBlueprint, protocol, *, owner_identity: dict,
                 deadline_monotonic: float, source_refs: list[dict], git_ref: dict,
                 chrome_context_refs: dict[str, dict]) -> dict:
    ident = blueprint.identity
    root = Path(ident['root'])
    context_id = hashlib.sha256((root.name + ':context').encode()).hexdigest()[:32]
    draft = contract.draft_context_envelopes(protocol, root=root, scope=ident['campaign'],
        actor=ident['actor'], round_id=ident['round_id'], head=ident['head'],
        context_id=context_id, owner_identity=owner_identity,
        deadline_monotonic=deadline_monotonic, allocations=contract.expected_allocations(root))
    metadata = blueprint.auxiliary_metadata(root, git_ref=git_ref,
        chrome_context_refs=chrome_context_refs)
    envelope_refs = {name: item['ref'] for name, item in draft['envelopes'].items()}
    descriptors = blueprint.descriptors(root, draft['context'], envelope_refs,
        metadata_by_job=metadata, source_refs=source_refs)
    sealed = contract.seal_plan(protocol, draft, descriptors,
        {name: envelope_refs[name] for name in contract.DIRECT_PARENTS})
    return {'sealed': sealed, 'rpc_commands': blueprint.rpc_commands(descriptors),
        'status': 'prepared_pure_not_published_not_admitted', 'runtime_admitted': False}


def validate_bundle(bundle: dict, blueprint: FullRpcBlueprint, protocol, **inputs) -> None:
    expected = build_bundle(blueprint, protocol, **inputs)
    contract.need(bundle == expected, 'Bundle différent des quinze vrais descriptors dérivés')


def requester_spec(stage: str, raw_spec: dict, blueprint: FullRpcBlueprint,
                   bundle: dict, *, git_ref: dict, reviewed_contract_ref: dict | None = None) -> dict:
    """Delta exact sur le spec déjà calculé par command_spec, AVANT revue root.

    Pour SQL, il faut le vrai SHA courant, qui restera autorisé par le binding
    tardif externe existant. Ce helper ne crée ni décision ni origine root.
    """
    contract.need(stage in contract.DIRECT_PARENTS, 'Demandeur hors des quatre parents RPC')
    ident = blueprint.identity
    root = Path(ident['root'])
    sealed = bundle['sealed']
    contract.need(bundle.get('runtime_admitted') is False
        and bundle.get('status') == 'prepared_pure_not_published_not_admitted'
        and sealed.get('runtime_admitted') is False
        and sealed.get('scope') == ident['campaign']
        and all(sealed['context'].get(k) == ident[k] for k in ('actor', 'round_id', 'head'))
        and sealed.get('root') == str(root), 'Bundle d’une autre identité/portée')
    contract.need(type(raw_spec) is dict and raw_spec.get('role') == 'stage-' + stage
        and raw_spec.get('timeout_seconds') == (1200 if stage == 'calibrate' else 360)
        and raw_spec.get('mode') == ('web' if stage == 'calibrate' else 'sql')
        and raw_spec.get('cwd') == str(root) and raw_spec.get('combine_stderr') is False
        and raw_spec.get('stdout_path') == str(root / 'ledger' / stage / 'stdout.log')
        and raw_spec.get('stderr_path') == str(root / 'ledger' / stage / 'stderr.log')
        and raw_spec.get('derived_deadline') == 'start_monotonic_plus_exact_timeout',
        'Spec coordinator parent hors argv/cwd/bornes/sinks existants')
    env = raw_spec.get('env')
    contract.need(type(env) is dict and env.get('C16_ACTOR') == ident['actor']
        and env.get('C16_ROUND_ID') == ident['round_id']
        and 'C17_RPC_CONTEXT_REF' not in env and 'C17_AUX_GIT_SNAPSHOT_REF' not in env,
        'Environnement parent héritant une autre identité/canal')
    contract.need(git_ref['path'] == str(root / 'authorization/git-snapshot.json'),
        'Snapshot Git d’une autre racine')
    result = deepcopy(raw_spec)
    if stage == 'calibrate':
        contract.need(reviewed_contract_ref is None
            and raw_spec.get('argv') == [str(blueprint.python), str(root / 'runtime/calibrate-all.py')],
            'Commande calibrate historique non concordante')
        result['argv'][1] = str(root / 'auxiliary-ports/runtime/calibrate-all.py')
    else:
        contract.need(reviewed_contract_ref is not None
            and reviewed_contract_ref.get('path') == str(root / 'complements/contrats-normalises-proposes.json'),
            'SQL parent indisponible avant revue du vrai contrat courant')
        ref_text(reviewed_contract_ref)
        script = ('preparer-harness-b1753-power.py' if stage == 'B1753-power'
                  else 'preparer-et-executer-harness-root-stack.py')
        argv = [str(blueprint.python), str(root / 'complements/instruments' / script),
            '--group', 'B1753' if stage == 'B1753-power' else stage,
            '--actor', ident['actor'], '--round-id', ident['round_id'],
            '--out', str(root / 'complements/runs' / stage),
            '--reviewed-contract-sha', reviewed_contract_ref['sha256']]
        contract.need(raw_spec.get('argv') == argv and 'THERESE_DB_PLAINTEXT' not in env,
            'SQL argv actuel ne porte pas la vraie revue/identité, ou plaintext interdit')
        result['argv'][1] = str(root / 'auxiliary-ports/complements/instruments' / script)
    result['env']['C17_RPC_CONTEXT_REF'] = json.dumps(sealed['envelopes'][stage]['ref'], sort_keys=True)
    result['env']['C17_AUX_GIT_SNAPSHOT_REF'] = ref_text(git_ref)
    return result


def attach_or_launch(*args, **kwargs):
    raise ValueError('Raccord runtime fermé : G1/admission/peer/listener/Chrome/watchdog non portés')
