"""Index causal de définitions et tests purs ; aucun instrument importé."""
from __future__ import annotations
import ast
from datetime import UTC, datetime
import difflib
import hashlib
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
BASE = Path('/private/tmp/therese-c17-full-composite-9I2loX52')
FIRST = Path('/private/tmp/therese-c17-worker-context-tests-9oEazR9W')
FINAL = Path('/private/tmp/therese-c17-worker-context-tests-AViZq0Kl')


def need(value, reason):
    if not value:
        raise ValueError(reason)


def ref(path):
    data = Path(path).read_bytes()
    return {'path': str(path), 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}


def checked(row):
    need(ref(Path(row['path'])) == row, 'Référence actuelle SHA/taille différente : ' + row['path'])


def save(path, value):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')


def module_closure(worker):
    local = {path.stem: path for path in (HERE / 'candidate/successor').glob('*.py')}
    visited = set()
    edges = []

    def visit(path):
        if path in visited:
            return
        visited.add(path)
        for node in ast.walk(ast.parse(path.read_text(), filename=str(path))):
            names = [item.name.split('.')[0] for item in node.names] if isinstance(node, ast.Import) else (
                [node.module.split('.')[0]] if isinstance(node, ast.ImportFrom) and node.module else [])
            for name in names:
                if name in local:
                    edges.append({'source': ref(path), 'dependency': ref(local[name]), 'kind': 'static_local_import'})
                    visit(local[name])
                else:
                    need(name in sys.stdlib_module_names or name == '__future__', 'Missing local/module closure : ' + name)
    visit(worker)
    return {'worker': ref(worker), 'files': [ref(path) for path in sorted(visited)], 'edges': edges,
            'runtime_imports_performed': False}


def validate_receipt(folder, tests, expected_sha):
    receipt_ref = ref(folder / 'receipt.json')
    need(receipt_ref['sha256'] == expected_sha, 'Actual pure receipt changed')
    raw = json.loads((folder / 'receipt.json').read_text())
    need(raw['passed'] is True and raw['tests'] == tests and raw['failures'] == raw['errors'] == raw['skipped'] == 0
         and raw['sources_unchanged'] is True and raw['pins_before'] == raw['pins_after']
         and raw['forbidden_events'] == raw['full_instrument_imports'] == []
         and raw['instrument_error'] is None and raw['round_created'] is False
         and raw['RUNTIME_ENABLED'] is raw['OS_STARTUP_QUALIFIED'] is raw['FULL'] is False,
         'Actual pure receipt not closed/passed')
    checked(raw['stdout']); checked(raw['stderr'])
    need(Path(raw['stderr']['path']).stat().st_size == 0, 'Pure stderr must be empty')
    return raw, receipt_ref


def main():
    need(not (HERE / 'INDEX.json').exists(), 'Freeze must be exclusive')
    prep = json.loads((HERE / 'preparation.json').read_text())
    checked(prep['base_index'])
    need(prep['sources_before'] == prep['sources_after'], 'Mechanical input drift')
    for item in prep['sources_after']:
        checked(item)
    changes = {
        str(HERE / 'candidate/successor/runtime78_core.py'): HERE / 'preimages/runtime78_core.py',
        str(HERE / 'candidate/g1/runtime_session.py'): HERE / 'preimages/runtime_session.py',
    }
    outputs = []
    for relation in prep['copies']:
        checked(relation['original'])
        original = Path(relation['original']['path'])
        current = Path(relation['copy']['path'])
        if str(current) in changes:
            need(changes[str(current)].read_bytes() == original.read_bytes(), 'Functional preimage non exact')
        else:
            need(current.read_bytes() == original.read_bytes(), 'Unchanged copy drift : ' + str(current))
        outputs.append({'source': relation['original'], 'current': ref(current),
                        'byte_exact': current.read_bytes() == original.read_bytes()})
    core_before = ast.parse((HERE / 'preimages/runtime78_core.py').read_text())
    core_after = ast.parse((HERE / 'candidate/successor/runtime78_core.py').read_text())
    for tree in (core_before, core_after):
        rows = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'worker_context']
        need(len(rows) == 1, 'Unique worker_context required'); tree.body.remove(rows[0])
    need(ast.dump(core_before, include_attributes=False) == ast.dump(core_after, include_attributes=False),
         'Core changes outside worker_context')
    g1_path = HERE / 'candidate/g1/runtime_session.py'
    g1_before = ast.parse((HERE / 'preimages/runtime_session.py').read_text())
    g1_after = ast.parse(g1_path.read_text())
    imports = [node for node in g1_after.body if isinstance(node, ast.Import)
               and len(node.names) == 1 and node.names[0].name == 'uuid' and node.names[0].asname is None]
    need(len(imports) == 1, 'One exact uuid import required')
    g1_after.body.remove(imports[0])
    need(ast.dump(g1_before, include_attributes=False) == ast.dump(g1_after, include_attributes=False),
         'G1 changes outside the uuid import')
    diffs = []
    for current, preimage in changes.items():
        path = Path(current)
        target = HERE / 'diffs' / (path.stem + '.diff')
        target.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        delta = ''.join(difflib.unified_diff(preimage.read_text().splitlines(True), path.read_text().splitlines(True),
            fromfile=str(preimage), tofile=str(path)))
        with target.open('x', encoding='utf-8') as stream:
            stream.write(delta)
        diffs.append({'before': ref(preimage), 'after': ref(path), 'diff': ref(target)})

    closure = [module_closure(HERE / 'candidate/successor' / name)
               for name in ('readiness_owned.py', 'density_owned.py')]
    frozen = json.loads((HERE / 'candidate/successor/frozen-inputs.json').read_text())
    frozen_definitions = []
    for path, expected in frozen['sources'].items():
        value = ref(Path(path)); need(value['sha256'] == expected, 'Frozen definition changed : ' + path)
        frozen_definitions.append(value)
    history = json.loads((HERE / 'definitions/historical-API-CONTRACT.json').read_text())
    need(history['schema'] == 'c17-runtime78-successor-api-proposal-v1'
         and history['session_api']['module'] is history['session_api']['contract'] is None
         and history['execution_enabled'] is False, 'Historical API cannot become an admission')
    export = next(node for node in ast.parse(g1_path.read_text()).body
                  if isinstance(node, ast.FunctionDef) and node.name == 'request_owned_listener_observation')
    api_map = {'schema': 'c17-worker-current-API-definition-map-v1', 'scope': 'source_definitions_only_not_session_contract',
        'session_module_definition': ref(g1_path), 'export': {'name': export.name,
            'signature': ast.unparse(export.args), 'line_start': export.lineno, 'line_end': export.end_lineno},
        'required_worker_API_schema': 'c17-runtime78-session-api-v1', 'uuid_stdlib_source_import_resolved': True,
        'historical_proposal': ref(HERE / 'definitions/historical-API-CONTRACT.json'),
        'session_contract_emitted': False, 'runtime_admitted': False, 'native_measured': False,
        'root_decision': None, 'FULL': False}
    save(HERE / 'api-definition-map.json', api_map)
    save(HERE / 'catalogue.json', {'schema': 'c17-closed-worker-definitions-catalogue-v1',
        'source_count': len(outputs), 'definitions': outputs, 'worker_import_closure': closure,
        'frozen_definition_sources': frozen_definitions, 'API_map': ref(HERE / 'api-definition-map.json'),
        'historical_API_not_current_contract': True, 'RUNTIME_ENABLED': False,
        'current_runtime_admission': None, 'FULL': False})

    first, first_ref = validate_receipt(FIRST, 38, 'f67c2a11bb27709903e8ecff2a89439f091f3c0b1f2529466ebd883d4882d6ee')
    final, final_ref = validate_receipt(FINAL, 40, '53ca328435bf6354bfd3378302328fc8d79510306f7d25024d5cb2d53c5a0f29')
    historical = {
        str(g1_path): HERE / 'preimages/runtime_session.py',
        str(HERE / 'tests/test_worker_context.py'): HERE / 'preimages/test_worker_context-first-38.py',
        str(HERE / 'run-pure.py'): HERE / 'preimages/run-pure-first-38.py',
    }
    historical_observations = []
    for observed in first['pins_after']:
        if observed['path'] in historical:
            preserved = ref(historical[observed['path']])
            need(preserved['sha256'] == observed['sha256'] and preserved['bytes'] == observed['bytes'],
                 'Historical first-38 preimage mismatch')
            historical_observations.append({'observation': observed, 'preserved': preserved,
                'historical_observation_not_current_path_dereference': True})
        else:
            checked(observed)
    for observed in final['pins_after']:
        checked(observed)
    need(final['extracted_stdlib_imports'] == [{'source': str(g1_path), 'module': 'uuid'}],
         'Only the exact selected uuid import is allowed')
    for path in HERE.rglob('*.py'):
        ast.parse(path.read_text(), filename=str(path))
    audit = {'schema': 'c17-closed-worker-context-static-audit-v1', 'actor': '/root/cycle17_gate_review',
        'observed_at': datetime.now(UTC).isoformat(), 'original_composite': prep['base_index'],
        'functional_diffs': diffs, 'unchanged_other_core_AST': True, 'unchanged_other_G1_AST': True,
        'worker_sources_byte_exact': True, 'closed_catalogue': ref(HERE / 'catalogue.json'),
        'first_38_pure_observation': first_ref, 'final_40_pure_observation': final_ref,
        'same_38_replayed_not_added_to_40': True, 'historical_pin_resolution': historical_observations,
        'mechanical_preparation_copies_note': 'Preparation copies describe before-edit observations; catalogue definitions carry the current refs.',
        'RUNTIME_ENABLED': False, 'OS_STARTUP_QUALIFIED': False, 'FULL': False, 'round_created': False}
    save(HERE / 'static-audit.json', audit)
    files = [ref(path) for path in sorted(HERE.rglob('*')) if path.is_file() and path.name != 'INDEX.json']
    raws = [ref(folder / name) for folder in (FIRST, FINAL) for name in ('receipt.json', 'stdout.log', 'stderr.log')]
    index = {'schema': 'c17-closed-worker-context-index-v1', 'actor': '/root/cycle17_gate_review',
        'generated_at': datetime.now(UTC).isoformat(), 'scope': 'definitions_and_pure_AST_tests_only',
        'status': 'immutable_closed_preparation', 'files': files,
        'origins': prep['sources_after'] + [prep['base_index']] + frozen_definitions,
        'raw_pure': raws, 'historical_first_38_pin_resolution': historical_observations,
        'preparation_observation': ref(HERE / 'preparation.json'), 'catalogue': ref(HERE / 'catalogue.json'),
        'static_audit': ref(HERE / 'static-audit.json'), 'RUNTIME_ENABLED': False, 'OS_STARTUP_QUALIFIED': False,
        'CAPABILITIES_admitted': False, 'ADMISSION_TABLE': {}, 'WRAPPER_ADMISSION_TABLE': {},
        'native_executed': False, 'session_contract_emitted': False, 'FULL': False,
        'obligations_122_212_129_82_1_unchanged': True}
    save(HERE / 'INDEX.json', index)
    for row in index['files'] + index['origins'] + index['raw_pure']:
        checked(row)
    print(json.dumps({'index': ref(HERE / 'INDEX.json'), 'files': len(files),
        'origins': len(index['origins']), 'raws': len(raws), 'functional_diffs': len(diffs),
        'status': 'closed_static_only', 'final_pure_tests': 40}))


if __name__ == '__main__':
    main()
