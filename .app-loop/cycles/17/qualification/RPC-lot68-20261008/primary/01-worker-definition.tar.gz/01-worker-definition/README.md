# Workers A/B : contexte frais et catalogue fermé

Successeur additif du composite `9I2loX52`, sans modification de ce dernier.
Ce lot ne construit aucune racine A/B, checkout, donnée, décision Q ou preuve
native. Aucun flag, capacité ou slot d'admission n'est ouvert.

## Deux changements fonctionnels

1. `worker_context` exige les champs binding/HEAD injectés par Session, une
   référence exacte path/SHA/bytes et le SHA distinct injecté. Il joint aussi
   les racines QA/Session, acteur, identifiant logique, campagne et HEAD à la
   configuration. Il configure ensuite le contexte physique depuis ce binding
   avant `config_identity`. Les contrôles d'admission, sources, module et API
   listener qui suivaient sont byte-exacts. Aucun défaut ni récupération vers
   l'ancien HEAD/source/binding n'est ajouté.
2. G1 reçoit seulement `import uuid`, requis par l'export listener déjà présent.
   Après retrait de ce nœud AST, tout le G1 reste identique au composite. Aucune
   permission, assertion, borne, commande ou lifecycle n'est modifiée.

Les deux workers `readiness_owned.py` et `density_owned.py` sont copiés
byte-exactement. Leurs oracles readiness, traces, 45 créations synthétiques,
absence de rejeu et garde listener ne changent pas.

## Catalogue et API

Les dépendances locales réellement importées sont présentes et indexées. Les
définitions `frozen-inputs.json`, `identity_port.py` et `identity-anchors.json`
sont également copiées à l'identique, avec leurs origines exactes. Les sources
de la table frozen sont rehashées, uniquement comme définitions historiques.
Aucun ancien résultat n'est adopté.

`api-definition-map.json` joint le symbole listener et son import stdlib au
G1 effectif. C'est une carte de sources, pas un contrat Session opérationnel.
La proposition historique `API-CONTRACT.json`, HEAD b517 et module nul, reste
archivée séparément. Aucun `decision.session.contract` n'est émis ni admis.
L'émetteur physique et le préflight A/B restent des travaux distincts.

## Mesures pures réelles

Premier reçu : `worker-context-tests-9oEazR9W/receipt.json`, 38 cas passés,
SHA `f67c2a11bb27709903e8ecff2a89439f091f3c0b1f2529466ebd883d4882d6ee`.
Il précède l'import uuid et son test. Ses trois préimages de sources changées
sont conservées ; leurs pins sont des observations historiques, pas des
références courantes à déréférencer après le changement.

Second reçu : `worker-context-tests-AViZq0Kl/receipt.json`, 40 cas passés,
SHA `53ca328435bf6354bfd3378302328fc8d79510306f7d25024d5cb2d53c5a0f29`.
Ce sont les mêmes 38 cas rejoués et deux contrôles supplémentaires, pas 78 cas
distincts. Les deux essais ont 0 échec, erreur ou saut et stderr vide. Aucun
premier rouge n'a eu lieu.

Les vrais corps AST de core/direct-round et des deux workers éprouvent le
contexte d'enfant frais, références absentes/malformées/mutées, HEAD, acteur,
round/config, blobs, modes et le refus avant import/HTTP/POST/FD. Le namespace
listener reçoit précisément le vrai nœud `import uuid`, puis son vrai corps
émet deux demandes synthétiques aux nonces distinctes. Leur interception
préserve les JSON dans la sortie de tests avant toute attente Session.

Les fixtures, noms Q et identités sont explicitement synthétiques. Les tests
rehashent réellement leurs petits fichiers/blobs/modes mais ne créent pas de
vraie ronde ni de décision. Aucun pair, naissance, listener, processus ou
publication kernel n'est qualifié.

Le profil OS interdit processus enfants et réseau, écrit seulement dans la
sortie de tests séparée du gel. La garde Python interdit processus, sockets,
ctypes, signaux et imports complets d'instrumentation. Le seul import extrait
est `uuid` ; aucun G1 complet ni code produit n'est exécuté. Sources égales
avant/après chaque essai, aucun événement interdit.

## Rejeu et limites

Après lecture, créer une sortie vide `therese-c17-worker-context-tests-<nonce>`
sous `/private/tmp`, puis exécuter le Python physique avec `-I -B run-pure.py
--output <sortie>`, sous `sandbox-exec -D TEST_ROOT=<sortie> -f pure.sb` et
environnement minimal. Aucun root GO ou admission runtime ne découle du rejeu.

Restent fermés : constructeur préparation-only, vrais checkout/dépendances
A/B, sources/contexts auxiliaires quatorze jobs, propriétaire/plan RPC réel,
canaris instrumentaux A/B et contrat API effectif, revue/admission des profils
et du Chrome original, consommateurs liés au HEAD historique, deux vraies
rondes indépendantes. Obligations 122/212/129/82/1 et assertions 27/78 inchangées.
