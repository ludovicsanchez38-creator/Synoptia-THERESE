"""Préimages byte-exactes avant le second delta ciblé, aucun instrument importé."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
FIRST = Path('/private/tmp/therese-c17-worker-context-tests-9oEazR9W/receipt.json')


def ref(path):
    raw = path.read_bytes()
    return {'path': str(path), 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}


def main():
    if ref(FIRST)['sha256'] != 'f67c2a11bb27709903e8ecff2a89439f091f3c0b1f2529466ebd883d4882d6ee':
        raise ValueError('First actual pure receipt changed')
    source = HERE / 'candidate/g1/runtime_session.py'
    origin = Path('/private/tmp/therese-c17-full-composite-9I2loX52/candidate/g1/runtime_session.py')
    if source.read_bytes() != origin.read_bytes():
        raise ValueError('G1 must still be original before preserving')
    rows = []
    for source, destination in (
        (source, HERE / 'preimages/runtime_session.py'),
        (HERE / 'tests/test_worker_context.py', HERE / 'preimages/test_worker_context-first-38.py'),
    ):
        destination.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        with destination.open('xb') as stream:
            stream.write(source.read_bytes())
        rows.append({'observed_path': str(source), 'observed_sha256': ref(source)['sha256'],
                     'preserved': ref(destination), 'scope': 'preimage_of_first_38_pure_observation'})
    with (HERE / 'first-38-preimages.json').open('x', encoding='utf-8') as stream:
        json.dump({'schema': 'c17-closed-worker-first-38-preimages-v1', 'receipt': ref(FIRST),
            'preimages': rows, 'historical_pins_not_current_source_refs': True}, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'preservation': ref(HERE / 'first-38-preimages.json')}))


if __name__ == '__main__':
    main()
