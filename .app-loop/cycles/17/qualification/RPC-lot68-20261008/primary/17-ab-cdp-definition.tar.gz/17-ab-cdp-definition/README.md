# Port fermé du préload trace vers CDP root-owned

Ce lot prépare une définition, pas une admission A/B. Il ne modifie ni le gel
worker-context `fc49fb91…`, ni ses profils, ni G1, ni les huit recettes, ni P162.
Il ne reprend aucun résultat WRAPPER. Toutes les admissions/capacités restent
vides et les indicateurs RUNTIME/OS restent faux.

## Delta causal unique

Le coordinateur actuel précharge `trace-chrome.mjs` pour les neuf jobs directs.
Pour P162, sa garde GET vient ensuite et entoure le lanceur décoré par la trace.
Remplacer chaque appel de recette par CDP contournerait ces deux décorations.

Le renderer ajoute au préload trace l'import relatif du helper déjà présent et
remplace uniquement :

```js
const originalLaunch=chromium.launch.bind(chromium);
```

par :

```js
const originalLaunch=options=>connectOwnedChrome(chromium,options);
```

Les validations headful/channel/sandbox, options enregistrées, version,
callbacks, `newContext`, gestes DOM, journal et codes de sortie restent les
mêmes. La garde P162 est byte-exacte ; sa politique GET et acceptDownloads=false
ne sont pas retirées. Les huit recettes sont byte-exactes, P157 sert deux jobs.
Les neuf commandes et l'ordre des préloads ne changent pas. Les cinq RPC restent
séparés : ce port ne crée pas de quinzième site Chrome.

Le helper courant `64555c1d…` contient déjà les quatorze identités A/B et les
contrôles actor/round/HEAD/source, registre root et birth/gate/release, endpoint
127.0.0.1:17594, deux scans frais et CDP5. Il n'est pas modifié. Démarrage50 et
cleanup8 relèvent toujours du G1 existant, non exécuté ici. `browser.close()`
déconnecte CDP ; la preuve d'arrêt physique reste indispensable chez G1.

## API de préparation

`render_direct_cdp.render(definitions, source_pins, helper_source=…,
helper_pin=…, root=…, actor=…, round_id=…, head=…)` retourne les dix textes
(huit recettes, trace, garde GET) et leurs pins. Il n'alloue rien et ne démarre
rien. Identités et inputs doivent être A/B exacts, les refs helper sont fermées
sur son SHA actuel, et l'inversion du delta reconstitue chaque octet original.
Les nouveaux inputs C17 préparés/pinnés et leur checkout HEAD devront être
fournis par le futur constructeur et revus séparément. Le JSON de sortie ne
constitue aucune autorité root.

`preimages-complete/` conserve quinze définitions. Quatre recettes runtime
proviennent des définitions C16 ; elles servent de fixtures normatives, pas de
résultats ni d'inputs courants C17. `preview-definition-only/` utilise cette
fixture et une identité synthétique explicitement signalée, jamais une ronde.
`INPUTS-COMPLETE.json` est le seul manifeste admissible aux purs.

## Tests et refus conservés

Le premier transfert groupé de texte a été tronqué. Une comparaison physique
fraîche a refusé ses treize copies avant test/usage, puis quinze copies complètes
ont été faites et comparées. `READ-REFUSAL.json` conserve ce refus ; `preimages/`
et `INPUTS.json` initiaux restent inéligibles et intacts.

Le premier jeu Python était rouge sur le compteur d'une ancre A/B présente
réellement deux fois. Préimage et reçu rouge sont conservés. Le correctif porte
sur le nombre exact d'occurrences, sans modifier helper ni assertion métier.
Les mêmes **19 tests Python** passent ensuite : delta/inversion, neuf sites,
bytes, sources, options gardées dans la trace, identités et fermeture des flags.

Le test JavaScript exécute les vrais corps helper/trace/garde P162, avec doubles
explicites FS/publication/identité/Playwright. Il contrôle les neuf sites,
refus d'options/source/actor/round/ports/contexte, CDP5 et la chaîne effective des
deux newContext, POST refusé et GET délégué. Il ne prouve pas le kernel, les
births réelles ou les hardlinks. L'essai V8 sans OS reste rouge : absence de URL.
Les ReferenceError/TypeError/assertions de test ne comptent jamais comme refus
métier dans la version actuelle.

Un essai Node22 pur a été explicitement autorisé sous deny-default OS, exec
seul Node physique, fork/réseau refusés et écritures limitées à la sortie. Il a
retourné 134 avec deux flux vides et sans reçu JS. Ce résultat est rouge
instrument, cause non établie, zéro cas qualifié. Aucune permission n'a été
élargie pour ce constat. Les commandes/reçus exacts sont liés dans l'INDEX.

## Deux raccords encore manquants, hors de ce lot

1. Git : les recettes general/invoices/crm et B1713/P162 font encore un
   `execFileSync('git', ['rev-parse','HEAD'], …)` ; `contexte-v3` le fait aussi.
   Le futur port doit fermer ces appels sur le snapshot root réel du checkout
   A/B actuel, avec contrôles HEAD/tree/blob et cwd exacts. Pas de HEAD ancien,
   pas de réponse synthétique ou de subprocess prétendument owned.
2. lsof : `ownership-only.mjs` utilise encore execFile pour sa vérification,
   et coverage utilise ses définitions de garde historiques. Un port borné doit
   appeler le rendez-vous owned-listener actuel avant chaque requête, garder
   l'oracle de PID/scans et refuser toute absence/port tiers. Les anciens succès
   listener ne qualifient pas cette future composition.

Ces deux ports seront distincts et demanderont ancrages/préimages/tests puis
revue root. La définition Chrome A/B originale et profile5266 sont inchangés,
non qualifiés ; aucune substitution implicite vers Chrome QA V8 n'est faite.
Il manque ensuite un constructeur physique préparation-only, les vrais bindings,
les décisions et calibrations A/B, leurs données neuves et les vrais parcours.
Ni les 27 étapes ni les 78 runtime ni leur dénominateur ne sont changés ici.
