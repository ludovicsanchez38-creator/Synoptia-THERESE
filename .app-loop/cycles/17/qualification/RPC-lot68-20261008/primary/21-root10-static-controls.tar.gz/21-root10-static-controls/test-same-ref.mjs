// Contrôles purs de l'égalité des seules références à trois champs.
import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
const folder='/private/tmp/therese-c17-root10-static-controls-v2-lTW3IXqj';
const source=fs.readFileSync(folder+'/verify-prepared-wrapper.mjs','utf8');
assert.equal(source.split('function sameRef(').length,2);
assert.equal(source.split('\nconst qa=').length,2);
const body=source.slice(source.indexOf('function sameRef('),source.indexOf('\nconst qa='));
const sameRef=new Function(body+';return sameRef;')();
const base={path:'/private/tmp/synthetic-ref',sha256:'a'.repeat(64),bytes:7};
const cases=[];
const run=(name,other,expected)=>{assert.equal(sameRef(base,other),expected,name);cases.push({name,passed:true});};
const entries=Object.entries(base);
for(const order of [[0,1,2],[0,2,1],[1,0,2],[1,2,0],[2,0,1],[2,1,0]])
  run('same_values_order_'+order.join(''),Object.fromEntries(order.map(i=>entries[i])),true);
for(const key of Object.keys(base)){
  const changed={...base,[key]:key==='bytes'?8:key==='path'?'/private/tmp/other':'b'.repeat(64)};
  run('changed_'+key,changed,false);
  const removed={...base};delete removed[key];run('missing_'+key,removed,false);
}
for(const [name,value]of [['extra',{...base,authority:true}],['null',null],['array',[]],
    ['boolean_bytes',{...base,bytes:true}],['negative_bytes',{...base,bytes:-1}],
    ['float_bytes',{...base,bytes:.5}],['unsafe_bytes',{...base,bytes:2**53}],
    ['relative_path',{...base,path:'relative'}],['invalid_sha',{...base,sha256:'x'.repeat(64)}]])
  run(name,value,false);
const ref=p=>{const b=fs.readFileSync(p);return{path:p,sha256:crypto.createHash('sha256').update(b).digest('hex'),bytes:b.length};};
const receipt={schema:'c17-root10-static-reference-equality-pure-tests-v1',actor:'/root',
  scope:'extracted_sameRef_only_synthetic_references',tests:cases.length,cases,passed:true,
  checker_ref:ref(folder+'/verify-prepared-wrapper.mjs'),test_ref:ref(import.meta.filename),
  native:false,G1:false,FULL:false};
fs.writeFileSync(folder+'/same-ref-pure-receipt.json',JSON.stringify(receipt,null,2)+'\n',{flag:'wx',mode:0o600});
console.log(JSON.stringify({tests:cases.length,passed:true}));
