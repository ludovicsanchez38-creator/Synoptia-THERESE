"""Rejeu pur RPC fermé : données de diagnostic, aucune admission native."""
from __future__ import annotations

import argparse
from contextlib import redirect_stdout, redirect_stderr
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import sys
import time
import traceback
import unittest

HERE = Path('/private/tmp/therese-c17-rpc-cause-observability-NRYrmF')
CONTROLS = Path(__file__).resolve().parent
FULL_NAMES = {'runtime_session', 'runtime_launch_gate', 'runtime78_core',
              'runtime78_coordinator', 'root_rpc_bootstrap', 'app', 'backend',
              'readiness_owned', 'density_owned'}


def reference(path):
    data = path.read_bytes()
    return {'path': str(path), 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', required=True, type=Path)
    out = parser.parse_args().out
    if (out.resolve(strict=True) != out or out.parent != Path('/private/tmp')
        or not out.name.startswith('therese-c17-rpc-cause-pure-root-') or any(out.iterdir())):
        raise ValueError('Fresh private canonical output required')
    os.umask(0o077)
    for name in ('synthetic-fixtures', 'home', 'tmp'):
        (out / name).mkdir(mode=0o700)
    os.environ['RPC_CAUSE_FIXTURES'] = str(out / 'synthetic-fixtures')
    os.environ['HOME'] = str(out / 'home')
    os.environ['TMPDIR'] = str(out / 'tmp')
    index_path = HERE / 'INDEX.json'
    if reference(index_path)['sha256'] != '604e4e02062dd37cafbf9e67b2545b7697bad70a7aeac2825598cefaa63d7596':
        raise ValueError('Closed source INDEX changed')
    index = json.loads(index_path.read_text())
    indexed = index['refs'] + index['actual_pure_proof_refs']
    for row in indexed:
        if reference(Path(row['path'])) != row:
            raise ValueError('Closed ref changed: ' + row['path'])
    paths = {Path(row['path']) for row in indexed}
    paths.update((index_path, Path(__file__).resolve(), CONTROLS / 'pure.sb',
                  CONTROLS / 'preimage-author-runner.py'))
    before = [reference(path) for path in sorted(paths)]
    forbidden = []

    def refuse(event, values):
        forbidden.append({'event': event, 'detail': str(values)[:300]})
        raise PermissionError('Pure audit guard: ' + event)

    def writable(path, event):
        if isinstance(path, int) or not Path(os.fsdecode(path)).resolve().is_relative_to(out):
            refuse(event, path)

    def audit(event, values):
        if event.startswith(('subprocess.', 'socket.', 'ctypes.', 'pty.')) or event in {
            'os.system', 'os.fork', 'os.forkpty', 'os.exec', 'os.posix_spawn',
            'os.spawn', 'os.kill', 'os.killpg'}:
            refuse(event, values)
        if event == 'import' and values[0].split('.')[0] in FULL_NAMES:
            refuse(event, values[0])
        if event == 'open':
            path, mode, flags = values
            if ((isinstance(mode, str) and any(c in mode for c in 'wax+')) or isinstance(flags, int)
                and flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND)):
                writable(path, event)
        elif event in {'os.mkdir', 'os.remove', 'os.rmdir', 'os.chmod', 'os.chown', 'os.utime', 'os.truncate'}:
            writable(values[0], event)
        elif event in {'os.rename', 'os.link', 'os.symlink'}:
            writable(values[0], event); writable(values[1], event)

    sys.addaudithook(audit)
    sys.path.insert(0, str(HERE / 'source'))
    started_at = datetime.now(timezone.utc).isoformat()
    start = time.monotonic()
    result = None
    error = None
    with (out / 'stdout.log').open('x', encoding='utf-8') as stdout, (out / 'stderr.log').open('x', encoding='utf-8') as stderr:
        with redirect_stdout(stdout), redirect_stderr(stderr):
            try:
                suite = unittest.defaultTestLoader.discover(str(HERE / 'tests'), pattern='test_rpc_diagnostics.py')
                result = unittest.TextTestRunner(stream=stderr, verbosity=2).run(suite)
            except BaseException as exc:
                error = {'type': type(exc).__name__, 'message': str(exc)}
                traceback.print_exc(file=stderr)
        stdout.flush(); stderr.flush()
        os.fsync(stdout.fileno()); os.fsync(stderr.fileno())
    after = [reference(path) for path in sorted(paths)]
    imported = sorted(name for name in sys.modules if name.split('.')[0] in FULL_NAMES)
    receipt = {'schema': 'c17-root-rpc-exception-observability-pure-tests-v1', 'actor': '/root',
        'observed_at_utc': datetime.now(timezone.utc).isoformat(), 'started_at': started_at,
        'root_replay_source_ref': reference(Path(__file__).resolve()),
        'tests_run': result.testsRun if result else 0,
        'failures': len(result.failures) if result else None, 'errors': len(result.errors) if result else None,
        'skips': len(result.skipped) if result else None, 'instrument_error': error,
        'elapsed_seconds': time.monotonic() - start, 'source_before': before, 'source_after': after,
        'sources_unchanged': before == after, 'forbidden_attempts': forbidden,
        'full_instrument_imports': imported,
        'stdout_ref': reference(out / 'stdout.log'), 'stderr_ref': reference(out / 'stderr.log'),
        'fixtures_explicitly_synthetic': True,
        'fixture_entries_after_cleanup': [p.name for p in (out / 'synthetic-fixtures').iterdir()],
        'G1_imported': False, 'native_executed': False, 'FULL': False, 'runtime_admission': False}
    receipt['passed'] = bool(result and result.wasSuccessful() and before == after and not forbidden
        and not imported and error is None and not receipt['fixture_entries_after_cleanup']
        and receipt['tests_run'] > 0 and not result.skipped)
    with (out / 'receipt.json').open('x', encoding='utf-8') as stream:
        json.dump(receipt, stream, ensure_ascii=False, sort_keys=True, indent=2)
        stream.write('\n'); stream.flush(); os.fsync(stream.fileno())
    print(json.dumps({'receipt': reference(out / 'receipt.json'), 'tests': receipt['tests_run'],
        'passed': receipt['passed'], 'failures': receipt['failures'], 'errors': receipt['errors'],
        'instrument_error': error, 'native': False}, ensure_ascii=False))
    return 0 if receipt['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
