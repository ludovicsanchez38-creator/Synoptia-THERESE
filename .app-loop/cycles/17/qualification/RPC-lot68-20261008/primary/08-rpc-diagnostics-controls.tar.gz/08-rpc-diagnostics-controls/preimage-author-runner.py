"""Run pure observability tests, with direct exclusive stdout/stderr sinks."""
from __future__ import annotations

import argparse
from contextlib import redirect_stdout, redirect_stderr
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import sys
import time
import unittest

HERE = Path(__file__).resolve().parent
ACTOR = "/root/shared4_execution"


def reference(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            "bytes": path.stat().st_size}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    out = Path(args.out)
    if out.resolve(strict=True) != out or HERE == out or HERE in out.parents:
        raise ValueError("Output must be a fresh canonical directory outside the immutable gel")
    files = sorted((HERE / "source").glob("*.py")) + sorted((HERE / "preimages").glob("*.py"))
    files += sorted((HERE / "tests").glob("*.py")) + [Path(__file__).resolve()]
    before = [reference(p) for p in files]
    forbidden = []
    def audit(event, args):
        if event in {"subprocess.Popen", "socket.__new__", "socket.connect", "socket.bind",
                     "os.fork", "os.forkpty", "os.posix_spawn", "os.kill", "os.killpg", "os.system"}:
            forbidden.append(event)
            raise RuntimeError("Pure test guard: " + event)
        if event == "import" and args and args[0] in {"runtime_session", "runtime_launch_gate"}:
            forbidden.append("import:" + args[0])
            raise RuntimeError("Full G1 import forbidden")
    sys.addaudithook(audit)
    fixtures = out / "synthetic-fixtures"
    fixtures.mkdir()
    os.environ["RPC_CAUSE_FIXTURES"] = str(fixtures)
    sys.path.insert(0, str(HERE / "source"))
    start = time.monotonic()
    with (out / "stdout.log").open("x", encoding="utf-8") as stdout, (out / "stderr.log").open("x", encoding="utf-8") as stderr:
        with redirect_stdout(stdout), redirect_stderr(stderr):
            suite = unittest.defaultTestLoader.discover(str(HERE / "tests"), pattern="test_rpc_diagnostics.py")
            result = unittest.TextTestRunner(stream=stderr, verbosity=2).run(suite)
        stdout.flush()
        stderr.flush()
        os.fsync(stdout.fileno())
        os.fsync(stderr.fileno())
    after = [reference(p) for p in files]
    receipt = {"schema": "c17-rpc-exception-observability-pure-test-receipt-v1", "actor": ACTOR,
        "observed_at_utc": datetime.now(timezone.utc).isoformat(), "tests_run": result.testsRun,
        "failures": len(result.failures), "errors": len(result.errors), "skips": len(result.skipped),
        "elapsed_seconds": time.monotonic() - start, "source_before": before, "source_after": after,
        "sources_unchanged": before == after, "forbidden_attempts": forbidden,
        "stdout_ref": reference(out / "stdout.log"), "stderr_ref": reference(out / "stderr.log"),
        "fixtures_explicitly_synthetic": True, "fixture_entries_after_cleanup": [p.name for p in fixtures.iterdir()],
        "G1_imported": False, "native_executed": False, "FULL": False, "runtime_admission": False}
    receipt["passed"] = (result.wasSuccessful() and before == after and not forbidden
        and not receipt["fixture_entries_after_cleanup"] and receipt["tests_run"] > 0 and not result.skipped)
    with (out / "receipt.json").open("x", encoding="utf-8") as f:
        json.dump(receipt, f, ensure_ascii=False, sort_keys=True, indent=2)
        f.write("\n")
    print(json.dumps({"receipt": reference(out / "receipt.json"), "tests": result.testsRun,
        "passed": receipt["passed"], "failures": receipt["failures"], "errors": receipt["errors"],
        "native": False}, ensure_ascii=False))
    return 0 if receipt["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
