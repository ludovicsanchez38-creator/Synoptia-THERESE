# Observations des replays purs Git et listener

Ces observations proviennent des invocations réelles du coordinateur `/root`. Elles ne signent pas une revue tierce et ne créent aucune admission native.

## Git

L’outil `715282` a terminé avec code 0. L’invocation réelle a exécuté `/private/tmp/therese-c17-ab-git-readonly-LgbRf1NJ/run_node_pure.mjs` avec une sortie neuve `/private/tmp/therese-c17-ab-git-node-gsBRXtrd`, sous le profil fermé `node-pure-root-read.sb`, SHA256 `468a30e15b06a23ff8d45d1d15c8e45938ae306f3394810f92cf3e1521651039`, 960 octets, HOME et TMPDIR dans la sortie, environnement vidé. Réseau, fork, autre exécutable et Mach restent interdits.

Le reçu brut `receipt.json` est SHA256 `81101013e4411b7cd0751558fe1db30f39dcdfc6e166f59b68020a28d3edc240`. Les 35 cas distincts sont passés, cinq pins avant/après identiques, erreur nulle. Les contrôles de pins `ca52db` et `dd1e96` lient aussi le profil et le gel Git inchangés. Le champ acteur du reçu désigne l’auteur `/root/cycle17_gate_review` ; l’exécuteur est `/root`. La commande brute est volontairement nulle : elle ne remplace pas l’invocation observée. Aucun reçu n’est réécrit.

Les vrais corps `environmentContext` et `ownedGitHead` sont extraits. FS, publication et lecteur Git sont des doubles explicites ; la sentinelle n’est volontairement pas un HEAD Git. Aucun objet commit, tree, checkout ou snapshot physique n’est qualifié par ces cas.

## Listener

L’outil `85c769` a terminé avec code 0. Il a exécuté le contrôleur `/private/tmp/therese-c17-root-listener-pure-controls-hybPNml4/run-listener-pure.mjs`, SHA256 `95ebea5b6afae39cbb5091c5dd47c098c657ab39b4edc63ef16ceec02f27224c`, avec sortie neuve `/private/tmp/therese-c17-listener-pure-root-jZjeZnUY` sous une copie byte-exacte du même profil fermé, sans nouveaux droits.

Le reçu SHA256 `b5022850241fa4ee63d8c99157f250808f0dd72adf66df25d5d2b4e583a8846e` rapporte six cas distincts passés et six pins avant/après identiques. Le coordinateur a lu le reçu entier (`47da83`), la sortie réelle (`e4fef1`) et vérifié les empreintes (`a3ed8b`). Les cas couvrent délégation et refus du port réel, attente avant émission, refus tiers/birth, routes HTTP/WS et coalescence en vol sans TTL. Ces noms ne signifient pas une mesure noyau : publication, process et services sont des doubles explicites.

Ces deux replays ne lancent ni Chrome, ni Git, ni lsof, ni Session, ni source produit. Ils ne prouvent pas listener native, hardlinks, ronde A/B, FULL ou release. Les refus antérieurs et le rouge ROOT10 sont conservés séparément.
