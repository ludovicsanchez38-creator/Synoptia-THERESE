# Contrôleurs ROOT10, préparation statique uniquement

Ce dossier contient les deux contrôleurs dérivés byte-à-byte des scripts ROOT9
avant deltas. **Ils n'ont pas été exécutés** ; aucun `identity-registry.json`,
`prepare-go.json`, racine QA ROOT10 ou GO natif n'a été émis ici.

`prepare-authority.mjs` est destiné à une future invocation explicite par root,
après réception de la revue indépendante. Il exige un dossier privé contenant
exactement les deux scripts, les préimages, les diffs, cet INDEX, ce README et
`V10-REVIEW-OBSERVATION.md` (écrite séparément par root). Il exige aussi que la
future racine
`/private/tmp/therese-c17-wrapper-canary-b90937dbae4845ca9d04b93aa4cdf9aa`
soit absente. Il émettrait alors seulement les deux JSON de préparation
exclusifs dans ce dossier. Leur `head` WRAPPER reste le HEAD historique
`2d69e30c9c6dd18823ee6102271876003a6a67cc`, distinct du HEAD du dépôt
actuel observé `19979e8a5ea9bd8e886d35d54793b3d1a560cd77`. Ni l'un ni
l'autre ne qualifie FULL A/B. Le constructeur exact est V10
`e697ec77…` / INDEX `ad4cbc19…`, le profil Chrome `19808ee2…` est inchangé.
Le reçu root de 71 tests purs et celui des 34 tests purs du helper diagnostic
sont des références épinglées, pas une qualification OS.

`verify-prepared-wrapper.mjs` est un audit **en lecture seule** destiné à la
future racine créée par un outil root distinct. Il exige 79 références source
physiques, 18 copies core, 28 sorties overlay dont 19 scripts, les quatre
origines et deltas RPC exacts, huit copies brutes préimage/diff et les trois
copies identiques de `rpc_diagnostics.py`. Il conserve aussi les 11 sorties
initiales, les six deltas ROOT9 encore applicables, les sept témoins, la QA
historique 3579 blobs/modes, les 36 sources SQL, cinq descripteurs Chrome et
les garde-fous de profils/absence d'état natif du contrôleur ROOT9. Le reçu de
test pur 34/34 ne devient jamais une preuve de runtime.

Invocations envisagées **seulement après GO root distinct** :

```sh
/Users/synoptia/.nvm/versions/node/v22.19.0/bin/node /private/tmp/therese-c17-root-fresh10-authority-5v3bqKwd/prepare-authority.mjs
/Users/synoptia/.nvm/versions/node/v22.19.0/bin/node /private/tmp/therese-c17-root-fresh10-authority-5v3bqKwd/verify-prepared-wrapper.mjs /private/tmp/therese-c17-wrapper-canary-b90937dbae4845ca9d04b93aa4cdf9aa
```

Le deuxième contrôleur est un audit de construction, pas un GO de démarrage.
Un refus réel du constructeur, du runtime, de Chrome, de G1 ou des gardes
reste rouge. Les scripts n'ouvrent aucun droit ni admission FULL. Les profils,
ports et délais restent ceux du builder V10 ; ce dossier ne les modifie pas.
