# Observation de l’exécution pure Node

Observation du coordinateur `/root`, sans création d’un reçu signé de relecteur.

Le résultat réel de l’outil `af16dd` est un code de sortie 0. L’exécution a utilisé le profil fermé `/private/tmp/therese-c17-ab-direct-cdp-root-read-ly2OJfDr/node-pure-root-read.sb`, SHA256 `468a30e15b06a23ff8d45d1d15c8e45938ae306f3394810f92cf3e1521651039`, 960 octets. Les contrôles physiques avant et après ont conservé cette empreinte.

Le reçu brut `/private/tmp/therese-c17-ab-direct-cdp-node-PCyIK8wE/receipt.json`, résolu par l’inventaire physique `962e85`, porte l’empreinte `5026481db690ed26c87c071105a4c8fe8c6d929fc003ef57a6413f0c52023a20`, 17 725 octets. Ses 35 cas distincts sont passés ; stdout est de 117 octets et stderr est vide. Ses 21 références sont stables avant et après.

Le champ acteur du reçu brut désigne l’auteur du test `/root/cycle17_gate_review`, tandis que l’exécuteur réel est `/root`. Le champ commande du reçu brut désigne encore l’ancien profil de 923 octets, car le runner a été conservé à l’identique. Le reçu brut n’est pas réécrit. C’est l’invocation réelle de l’outil, rapprochée des empreintes avant et après, qui établit le profil utilisé.

Le premier refus Node avec code 134 reste conservé. L’ajout du seul droit de lecture littérale de `/` provient du diagnostic kernel et dyld conservé ; il n’ajoute ni droit réseau, ni lancement de descendants, ni accès Mach.

Ces tests exécutent des corps de fonctions sélectionnés avec des doubles explicites. Ils ne constituent ni un lancement Chrome/CDP, ni une Session native, ni une ronde A/B, ni FULL, ni une autorisation de release.
