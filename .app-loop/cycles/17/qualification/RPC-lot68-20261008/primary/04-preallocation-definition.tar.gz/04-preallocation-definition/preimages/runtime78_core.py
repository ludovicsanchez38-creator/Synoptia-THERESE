"""Contrats du port statique. Aucun effet à l'import, aucune capacité admise."""
from __future__ import annotations

import direct_round_admission as direct_round
import rpc_abi_reader as rpc_abi

from datetime import UTC, datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import stat
import subprocess

REPO = Path('/Users/synoptia/Desktop/Dev Synoptia/Synoptia-THERESE-c15-codex')
QA_SOURCE = None  # aucun fallback vers le checkout historique des canaris.
PREDECESSOR = Path('/private/tmp/therese-c17-full-suite-ps_tgzy5/proofs/runtime78-constructor/prepare-runtime78.py')
HERE = Path(__file__).resolve().parent
HEAD = None  # paramètre HEAD attendu du checkout A/B physique.
Q = REPO / '.app-loop/cycles/17/qualification'
TABLE = Q / 'runtime78-closed-table.json'
TABLE_SHA = '419f60e9295cc0729a99ae782aa946bf9269737616cfff8307fb0b6b22e26db4'
ADAPTER = Q / 'runtime78_adapter.py'
ADAPTER_SHA = '771efc5f6fcd52e56862604f84b10e858c6a504df8386804c60f374687eb6998'
PYTHON = None
_DIRECT_CONTEXT = None
_DIRECT_BINDING = None
_DIRECT_BINDING_REF = None
NODE = Path('/Users/synoptia/.nvm/versions/node/v22.19.0/bin/node')
ACTORS = frozenset({'/root', '/root/cycle17_gate_review', '/root/environment_routes', '/root/native_policy_review'})
UI_CONTEXTS = ('B1713', 'P157-800', 'P157-1440', 'B1755', 'P162')
EIGHT_LOGS = ('runtime/backend-runtime.log', 'runtime/vite-runtime.log',
    'complements/runs/B1753/harness.stdout', 'complements/runs/B1753/harness.stderr',
    'complements/runs/B1753-power/harness.stdout', 'complements/runs/B1753-power/harness.stderr',
    'complements/runs/B1760/harness.stdout', 'complements/runs/B1760/harness.stderr')
LOG_PATTERN = r'\b(ERROR|CRITICAL)\b|Traceback \(most recent call last\)'
SESSION_ABI = 'c17-runtime78-session-api-v1'
RPC_ABI = rpc_abi.SCHEMA
# Le lot ne peut pas ouvrir sa propre exécution. Changement futur = nouveau SHA/revue/GO.
RUNTIME_ENABLED = False
SQL_READ_VIEW = None  # seulement dans un worker SQL effectivement admis ; jamais une capacité/autorité.


class ClosedPreparation(ValueError):
    pass


def need(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def now() -> str:
    return datetime.now(UTC).isoformat()


def sha(path: Path | str) -> str:
    return hashlib.sha256(read_path(path).read_bytes()).hexdigest()


def ref(path: Path | str) -> dict:
    path = Path(path)
    return {'path': str(path), 'sha256': sha(path), 'bytes': read_path(path).stat().st_size}


def load(path: Path | str) -> dict:
    return json.loads(read_path(path).read_text())


def read_path(path: Path | str) -> Path:
    return SQL_READ_VIEW.read_path(Path(path)) if SQL_READ_VIEW is not None else Path(path)


def canonical_reference_path(path: Path | str) -> Path:
    raw = Path(path)
    return raw if SQL_READ_VIEW is not None and SQL_READ_VIEW.has_origin(raw) else raw.resolve()


def checked(reference: dict, *, root: Path | None = None, definition_only: bool = False) -> Path:
    need(isinstance(reference, dict) and isinstance(reference.get('path'), str)
         and re.fullmatch(r'[0-9a-f]{64}', reference.get('sha256', '')) is not None, 'Référence exacte requise')
    raw = Path(reference['path'])
    if SQL_READ_VIEW is not None and SQL_READ_VIEW.has_origin(raw):
        need(root is None or raw.is_relative_to(root), 'Origine hors de la racine demandée')
        return SQL_READ_VIEW.checked(reference)
    if SQL_READ_VIEW is not None:
        need(any(raw.is_relative_to(base) for base in SQL_READ_VIEW.allowed), 'Référence SQL extérieure sans copie exacte')
    need(raw.is_absolute() and not raw.is_symlink(), 'Référence absolue non symlink requise')
    path = raw.resolve(strict=True)
    need(path == raw and path.is_file(), 'Référence non canonique/régulière')
    allowed = path.is_relative_to(Q) or path.is_relative_to(HERE) or (
        path.is_relative_to(Path('/private/tmp')) and any(p.startswith('therese-c17-') for p in path.parts))
    allowed |= any(path.is_relative_to(REPO / p) for p in ('src', 'tests', 'scripts'))
    if definition_only and not allowed:
        # Ancien instrument : seulement les octets déjà épinglés, jamais
        # preuve courante ni élargissement des références du consommateur.
        allowed = load(HERE / 'frozen-inputs.json')['sources'].get(str(path)) == reference['sha256']
    need(allowed and (root is None or path.is_relative_to(root)), 'Référence hors périmètre')
    need(sha(path) == reference['sha256']
         and ('bytes' not in reference or path.stat().st_size == reference['bytes']), 'SHA/taille différent : ' + str(path))
    return path


def round_root(root: Path) -> Path:
    need(root.is_absolute() and root.resolve(strict=True) == root and not root.is_symlink()
         and root.parent == Path('/private/tmp') and direct_round.ROUND.fullmatch(root.name) is not None, 'Racine ronde privée neuve exacte requise')
    return root


def inside(root: Path, path: Path) -> Path:
    round_root(root)
    need(path.is_absolute() and path.resolve() == path and path.is_relative_to(root), 'Destination non canonique hors ronde')
    for ancestor in (path, *path.parents):
        if ancestor == root.parent:
            break
        need(not ancestor.is_symlink(), 'Symlink de destination refusé')
    return path


def write_new(root: Path, path: Path, data: bytes) -> None:
    need(RUNTIME_ENABLED, 'Écriture de ronde fermée dans ce lot statique')
    inside(root, path)
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())


def save_new(root: Path, path: Path, data: object) -> None:
    write_new(root, path, (json.dumps(data, ensure_ascii=False, indent=2) + '\n').encode())


def write_atomic_new(root: Path, path: Path, data: bytes) -> None:
    """Publication sans overwrite : pending fermé/fsync puis hardlink exclusif.

    Le pending est conservé comme brut. Aucun ancien reçu ni fichier cible
    n'est supprimé ou remplacé, même après une erreur.
    """
    need(RUNTIME_ENABLED, 'Publication de ronde fermée dans ce lot statique')
    inside(root, path)
    pending = path.with_name(path.name + '.pending')
    write_new(root, pending, data)
    os.link(pending, path, follow_symlinks=False)
    fd = os.open(path.parent, os.O_RDONLY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def save_atomic_new(root: Path, path: Path, data: object) -> None:
    write_atomic_new(root, path, (json.dumps(data, ensure_ascii=False, indent=2) + '\n').encode())


def rewrite_owned_bytes(root: Path, path: Path, expected_sha: str, encoded: bytes) -> str:
    """Réécrit uniquement le FD régulier dont les octets exacts sont connus.

    Pas de rename/unlink de fichier inconnu. Aucun lecteur métier actif lors
    des changements prepared→starting→running→stopped du manifeste.
    """
    need(RUNTIME_ENABLED, 'Réécriture de ronde fermée dans ce lot statique')
    inside(root, path)
    fd = os.open(path, os.O_RDWR | os.O_NOFOLLOW)
    with os.fdopen(fd, 'r+b') as stream:
        before = os.fstat(stream.fileno())
        need(stat.S_ISREG(before.st_mode), 'FD non régulier')
        need(hashlib.sha256(stream.read()).hexdigest() == expected_sha, 'Ancien contenu inconnu, aucune écriture')
        named = path.lstat()
        need((before.st_dev, before.st_ino) == (named.st_dev, named.st_ino), 'Nom remplacé')
        stream.seek(0)
        stream.write(encoded)
        stream.truncate()
        stream.flush()
        os.fsync(stream.fileno())
        after = path.lstat()
        need((before.st_dev, before.st_ino) == (after.st_dev, after.st_ino), 'Nom changé pendant écriture du FD propre')
    return sha(path)


def rewrite_owned(root: Path, path: Path, expected_sha: str, data: object) -> str:
    return rewrite_owned_bytes(root, path, expected_sha,
        (json.dumps(data, ensure_ascii=False, indent=2) + '\n').encode())


def configure_direct_round(root: Path, binding_ref: dict, *, expected_head: str) -> dict:
    """Lecture physique seulement. Aucun changement de RUNTIME_ENABLED."""
    global HEAD, QA_SOURCE, PYTHON, _DIRECT_CONTEXT, _DIRECT_BINDING, _DIRECT_BINDING_REF
    binding = load(checked(binding_ref))
    need(Path(binding_ref['path']).is_relative_to(Q), 'Binding initial doit rester autorité Q externe')
    candidate = direct_round.source_context(root, binding, actor=binding.get('actor'),
        round_id=binding.get('round_id'), campaign=binding.get('round_name'), expected_head=expected_head)
    HEAD, QA_SOURCE, PYTHON = expected_head, Path(candidate['product_source_root']), Path(candidate['qa_python'])
    _DIRECT_CONTEXT, _DIRECT_BINDING, _DIRECT_BINDING_REF = candidate, binding, dict(binding_ref)
    return candidate

def frozen_inputs() -> dict:
    inputs = load(HERE / 'frozen-inputs.json')
    for path, expected in inputs['sources'].items():
        need(sha(path) == expected, 'Définition/source modifiée : ' + path)
    need(sha(TABLE) == TABLE_SHA and sha(ADAPTER) == ADAPTER_SHA, 'Table/adaptateur modifié')
    need(_DIRECT_CONTEXT is not None, 'Contexte A/B frais physique absent')
    direct_round.source_context(Path(_DIRECT_CONTEXT['identity']['qa_root']), _DIRECT_BINDING,
        actor=_DIRECT_CONTEXT['identity']['actor'], round_id=_DIRECT_CONTEXT['identity']['round_id'],
        campaign=_DIRECT_CONTEXT['identity']['round_name'], expected_head=HEAD)
    return inputs

def config_identity(config: dict, root: Path) -> None:
    round_root(root)
    need(_DIRECT_CONTEXT is not None and config == _DIRECT_CONTEXT['config'], 'Config A/B physique non configurée')
    direct_round.identity(root, actor=config['actor'], round_id=config['round_id'],
                          campaign=config['campaign'], expected_head=HEAD)
    need(config['python'] == str(PYTHON) and config['frontend_dependencies'] == str(QA_SOURCE / 'src/frontend/node_modules')
         and config['playwright_dependencies'] == str(QA_SOURCE / 'node_modules'), 'Interpréteur/dépendances hors QA verrouillée')

def sources_unchanged(config: dict) -> dict:
    config_identity(config, Path(config['root']))
    if SQL_READ_VIEW is None:
        direct_round.source_context(Path(config['root']), _DIRECT_BINDING, actor=config['actor'],
            round_id=config['round_id'], campaign=config['campaign'], expected_head=HEAD)
    else:
        need(config['head'] == HEAD, 'Snapshot worker lié à un autre HEAD')
    product_root = QA_SOURCE
    observed = {name: sha(product_root / name) for name in config['product_sources']}
    need(observed == config['product_sources'], 'Source produit modifiée')
    qa_imports = {name: sha(QA_SOURCE / name) for name in config['product_sources']
                  if name.startswith(('src/backend/', 'tests/'))}
    need(all(qa_imports[name] == observed[name] for name in qa_imports), 'Source QA importable différente du HEAD préparé')
    frontend = Path(config['frontend_qa'])
    served = {name: sha(frontend / Path(name).relative_to('src/frontend')) for name in config['frontend_qa_sources']}
    need(served == config['frontend_qa_sources'], 'Source réellement servie différente')
    for root_key, version_key in [('frontend_dependencies', 'frontend_dep_versions'), ('playwright_dependencies', 'playwright_dep_versions')]:
        for entry, row in config[version_key].items():
            path = Path(config[root_key]) / entry.removeprefix('node_modules/') / 'package.json'
            need(sha(path) == row['sha256'], 'Dépendance modifiée : ' + entry)
    return {'product': observed, 'served': served, 'QA_importable': qa_imports}


def qa_sources_unchanged(config: dict) -> dict:
    """Contrôle enfant borné ; les contrôles repo/HEAD restent dans le parent.

    Aucun accès implicite au checkout/.git depuis une sandbox workload. Le
    coordinateur appelle toujours sources_unchanged avant et après chaque étape.
    """
    observed = {name: sha(QA_SOURCE / name) for name in config['product_sources']}
    need(observed == config['product_sources'], 'Copies QA différentes du snapshot HEAD lié')
    return observed


def stack_profile(config: dict, root: Path, *, running: bool = False) -> dict:
    config_identity(config, root)
    data = load(root / 'runtime/pile-reprise.json')
    need(data['cycle'] == 17 and data['repo'] == str(QA_SOURCE), 'Autre pile')
    need(data['backend']['host'] == data['vite']['host'] == '127.0.0.1'
         and data['backend']['port'] == 17593 and data['vite']['port'] == 5173, 'Autres ports/hôtes QA')
    temporary = Path(data['temporary_root'])
    inside(root, temporary)
    need(temporary.is_dir() and temporary.is_relative_to(root / 'profiles'), 'Profil hors ronde')
    for key in ['home', 'data_dir']:
        path = Path(data[key])
        inside(root, path)
        need(path.is_dir() and path.is_relative_to(temporary), 'Profil réel/non propre')
    if running:
        need(data['status'] == 'running' and data['head_at_start'] == HEAD, 'Pile non courante running')
    return data


def environment(config: dict, root: Path, mode: str, stage: str) -> dict[str, str]:
    """Aucune variable héritée. Les jetons HTTP restent uniquement en mémoire."""
    config_identity(config, root)
    need(mode in ('web', 'sql'), 'Profil absent')
    capability = load(checked(config['session_contract']))
    need(capability['schema'] == SESSION_ABI, 'Contrat Session exact absent dans configuration portée')
    env = {'PATH': str(NODE.parent) + ':/usr/bin:/bin:/usr/sbin:/sbin', 'LANG': 'en_US.UTF-8', 'LC_ALL': 'en_US.UTF-8',
           '__CF_USER_TEXT_ENCODING': f'0x{os.getuid():X}:0:0',
           'HOME': str(root / 'bootstrap-home'), 'CFFIXED_USER_HOME': str(root / 'bootstrap-home'),
           'TMPDIR': str(root / 'bootstrap-tmp'), 'PYTHONNOUSERSITE': '1', 'PYTHONDONTWRITEBYTECODE': '1',
           'PYTHONUNBUFFERED': '1', 'HF_HUB_OFFLINE': '1', 'TRANSFORMERS_OFFLINE': '1',
           'PYTHONPATH': str(QA_SOURCE) + ':' + str(QA_SOURCE / 'src/backend'),
           'C16_ACTOR': config['actor'], 'C16_ROUND_ID': config['round_id']}
    if mode == 'web' and stage != 'prepare-runtime':
        data = stack_profile(config, root)
        cache = config.get('browser_cache')
        need(isinstance(cache, str) and inside(root, Path(cache)).is_dir(),
             'Cache navigateur QA exact absent ; aucun fallback cache utilisateur')
        home, chosen = data['home'], Path(data['data_dir'])
        env.update({'HOME': home, 'CFFIXED_USER_HOME': home, 'TMPDIR': data['temporary_root'],
            'PYTHONPATH': str(QA_SOURCE) + ':' + str(QA_SOURCE / 'src/backend'), 'THERESE_DATA_DIR': str(chosen),
            'DATA_DIR': str(chosen), 'DB_PATH': str(chosen / 'therese.db'), 'QDRANT_PATH': str(chosen / 'qdrant'),
            'PORT': '17593', 'HOST': '127.0.0.1', 'THERESE_DB_PLAINTEXT': '1', 'THERESE_SKIP_SERVICES': '1',
            'PYTHON_KEYRING_BACKEND': 'keyring.backends.null.Keyring', 'THERESE_SONDE_CATALOGUE': 'off',
            'OLLAMA_BASE_URL': 'http://127.0.0.1:9', 'VITE_THERESE_BACKEND_PORT': '17593',
            'PLAYWRIGHT_BROWSERS_PATH': cache,
            'C16_ACTION_TRACE': str(root / 'ledger' / stage / 'chrome-dom-actions.json')})
    if stage in UI_CONTEXTS:
        contract = root / 'complements/contrats-normalises-proposes.json'
        env.update({'C16_OUT': str(root / 'complements/runs' / stage), 'C16_REVIEWED_SHA256': sha(contract)})
        if stage.startswith('P157-'):
            env['C16_WIDTH'] = stage.split('-')[1]
    need(mode != 'sql' or 'THERESE_DB_PLAINTEXT' not in env, 'Plaintext interdit dans SQL')
    return env


def admission(reference: dict, phase: str, *, config: dict | None = None, root: Path | None = None) -> dict:
    """Validation de contenu épinglé ; root vérifie l'origine réelle avant GO.

    Les chaînes JSON ne sont jamais présentées comme authentification root.
    Cette préparation garde en plus sa porte matérielle RUNTIME_ENABLED=False.
    """
    decision = load(checked(reference))
    need(decision.get('schema') == 'c17-runtime78-successor-admission-v1'
         and decision.get('provided_by') == '/root' and decision.get('phase') == phase
         and decision.get('head') == HEAD and decision.get('actor') in ACTORS, 'Décision root exacte absente')
    registry = load(checked(decision['identity_registry']))
    actors = [r for r in registry['actors'] if r['actor'] == decision['actor']]
    need(registry['schema'] == 'c17-identity-registry-v1' and len(actors) == 1, 'Acteur réel non unique')
    origin = actors[0]['origin']; origin = dict(origin, path=str(canonical_reference_path(REPO / origin['path'])))
    raw = load(checked(origin))
    need(raw['actor'] == decision['actor'] and raw['origin_kind'] == 'collaboration_tool_call'
         and raw['provided_by'] == '/root', 'Origine collaboration exacte requise')
    checked(decision['root_review_origin'])
    index = load(checked(decision['successor_index']))
    need(index['schema'] == 'c17-runtime78-successor-index-v1', 'Index successeur absent/différent')
    for item in index['files']:
        checked(item)
    need(any(item['path'] == str(Path(__file__)) and item['sha256'] == sha(__file__) for item in index['files']),
         'Source core effective non épinglée dans index relu')
    capability = decision['session']
    module = checked(capability['module'])
    contract = load(checked(capability['contract']))
    need(contract['schema'] == SESSION_ABI and contract['module'] == capability['module'],
         'ABI/SHA Session différent')
    required = {'fresh_round_binding', 'exact_command_env_cwd_sinks', 'direct_combined_service_logs',
                'PID_birth_UID_PGID_parent', 'worker_owned_listener_rendezvous',
                'real_parent_phase_identity', 'real_root_review_rendezvous',
                'stop_services_before_final_stop', 'outer_monotonic_deadline_derived',
                'no_foreign_signal', 'raw_timeout_preserved', 'untainted_log_stability',
                'unlaunched_handles_never_runtime_success', 'cleanup_deadline_taint_before_raw_stable',
                'real_immutable_stage_binding_rendezvous_and_admission'}
    need(required <= set(contract['features']) and module.suffix == '.py', 'ABI Session générale incomplète')
    need(config is not None and root is not None and _DIRECT_BINDING is not None
         and decision['session_binding'] == _DIRECT_BINDING_REF,
         'Contexte/binding A/B exact requis avant lecture du contrat RPC')
    rpc_abi.validate(decision, _DIRECT_BINDING, config, root, checked=checked, load=load,
                     effective_reader_ref=ref(Path(rpc_abi.__file__)))
    if config is not None:
        need(root is not None and decision['actor'] == config['actor'] and decision['round_id'] == config['round_id']
             and decision['qa_root'] == str(root), 'Décision autre ronde/acteur/racine')
    round_name = decision.get('round_name', config.get('campaign') if config else None)
    if round_name == 'B':
        prior = load(checked(decision['prior_A_shutdown']))
        need(prior.get('termination_proved') is True and prior.get('log_stability_proved') is True
             and prior.get('ports_absent') == [17593, 5173]
             and prior.get('actor') in ACTORS and prior.get('actor') != decision['actor'],
             'B exige arrêt réel A et deux acteurs canoniques distincts ; aucun override déclaratif')
    if not RUNTIME_ENABLED:
        raise ClosedPreparation('Lot statique fermé : G1/G5 et portes runtime non admis')
    return decision


def import_admitted(reference: dict, name: str):
    need(RUNTIME_ENABLED, 'Import de capacité fermé dans ce lot')
    path = checked(reference)
    spec = importlib.util.spec_from_file_location(name, path)
    need(spec is not None and spec.loader is not None, 'Module absent')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    need(sha(path) == reference['sha256'], 'Module changé pendant import')
    return module


def closed_main() -> int:
    print(json.dumps({'status': 'static_preparation_closed', 'execution_enabled': False,
        'root_decision': None, 'required_missing_capabilities': ['G1 exact admitted Session A/B', 'root-owned RPC exact ABI and current A/B calibration'],
        'legacy_fallback': False, 'round_created': False, 'runtime_started': False}, ensure_ascii=False))
    return 2


def worker_context(root: Path, decision_ref: dict):
    """Future entrée worker : aucun repli vers lsof/ps ou profil non admis."""
    config = load(round_root(root) / 'prepared-config.json')
    config_identity(config, root)
    decision = admission(decision_ref, 'runtime', config=config, root=root)
    qa_sources_unchanged(config)
    module = import_admitted(decision['session']['module'], 'runtime78_admitted_session_worker')
    need(getattr(module, 'API_SCHEMA', None) == SESSION_ABI
         and callable(getattr(module, 'request_owned_listener_observation', None)), 'API de rendezvous listener worker absente')
    return config, decision, module
