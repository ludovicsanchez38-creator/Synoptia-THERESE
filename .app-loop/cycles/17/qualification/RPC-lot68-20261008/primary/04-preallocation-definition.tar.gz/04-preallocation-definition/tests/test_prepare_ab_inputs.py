from __future__ import annotations

import json
from pathlib import Path
import tempfile
import unittest
import uuid

import calibration_round_producer as producer
import prepare_ab_inputs as subject


def save(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)


class Fixture:
    def __init__(self) -> None:
        # Les fixtures sont synthétiques. Aucun git/uv/npm/Session n'est lancé.
        self.folder = Path(tempfile.mkdtemp(prefix="therese-c17-direct-source-test-", dir="/private/tmp"))
        self.folder.chmod(0o700)
        self.source = self.folder / "source"
        self.source.mkdir(mode=0o700)
        self.repository = self.folder / "current-repository"
        self.repository.mkdir(mode=0o700)
        self.proofs = self.folder / "proofs"
        self.proofs.mkdir(mode=0o700)
        self.commit = b"tree synthetic\nauthor fixture\n"
        self.head = producer.git_object("commit", self.commit)
        save(self.source / ".git/HEAD", (self.head + "\n").encode())
        save(self.source / "src/frontend/src/App.tsx", b"export const App = 1;\n")
        save(self.source / "tests/test_smoke.py", b"def test_smoke(): assert True\n")
        save(self.source / "uv.lock", b"version = 1\n")
        self.root_packages = {name: "1.0.0" for name in subject.REQUIRED_ROOT}
        self.front_packages = {name: "2.0.0" for name in subject.REQUIRED_FRONTEND}
        for folder, versions in ((self.source, self.root_packages),
                                 (self.source / "src/frontend", self.front_packages)):
            lock = {"packages": {"node_modules/" + name: {"version": version}
                                 for name, version in versions.items()}}
            save(folder / "package-lock.json", json.dumps(lock).encode())
            for name, version in versions.items():
                save(folder / "node_modules" / name / "package.json",
                     json.dumps({"version": version}).encode())
        self.python = self.source / ".venv-conforme/bin/python"
        self.python.parent.mkdir(parents=True)
        self.python.symlink_to("/usr/bin/python3")
        save(self.source / ".venv-conforme/pyvenv.cfg", b"home = /usr/bin\n")
        metadata = self.source / ".venv-conforme/lib/python3.13/site-packages/demo.dist-info"
        metadata.mkdir(parents=True)
        save(self.proofs / "uv-graph-check.stdout", b"")
        save(self.proofs / "uv-graph-check.stderr", b"checked\n")
        python_audit = {"schema": "c17-fresh-python-metadata-audit-v1", "status": "PASS",
                        "qa_source": str(self.source), "head": self.head,
                        "qa_python": str(self.python), "mismatches": [],
                        "graph_check_exit_observed_by_root": 0,
                        "packages": [{"metadata_path": str(metadata)}], "installed_count": 1,
                        "lock": subject.ref(self.source / "uv.lock"), "pth": [],
                        "uv_graph_check_stdout": subject.ref(self.proofs / "uv-graph-check.stdout"),
                        "uv_graph_check_stderr": subject.ref(self.proofs / "uv-graph-check.stderr")}
        save(self.proofs / "python-metadata-result.json", json.dumps(python_audit).encode())
        node_audit = {"schema": "c17-fresh-node-metadata-audit-v1", "status": "PASS",
                      "head": self.head, "proofs": [
                          {"root": str(self.source), "installed": 2, "mismatches": [],
                           "lock_sha256": subject.sha((self.source / "package-lock.json").read_bytes())},
                          {"root": str(self.source / "src/frontend"), "installed": 6,
                           "mismatches": [], "lock_sha256": subject.sha((self.source / "src/frontend/package-lock.json").read_bytes())}]}
        save(self.proofs / "node-metadata-result.json", json.dumps(node_audit).encode())
        self.python_ref = subject.ref(self.proofs / "python-metadata-result.json")
        self.node_ref = subject.ref(self.proofs / "node-metadata-result.json")
        tracked = ["src/frontend/src/App.tsx", "tests/test_smoke.py", "uv.lock",
                   "package-lock.json", "src/frontend/package-lock.json"]
        self.tree = b"".join(
            f"100644 blob {producer.git_object('blob', (self.source / name).read_bytes())}\t{name}".encode() + b"\0"
            for name in tracked)

    def capture(self, source: Path, argv: list[str]) -> bytes:
        if source == self.repository and argv == ["rev-parse", "--verify", "HEAD"]:
            return (self.head + "\n").encode()
        assert source == self.source
        if argv == ["rev-parse", "--verify", "HEAD"]:
            return (self.head + "\n").encode()
        if argv == ["cat-file", "commit", self.head]:
            return self.commit
        if argv == ["ls-tree", "-r", "-z", self.head]:
            return self.tree
        raise AssertionError(argv)

    def preflight(self, campaign: str = "A", nonce: str | None = None) -> dict:
        return subject.preflight(self.source, campaign=campaign,
                                 nonce=nonce or uuid.uuid4().hex[:12], expected_head=self.head,
                                 python_audit_ref=self.python_ref, node_audit_ref=self.node_ref,
                                 capture=self.capture, current_repository=self.repository)


class PreparationTests(unittest.TestCase):
    def setUp(self) -> None:
        self.f = Fixture()

    def test_preflight_reads_actual_head_and_git_blobs_before_root(self) -> None:
        plan = self.f.preflight()
        self.assertEqual(plan["status"], "preflight_only_not_admitted")
        self.assertEqual(plan["head"], self.f.head)
        self.assertFalse(Path(plan["root"]).exists())
        self.assertEqual(plan["git_preview"]["file_count"], 5)
        self.assertEqual(plan["config_fields"]["frontend_qa_sources"]["src/frontend/src/App.tsx"],
                         subject.sha(b"export const App = 1;\n"))
        self.assertIn("src/frontend/package-lock.json", plan["config_fields"]["frontend_qa_sources"])

    def test_identity_couples_logical_and_physical_name(self) -> None:
        row = subject.identity("B", "012345abcdef")
        self.assertEqual(row["round_id"], "c17-direct-round-b-012345abcdef")
        self.assertEqual(Path(row["root"]).name, "therese-" + row["round_id"])
        self.assertEqual(row["actor"], "/root")
        for campaign, nonce in (("C", "012345abcdef"), ("A", "ABCDEF012345"), ("A", "123")):
            with self.assertRaises(ValueError):
                subject.identity(campaign, nonce)

    def test_wrong_head_or_modified_blob_refuses(self) -> None:
        with self.assertRaisesRegex(ValueError, "HEAD du dépôt courant"):
            subject.preflight(self.f.source, campaign="A", nonce="012345abcdef",
                              expected_head="a" * 40, python_audit_ref=self.f.python_ref,
                              node_audit_ref=self.f.node_ref, capture=self.f.capture,
                              current_repository=self.f.repository)
        save(self.f.source / ".git/HEAD", b"a" * 40 + b"\n")
        with self.assertRaisesRegex(ValueError, "HEAD physique"):
            self.f.preflight()
        save(self.f.source / ".git/HEAD", (self.f.head + "\n").encode())
        save(self.f.source / "tests/test_smoke.py", b"altered\n")
        with self.assertRaisesRegex(ValueError, "Blob Git"):
            self.f.preflight()

    def test_node_lock_or_proof_other_checkout_refuses(self) -> None:
        package = self.f.source / "node_modules/playwright/package.json"
        save(package, b'{"version":"9.9.9"}')
        with self.assertRaisesRegex(ValueError, "Version Node"):
            self.f.preflight()
        save(package, b'{"version":"1.0.0"}')
        audit = json.loads((self.f.proofs / "python-metadata-result.json").read_text())
        audit["qa_source"] = "/private/tmp/therese-c17-wrapper-source-old/source"
        save(self.f.proofs / "python-metadata-result.json", json.dumps(audit).encode())
        self.f.python_ref = subject.ref(self.f.proofs / "python-metadata-result.json")
        with self.assertRaisesRegex(ValueError, "Audit Python"):
            self.f.preflight()

    def test_root_collision_refuses_before_git_capture(self) -> None:
        nonce = uuid.uuid4().hex[:12]
        root = Path(subject.identity("A", nonce)["root"])
        root.mkdir(mode=0o700)
        with self.assertRaisesRegex(ValueError, "déjà allouée"):
            self.f.preflight(nonce=nonce)

    def test_attest_calls_exact_producer_after_root_and_config(self) -> None:
        plan = self.f.preflight()
        root = Path(plan["root"])
        root.mkdir(mode=0o700)
        (root / "authorization").mkdir(mode=0o700)
        config = dict(plan["config_fields"], browser_cache=str(root / "profiles/browser-cache"))
        save(root / "prepared-config.json", producer.json_bytes(config))
        checkout_ref = subject.attest_prepared_root(
            plan, subject.ref(root / "prepared-config.json"), capture=self.f.capture)
        checkout = json.loads(Path(checkout_ref["path"]).read_text())
        self.assertEqual(checkout["schema"], "c17-direct-round-source-checkout-v1")
        self.assertEqual(checkout["head"], self.f.head)
        self.assertEqual(checkout["round_id"], plan["round_id"])
        self.assertEqual(checkout["source_manifest_ref"]["path"], str(root / "authorization/source-files.json"))
        with self.assertRaisesRegex(ValueError, "déjà émise"):
            subject.attest_prepared_root(plan, subject.ref(root / "prepared-config.json"), capture=self.f.capture)

    def test_no_session_contract_or_stale_config_at_attestation(self) -> None:
        plan = self.f.preflight()
        root = Path(plan["root"])
        root.mkdir(mode=0o700)
        (root / "authorization").mkdir(mode=0o700)
        config = dict(plan["config_fields"], browser_cache=str(root / "profiles/browser-cache"),
                      session_contract={"path": "/outside"})
        save(root / "prepared-config.json", producer.json_bytes(config))
        with self.assertRaisesRegex(ValueError, "admission déjà injectée"):
            subject.attest_prepared_root(plan, subject.ref(root / "prepared-config.json"), capture=self.f.capture)
        self.assertFalse((root / "authorization/source-checkout.json").exists())


if __name__ == "__main__":
    unittest.main()
