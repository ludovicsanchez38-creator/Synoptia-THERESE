# Tests purs du lot

Commande exécutée depuis cette racine : `python3 -B -m unittest discover -s tests -v`.

Premier passage : 7 tests, 1 échec. Le test attendait seulement `src/frontend/src/App.tsx` dans `frontend_qa_sources`, alors que le producteur conserve aussi `src/frontend/package-lock.json`. Aucun code de production n'a été changé pour ce rouge ; seule l'attente synthétique a été corrigée.

Dernier passage : 7 tests, 7 `ok`, `Ran 7 tests in 0.031s`, `OK`, code de sortie 0. Les captures de commandes restent dans la conversation root ; ce fichier est un relevé, pas un reçu système immuable. Les tests utilisent un callback Git synthétique et des fixtures jetables dans `/private/tmp` ; ils ne prouvent ni Git courant, ni audit UV réel, ni admission G1, ni runtime A/B.
