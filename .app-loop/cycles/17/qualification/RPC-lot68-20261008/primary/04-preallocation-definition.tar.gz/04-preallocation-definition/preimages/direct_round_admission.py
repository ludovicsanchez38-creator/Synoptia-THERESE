"""Lecteur A/B physique et jointures pures, sans admission ou lancement.

Les callbacks de tests sont déclarés synthétiques. Le chemin normal rehash les
références physiques et le checkout ; aucun champ JSON ne prouve une origine
outil ou une identité OS. Cette origine reste root externe et G1 reste fermé.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import re
import stat

ROUND = re.compile(r'therese-(c17-direct-round-([ab])-[0-9a-f]{12})')
AUTHORITY_ROOT = Path('/Users/synoptia/Desktop/Dev Synoptia/Synoptia-THERESE-c15-codex/.app-loop/cycles/17/qualification')
SQL_PARENTS = frozenset(('B1753', 'B1760', 'B1753-power'))
DIRECT_PARENTS = SQL_PARENTS | {'calibrate'}
RUNTIME_ENABLED = False


def need(value, reason):
    if not value:
        raise ValueError(reason)


def identity(root, *, actor, round_id, campaign, expected_head):
    root = Path(root)
    match = ROUND.fullmatch(root.name)
    need(root.is_absolute() and root.parent == Path('/private/tmp') and match is not None
         and match[1] == round_id and match[2].upper() == campaign
         and actor in {'/root', '/root/environment_routes', '/root/native_policy_review'}
         and re.fullmatch(r'[a-f0-9]{40}', expected_head or '') is not None,
         'Identité A/B logique/physique/acteur/HEAD paramétré divergente')
    return {'actor': actor, 'round_id': round_id, 'round_name': campaign,
            'head': expected_head, 'qa_root': str(root)}


def checked_bytes(ref, roots):
    need(type(ref) is dict and set(ref) == {'path', 'sha256', 'bytes'}
         and re.fullmatch(r'[a-f0-9]{64}', ref.get('sha256', '')) is not None
         and type(ref.get('bytes')) is int and ref['bytes'] >= 0, 'Référence SHA/bytes exacte requise')
    path = Path(ref['path'])
    need(path.is_absolute() and not path.is_symlink() and path.resolve(strict=True) == path
         and any(path.is_relative_to(Path(base)) for base in roots), 'Référence physique hors bases exactes')
    with os.fdopen(os.open(path, os.O_RDONLY | os.O_NOFOLLOW), 'rb') as stream:
        before = os.fstat(stream.fileno())
        need(stat.S_ISREG(before.st_mode) and before.st_uid == os.getuid()
             and before.st_size == ref['bytes'], 'Référence non régulière/owner/taille')
        raw = stream.read()
        after = os.fstat(stream.fileno())
    named = path.lstat()
    need((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) ==
         (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns)
         and (named.st_dev, named.st_ino) == (before.st_dev, before.st_ino)
         and len(raw) == ref['bytes'] and hashlib.sha256(raw).hexdigest() == ref['sha256'],
         'Référence changée pendant lecture')
    return raw


def checked_json(ref, roots):
    value = json.loads(checked_bytes(ref, roots))
    need(type(value) is dict, 'Référence JSON non objet')
    return value


def tree_rows(source, raw_tree):
    need(raw_tree and raw_tree.endswith(b'\0'), 'Tree Git raw absent/non NUL terminé')
    result = {}
    for item in raw_tree[:-1].split(b'\0'):
        need(item and b'\t' in item, 'Entrée tree brute malformée')
        left, name = item.split(b'\t', 1)
        pieces = left.decode('ascii').split(' ')
        need(len(pieces) == 3, 'Mode/type/blob tree malformé')
        mode, kind, blob = pieces
        name = name.decode('utf-8', 'strict')
        relative = Path(name)
        need(kind == 'blob' and mode in ('100644', '100755', '120000')
             and re.fullmatch(r'[a-f0-9]{40}', blob) is not None
             and not relative.is_absolute() and relative.parts and str(relative) == name
             and all(part not in ('', '.', '..') for part in relative.parts), 'Entrée tree hors QA')
        path = str(source / relative)
        need(path not in result, 'Tree dupliqué')
        result[path] = (mode, blob)
    return result


def verify_files(source, manifest, raw_tree):
    """Même invariant blobs/modes/liens que le producteur Git, sans subprocess."""
    rows, modes = manifest.get('files'), manifest.get('modes')
    need(type(rows) is list and rows and type(modes) is dict and len(rows) == len(modes),
         'Manifest files/modes incomplet')
    tree = tree_rows(source, raw_tree)
    need(set(modes) == set(tree) and all(modes[path] == tree[path][0] for path in tree),
         'Table modes/manifeste différente du ls-tree root brut')
    seen = set()
    for row in rows:
        need(type(row) is dict and set(row) == {'path', 'sha256', 'bytes', 'git_blob'}, 'Ligne manifest exacte absente')
        path = Path(row['path'])
        need(path.is_absolute() and path.is_relative_to(source) and '..' not in path.parts
             and str(path) not in seen and str(path) in modes, 'Source dupliquée/hors checkout')
        seen.add(str(path))
        mode = modes[str(path)]
        meta = path.lstat()
        need(meta.st_uid == os.getuid(), 'Source autre owner')
        if mode == '120000':
            need(stat.S_ISLNK(meta.st_mode), 'Lien Git absent')
            link = os.readlink(path)
            need(not Path(link).is_absolute() and path.resolve(strict=True).is_relative_to(source), 'Lien Git hors QA')
            raw = os.fsencode(link)
        else:
            need(mode in ('100644', '100755') and stat.S_ISREG(meta.st_mode)
                 and path.resolve(strict=True) == path and bool(meta.st_mode & 0o111) == (mode == '100755'),
                 'Mode/type source Git divergent')
            raw = checked_bytes({key: row[key] for key in ('path', 'sha256', 'bytes')}, (source,))
        blob = hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
        need(type(row['bytes']) is int and len(raw) == row['bytes']
             and hashlib.sha256(raw).hexdigest() == row['sha256']
             and blob == row['git_blob'] == tree[str(path)][1], 'Source/blob Git modifié')
    need(seen == set(tree), 'Couverture manifeste/tree non exacte')


def source_context(root, binding, *, actor, round_id, campaign, expected_head,
                   reader=checked_json, bytes_reader=checked_bytes, files_verifier=verify_files):
    """Refus si les refs config/checkout/manifeste physiques sont absentes.

    Injection réservée aux doubles de tests, jamais une preuve d'OS/fraîcheur.
    G1/core appellent sans callback et recontrôlent avant leurs opérations.
    """
    root = Path(root)
    ident = identity(root, actor=actor, round_id=round_id, campaign=campaign, expected_head=expected_head)
    need(all(binding.get(k) == value for k, value in ident.items()), 'Binding autre identité A/B')
    config_ref, checkout_ref = binding.get('prepared_config_ref'), binding.get('source_checkout_ref')
    need(type(config_ref) is dict and config_ref.get('path') == str(root / 'prepared-config.json')
         and type(checkout_ref) is dict and checkout_ref.get('path') == str(root / 'authorization/source-checkout.json'),
         'Deux refs physiques config/checkout exactes absentes')
    config = reader(config_ref, (root,))
    checkout = reader(checkout_ref, (root,))
    need(config.get('cycle') == 17 and all(config.get(k) == value for k, value in (
        ('actor', actor), ('round_id', round_id), ('campaign', campaign), ('head', expected_head), ('root', str(root))))
        and checkout.get('schema') == 'c17-direct-round-source-checkout-v1'
        and all(checkout.get(k) == value for k, value in ident.items())
        and checkout.get('git_head') == expected_head and checkout.get('git_tree_verified') is True,
        'Config/checkout actuels étrangers')
    source = Path(checkout['product_source_root'])
    need(source.is_absolute() and source.is_relative_to(Path('/private/tmp')) and '..' not in source.parts
         and source.name == 'source' and source.parent.name.startswith('therese-c17-')
         and binding.get('product_source_root') == str(source)
         and binding.get('qa_python') == config.get('python') == str(source / '.venv-conforme/bin/python')
         and config.get('frontend_qa') == str(source / 'src/frontend')
         and config.get('frontend_dependencies') == str(source / 'src/frontend/node_modules')
         and config.get('playwright_dependencies') == str(source / 'node_modules'), 'Chemins checkout/dépendances divergents')
    head_ref = checkout.get('git_head_ref')
    manifest_ref = checkout.get('source_manifest_ref')
    need(type(head_ref) is dict and head_ref.get('path') == str(source / '.git/HEAD')
         and type(manifest_ref) is dict and manifest_ref.get('path') == str(root / 'authorization/source-files.json')
         and binding.get('source_manifest_ref') == manifest_ref, 'Refs HEAD/manifeste exactes absentes')
    need(bytes_reader(head_ref, (source,)) == (expected_head + '\n').encode(), 'HEAD détaché physique différent du paramètre')
    manifest = reader(manifest_ref, (root,))
    need(manifest.get('schema') == 'c17-root-fresh-git-source-manifest-v1' and manifest.get('status') == 'PASS'
         and manifest.get('head') == expected_head and manifest.get('product_source_root') == str(source)
         and manifest.get('git_head_ref') == head_ref and manifest.get('git_tree_verified') is True,
         'Manifeste Git actuel non concordant')
    commit_ref, tree_ref = manifest.get('git_commit_ref'), manifest.get('git_tree_ref')
    need(type(commit_ref) is dict and commit_ref.get('path') == str(root / 'authorization/git-commit.raw')
         and type(tree_ref) is dict and tree_ref.get('path') == str(root / 'authorization/git-tree.raw'), 'Origines Git raw absentes')
    commit = bytes_reader(commit_ref, (root,))
    need(hashlib.sha1(b'commit ' + str(len(commit)).encode() + b'\0' + commit).hexdigest() == expected_head,
         'Objet commit Git ne correspond pas au HEAD attendu')
    tree = bytes_reader(tree_ref, (root,))
    files_verifier(source, manifest, tree)
    rows = {row['path']: row for row in manifest['files']}
    for field in ('product_sources', 'frontend_qa_sources'):
        need(type(config.get(field)) is dict, 'Maps sources config absentes')
        for name, digest in config[field].items():
            need(rows.get(str(source / name), {}).get('sha256') == digest,
                 'Sources config non jointes aux blobs Git physiques')
    need(bytes_reader(head_ref, (source,)) == (expected_head + '\n').encode(), 'HEAD changé pendant rechecks source')
    return {'identity': ident, 'config': config, 'checkout': checkout, 'manifest': manifest,
            'product_source_root': str(source), 'qa_python': binding['qa_python'],
            'prepared_config_ref': config_ref, 'source_checkout_ref': checkout_ref,
            'source_manifest_ref': manifest_ref, 'physical_ref_rechecks_required': True}


def closed_admission(*args, **kwargs):
    raise ValueError('Préparation FULL RPC fermée : aucune admission native créée')
