# Deltas par rapport aux préimages épinglées

- `preimages/calibration_round_producer.py` → `calibration_round_producer.py` : copie byte-exacte, **aucun delta**. `publish_source_checkout` garde toutes ses vérifications et écritures exclusives.
- `preimages/direct_round_admission.py` et `preimages/runtime78_core.py` : témoins du contrat consommateur, inchangés et non importés par les tests.
- `prepare_ab_inputs.py` : **nouvelle définition**, sans prédécesseur modifié. Elle porte seulement l’identité A/B, la lecture du HEAD courant/QA, les contrôles Git/dépendances préallocation et la liaison explicite à `publish_source_checkout` après une config physique.
- `tests/test_prepare_ab_inputs.py` : nouvelles contre-épreuves synthétiques, aucune qualification produit ou OS.
- `SCHEMA.json` et `README.md` : frontière de phase et limites. Aucun fichier de repo, des gels anciens, d’une racine A/B ou de la boucle n’est modifié.
