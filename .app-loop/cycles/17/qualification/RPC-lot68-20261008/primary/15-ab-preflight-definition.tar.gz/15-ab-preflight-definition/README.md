# Préflight A/B strictement préparatoire

Statut : **préparé, non exécuté**. Ce dossier n'est ni une racine de ronde A/B,
ni une décision G1, ni un reçu de calibration. Les quatre préimages sont des
copies byte-exactes, sans correction du producteur historique.

Le wrapper `run_ab_preflight.py` fixe le checkout QA
`/private/tmp/therese-c17-direct-source-F4KirwuR/source` et le HEAD
`19979e8a5ea9bd8e886d35d54793b3d1a560cd77`. Au moment d'une future
exécution autorisée par root, il relit l'INDEX QA épinglé et ses **24 références
physiques**, puis le reçu UV `--frozen --offline --check` à code de sortie zéro.
Il appelle ensuite le préparateur byte-exact avec les audits Python/Node QA et
un callback Git **explicite**. Ce callback est dérivé de `capture-source.py` :
`/Applications/Xcode.app/Contents/Developer/usr/bin/git`, environnement fermé,
45 secondes maximum par appel, code zéro et stderr vide obligatoires. Aucune
branche du wrapper ne laisse utiliser le Git `/usr/bin/git` par défaut du
producteur. Le préparateur vérifie le HEAD actuel du dépôt avant/après, le HEAD
détaché QA, l'objet commit, l'arbre Git, les blobs et modes de tous les fichiers
suivis, ainsi que les métadonnées de dépendances. Le wrapper refait les
24 empreintes et le HEAD actuel avant d'émettre le reçu.

Commande envisagée **uniquement après GO root exact** :

```sh
/Users/synoptia/.local/share/uv/python/cpython-3.13.5-macos-aarch64-none/bin/python3.13 -I -B /private/tmp/therese-c17-ab-preflight-wrapper-wMnJq2/run_ab_preflight.py --preflight --campaign A
```

Pour B, seule la valeur `--campaign B` change. Le nonce est tiré par le
wrapper ; il ne peut pas être réutilisé ou injecté par la CLI. En cas de
succès seulement, le wrapper crée exclusivement
`/private/tmp/therese-c17-ab-preflight-<a|b>-<nonce>/` (mode 0700), avec
`plan.json` et `receipt.json` exclusifs et fsync. Le futur chemin
`/private/tmp/therese-c17-direct-round-<a|b>-<nonce>` doit rester absent.
Le reçu garde le statut `preflight_only_not_admitted`, les références, les
commandes Git observées et les limites. Il ne crée aucune prepared-config,
aucune attestation publiée, aucun `frozen_inputs`, aucune Session et aucune
admission. Le second acteur et la seconde ronde restent à établir ailleurs.

Le contexte d'exécution futur doit rester le sandbox géré existant, avec
lecture du seul dépôt courant, du checkout QA et du Git Xcode ; écriture du
seul reçu privé `/private/tmp`. Aucun nouveau profil Seatbelt ni droit réseau
n'est déduit ici. Cette préparation n'a pas exécuté Git, UV, Node, G1, serveur,
port, navigateur ou produit. Les audits Python/Node/UV déjà présents sont
contrôlés comme preuves historiques du **même** checkout, pas relancés. Le
checkout contient aussi des archives Git historiques comme blobs suivis ; ce
ne sont pas des résultats A/B adoptés.

Contrôle effectué sur ce candidat : 4 tests **statiques** via
`python3 -I -B -m unittest discover -s tests -v`, tous verts. Ils n'importent
ni n'exécutent le wrapper. Les vérifications physiques et l'émission du reçu
restent à réaliser par root sur autorisation séparée.
