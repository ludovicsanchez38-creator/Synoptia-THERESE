#!/usr/bin/env python3
"""Prépare les preuves Git A/B et la demande des six calibrations closes.

Ce module n'ouvre aucune Session ni service. La fonction Git est destinée à
un futur exécuteur root, avant la ronde ; publish_request intervient après le
vrai Session.stop_services. Les autorisations de runtime restent externes.
"""
from __future__ import annotations

import argparse
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess


ROUND = re.compile(r"therese-c17-direct-round-([ab])-[0-9a-f]{12}")
HEX40 = re.compile(r"[0-9a-f]{40}")
HEX64 = re.compile(r"[0-9a-f]{64}")
ACTORS = frozenset({"/root", "/root/cycle17_gate_review", "/root/environment_routes",
                    "/root/native_policy_review"})
AUTHORITY_ROOT = Path(
    "/Users/synoptia/Desktop/Dev Synoptia/Synoptia-THERESE-c15-codex/.app-loop/cycles/17/qualification"
)
RAW = {
    "summary": "runtime/calibration/all-rpc/calibration-summary.json",
    "test_runner": "runtime/calibration/test-runner-rpc/test-runner-controls.json",
    "logs": "runtime/calibration/logs-rpc/logs-controls.json",
    "browser": "runtime/calibration/browser-rpc/browser-controls.json",
    "screen_coverage": "runtime/calibration/screen-rpc/screen-controls.json",
}


def need(value: bool, reason: str) -> None:
    if not value:
        raise ValueError(reason)


def sha256(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def git_object(kind: str, value: bytes) -> str:
    return hashlib.sha1(kind.encode() + b" " + str(len(value)).encode() + b"\0" + value).hexdigest()


def reference(path: Path) -> dict:
    payload = path.read_bytes()
    return {"path": str(path), "sha256": sha256(payload), "bytes": len(payload)}


def regular(path: Path, roots: tuple[Path, ...]) -> Path:
    need(path.is_absolute() and path.resolve(strict=True) == path
         and any(path.is_relative_to(root) for root in roots),
         "Référence hors racines canoniques admises")
    meta = path.lstat()
    need(stat.S_ISREG(meta.st_mode) and meta.st_uid == os.getuid(),
         "Référence non régulière ou autre owner")
    return path


def checked(reference_value: dict, roots: tuple[Path, ...], *, exact: Path | None = None) -> Path:
    need(isinstance(reference_value, dict)
         and isinstance(reference_value.get("path"), str)
         and HEX64.fullmatch(reference_value.get("sha256", "")) is not None,
         "Référence SHA invalide")
    path = regular(Path(reference_value["path"]), roots)
    need(exact is None or path == exact, "Chemin de référence différent")
    payload = path.read_bytes()
    need(sha256(payload) == reference_value["sha256"]
         and ("bytes" not in reference_value or reference_value["bytes"] == len(payload)),
         "Référence SHA/taille différente")
    return path


def read_json(reference_value: dict, roots: tuple[Path, ...], *, exact: Path | None = None) -> dict:
    value = json.loads(checked(reference_value, roots, exact=exact).read_text(encoding="utf-8"))
    need(isinstance(value, dict), "Référence JSON non objet")
    return value


def round_identity(root: Path, config: dict, expected_head: str) -> tuple[str, str, str]:
    need(root.is_absolute() and root.parent == Path("/private/tmp")
         and ROUND.fullmatch(root.name) is not None and root.resolve(strict=True) == root
         and root.is_dir() and not root.is_symlink(), "Racine A/B physique différente")
    meta = root.lstat()
    need(meta.st_uid == os.getuid() and stat.S_IMODE(meta.st_mode) & 0o077 == 0,
         "Racine A/B non privée/possédée")
    need(isinstance(expected_head, str) and HEX40.fullmatch(expected_head) is not None,
         "HEAD attendu invalide")
    campaign = ROUND.fullmatch(root.name)[1].upper()
    logical_round = root.name.removeprefix("therese-")
    need(config.get("root") == str(root) and config.get("round_id") == logical_round
         and config.get("campaign") == campaign and config.get("head") == expected_head
         and config.get("cycle") == 17 and config.get("actor") in ACTORS,
         "Config/acteur/round/HEAD A-B discordants")
    return config["actor"], logical_round, campaign


def git_capture(source: Path, argv: list[str]) -> bytes:
    """Commandes Git en lecture seule, à invoquer seulement par l'exécuteur root futur."""
    need(argv and argv[0] in ("rev-parse", "cat-file", "ls-tree"), "Commande Git hors inventaire")
    proc = subprocess.run(["/usr/bin/git", "-C", str(source), *argv],
                          cwd=source, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                          timeout=45, check=False,
                          env={"PATH": "/usr/bin:/bin", "LANG": "C", "LC_ALL": "C",
                               "GIT_CONFIG_NOSYSTEM": "1", "GIT_CONFIG_GLOBAL": "/dev/null",
                               "GIT_OPTIONAL_LOCKS": "0"})
    need(proc.returncode == 0 and proc.stderr == b"", "Capture Git rouge/non silencieuse")
    return proc.stdout


def source_rows(source: Path, raw_tree: bytes) -> tuple[list[dict], dict[str, str], list[dict]]:
    need(raw_tree and raw_tree.endswith(b"\0"), "ls-tree brut vide/non NUL terminé")
    files: list[dict] = []
    modes: dict[str, str] = {}
    symlinks: list[dict] = []
    for item in raw_tree[:-1].split(b"\0"):
        need(item and b"\t" in item, "Entrée Git brute malformée")
        left, raw_name = item.split(b"\t", 1)
        pieces = left.decode("ascii").split(" ")
        need(len(pieces) == 3, "Mode/type/blob Git malformé")
        mode, kind, blob = pieces
        name = raw_name.decode("utf-8", "strict")
        parts = Path(name).parts
        need(kind == "blob" and HEX40.fullmatch(blob) is not None
             and mode in ("100644", "100755", "120000")
             and not Path(name).is_absolute() and parts and str(Path(name)) == name
             and all(p not in ("", ".", "..") for p in parts),
             "Entrée Git hors checkout ou type interdit")
        target = source / name
        need(target.is_relative_to(source) and str(target) not in modes,
             "Fichier Git dupliqué/hors source")
        meta = target.lstat()
        need(meta.st_uid == os.getuid(), "Fichier Git autre owner")
        if mode == "120000":
            need(stat.S_ISLNK(meta.st_mode), "Symlink Git absent")
            link = os.readlink(target)
            resolved = target.resolve(strict=True)
            need(not Path(link).is_absolute() and resolved.is_relative_to(source),
                 "Symlink Git hors QA")
            payload = os.fsencode(link)
            symlinks.append({"path": str(target), "link": link})
        else:
            regular(target, (source,))
            need(bool(meta.st_mode & 0o111) == (mode == "100755"),
                 "Mode exécutable Git différent")
            payload = target.read_bytes()
        need(git_object("blob", payload) == blob, "Blob Git différent : " + name)
        files.append({"path": str(target), "sha256": sha256(payload),
                      "bytes": len(payload), "git_blob": blob})
        modes[str(target)] = mode
    need(bool(files), "Arbre Git vide")
    return files, modes, symlinks


def source_identity(source: Path) -> None:
    need(source.is_absolute() and source.resolve(strict=True) == source and source.is_dir()
         and source.is_relative_to(Path("/private/tmp"))
         and source.name == "source" and source.parent.name.startswith("therese-c17-"),
         "Checkout QA non canonique/frais")
    for path in (source, source.parent):
        need(path.lstat().st_uid == os.getuid(), "Checkout QA autre owner")
    need(stat.S_IMODE(source.parent.lstat().st_mode) & 0o077 == 0,
         "Parent checkout QA non privé")


def verified_source_payload(source: Path, expected_head: str, *, capture=git_capture) -> tuple[dict, bytes, bytes]:
    source_identity(source)
    head_path = regular(source / ".git/HEAD", (source,))
    head_bytes = head_path.read_bytes()
    need(head_bytes == (expected_head + "\n").encode(), "HEAD détaché physique différent")
    observed = capture(source, ["rev-parse", "--verify", "HEAD"])
    need(observed == head_bytes, "Git rev-parse HEAD différent du paramètre physique")
    commit_raw = capture(source, ["cat-file", "commit", expected_head])
    need(git_object("commit", commit_raw) == expected_head, "Objet commit Git différent")
    tree_raw = capture(source, ["ls-tree", "-r", "-z", expected_head])
    files, modes, symlinks = source_rows(source, tree_raw)
    need(capture(source, ["rev-parse", "--verify", "HEAD"]) == head_bytes
         and head_path.read_bytes() == head_bytes,
         "HEAD Git changé pendant vérification des blobs")
    manifest = {"schema": "c17-root-fresh-git-source-manifest-v1", "status": "PASS",
                "head": expected_head, "product_source_root": str(source),
                "git_tree_verified": True, "files": files, "modes": modes,
                "symlinks": symlinks,
                "method": "detached HEAD plus root Git rev-parse/cat-file/ls-tree and byte/mode verification",
                "limits": ["No product runtime result", "No inherited A/B qualification"]}
    return manifest, tree_raw, commit_raw


def verify_manifest_files(source: Path, manifest: dict) -> None:
    rows, modes = manifest.get("files"), manifest.get("modes")
    need(isinstance(rows, list) and bool(rows) and isinstance(modes, dict)
         and len(rows) == len(modes), "Manifest Git sans table de modes complète")
    seen: set[str] = set()
    for row in rows:
        need(isinstance(row, dict) and set(row) == {"path", "sha256", "bytes", "git_blob"},
             "Ligne manifest Git incomplète")
        name = row["path"]
        need(isinstance(name, str) and name not in seen and name in modes,
             "Chemin Git dupliqué/sans mode")
        seen.add(name)
        path = Path(name)
        need(path.is_absolute() and path.is_relative_to(source), "Fichier Git hors QA")
        meta = path.lstat()
        need(meta.st_uid == os.getuid(), "Fichier Git autre owner")
        mode = modes[name]
        if mode == "120000":
            need(stat.S_ISLNK(meta.st_mode), "Symlink Git disparu")
            link = os.readlink(path)
            need(not Path(link).is_absolute() and path.resolve(strict=True).is_relative_to(source),
                 "Symlink Git sorti de QA")
            data = os.fsencode(link)
        else:
            need(mode in ("100644", "100755"), "Mode Git non admis")
            regular(path, (source,))
            need(bool(meta.st_mode & 0o111) == (mode == "100755"),
                 "Mode exécutable Git changé")
            data = path.read_bytes()
        need(row["sha256"] == sha256(data) and row["bytes"] == len(data)
             and row["git_blob"] == git_object("blob", data),
             "Fichier Git changé depuis l'attestation : " + name)


def write_new(path: Path, payload: bytes) -> None:
    fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, "wb") as stream:
        stream.write(payload)
        stream.flush()
        os.fsync(stream.fileno())


def json_bytes(value: dict) -> bytes:
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def publish_source_checkout(root: Path, source: Path, expected_head: str,
                            config_ref: dict, *, capture=git_capture) -> dict:
    config = read_json(config_ref, (root,), exact=root / "prepared-config.json")
    actor, round_id, campaign = round_identity(root, config, expected_head)
    need(config.get("python") == str(source / ".venv-conforme/bin/python")
         and config.get("frontend_qa") == str(source / "src/frontend")
         and config.get("frontend_dependencies") == str(source / "src/frontend/node_modules")
         and config.get("playwright_dependencies") == str(source / "node_modules"),
         "Configuration autre checkout QA")
    manifest, tree_raw, commit_raw = verified_source_payload(source, expected_head, capture=capture)
    rows = {row["path"]: row for row in manifest["files"]}
    for field in ("product_sources", "frontend_qa_sources"):
        need(isinstance(config.get(field), dict), "Sources config absentes : " + field)
        for name, digest in config[field].items():
            row = rows.get(str(source / name))
            need(row is not None and row["sha256"] == digest,
                 "Source préparée différente du Git QA : " + name)
    auth = root / "authorization"
    need(auth.is_dir() and auth.resolve(strict=True) == auth and auth.lstat().st_uid == os.getuid(),
         "Dossier d'autorisation QA absent/non possédé")
    targets = [auth / name for name in ("git-tree.raw", "git-commit.raw", "source-files.json", "source-checkout.json")]
    need(all(not path.exists() and not path.is_symlink() for path in targets),
         "Attestation Git A/B déjà émise : aucun remplacement")
    write_new(targets[0], tree_raw)
    write_new(targets[1], commit_raw)
    manifest |= {"git_tree_ref": reference(targets[0]),
                 "git_commit_ref": reference(targets[1]),
                 "git_head_ref": reference(source / ".git/HEAD")}
    write_new(targets[2], json_bytes(manifest))
    checkout = {"schema": "c17-direct-round-source-checkout-v1",
                "actor": actor, "round_id": round_id, "head": expected_head,
                "qa_root": str(root), "round_name": campaign,
                "git_head": expected_head, "product_source_root": str(source),
                "git_tree_verified": True, "git_head_ref": reference(source / ".git/HEAD"),
                "source_manifest_ref": reference(targets[2])}
    need(regular(source / ".git/HEAD", (source,)).read_bytes() == (expected_head + "\n").encode(),
         "HEAD changé avant publication finale")
    verify_manifest_files(source, manifest)
    write_new(targets[3], json_bytes(checkout))
    return reference(targets[3])


def iso(value: str) -> datetime:
    stamp = datetime.fromisoformat(value.replace("Z", "+00:00"))
    need(stamp.tzinfo is not None, "Horodatage sans fuseau")
    return stamp


def request_payload(root: Path, config_ref: dict, checkout_ref: dict,
                    successor_ref: dict, session_ref: dict, binding_ref: dict,
                    stop_ref: dict) -> dict:
    config = read_json(config_ref, (root,), exact=root / "prepared-config.json")
    actor, round_id, campaign = round_identity(root, config, config["head"])
    checkout = read_json(checkout_ref, (root,), exact=root / "authorization/source-checkout.json")
    need(all(checkout.get(key) == expected for key, expected in (
        ("actor", actor), ("round_id", round_id), ("head", config["head"]),
        ("qa_root", str(root)), ("round_name", campaign)))
        and checkout.get("schema") == "c17-direct-round-source-checkout-v1"
        and checkout.get("git_tree_verified") is True,
        "Attestation Git A/B autre ronde/HEAD")
    source = Path(checkout["product_source_root"])
    source_identity(source)
    checked(checkout["git_head_ref"], (source,), exact=source / ".git/HEAD")
    need((source / ".git/HEAD").read_text().strip() == config["head"],
         "HEAD physique changé avant demande")
    manifest = read_json(checkout["source_manifest_ref"], (root,),
                         exact=root / "authorization/source-files.json")
    need(manifest.get("schema") == "c17-root-fresh-git-source-manifest-v1"
         and manifest.get("status") == "PASS" and manifest.get("head") == config["head"]
         and manifest.get("product_source_root") == str(source)
         and manifest.get("git_tree_verified") is True,
         "Manifest Git A/B non concordant")
    need(manifest.get("git_head_ref") == checkout["git_head_ref"],
         "Ref HEAD attestation/manifest différente")
    commit_raw = checked(manifest["git_commit_ref"], (root,),
                         exact=root / "authorization/git-commit.raw").read_bytes()
    checked(manifest["git_tree_ref"], (root,), exact=root / "authorization/git-tree.raw")
    need(git_object("commit", commit_raw) == config["head"],
         "Objet commit attestation/HEAD différent")
    verify_manifest_files(source, manifest)
    refs = {key: value for key, value in (("successor", successor_ref),
            ("admission", session_ref), ("binding", binding_ref))}
    successor, session, binding = (read_json(refs[key], (AUTHORITY_ROOT,))
                                   for key in ("successor", "admission", "binding"))
    need(successor.get("schema") == "c17-runtime78-successor-admission-v1"
         and successor.get("provided_by") == "/root" and successor.get("phase") == "runtime"
         and session.get("schema") == "c17-runtime78-session-root-go-v1"
         and binding.get("schema") == "c17-runtime78-session-binding-v1"
         and successor.get("session_decision") == session_ref
         and successor.get("session_binding") == binding_ref
         and session.get("binding") == binding_ref,
         "Autorité G1 externe non liée")
    for body in (successor, session, binding):
        need(all(body.get(key) == expected for key, expected in (
            ("actor", actor), ("round_id", round_id), ("head", config["head"]),
            ("qa_root", str(root)), ("round_name", campaign))),
            "Autorité G1 autre ronde")
    executions = {name: reference(root / "ledger" / folder / "execution.json") for name, folder in
                  (("start", "start-runtime"), ("calibrate", "calibrate"), ("stop", "stop-runtime"))}
    need(isinstance(stop_ref, dict)
         and all(executions["stop"].get(key) == stop_ref.get(key)
                 for key in ("path", "sha256"))
         and ("bytes" not in stop_ref or stop_ref["bytes"] == executions["stop"]["bytes"]),
         "Arrêt Session différent de la demande")
    start, calibrate, stopped = (read_json(executions[key], (root,))
                                 for key in ("start", "calibrate", "stop"))
    need(all(item.get("actor") == actor and item.get("round_id") == round_id
             and item.get("head") == config["head"] and item.get("exit_code") == 0
             and item.get("instrument_error") is None for item in (start, calibrate, stopped))
         and stopped.get("kind") == "in_process_owned_phase"
         and stopped.get("operation") == "stop-runtime"
         and iso(start["completed_at"]) <= iso(calibrate["started_at"])
         <= iso(calibrate["completed_at"]) <= iso(stopped["started_at"])
         <= iso(stopped["completed_at"]),
         "Stage/arrêt non clos dans l'ordre A/B")
    running_ref = reference(root / "runtime/pile-reprise-running-preserved.json")
    stopped_ref = reference(root / "runtime/pile-reprise.json")
    running, stopped_stack = (read_json(row, (root,)) for row in (running_ref, stopped_ref))
    need(running.get("status") == "running" and stopped_stack.get("status") == "stopped"
         and running.get("head_at_start") == stopped_stack.get("head_at_start") == config["head"],
         "Pile réelle non close avant demande")
    raw_results = {key: reference(root / rel) for key, rel in RAW.items()}
    return {"schema": "c17-calibration-builder-request-v2", "root": str(root),
            "actor": actor, "round_id": round_id, "head": config["head"],
            "qa_source": str(source), "executions": executions,
            "round_sources": {"configuration": config_ref, "running_manifest": running_ref,
                              "stopped_manifest": stopped_ref, "source_checkout": checkout_ref},
            "g1_authority": refs, "raw_results": raw_results}


def publish_request(root: Path, config_ref: dict, checkout_ref: dict,
                    successor_ref: dict, session_ref: dict, binding_ref: dict,
                    stop_ref: dict) -> dict:
    payload = request_payload(root, config_ref, checkout_ref, successor_ref,
                              session_ref, binding_ref, stop_ref)
    target = root / "authorization/calibration-builder-request.json"
    need(not target.exists() and not target.is_symlink(), "Demande déjà émise")
    write_new(target, json_bytes(payload))
    return reference(target)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--round-root", required=True, type=Path)
    parser.add_argument("--qa-source", required=True, type=Path)
    parser.add_argument("--expected-head", required=True)
    parser.add_argument("--config-sha256", required=True)
    args = parser.parse_args()
    root = args.round_root
    result = publish_source_checkout(root, args.qa_source, args.expected_head,
        {"path": str(root / "prepared-config.json"), "sha256": args.config_sha256})
    print(json.dumps({"status": "source_checkout_prepared_not_runtime_qualified",
                      "source_checkout": result}, ensure_ascii=False))


if __name__ == "__main__":
    main()
