#!/usr/bin/env python3
"""Préflight A/B avant allocation, puis attestation Git après préparation.

Aucune fonction de ce module ne démarre une Session ou n'accorde une admission.
`preflight` lit le checkout QA et ses dépendances avant qu'une racine de ronde
existe. `attest_prepared_root` ne publie que les quatre objets Git du producteur
déjà gelé, après émission externe d'une vraie prepared-config.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import re
import stat
from typing import Callable

import calibration_round_producer as producer


PRODUCER_SHA256 = "70be1e802b35fc067492f684e70e93b4990dabbb669a70e0d1303be4b90c6f85"
NONCE = re.compile(r"[0-9a-f]{12}")
HEAD = re.compile(r"[0-9a-f]{40}")
REQUIRED_FRONTEND = ("vite", "@vitejs/plugin-react", "@tailwindcss/vite", "vitest", "react", "react-dom")
REQUIRED_ROOT = ("playwright", "playwright-core")
CURRENT_REPOSITORY = Path("/Users/synoptia/Desktop/Dev Synoptia/Synoptia-THERESE-c15-codex")


def need(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def ref(path: Path) -> dict[str, object]:
    data = path.read_bytes()
    return {"path": str(path), "sha256": sha(data), "bytes": len(data)}


def checked_ref(value: dict, *, exact: Path, under: Path) -> bytes:
    need(type(value) is dict and set(value) == {"path", "sha256", "bytes"}
         and value.get("path") == str(exact) and type(value.get("bytes")) is int
         and re.fullmatch(r"[0-9a-f]{64}", value.get("sha256", "")) is not None,
         "Référence physique/SHA/taille incomplète")
    need(exact.is_absolute() and exact.is_relative_to(under)
         and exact.resolve(strict=True) == exact, "Référence non canonique ou hors QA")
    meta = exact.lstat()
    need(stat.S_ISREG(meta.st_mode) and meta.st_uid == os.getuid(),
         "Référence non régulière ou autre UID")
    raw = exact.read_bytes()
    need(len(raw) == value["bytes"] and sha(raw) == value["sha256"],
         "Octets de référence divergents")
    return raw


def identity(campaign: str, nonce: str) -> dict[str, str]:
    need(campaign in ("A", "B") and isinstance(nonce, str)
         and NONCE.fullmatch(nonce) is not None, "Campagne/nonce root exacts requis")
    logical = f"c17-direct-round-{campaign.lower()}-{nonce}"
    return {"actor": "/root", "campaign": campaign, "round_id": logical,
            "root": str(Path("/private/tmp") / f"therese-{logical}")}


def source_head(source: Path, expected_head: str) -> dict[str, object]:
    """Lit le HEAD réellement détaché du checkout QA, pas celui d'un vieux reçu."""
    need(isinstance(expected_head, str) and HEAD.fullmatch(expected_head) is not None,
         "HEAD root attendu invalide")
    producer.source_identity(source)
    need(source.parent.name.startswith("therese-c17-direct-source-"),
         "Source A/B neuve distincte des anciens WRAPPER exigée")
    path = producer.regular(source / ".git/HEAD", (source,))
    raw = path.read_bytes()
    need(raw == (expected_head + "\n").encode("ascii"),
         "HEAD physique détaché différent du HEAD root demandé")
    return ref(path)


def audit_python(source: Path, expected_head: str, proof_ref: dict) -> dict:
    proof_path = source.parent / "proofs/python-metadata-result.json"
    audit = json.loads(checked_ref(proof_ref, exact=proof_path, under=source.parent))
    python = source / ".venv-conforme/bin/python"
    need(audit.get("schema") == "c17-fresh-python-metadata-audit-v1"
         and audit.get("status") == "PASS" and audit.get("qa_source") == str(source)
         and audit.get("head") == expected_head and audit.get("qa_python") == str(python)
         and audit.get("mismatches") == [] and audit.get("graph_check_exit_observed_by_root") == 0,
         "Audit Python frais QA/HEAD non concordant")
    need(python.is_file() and os.access(python, os.X_OK)
         and (source / ".venv-conforme/pyvenv.cfg").is_file(),
         "Venv QA absent/non exécutable")
    packages = audit.get("packages")
    need(type(packages) is list and packages and audit.get("installed_count") == len(packages),
         "Décompte Python non relié aux distributions")
    site = source / ".venv-conforme/lib/python3.13/site-packages"
    for item in packages:
        path = Path(item.get("metadata_path", ""))
        need(path.is_absolute() and path.is_relative_to(site)
             and path.is_dir() and path.resolve(strict=True) == path,
             "Distribution Python hors venv QA")
    checked_ref(audit["lock"], exact=source / "uv.lock", under=source)
    for item in audit.get("pth", []):
        path = Path(item.get("path", ""))
        checked_ref(item, exact=path, under=site)
    for name in ("uv_graph_check_stdout", "uv_graph_check_stderr"):
        item = audit[name]
        checked_ref(item, exact=Path(item["path"]), under=source.parent / "proofs")
    return {"audit_ref": proof_ref, "qa_python": str(python),
            "distribution_count": len(packages), "lock_ref": audit["lock"]}


def node_versions(lock_path: Path, modules: Path, required: tuple[str, ...]) -> dict:
    lock = json.loads(lock_path.read_text(encoding="utf-8"))
    entries = lock.get("packages")
    need(type(entries) is dict, "Lock Node sans packages")
    observed = {}
    for entry, row in entries.items():
        if not entry.startswith("node_modules/") or not isinstance(row, dict) or not row.get("version"):
            continue
        package = modules / entry.removeprefix("node_modules/") / "package.json"
        if not package.is_file():
            need(row.get("optional") is True, "Package requis du lock absent : " + entry)
            continue
        need(package.resolve(strict=True).is_relative_to(modules),
             "Package Node résolu hors QA")
        actual = json.loads(package.read_text(encoding="utf-8"))
        need(actual.get("version") == row["version"], "Version Node différente du lock : " + entry)
        observed[entry] = {"version": row["version"], "sha256": sha(package.read_bytes())}
    need(all("node_modules/" + name in observed for name in required),
         "Paquet Node nécessaire absent")
    return observed


def audit_node(source: Path, expected_head: str, proof_ref: dict) -> dict:
    proof_path = source.parent / "proofs/node-metadata-result.json"
    audit = json.loads(checked_ref(proof_ref, exact=proof_path, under=source.parent))
    need(audit.get("schema") == "c17-fresh-node-metadata-audit-v1"
         and audit.get("status") == "PASS" and audit.get("head") == expected_head
         and type(audit.get("proofs")) is list and len(audit["proofs"]) == 2,
         "Audit Node frais QA/HEAD non concordant")
    root_lock = source / "package-lock.json"
    front_lock = source / "src/frontend/package-lock.json"
    root_rows = node_versions(root_lock, source / "node_modules", REQUIRED_ROOT)
    front_rows = node_versions(front_lock, source / "src/frontend/node_modules", REQUIRED_FRONTEND)
    expected = ((source, root_lock, root_rows),
                (source / "src/frontend", front_lock, front_rows))
    for proof, (folder, lock, observed) in zip(audit["proofs"], expected, strict=True):
        need(proof.get("root") == str(folder) and proof.get("lock_sha256") == sha(lock.read_bytes())
             and proof.get("mismatches") == [] and proof.get("installed") == len(observed),
             "Audit Node différent des packages physiques/lock")
    return {"audit_ref": proof_ref, "frontend_dep_versions": front_rows,
            "playwright_dep_versions": root_rows,
            "lock_refs": [ref(root_lock), ref(front_lock)]}


def preflight(source: Path, *, campaign: str, nonce: str, expected_head: str,
              python_audit_ref: dict, node_audit_ref: dict,
              capture: Callable = producer.git_capture,
              current_repository: Path = CURRENT_REPOSITORY,
              root_allocated: bool = False) -> dict:
    """Préallocation : aucune création de racine ni émission d'une décision."""
    ident = identity(campaign, nonce)
    root = Path(ident["root"])
    if root_allocated:
        need(root.is_dir() and root.resolve(strict=True) == root
             and not root.is_symlink() and root.lstat().st_uid == os.getuid()
             and stat.S_IMODE(root.lstat().st_mode) & 0o077 == 0,
             "Racine A/B après allocation absente/non privée")
    else:
        need(not root.exists() and not root.is_symlink(), "Racine A/B déjà allouée")
    need(current_repository.is_absolute() and current_repository.is_dir()
         and current_repository.resolve(strict=True) == current_repository,
         "Dépôt courant physique non canonique")
    current_head = capture(current_repository, ["rev-parse", "--verify", "HEAD"])
    need(current_head == (expected_head + "\n").encode("ascii"),
         "HEAD du dépôt courant différent du HEAD root demandé")
    head_ref = source_head(source, expected_head)
    need(sha(Path(producer.__file__).read_bytes()) == PRODUCER_SHA256,
         "Producteur Git différent de la préimage byte-exacte")
    manifest, tree_raw, commit_raw = producer.verified_source_payload(
        source, expected_head, capture=capture)
    py = audit_python(source, expected_head, python_audit_ref)
    node = audit_node(source, expected_head, node_audit_ref)
    rows = {str(Path(row["path"]).relative_to(source)): row["sha256"] for row in manifest["files"]}
    product = {name: digest for name, digest in rows.items()
               if name.startswith(("src/", "scripts/", "tests/"))}
    frontend = {name: digest for name, digest in product.items()
                if name.startswith("src/frontend/")
                and not name.startswith("src/frontend/src-tauri/")}
    need(product and frontend, "Cartographie source/FRONT vide")
    source_head(source, expected_head)
    need(capture(current_repository, ["rev-parse", "--verify", "HEAD"]) == current_head,
         "HEAD du dépôt courant changé pendant le préflight")
    return {"schema": "c17-ab-preallocation-plan-v1", "status": "preflight_only_not_admitted",
            **ident, "head": expected_head, "product_source_root": str(source),
            "current_repository": str(current_repository),
            "current_head_capture_sha256": sha(current_head),
            "head_ref": head_ref, "python_audit": py, "node_audit": node,
            "git_preview": {"file_count": len(manifest["files"]),
                            "manifest_sha256": sha(producer.json_bytes(manifest)),
                            "tree_sha256": sha(tree_raw), "commit_sha256": sha(commit_raw)},
            "config_fields": {"cycle": 17, "actor": "/root", "campaign": campaign,
                              "round_id": ident["round_id"], "head": expected_head,
                              "root": str(root), "repo": str(source),
                              "python": str(source / ".venv-conforme/bin/python"),
                              "frontend_qa": str(source / "src/frontend"),
                              "frontend_dependencies": str(source / "src/frontend/node_modules"),
                              "playwright_dependencies": str(source / "node_modules"),
                              "product_sources": product, "frontend_qa_sources": frontend,
                              "frontend_dep_versions": node["frontend_dep_versions"],
                              "playwright_dep_versions": node["playwright_dep_versions"]},
            "not_proved": ["A/B source checkout is not yet published",
                           "No Session, admission, calibration, or product result",
                           "Second actor and independent B round remain required"]}


def attest_prepared_root(plan: dict, config_ref: dict, *,
                         capture: Callable = producer.git_capture) -> dict:
    """Publication Git seule, après config/authorization préparées par root.

    La préallocation et les audits sont refaits avant l'appel au producteur
    byte-exact. Ce helper ne crée ni binding ni entrée `frozen_inputs`.
    """
    need(type(plan) is dict and plan.get("schema") == "c17-ab-preallocation-plan-v1"
         and plan.get("status") == "preflight_only_not_admitted",
         "Plan A/B absent/non préparatoire")
    source = Path(plan["product_source_root"])
    root = Path(plan["root"])
    refreshed = preflight(source, campaign=plan["campaign"],
                          nonce=plan["round_id"].rsplit("-", 1)[1],
                          expected_head=plan["head"],
                          python_audit_ref=plan["python_audit"]["audit_ref"],
                          node_audit_ref=plan["node_audit"]["audit_ref"],
                          capture=capture,
                          current_repository=Path(plan["current_repository"]),
                          root_allocated=True)
    need(refreshed == plan, "Checkout/dépendances/Git changés depuis préallocation")
    config = producer.read_json(config_ref, (root,), exact=root / "prepared-config.json")
    need(all(config.get(key) == value for key, value in plan["config_fields"].items()),
         "Prepared-config physique différente des entrées préallouées")
    need(config.get("browser_cache") == str(root / "profiles/browser-cache")
         and "session_contract" not in config
         and "nested_capture_contract" not in config,
         "Préparation préalable différente ou admission déjà injectée")
    return producer.publish_source_checkout(root, source, plan["head"], config_ref,
                                            capture=capture)
