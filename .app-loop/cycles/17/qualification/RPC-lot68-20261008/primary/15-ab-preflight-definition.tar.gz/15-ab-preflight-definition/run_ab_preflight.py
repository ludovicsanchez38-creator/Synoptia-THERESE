#!/usr/bin/env python3
"""Préflight A/B seul : aucune allocation de ronde ni admission.

Ce wrapper est destiné à l'exécuteur root après une décision distincte. Il
réutilise les trois sources épinglées et passe toujours le callback Git Xcode
explicite. Le module n'ouvre aucun service et n'importe pas le produit.
"""
from __future__ import annotations

import argparse
from datetime import UTC, datetime
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import stat
import sys
from types import ModuleType


HERE = Path(__file__).resolve().parent
QA_ROOT = Path("/private/tmp/therese-c17-direct-source-F4KirwuR")
SOURCE = QA_ROOT / "source"
PROOFS = QA_ROOT / "proofs"
REPOSITORY = Path("/Users/synoptia/Desktop/Dev Synoptia/Synoptia-THERESE-c15-codex")
HEAD = "19979e8a5ea9bd8e886d35d54793b3d1a560cd77"
INDEX_SHA = "b3f54844903c90cfa3bdfe1b711a7ccb522ba3d8c2004f1e549e11c6c22fecb9"
SOURCES = {
    "producer": (Path("/private/tmp/therese-c17-ab-preallocation-juPxhwe2/calibration_round_producer.py"),
                 "70be1e802b35fc067492f684e70e93b4990dabbb669a70e0d1303be4b90c6f85"),
    "preallocator": (Path("/private/tmp/therese-c17-ab-preallocation-juPxhwe2/prepare_ab_inputs.py"),
                     "7d4227253d7ca92d6905ccf4e4caca4500528d785d6a1a55a353ad39ce02a23d"),
    "git_capture": (PROOFS / "capture-source.py",
                    "d9f3be62141164cc64e3e14ae247512567c71467d95f55f4b75493d08afa37d7"),
}
SHA64 = re.compile(r"[0-9a-f]{64}\Z")


def need(ok: bool, message: str) -> None:
    if not ok:
        raise ValueError(message)


def digest(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def read_exact(path: Path, expected_sha: str, *, under: Path, max_bytes: int = 2_000_000) -> bytes:
    """Relit un fichier épinglé, canonique, régulier et du même UID."""
    need(path.is_absolute() and path.is_relative_to(under)
         and path.resolve(strict=True) == path, "Chemin non canonique/hors périmètre : " + str(path))
    flags = os.O_RDONLY | os.O_NOFOLLOW | getattr(os, "O_CLOEXEC", 0)
    fd = os.open(path, flags)
    try:
        meta = os.fstat(fd)
        need(stat.S_ISREG(meta.st_mode) and meta.st_uid == os.getuid()
             and 0 <= meta.st_size <= max_bytes, "Fichier non régulier/UID/taille : " + str(path))
        with os.fdopen(fd, "rb", closefd=False) as stream:
            raw = stream.read(max_bytes + 1)
        need(len(raw) == meta.st_size and digest(raw) == expected_sha,
             "Référence SHA/taille différente : " + str(path))
        return raw
    finally:
        os.close(fd)


def reference(path: Path, raw: bytes) -> dict[str, object]:
    return {"path": str(path), "sha256": digest(raw), "bytes": len(raw)}


def verify_source_index() -> tuple[dict, dict[str, dict]]:
    index_path = PROOFS / "INDEX.json"
    index_raw = read_exact(index_path, INDEX_SHA, under=QA_ROOT)
    index = json.loads(index_raw)
    need(index.get("schema") == "c17-direct-fresh-source-preparation-index-v1"
         and index.get("status") == "prepared_source_only"
         and index.get("qa_root") == str(QA_ROOT)
         and index.get("qa_source") == str(SOURCE)
         and index.get("repository") == str(REPOSITORY)
         and index.get("head_at_capture_and_final_audit") == HEAD
         and index.get("tracked_files") == 3586,
         "INDEX QA frais ne correspond pas au checkout et HEAD attendus")
    rows = index.get("selected_refs")
    need(type(rows) is list and len(rows) == 24, "Les 24 références QA ne sont pas présentes")
    selected: dict[str, dict] = {}
    for item in rows:
        need(type(item) is dict and set(item) == {"path", "sha256", "bytes"}
             and type(item["path"]) is str and type(item["sha256"]) is str
             and SHA64.fullmatch(item["sha256"]) is not None
             and type(item["bytes"]) is int and item["bytes"] >= 0,
             "Ligne INDEX QA invalide")
        path = Path(item["path"])
        need(str(path) not in selected, "Référence QA dupliquée")
        raw = read_exact(path, item["sha256"], under=QA_ROOT)
        need(len(raw) == item["bytes"], "Taille d'une référence QA divergente")
        selected[str(path)] = item
    need(str(PROOFS / "capture-source.py") in selected
         and str(PROOFS / "uv-graph-check-receipt.json") in selected
         and str(PROOFS / "python-metadata-result.json") in selected
         and str(PROOFS / "node-metadata-result.json") in selected
         and str(SOURCE / ".git/HEAD") in selected,
         "Références obligatoires QA manquantes")
    return index, selected


def verify_uv_receipt(selected: dict[str, dict]) -> dict:
    path = PROOFS / "uv-graph-check-receipt.json"
    row = selected[str(path)]
    audit = json.loads(read_exact(path, row["sha256"], under=QA_ROOT))
    argv = audit.get("argv")
    need(audit.get("schema") == "c17-direct-source-uv-frozen-check-v1"
         and audit.get("source") == str(SOURCE) and audit.get("cwd") == str(SOURCE)
         and audit.get("head") == HEAD and audit.get("exit_code") == 0
         and audit.get("no_product_import") is True
         and audit.get("runtime_started") is False
         and type(argv) is list and len(argv) == 11
         and argv[:2] == ["/opt/homebrew/bin/uv", "sync"]
         and argv[2:9] == ["--frozen", "--offline", "--check", "--dev",
                          "--no-install-project", "--no-build", "--python"]
         and argv[10:] == ["--no-python-downloads"],
         "Audit UV ne prouve pas le frozen/offline/exit0 réel")
    python = Path(argv[9])
    need(python.is_absolute() and python.is_file() and os.access(python, os.X_OK)
         and python.name == "python3.13", "Python physique UV attendu indisponible")
    env = audit.get("environment")
    need(type(env) is dict and env.get("UV_PROJECT_ENVIRONMENT") == str(SOURCE / ".venv-conforme")
         and env.get("UV_PYTHON_DOWNLOADS") == "never"
         and env.get("UV_LINK_MODE") == "copy"
         and env.get("HOME") == str(PROOFS / "uv-home")
         and env.get("CFFIXED_USER_HOME") == str(PROOFS / "uv-home")
         and env.get("TMPDIR") == str(PROOFS / "uv-tmp"),
         "Environnement UV observé hors QA")
    for key in ("stdout", "stderr"):
        ref = audit.get(key)
        need(type(ref) is dict and str(ref.get("path")) in selected,
             "Flux UV non épinglé")
        need(ref == selected[str(ref["path"])], "Flux UV différent de l'INDEX QA")
    return audit


def load_pinned(name: str, module_name: str, *, under: Path):
    path, expected_sha = SOURCES[name]
    raw = read_exact(path, expected_sha, under=under)
    need(module_name not in sys.modules, "Module préalable non admis : " + module_name)
    module = ModuleType(module_name)
    module.__file__ = str(path)
    sys.modules[module_name] = module
    # Compiler les octets vérifiés évite qu'un ancien .pyc supplante la source épinglée.
    exec(compile(raw, str(path), "exec"), module.__dict__)
    return module


def verify_git_capture(capture) -> None:
    need(capture.GIT == "/Applications/Xcode.app/Contents/Developer/usr/bin/git"
         and capture.ROOT == QA_ROOT and capture.SOURCE == SOURCE
         and capture.PROOFS == PROOFS and capture.REPOSITORY == REPOSITORY
         and capture.EXPECTED == HEAD,
         "Capture Git différente des chemins Xcode/QA fixés")
    expected_env = {"PATH": "/usr/bin:/bin", "LANG": "C", "LC_ALL": "C",
                    "GIT_CONFIG_NOSYSTEM": "1", "GIT_CONFIG_GLOBAL": "/dev/null",
                    "GIT_OPTIONAL_LOCKS": "0", "TMPDIR": str(PROOFS / "tmp"),
                    "HOME": str(PROOFS / "home"),
                    "CFFIXED_USER_HOME": str(PROOFS / "home"),
                    "DEVELOPER_DIR": "/Applications/Xcode.app/Contents/Developer"}
    need(capture.GIT_ENV == expected_env, "Environnement Git doit rester fermé")
    need(Path(capture.GIT).is_file() and os.access(capture.GIT, os.X_OK),
         "Git Xcode direct indisponible")
    for folder in (PROOFS / "home", PROOFS / "tmp"):
        meta = folder.lstat()
        need(folder.is_dir() and not folder.is_symlink() and meta.st_uid == os.getuid()
             and stat.S_IMODE(meta.st_mode) & 0o077 == 0,
             "HOME/TMP Git non privé : " + str(folder))


def write_new(path: Path, raw: bytes) -> None:
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, "wb") as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())


def canonical_json(value: dict) -> bytes:
    return (json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode("utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description="Préflight A/B seul ; aucune admission")
    parser.add_argument("--preflight", action="store_true", required=True)
    parser.add_argument("--campaign", required=True, choices=("A", "B"))
    args = parser.parse_args()
    os.umask(0o077)
    sys.dont_write_bytecode = True
    need(HERE == Path("/private/tmp/therese-c17-ab-preflight-wrapper-wMnJq2"),
         "Wrapper déplacé hors du gel préparé")
    wrapper_path = HERE / "run_ab_preflight.py"
    wrapper_raw = wrapper_path.read_bytes()
    wrapper_ref = reference(wrapper_path, wrapper_raw)
    index, selected = verify_source_index()
    uv = verify_uv_receipt(selected)
    producer = load_pinned("producer", "calibration_round_producer",
                           under=SOURCES["producer"][0].parent)
    capture = load_pinned("git_capture", "c17_direct_xcode_capture", under=QA_ROOT)
    preparer = load_pinned("preallocator", "c17_ab_preallocator",
                           under=SOURCES["preallocator"][0].parent)
    verify_git_capture(capture)
    need(preparer.producer is producer and capture.producer is producer,
         "Producteur byte-exact non partagé")

    nonce = secrets.token_hex(6)
    calls: list[dict[str, object]] = []

    def git(folder: Path, argv: list[str]) -> bytes:
        need(folder in (REPOSITORY, SOURCE) and type(argv) is list and bool(argv)
             and argv[0] in ("rev-parse", "cat-file", "ls-tree")
             and all(type(part) is str for part in argv),
             "Commande Git hors lecture fermée")
        raw = capture.git(folder, *argv)
        calls.append({"cwd": str(folder), "argv": argv, "sha256": digest(raw),
                      "bytes": len(raw), "via": capture.GIT})
        return raw

    py_ref = selected[str(PROOFS / "python-metadata-result.json")]
    node_ref = selected[str(PROOFS / "node-metadata-result.json")]
    plan = preparer.preflight(SOURCE, campaign=args.campaign, nonce=nonce,
                              expected_head=HEAD, python_audit_ref=py_ref,
                              node_audit_ref=node_ref, capture=git,
                              current_repository=REPOSITORY, root_allocated=False)
    need(plan.get("status") == "preflight_only_not_admitted"
         and plan.get("actor") == "/root" and plan.get("head") == HEAD
         and plan.get("product_source_root") == str(SOURCE)
         and plan.get("git_preview", {}).get("file_count") == index["tracked_files"],
         "Plan de préallocation ne correspond pas aux blobs du checkout")
    round_root = Path(plan["root"])
    need(not round_root.exists() and not round_root.is_symlink(),
         "Racine A/B créée pendant le préflight")
    verify_source_index()
    verify_uv_receipt(selected)
    for path, expected_sha in SOURCES.values():
        read_exact(path, expected_sha, under=QA_ROOT if path.is_relative_to(QA_ROOT) else path.parent)
    need(wrapper_path.read_bytes() == wrapper_raw, "Wrapper changé pendant le préflight")
    need(git(REPOSITORY, ["rev-parse", "--verify", "HEAD"]) == (HEAD + "\n").encode(),
         "HEAD réel changé après le contrôle des 24 références")
    need(not round_root.exists() and not round_root.is_symlink(),
         "Racine A/B apparue avant l'émission du reçu")

    # Un reçu de préflight est distinct de la future racine therese-c17-direct-round-*.
    receipt_root = Path("/private/tmp") / f"therese-c17-ab-preflight-{args.campaign.lower()}-{nonce}"
    os.mkdir(receipt_root, mode=0o700)
    plan_raw = canonical_json(plan)
    plan_path = receipt_root / "plan.json"
    write_new(plan_path, plan_raw)
    receipt = {"schema": "c17-ab-main-preflight-receipt-v1",
               "status": "preflight_only_not_admitted", "actor": "/root",
               "observed_at": datetime.now(UTC).isoformat(),
               "campaign": args.campaign, "round_id": plan["round_id"],
               "future_round_root": str(round_root), "future_round_root_allocated": False,
               "head": HEAD, "qa_source": str(SOURCE),
               "qa_index_ref": reference(PROOFS / "INDEX.json", read_exact(PROOFS / "INDEX.json", INDEX_SHA, under=QA_ROOT)),
               "selected_ref_count": len(selected), "uv_receipt_ref": selected[str(PROOFS / "uv-graph-check-receipt.json")],
               "uv_exit_code": uv["exit_code"],
               "producer_ref": reference(SOURCES["producer"][0],
                                         read_exact(*SOURCES["producer"], under=SOURCES["producer"][0].parent)),
               "preallocator_ref": reference(SOURCES["preallocator"][0],
                                             read_exact(*SOURCES["preallocator"], under=SOURCES["preallocator"][0].parent)),
               "git_capture_ref": selected[str(PROOFS / "capture-source.py")],
               "wrapper_ref": wrapper_ref,
               "git_calls": calls,
               "plan_ref": reference(plan_path, plan_raw),
               "runtime_started": False, "admission_consumed": False,
               "not_proved": ["A/B root allocated", "Session or product runtime",
                              "Calibrations or FULL qualification", "Independent second actor/round"]}
    receipt_raw = canonical_json(receipt)
    receipt_path = receipt_root / "receipt.json"
    write_new(receipt_path, receipt_raw)
    print(json.dumps({"status": receipt["status"], "receipt": str(receipt_path),
                      "receipt_sha256": digest(receipt_raw),
                      "future_round_root_allocated": False}, ensure_ascii=False))


if __name__ == "__main__":
    main()
