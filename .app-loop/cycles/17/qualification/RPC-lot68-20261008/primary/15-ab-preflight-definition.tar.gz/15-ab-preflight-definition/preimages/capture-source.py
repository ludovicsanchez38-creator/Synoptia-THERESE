#!/usr/bin/env python3
"""Capture Git en lecture seule du seul checkout QA détaché.

Émet des bruts exclusifs dans proofs. Aucun import produit ni admission A/B.
"""
from __future__ import annotations

from datetime import UTC, datetime
import json
import os
from pathlib import Path
import subprocess

import calibration_round_producer as producer


ROOT = Path(__file__).resolve().parent.parent
SOURCE = ROOT / "source"
PROOFS = ROOT / "proofs"
REPOSITORY = Path("/Users/synoptia/Desktop/Dev Synoptia/Synoptia-THERESE-c15-codex")
EXPECTED = "19979e8a5ea9bd8e886d35d54793b3d1a560cd77"
GIT_ENV = {"PATH": "/usr/bin:/bin", "LANG": "C", "LC_ALL": "C",
           "GIT_CONFIG_NOSYSTEM": "1", "GIT_CONFIG_GLOBAL": "/dev/null",
           "GIT_OPTIONAL_LOCKS": "0", "TMPDIR": str(PROOFS / "tmp"),
           "HOME": str(PROOFS / "home"), "CFFIXED_USER_HOME": str(PROOFS / "home"),
           "DEVELOPER_DIR": "/Applications/Xcode.app/Contents/Developer"}
GIT = "/Applications/Xcode.app/Contents/Developer/usr/bin/git"


def git(folder: Path, *args: str) -> bytes:
    child = subprocess.run([GIT, "-C", str(folder), *args], cwd=folder,
                           env=GIT_ENV, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                           timeout=45, check=False)
    producer.need(child.returncode == 0 and child.stderr == b"",
                  "Git rouge/non silencieux : " + " ".join(args)
                  + " rc=" + str(child.returncode)
                  + " stderr=" + repr(child.stderr[:400]))
    return child.stdout


def main() -> None:
    os.umask(0o077)
    for name in ("tmp", "home"):
        (PROOFS / name).mkdir(mode=0o700, exist_ok=True)
    producer.need(ROOT.parent == Path("/private/tmp") and ROOT.name.startswith("therese-c17-direct-source-")
                  and SOURCE.resolve(strict=True) == SOURCE,
                  "Racine source QA privée différente")
    before = git(REPOSITORY, "rev-parse", "--verify", "HEAD")
    producer.need(before == (EXPECTED + "\n").encode(), "HEAD actuel source changé avant capture")
    producer.need(git(SOURCE, "status", "--porcelain=v1", "-z") == b"",
                  "Checkout QA initial non propre")
    manifest, tree, commit = producer.verified_source_payload(SOURCE, EXPECTED,
                                                               capture=lambda folder, args: git(folder, *args))
    producer.need(git(REPOSITORY, "rev-parse", "--verify", "HEAD") == before,
                  "HEAD source changé pendant capture")
    producer.need(git(SOURCE, "status", "--porcelain=v1", "-z") == b"",
                  "Checkout QA changé pendant capture")
    names = ("qa-head.stdout", "qa-tree.raw", "qa-commit.raw", "qa-status.stdout", "qa-source-files.json")
    producer.need(all(not (PROOFS / name).exists() for name in names),
                  "Brut Git existant : aucune réécriture")
    producer.write_new(PROOFS / names[0], before)
    producer.write_new(PROOFS / names[1], tree)
    producer.write_new(PROOFS / names[2], commit)
    producer.write_new(PROOFS / names[3], b"")
    manifest |= {"git_head_ref": producer.reference(SOURCE / ".git/HEAD"),
                 "git_tree_ref": producer.reference(PROOFS / names[1]),
                 "git_commit_ref": producer.reference(PROOFS / names[2]),
                 "method": "fresh detached clone, root read-only Git HEAD/commit/tree and all blobs/modes"}
    producer.write_new(PROOFS / names[4], producer.json_bytes(manifest))
    receipt = {"schema": "c17-direct-source-git-capture-v1", "status": "PASS",
               "observed_at": datetime.now(UTC).isoformat(), "actor": "/root/environment_routes",
               "head": EXPECTED, "source": str(SOURCE), "repository": str(REPOSITORY),
               "source_manifest": producer.reference(PROOFS / names[4]),
               "head_output": producer.reference(PROOFS / names[0]),
               "tree_raw": producer.reference(PROOFS / names[1]),
               "commit_raw": producer.reference(PROOFS / names[2]),
               "status_output": producer.reference(PROOFS / names[3]),
               "file_count": len(manifest["files"]), "modes_count": len(manifest["modes"]),
               "copied_results": [], "runtime_started": False, "round_created": False}
    producer.write_new(PROOFS / "git-capture-receipt.json", producer.json_bytes(receipt))
    print(json.dumps({"status": "PASS", "source": str(SOURCE), "head": EXPECTED,
                      "tracked_files": len(manifest["files"]),
                      "receipt": str(PROOFS / "git-capture-receipt.json")}))


if __name__ == "__main__":
    main()
