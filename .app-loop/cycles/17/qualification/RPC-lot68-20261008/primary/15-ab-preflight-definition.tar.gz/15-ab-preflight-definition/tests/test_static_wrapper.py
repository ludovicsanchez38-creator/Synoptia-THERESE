"""Tests statiques : aucun import/exec du wrapper ou lancement Git."""
from __future__ import annotations

import ast
import hashlib
from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[1]
WRAPPER = ROOT / "run_ab_preflight.py"
PINS = {
    "prepare_ab_inputs.py": "7d4227253d7ca92d6905ccf4e4caca4500528d785d6a1a55a353ad39ce02a23d",
    "calibration_round_producer.py": "70be1e802b35fc067492f684e70e93b4990dabbb669a70e0d1303be4b90c6f85",
    "capture-source.py": "d9f3be62141164cc64e3e14ae247512567c71467d95f55f4b75493d08afa37d7",
    "qa-source-INDEX.json": "b3f54844903c90cfa3bdfe1b711a7ccb522ba3d8c2004f1e549e11c6c22fecb9",
}


class WrapperStaticTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.text = WRAPPER.read_text(encoding="utf-8")
        cls.tree = ast.parse(cls.text, filename=str(WRAPPER))

    def test_preimages_byte_exact(self) -> None:
        for name, expected in PINS.items():
            with self.subTest(name=name):
                raw = (ROOT / "preimages" / name).read_bytes()
                self.assertEqual(hashlib.sha256(raw).hexdigest(), expected)

    def test_git_callback_passed_explicitly(self) -> None:
        calls = [node for node in ast.walk(self.tree) if isinstance(node, ast.Call)
                 and isinstance(node.func, ast.Attribute) and node.func.attr == "preflight"]
        self.assertEqual(len(calls), 1)
        keywords = {item.arg: item.value for item in calls[0].keywords}
        self.assertIn("capture", keywords)
        self.assertIsInstance(keywords["capture"], ast.Name)
        self.assertEqual(keywords["capture"].id, "git")
        self.assertIn("root_allocated", keywords)
        self.assertIsInstance(keywords["root_allocated"], ast.Constant)
        self.assertIs(keywords["root_allocated"].value, False)

    def test_no_attestation_admission_or_default_git_invocation(self) -> None:
        self.assertNotIn("attest_prepared_root(", self.text)
        self.assertNotIn("publish_source_checkout(", self.text)
        self.assertNotIn('["/usr/bin/git"', self.text)
        self.assertIn("/Applications/Xcode.app/Contents/Developer/usr/bin/git", self.text)
        self.assertIn("preflight_only_not_admitted", self.text)
        self.assertIn("len(rows) == 24", self.text)

    def test_no_import_time_execution(self) -> None:
        body = self.tree.body
        calls_at_top = [node for node in body if isinstance(node, ast.Expr)
                        and isinstance(node.value, ast.Call)]
        self.assertEqual(calls_at_top, [])
        self.assertTrue(any(isinstance(node, ast.If)
                            and isinstance(node.test, ast.Compare)
                            and isinstance(node.test.left, ast.Name)
                            and node.test.left.id == "__name__" for node in body))


if __name__ == "__main__":
    unittest.main()
