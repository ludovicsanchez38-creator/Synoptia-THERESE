import fs from 'node:fs';
import crypto from 'node:crypto';
import path from 'node:path';
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
const root='/private/tmp/therese-c17-root10-system-diagnostic-25smI0KQ';
const qa='/private/tmp/therese-c17-wrapper-canary-b90937dbae4845ca9d04b93aa4cdf9aa';
assert.equal(process.argv[2],'--execute-read-only');
const ref=p=>{const b=fs.readFileSync(p);return{path:p,sha256:crypto.createHash('sha256').update(b).digest('hex'),bytes:b.length};};
const resultRef=ref(qa+'/wrapper-canary-result.json');
assert.equal(resultRef.sha256,'49b980383365fd98d87cab77b113946eacbdc7881b1bdd60ef20b71e767901dc');
assert.equal(resultRef.bytes,2778);
const chromePath=qa+'/ledger/aux-chrome-rpc-all-runtime_ui-visual_capture-network_capture/receipt.json';
const chromeRef=ref(chromePath),chrome=JSON.parse(fs.readFileSync(chromePath));
const birth=chrome.root_identity;
assert.equal(birth.pid,70792);assert.equal(birth.ppid,70354);assert.equal(birth.uid,501);
assert.equal(birth.start_sec,1791474774);assert.equal(birth.start_usec,727823);
assert.equal(chrome.started_at,'2026-10-08T15:52:54.727687+00:00');
assert.equal(chrome.exit_code,-9);
const argv=['show','--style','json','--start','2026-10-08 17:52:53','--end','2026-10-08 17:53:10',
  '--predicate','((process == "syspolicyd" OR process == "amfid" OR process == "taskgated" OR process == "kernel" OR process == "sandboxd") AND (eventMessage CONTAINS "70792" OR eventMessage CONTAINS "b90937dbae4845ca9d04b93aa4cdf9aa"))'];
const started=new Date().toISOString();
const result=spawnSync('/usr/bin/log',argv,{encoding:'buffer',timeout:15000,maxBuffer:2*1024*1024,
  env:{PATH:'/usr/bin:/bin:/usr/sbin:/sbin',LANG:'en_US.UTF-8'},cwd:root});
for(const[name,bytes]of[['stdout.json',result.stdout||Buffer.alloc(0)],['stderr.log',result.stderr||Buffer.alloc(0)]])
  fs.writeFileSync(path.join(root,name),bytes,{flag:'wx',mode:0o600});
let events=null,parseError=null;
try{events=JSON.parse((result.stdout||Buffer.alloc(0)).toString('utf8'));}catch(e){parseError=String(e);}
assert.deepEqual(ref(chromePath),chromeRef);assert.deepEqual(ref(resultRef.path),resultRef);
const passed=result.status===0&&!result.signal&&!result.error&&!parseError&&Array.isArray(events);
const messages=passed?[...new Set(events.map(x=>x.eventMessage))]:[];
const receipt={schema:'c17-root10-chrome-policy-system-log-v1',actor:'/root',executable:'/usr/bin/log',argv,
  started_at:started,completed_at:new Date().toISOString(),exit_code:result.status,signal:result.signal,
  error:result.error?String(result.error):null,parse_error:parseError,stdout_ref:ref(root+'/stdout.json'),
  stderr_ref:ref(root+'/stderr.log'),script_ref:ref(import.meta.filename),source_result_ref:resultRef,
  source_chrome_ref:chromeRef,birth,event_count:passed?events.length:0,unique_messages:messages.length,passed,
  diagnostic_only:true,causal_claim:false,G1_imported:false,profile_changed:false,FULL:false,release:false};
fs.writeFileSync(root+'/receipt.json',JSON.stringify(receipt,null,2)+'\n',{flag:'wx',mode:0o600});
console.log(JSON.stringify({receipt_ref:ref(root+'/receipt.json'),passed,event_count:receipt.event_count,
  first_unique_messages:messages.slice(0,12),remaining_unique_messages:Math.max(0,messages.length-12)},null,2));
process.exitCode=passed?0:1;
