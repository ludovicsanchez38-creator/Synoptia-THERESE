# Relecture ROOT10 close, préparation statique

Auteur du port : /root/shared4_execution. Exécution prévue : MAIN /root, après sa lecture et son GO exact. Aucun exécuteur supplémentaire ni revue fictive.

ROOT10 est réellement clos selon le message MAIN : outil 7b3ec8, session 7876 puis e96370, code 86. Le résultat est physiquement relu et pinné à 49b980383365fd98d87cab77b113946eacbdc7881b1bdd60ef20b71e767901dc, 2778 octets. Ce fait ne constitue pas une permission d'exécuter cet auditeur.

## Adaptation exacte

Préimage byte-exacte de /private/tmp/therese-c17-root-close9-1LGYyudq/verify-closed.mjs : SHA491eb37ef82f65147e1628559e9c23548a3fc07575f4f202923e844ab1696a0c, 11494 octets. Diff exhaustif verify-closed.diff.

Port des seuls chemins et observations réelles ROOT10 : 79 sources, résultat rouge, Chrome PID 70792, birth 1791474774/727823, stderr 44a575f1… / 2876 B. Les oracles pytest/Vitest 1/0/1/0, XML un test, erreurs et skips zéro, contrôle logs, readiness, taint rouge, ACK complete sans signaux et garde de nettoyage ≤ 8 s restent conservés.

Le nouveau diagnostic est uniquement donnée : max 8 nœuds, message UTF8 ≤ 1024 B, type ≤ 128 B, module ≤ 256 B, JSON ≤ 16 KiB. ACK error et affichage calibrate.stderr doivent conserver la même chaîne exacte outer/cause. Aucune classe distante exécutée, aucun contenu traité comme autorité ou comme cause OS prouvée. Le résultat final générique de Session.wait n'est pas réécrit.

## Périmètre de lecture

Aucun accès syslog, aucun scan de processus/ports, aucun import G1 ni lancement Chrome/services. Les preuves d'arrêt sont les reçus déjà clos, leurs références et jointures exactes.

MAIN a explicitement autorisé le rehash du seul ancien .ips littéral /Users/synoptia/Library/Logs/DiagnosticReports/Google Chrome-2026-10-08-143832.000.ips. Son pin complet est lu dans le manifest gelé /private/tmp/therese-c17-chrome-rootdomain-h5whIv/INDEX.json : 2e1d81e295a1a75af7498e1698b4284c53206f7a031058ebd3331aad6fc8a3b3/31835B. Aucun inventaire, parse ou autre crash hors QA. Refus explicite de toute autre .ips hors QA. Cette ancienne preuve n'est ni ROOT10 ni une causalité actuelle.

Le rehash SHA de références reste borné à 6000 et exige UID, chemin canonique et fichier régulier. Deux passages avant/après, reçu exclusif dans ce seul dossier. Les INDEX historiques copiés restent des données exactes, non réinterprétées comme tables de la copie. Le profil, les permissions, les ports et les bornes 5 s/50 s/8 s natifs et les assertions instrumentées ne changent pas.

## Lancement futur, NON exécuté

MAIN choisit son Node 22 déjà pinné et sa borne outil, après lecture du code et du diff :

    node /private/tmp/therese-c17-root10-closure-review-BawAYTLf/verify-closed.mjs --verify-closed

Sans ce seul argument explicite : exit 2 avant lecture ROOT10. Avec : relecture de fichiers uniquement et émission receipt.json exclusive, aucun processus enfant/réseau. Aucun test ou Node exécuté par l'auteur.

La préparation n'attribue aucun verdict FULL, ronde A/B, release ou produit. Le contrôle physique d'arrêt ne verdit pas clean/log_stability/owned_shutdown du résultat natif rouge.
