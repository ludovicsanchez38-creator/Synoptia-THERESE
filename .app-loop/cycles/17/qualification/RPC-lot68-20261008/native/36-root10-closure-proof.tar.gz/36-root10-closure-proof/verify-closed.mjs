// Relecture des bruts natifs clos, sans processus ni réseau.
import fs from 'node:fs';
import crypto from 'node:crypto';
import path from 'node:path';
const root='/private/tmp/therese-c17-wrapper-canary-b90937dbae4845ca9d04b93aa4cdf9aa';
const out='/private/tmp/therese-c17-root10-closure-review-BawAYTLf/receipt.json';
// Aucun accès aux bruts et aucune écriture sans lancement explicite après fermeture.
if(process.argv.length!==3||process.argv[2]!=='--verify-closed'){
  console.error('Fermé : revue root et fin réelle requises ; utiliser --verify-closed seulement après GO exact.');
  process.exit(2);
}
// Les INDEX archivés sous preimages sont des données historiques pinnées,
// pas des tables de références au répertoire actuel de leur copie.
const archivedIndexData=new Set([
  '/private/tmp/therese-c17-fresh-wrapper-builder-v6-Z5hOLj/preimages/INDEX-v5.json',
  '/private/tmp/therese-c17-fresh-wrapper-builder-v8-pB5tPP/preimages/INDEX-v6.json',
  '/private/tmp/therese-c17-fresh-wrapper-builder-v8-pB5tPP/preimages/INDEX-v7.json',
  '/private/tmp/therese-c17-fresh-wrapper-builder-v7-cnR8Hm/preimages/INDEX-v6.json',
  '/private/tmp/therese-c17-fresh-wrapper-builder-v9-1G4jE1/preimages/INDEX-v8.json',
  '/private/tmp/therese-c17-fresh-wrapper-builder-v9-1G4jE1/preimages/INDEX-v6.json',
  '/private/tmp/therese-c17-fresh-wrapper-builder-v9-1G4jE1/preimages/INDEX-v7.json',
  '/private/tmp/therese-c17-fresh-wrapper-builder-v10-ynPAzC/preimages/INDEX-v9.json',
]);
const need=(x,m)=>{if(!x)throw Error(m);};
// Seul historique hors QA explicitement autorisé au rehash ; aucune causalité ROOT10.
const historicalCrashReference={
  path:'/Users/synoptia/Library/Logs/DiagnosticReports/Google Chrome-2026-10-08-143832.000.ips',
  sha256:'2e1d81e295a1a75af7498e1698b4284c53206f7a031058ebd3331aad6fc8a3b3',bytes:31835};
const ref=p=>{
  const crashOutsideQA=!p.startsWith('/private/tmp/')
    &&(p.toLowerCase().endsWith('.ips')||p.includes('/DiagnosticReports/'));
  need(!crashOutsideQA||p===historicalCrashReference.path,
    'Lecture crash hors QA interdite '+p);
  const s=fs.lstatSync(p),b=fs.readFileSync(p);
  need(s.isFile()&&!s.isSymbolicLink()&&s.uid===process.getuid()&&fs.realpathSync(p)===p,'Non canonique '+p);
  const result={path:p,sha256:crypto.createHash('sha256').update(b).digest('hex'),bytes:b.length};
  if(p===historicalCrashReference.path)need(result.sha256===historicalCrashReference.sha256
    &&result.bytes===historicalCrashReference.bytes,'Ancien crash changé physiquement');
  return result;
};
const pins=new Map(), pending=[], historicalObservations=[];
const historicalG1ReceiptPaths=new Set([
  '/private/tmp/therese-c17-g1-26-pure-rgpjt79j/receipt.json',
  '/private/tmp/therese-c17-g1-26-pure-bmy35r8g/receipt.json',
  '/private/tmp/therese-c17-g1-26-pure-we_pel56/receipt.json',
]);
const collect=(v,origin='direct')=>{
  if(Array.isArray(v))v.forEach(x=>collect(x,origin));
  else if(v&&typeof v==='object'){
    if(v.schema==='c17-g1-26-pure-tests-v1'&&historicalG1ReceiptPaths.has(origin)){
      // Le fichier du reçu historique est rehashé ; ses snapshots ne sont pas
      // des exigences sur des chemins physiques modifiés par son successeur.
      need(v.pins_before.length===11&&JSON.stringify(v.pins_before)===JSON.stringify(v.pins_after)
        &&v.pins_unchanged===true&&v.passed===true&&v.native_OS_qualification===false
        &&v.FULL_admission===false,'Observation historique invalide '+origin);
      historicalObservations.push({origin,refs:v.pins_before.length});
      for(const [k,x] of Object.entries(v))if(!['pins_before','pins_after'].includes(k))collect(x,origin);
    }else if(Object.keys(v).sort().join(',')==='bytes,path,sha256'){
      let pin=v;
      if(!path.isAbsolute(v.path)){
        need(['/private/tmp/therese-c17-chrome-unixbind-PUUOvY00/INDEX.json',
          '/private/tmp/therese-c17-chrome-rootdomain-h5whIv/INDEX.json',
          '/private/tmp/therese-c17-fresh-wrapper-builder-v5-NbNXOk/INDEX.json',
          '/private/tmp/therese-c17-fresh-wrapper-builder-v6-Z5hOLj/INDEX.json',
          '/private/tmp/therese-c17-fresh-wrapper-builder-v7-cnR8Hm/INDEX.json',
          '/private/tmp/therese-c17-fresh-wrapper-builder-v7-cnR8Hm/profile/INDEX.json',
          '/private/tmp/therese-c17-fresh-wrapper-builder-v8-pB5tPP/INDEX.json',
          '/private/tmp/therese-c17-fresh-wrapper-builder-v9-1G4jE1/INDEX.json',
          '/private/tmp/therese-c17-fresh-wrapper-builder-v10-ynPAzC/INDEX.json'].includes(origin)
          &&!v.path.split('/').includes('..'),'Ref relative hors INDEX Chrome exact '+origin+' '+v.path);
        pin={...v,path:path.resolve(path.dirname(origin),v.path)};
      }
      const old=pins.get(pin.path);
      need(!old||old.sha256===pin.sha256&&old.bytes===pin.bytes,'Pins contradictoires '+pin.path+' '+JSON.stringify({old,new:pin}));
      if(!old){pins.set(pin.path,pin);pending.push(pin);}
    }else Object.values(v).forEach(x=>collect(x,origin));
  }
};
const read=p=>JSON.parse(fs.readFileSync(p));
const historicalCrashManifest={path:'/private/tmp/therese-c17-chrome-rootdomain-h5whIv/INDEX.json',
  sha256:'c0f542c377d37efd8e88103e2d760fdc126b785793f167755a319f0f5fb8d3c6',bytes:2605};
need(ref(historicalCrashManifest.path).sha256===historicalCrashManifest.sha256
  &&ref(historicalCrashManifest.path).bytes===historicalCrashManifest.bytes,
  'Manifest historique crash changé');
collect(read(historicalCrashManifest.path),historicalCrashManifest.path);
// Diagnostics seulement : ni classes distantes, ni pouvoir de lancement ou preuve de cause OS.
const diagnosticObservations=[];
const diagnosticKeys=['budget_truncated','cycle_detected','depth_truncated','diagnostic_only','nodes','schema','serializer_failed'];
const nodeKeys=['index','message','message_truncated','module','relation','suppress_context','type'];
const validateDiagnostic=(value,origin)=>{
  need(value!==null&&typeof value==='object'&&!Array.isArray(value)
    &&JSON.stringify(Object.keys(value).sort())===JSON.stringify(diagnosticKeys)
    &&value.schema==='c17-rpc-exception-diagnostic-v1'&&value.diagnostic_only===true,
    'Diagnostic autre schéma '+origin);
  for(const k of ['budget_truncated','cycle_detected','depth_truncated','serializer_failed'])
    need(typeof value[k]==='boolean','Diagnostic booléen '+origin+'/'+k);
  need(Array.isArray(value.nodes)&&value.nodes.length<=8
    &&Buffer.byteLength(JSON.stringify(value),'utf8')<=16384,'Diagnostic hors borne '+origin);
  value.nodes.forEach((n,i)=>{
    need(n!==null&&typeof n==='object'&&!Array.isArray(n)
      &&JSON.stringify(Object.keys(n).sort())===JSON.stringify(nodeKeys)
      &&Number.isSafeInteger(n.index)&&n.index===i
      &&(i===0?n.relation==='outer':['cause','context'].includes(n.relation))
      &&typeof n.message_truncated==='boolean'&&typeof n.suppress_context==='boolean',
      'Nœud diagnostic invalide '+origin+'/'+i);
    for(const [key,max] of [['message',1024],['type',128],['module',256]])
      need(typeof n[key]==='string'&&Buffer.byteLength(n[key],'utf8')<=max,
        'Texte diagnostic hors borne '+origin+'/'+i+'/'+key);
  });
  return value;
};
const result=read(root+'/wrapper-canary-result.json');
need(ref(root+'/wrapper-canary-result.json').sha256==='49b980383365fd98d87cab77b113946eacbdc7881b1bdd60ef20b71e767901dc'
  &&ref(root+'/wrapper-canary-result.json').bytes===2778,'Résultat changé');
need(result.runner_exit===86&&result.passed===false&&result.FULL===false&&result.source_unchanged===true
  &&result.owned_shutdown_proved===false&&result.rpc_transport_closed===true&&result.rpc_audit.observed===7
  &&result.readiness_ref&&Object.keys(result.stage_refs).length===0
  &&result.error.type==='InstrumentError'&&result.error.message==='Timeout/interruption/source/ambiguïté instrument : pas un rouge causal','Rouge modifié');
const source=read(root+'/authorization/source-refs.json');
need(source.source_refs.length===79&&new Set(source.source_refs.map(r=>r.path)).size===79,'Sources79 absentes/dupliquées');
need(result.scope==='WRAPPER_CANARY'&&result.round_A_or_B===false&&result.density_or_78===false
  &&result.rpc_audit.expected===15&&result.rpc_audit.passed===false
  &&result.transport_final.active===0&&result.transport_final.errors.length===0
  &&result.transport_errors.length===0,'Portée ou fermeture transport divergente');
const stopRefs=[result.service_stop_ref,result.session_stop_ref];
const stops=stopRefs.map(r=>read(r.path));
for(const s of stops){
  need(s.cleanup.clean===true&&s.cleanup.termination_of_exact_targets_proved===true
    &&s.cleanup.remaining_attributed.length===0&&s.cleanup.ambiguities.length===0&&s.cleanup.errors.length===0
    &&s.remaining_handles.length===0&&s.cleanup_error===null
    &&s.cleanup_deadline_met===true&&Number.isFinite(s.cleanup_elapsed_seconds)&&s.cleanup_elapsed_seconds<=8
    &&s.ports_absence_proved===true&&JSON.stringify(s.ports_absent)==='[17593,5173]'
    &&JSON.stringify(s.auxiliary_ports_absent)==='[17594]','Nettoyage physique non prouvé');
  need(s.clean===false&&s.log_stability_tainted===true&&s.log_stability_proved===false,'Taint rouge masquée');
  collect(s);collect(s.ports_absence_receipt);
}
need(stops[0].services_stopped===true&&stops[1].session_closed===true&&stops[1].interrupt_handlers_restored===true,'Services/session/handlers');
const stageReceipts=['backend','vite','calibrate','aux-chrome-rpc-all-runtime_ui-visual_capture-network_capture'].map(n=>read(root+'/ledger/'+n+'/receipt.json'));
let signalJoins=0;
for(const r of stageReceipts){
  need(r.termination_proved===true&&r.cleanup.clean===true&&r.cleanup_deadline_met===true,'Étape non terminée');
  for(const sig of r.cleanup.signals){
    need(r.attributed.some(x=>JSON.stringify([x.pid,x.start_sec,x.start_usec])===JSON.stringify(sig.identity)
      &&x.uid===sig.uid&&x.pgid===sig.pgid&&x.role===sig.role),'Signal sans birth exacte');
    signalJoins++;
  }
  collect(r);collect(ref(root+'/ledger/'+r.name+'/receipt.json'));
}
collect(result);collect(source);collect(ref(root+'/wrapper-canary-result.json'));
collect(ref(root+'/authorization/source-refs.json'));
for(let i=0;i<pending.length;i++){
  need(pending.length<=6000,'Refs hors borne du lecteur statique');
  const r=pending[i],a=ref(r.path);
  need(a.sha256===r.sha256&&a.bytes===r.bytes,'Ref modifiée '+r.path);
  if(r.path.endsWith('.json')&&!archivedIndexData.has(r.path))collect(read(r.path),r.path);
}
const ready=read(result.readiness_ref.path);
need(ready.vite_http_status===200&&ready.onboarding_completed===true
  &&ready.verified_data_dir===root+'/profiles/service/data'
  &&ready.verified_db_path===root+'/profiles/service/data/therese.db','Readiness autre QA');
const ackFiles=fs.readdirSync(root+'/session-rpc/ack').filter(n=>n.endsWith('.json'));
need(ackFiles.length===7,'Sept ACK réels attendus');
const acknowledgements=[];
for(const n of ackFiles){
  const p=root+'/session-rpc/ack/'+n,a=read(p),s=fs.statSync(p),h=fs.statSync(p+'.pending');
  need(s.ino===h.ino&&s.dev===h.dev,'ACK publication autre inode');
  collect(a);collect(ref(p));
  if(a.state==='complete')need(a.termination_proved===true&&a.tainted===false&&a.signals.length===0
    &&a.synthetic_authentication===false&&a.runtime_admission===false
    &&a.real_peer_identity_qualified_by_file_transport===false,'ACK feuille instrument taint ou admission inventée');
  else need(a.state==='error'&&n.startsWith('rpc-all-runtime_ui-visual_capture-network_capture-')
    &&a.tainted===true&&a.runtime_admission===false&&a.real_peer_identity_qualified_by_file_transport===false
    &&a.receipt_ref===undefined,'Refus pré-lancement Node masqué');
  if(a.state==='error'){
    const diagnostic=validateDiagnostic(a.instrument_error?.diagnostic,p);
    need(a.instrument_error.type==='RpcPrelaunchRefused'
      &&a.instrument_error.phase==='accept_or_begin_refused'
      &&diagnostic.nodes.length===2&&diagnostic.nodes[0].type==='RpcPrelaunchRefused'
      &&diagnostic.nodes[0].message==='RPC refusé avant enregistrement de tout handle'
      &&diagnostic.nodes[1].relation==='cause'&&diagnostic.nodes[1].type==='InstrumentError'
      &&diagnostic.nodes[1].message==='Chrome absent/changé ou admission CDP hors délai5s'
      &&diagnostic.cycle_detected===false&&diagnostic.depth_truncated===false
      &&diagnostic.budget_truncated===false&&diagnostic.serializer_failed===false,
      'Chaîne ROOT10 perdue ou modifiée');
    diagnosticObservations.push({ack_ref:ref(p),diagnostic,authority:false,OS_cause_proved:false});
  }
  acknowledgements.push({ref:ref(p),state:a.state,exit_code:a.exit_code??null});
}
for(let i=0;i<pending.length;i++){
  need(pending.length<=6000,'Refs hors borne du lecteur statique');
  const r=pending[i],a=ref(r.path);need(a.sha256===r.sha256&&a.bytes===r.bytes,'Ref modifiée '+r.path);
  if(r.path.endsWith('.json')&&!archivedIndexData.has(r.path))collect(read(r.path),r.path);
}
const controls=read(root+'/runtime/calibration/test-runner-rpc/test-runner-controls.json');
need(controls.status==='passed'&&Object.values(controls.controls).every(c=>c.pass===true),'Témoins non conformes');
for(const kind of ['positive','negative']){
  const p=controls.controls['pytest-'+kind],v=controls.controls['vitest-'+kind];
  const expected=kind==='positive'?1:0;
  need([p,v].every(c=>c.exit_code===expected&&c.counts.tests===1&&c.counts.failures===expected&&c.counts.errors===0&&c.counts.skipped===0&&/^[a-f0-9]{64}$/.test(c.sha256)),'Oracles témoins changés');
}
const logs=read(root+'/runtime/calibration/logs-rpc/logs-controls.json');
need(logs.status==='passed'&&logs.run_id==='logs-rpc'&&logs.negative_control.pass===true&&logs.positive_control.pass===true,'Logs témoin non passé');
for(const p of ['test-runner-rpc/test-runner-controls.json','logs-rpc/logs-controls.json'])collect(ref(root+'/runtime/calibration/'+p));
for(const [p,sha] of Object.entries(controls.witnesses)){const r=ref(p);need(r.sha256===sha,'Témoin muté');collect(r);}
for(const c of Object.values(controls.controls)){
  if(c.sha256){const r=ref(c.xml);need(r.sha256===c.sha256,'XML muté');collect(r);}
  else need(!fs.existsSync(c.xml),'XML absent apparu après clôture');
}
const logRaw=ref(logs.raw_log);need(logRaw.sha256===logs.raw_log_sha256,'Logs bruts mutés');collect(logRaw);
const chrome=stageReceipts[3],chromeRaw=ref(chrome.stderr_path);
need(chrome.exit_code===-9&&chrome.timed_out===false&&chrome.interruption===null
  &&chrome.root_identity.pid===70792&&chrome.root_identity.start_sec===1791474774
  &&chrome.root_identity.start_usec===727823
  &&chromeRaw.sha256==='44a575f1f60a230d3d63415af2689439bb0b8ce2089ce0a0bf7e8071b789e695'
  &&chromeRaw.bytes===2876&&chrome.cleanup.signals.length===6
  &&JSON.stringify(chrome.cleanup.signals.map(s=>s.signal))==='["SIGSTOP","SIGSTOP","SIGSTOP","SIGTERM","SIGCONT","SIGKILL"]'
  &&!fs.readFileSync(chrome.stderr_path,'utf8').includes('-[NSBundle initWithURL:]: non-file URL argument'),
  'Chrome ROOT10 autre observation : SIGKILL de nettoyage sur birth exacte');
need(diagnosticObservations.length===1,'Un refus diagnostic ROOT10 attendu');
const calibrateRaw=ref(root+'/output/calibrate.stderr');
need(calibrateRaw.sha256==='63f73831d3a28e1c1fc44d7b4bf0346f60623842d0658d1dc422762c509ed9fe'
  &&calibrateRaw.bytes===2118,'Stderr calibrate modifié');
const diagnosticLine=fs.readFileSync(calibrateRaw.path,'utf8').split('\n')
  .filter(line=>line.startsWith('rpc_protocol.RpcInstrumentError: RPC instrument refused/timeout: '));
need(diagnosticLine.length===1,'Affichage client diagnostic absent/dupliqué');
const displayed=JSON.parse(diagnosticLine[0].slice('rpc_protocol.RpcInstrumentError: RPC instrument refused/timeout: '.length));
const displayedDiagnostic=validateDiagnostic(displayed.diagnostic,calibrateRaw.path);
need(JSON.stringify(displayedDiagnostic)===JSON.stringify(diagnosticObservations[0].diagnostic),
  'Chaîne affichée différente du ACK');
need(!fs.existsSync(root+'/ledger/rpc-all-runtime_ui-visual_capture-network_capture/receipt.json'),
  'Reçu feuille Node apparu malgré refus prélaunch');
collect(calibrateRaw);
for(let i=0;i<pending.length;i++){
  const r=pending[i],a=ref(r.path);need(a.sha256===r.sha256&&a.bytes===r.bytes,'Ref modifiée '+r.path);
}
const body={schema:'c17-root-closed-wrapper-red10-verification-v1',actor:'/root',instrument_author:'/root/shared4_execution',result_ref:ref(root+'/wrapper-canary-result.json'),
  verified_refs:[...pins.values()],historical_observations:historicalObservations,refs_unchanged:true,
  refs_unchanged_scope:'verified_refs_only',historical_crash_ref:historicalCrashReference,
  historical_crash_is_current_ROOT10_cause:false,
  source_count:79,signal_birth_joins:signalJoins,
  physical_cleanup_proved:true,cleanup_seconds:stops.map(s=>s.cleanup_elapsed_seconds),handlers_restored:true,
  readiness_observed:true,red_taint_preserved:true,instrument_passed:false,runner_exit:86,
  acknowledgements,leaf_count:6,chrome_stderr_ref:chromeRaw,calibrate_stderr_ref:calibrateRaw,
  diagnostic_observations:diagnosticObservations,diagnostics_only_no_OS_cause:true,test_runner_four_controls_passed:true,
  owned_shutdown_proved_from_original_result:false,verifier_no_OS_process_launch:true,system_log_read:false,FULL:false,round_A_or_B:false,release:false};
fs.writeFileSync(out,JSON.stringify(body,null,2)+'\n',{flag:'wx',mode:0o600});
console.log(JSON.stringify({status:'closed_red10_physical_cleanup_verified',refs:pins.size,signal_birth_joins:signalJoins,receipt:ref(out)}));
