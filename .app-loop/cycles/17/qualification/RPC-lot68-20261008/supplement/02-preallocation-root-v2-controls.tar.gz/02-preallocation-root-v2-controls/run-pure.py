"""Rejeu principal des sept cas, fixtures confinées, sans Git/OS/A-B réel."""
from __future__ import annotations
from datetime import UTC, datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import tempfile
import time
import traceback
import unittest

GEL = Path('/private/tmp/therese-c17-ab-preallocation-juPxhwe2')
OUT = Path('/private/tmp/therese-c17-ab-preallocation-tests-root-v2-PrrYqZgO')
CONTROL = Path(__file__).resolve().parent

def ref(path):
    b = path.read_bytes()
    return {'path': str(path), 'sha256': hashlib.sha256(b).hexdigest(), 'bytes': len(b)}

def need(ok, reason):
    if not ok:
        raise ValueError(reason)

need(OUT.resolve(strict=True) == OUT and not any(OUT.iterdir()), 'Sortie neuve canonique requise')
index = json.loads((GEL / 'INDEX.json').read_bytes())
need(ref(GEL / 'INDEX.json')['sha256'] == 'b37a4a0ac38ba69083466b80905b4b0db6cb4c146244143fb00c5348e95855ad', 'Gel différent')
paths = [GEL / row['path'] for row in index['references']]
for row, path in zip(index['references'], paths, strict=True):
    actual = ref(path)
    need(actual['sha256'] == row['sha256'] and actual['bytes'] == row['bytes'], 'Pin divergent')
paths += [GEL / 'INDEX.json', Path(__file__).resolve(), CONTROL / 'pure.sb']
paths += [CONTROL / 'test_prepare_ab_inputs.py', CONTROL / 'preimage-author-tests.py',
          CONTROL / 'preimage-v1-runner.py', CONTROL / 'preimage-v1-profile.sb']
before = [ref(path) for path in paths]
fixtures = OUT / 'fixtures'
fixtures.mkdir(mode=0o700)
os.environ['HOME'] = str(OUT)
os.environ['TMPDIR'] = str(OUT)
rejected = []

def writable(path, event):
    if isinstance(path, int):
        return
    if not Path(os.fsdecode(path)).resolve().is_relative_to(OUT):
        rejected.append({'event': event, 'detail': str(path)[:300]})
        raise PermissionError('Ecriture hors fixtures principales')

def audit(event, args):
    if event.startswith(('subprocess.', 'socket.', 'ctypes.', 'pty.')) or event in {
        'os.system', 'os.fork', 'os.forkpty', 'os.exec', 'os.posix_spawn', 'os.spawn', 'os.kill', 'os.killpg'}:
        rejected.append({'event': event, 'detail': str(args)[:300]})
        raise PermissionError('Processus/socket/ctypes/signaux interdits')
    if event == 'import' and args[0].split('.')[0] in {
        'runtime_session', 'runtime78_core', 'runtime78_coordinator', 'root_rpc_bootstrap',
        'rpc_client', 'rpc_dispatcher', 'session_rpc_adapter', 'app', 'backend'}:
        rejected.append({'event': event, 'detail': str(args[0])})
        raise PermissionError('Import instrumentation interdit')
    if event == 'open':
        path, mode, flags = args
        if (isinstance(mode, str) and any(c in mode for c in 'wax+')) or (
            isinstance(flags, int) and flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND)):
            writable(path, event)
    elif event in {'os.mkdir', 'os.remove', 'os.rmdir', 'os.chmod', 'os.chown', 'os.utime', 'os.truncate'}:
        writable(args[0], event)
    elif event in {'os.rename', 'os.link'}:
        writable(args[0], event); writable(args[1], event)
    elif event == 'os.symlink':
        need(args[0] == '/Users/synoptia/.local/share/uv/python/cpython-3.13.5-macos-aarch64-none/bin/python3.13',
             'Seul faux exécutable de fixture autorisé, même binaire que le profil pur')
        writable(args[1], event)

sys.addaudithook(audit)
sys.path.insert(0, str(GEL))
started = datetime.now(UTC).isoformat()
begin = time.monotonic()
result = None
error = None
raw_out, raw_err = OUT / 'stdout.log', OUT / 'stderr.log'
with raw_out.open('x', encoding='utf-8') as stdout, raw_err.open('x', encoding='utf-8') as stderr:
    oldout, olderr = sys.stdout, sys.stderr
    sys.stdout, sys.stderr = stdout, stderr
    try:
        # Les modules sont des producteurs de données, pas G1 ou code produit.
        import calibration_round_producer as producer
        import prepare_ab_inputs as subject
        real_path = Path
        def fixture_path(*parts):
            if len(parts) == 1 and str(parts[0]) == '/private/tmp':
                return fixtures
            return real_path(*parts)
        # Double explicite de la base physique : aucun root A/B canonique n'est
        # alloué. Les corps et contrôles Git restent ceux des sources gelées.
        producer.Path = fixture_path
        subject.Path = fixture_path
        real_mkdtemp = tempfile.mkdtemp
        def fixture_mkdtemp(*args, **kwargs):
            need(kwargs.get('dir') == '/private/tmp', 'Fixture mkdtemp hors inventaire')
            kwargs['dir'] = str(fixtures)
            return real_mkdtemp(*args, **kwargs)
        tempfile.mkdtemp = fixture_mkdtemp
        spec = importlib.util.spec_from_file_location('root_preallocation_tests', CONTROL / 'test_prepare_ab_inputs.py')
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        result = unittest.TextTestRunner(stream=stdout, verbosity=2).run(
            unittest.defaultTestLoader.loadTestsFromModule(module))
    except BaseException as exc:
        error = {'type': type(exc).__name__, 'message': str(exc)}
        traceback.print_exc(file=stderr)
    finally:
        sys.stdout, sys.stderr = oldout, olderr
        stdout.flush(); stderr.flush()
        os.fsync(stdout.fileno()); os.fsync(stderr.fileno())
after = [ref(path) for path in paths]
body = {'schema': 'c17-root-preallocation-synthetic-pure-tests-v1', 'actor': '/root',
    'started_at': started, 'completed_at': datetime.now(UTC).isoformat(),
    'elapsed_seconds': time.monotonic() - begin,
    'tests': result.testsRun if result else 0,
    'failures': len(result.failures) if result else None,
    'errors': len(result.errors) if result else None,
    'skipped': len(result.skipped) if result else None, 'instrument_error': error,
    'stdout_ref': ref(raw_out), 'stderr_ref': ref(raw_err),
    'pins_before': before, 'pins_after': after, 'sources_unchanged': before == after,
    'forbidden_events': rejected, 'physical_base_is_synthetic_double': True,
    'fixture_outputs_confined_to': str(fixtures), 'Git_capture_is_synthetic_callback': True,
    'fixture_python_link_only_delta': 'same interpreter already executable in the unchanged pure policy',
    'first_root_red_ref': ref(Path('/private/tmp/therese-c17-ab-preallocation-tests-root-XdeB6FHz/receipt.json')),
    'actual_current_HEAD_or_dependencies_qualified': False,
    'A_B_root_allocated': False, 'G1_imported': False, 'FULL': False, 'release': False,
    'passed': bool(result and result.wasSuccessful() and not result.skipped
                   and not rejected and error is None and before == after)}
with (OUT / 'receipt.json').open('x', encoding='utf-8') as stream:
    json.dump(body, stream, ensure_ascii=False, indent=2); stream.write('\n')
    stream.flush(); os.fsync(stream.fileno())
print(json.dumps({'receipt_ref': ref(OUT / 'receipt.json'), 'tests': body['tests'],
    'passed': body['passed'], 'failures': body['failures'], 'errors': body['errors']}))
raise SystemExit(0 if body['passed'] else 1)
