# Contrôleur d'archive du lot 68 (préparé, non exécuté)

Ce dossier contient un contrôleur neuf inspiré de `package.mjs` et `verify-lot67.mjs` sous `/private/tmp/therese-c17-lot67-archive-7iTBan7Z`. Il ne dépose rien dans le dépôt ni dans l'emplacement canonique. Aucun TAR de lot 68 n'a été créé par cette préparation.

`PLAN.json` nomme exactement 22 racines déjà closes et les sépare en définitions, contrôles, preuves pures vertes, bruts rouges, diagnostic, autorité et préflight non admis. Chaque racine devient une archive distincte ; les rouges ne partagent jamais une archive avec les verts. La racine native ROOT10 `...wrapper-canary-b90937dbae4845ca9d04b93aa4cdf9aa` est différée jusqu'à sa fermeture et impose une nouvelle révision explicite du plan et de son pin.

La source QA fraîche est un cas spécial : seul `proofs/INDEX.json` et ses 24 `selected_refs` sont retenus. Ces références incluent cinq fichiers exacts du checkout, notamment `source/.git/HEAD`, les locks et `pyproject.toml`. Le contrôleur vérifie leur chemin, taille et SHA et ne parcourt jamais le checkout, `.git/objects`, les dépendances ou le venv. Des archives historiques peuvent être présentes comme blobs suivis dans le checkout ; cela ne signifie pas qu'elles sont des résultats adoptés ou archivés ici.

Au futur GO root, et seulement après revue des pins, l'invocation proposée est :

```
node /private/tmp/therese-c17-lot68-archive-controller-vVzFqI/archive_lot68.mjs --execute --expected-plan-sha256 <SHA256_DE_PLAN_JSON> --out-dir /private/tmp/therese-c17-lot68-archive-<nouvel-identifiant>
```

La destination doit être neuve et sous ce préfixe privé. Avant création, le contrôleur revérifie les 22 ancres SHA et les statuts rouges/verts épinglés. Il refuse symlinks et autres types non réguliers, exclut explicitement sockets, `__pycache__` et fichiers `._*`, borne chaque archive à 64 MiB (TAR non compressé et gzip) et chaque liste à 4 096 membres. Il produit un USTAR régulier gzip sans appel à `tar` ni métadonnées Apple, vérifie noms/types/checksums/octets/modes/UID/GID de chaque membre, puis recontrôle SHA, taille et identité de chaque fichier source après écriture. En cas d'échec après allocation, `failure.json` signale le lot incomplet ; aucun reçu vert global n'est publié. Un succès ne qualifie que l'archivage, jamais le runtime, A/B, FULL ou la release.

Le script ne supprime aucun fichier. Les xattrs, ACL et signatures ne sont pas encodés dans les membres USTAR ; seules les propriétés déclarées dans le reçu sont vérifiées. Le contrôle technique `node --check` a été passé lors de la préparation, sans exécuter le contrôleur.
