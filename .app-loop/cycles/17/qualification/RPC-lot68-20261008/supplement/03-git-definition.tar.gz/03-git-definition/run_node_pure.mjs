// Prepared only, not invoked in this lot. Root must read source/profile/command.
import * as fs from 'node:fs';
import {createHash} from 'node:crypto';
import {dirname, resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {runCases} from './pure_git_cases.mjs';

const base = dirname(fileURLToPath(import.meta.url)), out = resolve(process.argv[2] ?? '');
if (!/^\/private\/tmp\/therese-c17-ab-git-node-[a-zA-Z0-9]+$/.test(out) || fs.realpathSync(out) !== out
  || !fs.statSync(out).isDirectory() || out === base) throw new Error('Fresh exact output directory required');
const started = new Date().toISOString();
const sha = raw => createHash('sha256').update(raw).digest('hex');
const files = [fileURLToPath(import.meta.url), base + '/pure_git_cases.mjs', base + '/render_git_readonly.py',
  base + '/preimages/aux_node.mjs', base + '/preview-definition-only/auxiliary-ports/runtime/aux_node.mjs'];
const pins = () => files.map(path => {const raw = fs.readFileSync(path); return {path, sha256: sha(raw), bytes: raw.length};});
const before = pins();
let result = null, error = null;
try {result = runCases(fs.readFileSync(files.at(-1), 'utf8'));} catch (cause) {error = String(cause);}
const after = pins(), unchanged = JSON.stringify(before) === JSON.stringify(after);
const receipt = {schema: 'c17-ab-git-node-pure-tests-v1', scope: 'definition_behavior_doubles_only',
  actor: '/root/cycle17_gate_review', round_id: null, head: null, started_at: started, completed_at: new Date().toISOString(),
  pins_before: before, pins_after: after, pins_unchanged: unchanged, error, result,
  passed: !error && result?.passed === true && unchanged,
  command: null, command_provenance: 'Actual root invocation/profile/env must be bound separately, never inferred from this runner',
  runtime_enabled: false, os_startup_qualified: false, admissions: {}, capabilities: {}};
fs.writeFileSync(out + '/receipt.json', JSON.stringify(receipt, null, 2) + '\n', {flag: 'wx', mode: 0o600});
console.log(JSON.stringify({passed: receipt.passed, tests: result?.results.length ?? 0, receipt: out + '/receipt.json'}));
process.exitCode = receipt.passed ? 0 : 1;
