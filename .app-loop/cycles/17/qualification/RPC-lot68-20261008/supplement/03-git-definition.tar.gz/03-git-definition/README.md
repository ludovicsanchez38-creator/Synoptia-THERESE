# Raccord Git A/B fermé, préparation seulement

Ce lot ajoute un renderer de définitions. Il ne lance ni recette, Git, Node,
Chrome, G1, session ou ronde. Il ne produit aucun HEAD, checkout, snapshot,
binding, décision ni admission. Toutes les capacités et tables restent fermées.

## Delta exact

Six fichiers comportent chacun un import `execFileSync` et un seul appel
`git rev-parse HEAD` : recettes générale, facturation, CRM, B1713, P162 et
`complements/instruments/contexte-v3.mjs`. Seules ces deux ancres sont remplacées
par l'import `ownedGitHead` et `ownedGitHead(repo)`. Les autres octets sont
reconstructibles exactement. Le contexte conserve ses appels HEAD initial et
final. Les codes, assertions, options Chrome, ordre d'import/décoration, trace,
garde GET P162 et recettes sans Git ne sont pas modifiés.

Le helper est dérivé par ajout de 14 lignes, sans remplacer aucun ancien octet.
`ownedGitHead` appelle à chaque invocation `environmentContext`, compare la
source et la référence Git de l'environnement au contexte A/B, puis appelle
`gitHead` et compare le résultat au contexte. Aucun cache ni repli subprocess.
`environmentContext` appelle toujours uniquement `gitHead`, jamais
`ownedGitHead`. Il n'y a donc pas de récursion dans cette chaîne.

## Composition et références

Ordre obligatoire : renderer CDP fermé avec le helper original
`64555c1d39590d944bce79a84479bc7deca7d1bdcdfd4552f842651bc307baf3`
(14 247 octets), puis ce renderer Git. Le helper résultant est
`f302e0fd1cb6f64d87c606eabcf6a8b7184b1ca05654024bfd52ec569c1478db`
(15 031 octets). Le gel CDP n'est ni modifié ni repinné rétroactivement.

Le renderer exige exactement onze textes déjà préparés/pinnés par son appelant :
huit recettes uniques, contexte partagé, trace CDP et garde GET. Il ne rebase
pas leurs chemins, leur cycle, leurs ports ou leur identité. Les fichiers sous
`preimages/` et `preview-definition-only/` sont des définitions de test,
certaines historiques. Leurs anciennes constantes rendent notamment ces
préviews inéligibles comme entrées de ronde actuelle. Aucun ancien résultat
runtime ou succès WRAPPER n'est transposé.

## Fermeture runtime qui reste à produire réellement

Le contexte A/B existant exige acteur/ronde/étape/HEAD identiques à l'environnement
Session, racine canonique et script direct exact. Le registre hardlink owned
lie aussi décision et SHA du binding. Le nouveau reader impose la même référence
environnement/contexte, au chemin exact
`<nouvelle-racine-A-B>/authorization/git-snapshot.json`.

Le checkout neuf doit avoir son attestation propre
`authorization/source-checkout.json`, sa source QA et son HEAD réellement
contrôlés. Root devra publier et épingler le snapshot neuf depuis cette source.
Le nom technique existant `c17-wrapper-physical-git-snapshot-v1` est un schéma
de lecteur, pas une preuve WRAPPER réutilisable en A/B. Aucune instance d'un
ancien snapshot n'est admise par ce lot.

Le reader JS `gitHead` recontrôle les SHA/taille des bruts, l'objet commit et
la chaîne physique `.git/HEAD` à chaque lecture. Il ne reconstruit pas le tree
récursif. La vérification root fraîche `GitSnapshot.verify_worktree`, liant
commit/tree/blobs/modes à la source réelle, demeure obligatoire avant admission.
Les lecteurs existants sont intégralement conservés, pas remplacés par un booléen.

## Vérifications réellement exécutées

Les 47 tests Python finaux ont passé, sans erreur ni saut, sous garde d'audit
interdisant subprocess/socket/ctypes/fork/signaux et écritures hors sortie privée.
Ils exécutent les vrais corps AST du renderer et vérifient les onze préviews,
les sept différences, la reconstruction des préimages et la composition CDP.
54 références avant/après sont inchangées. Reçu final externe :
`/private/tmp/therese-c17-ab-git-python-ds9xtRZb/receipt.json`, SHA
`9b78d13420d9c96d6eb1852b3e9940d1608884eafad3f31dd46dc9a6001f75bd`.

Le premier contrôle AST avait refusé une concaténation accidentelle de deux
affectations du runner. Préimage et diagnostic sont conservés, aucun test n'avait
démarré. Le premier reçu Python de 46 tests reste distinct et conservé ; il ne
s'additionne pas aux 47 finaux. Deux observations de pins historiques y sont
reliées à leurs préimages exactes, sans réécriture de ce reçu.

## JavaScript préparé, non exécuté

`pure_git_cases.mjs` extrait les vrais corps `environmentContext` et
`ownedGitHead` avec des doubles explicitement déclarés pour FS/publication/lecteur
Git. Un résultat opaque, volontairement non-HEAD Git, teste le passage du reader
et l'absence de cache. Aucun objet Git ou HEAD n'est synthétisé ni qualifié.
Les fixtures couvrent les refus champ par champ, contexte/checkout/ref/binding,
et les lectures répétées. Elles ne prouvent pas SHA/FS/ownership physiques.

`run_node_pure.mjs` n'a pas été lancé. La commande proposée utilise le profil
pur fermé déjà dérivé séparément avec le seul droit de lecture du répertoire `/`.
Root doit relire ce nouveau code, allouer sa sortie, contrôler les pins puis
autoriser explicitement son invocation. Aucune permission nouvelle n'est préparée.

Restent hors de ce lot : lsof dans `ownership-only`, constructeur physique A/B,
admissions et canaris natifs des nouveaux composites, deux rondes, qualification
FULL et release. Les obligations 27/78 et les dénominateurs restent inchangés.
