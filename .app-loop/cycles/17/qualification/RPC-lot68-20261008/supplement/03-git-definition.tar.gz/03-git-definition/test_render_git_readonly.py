"""Actual Python renderer bodies; JavaScript behavioral fixtures remain unrun."""
import ast
import hashlib
import json
from pathlib import Path
import unittest

BASE = Path(__file__).resolve().parent


def extracted(path):
    tree = ast.parse(path.read_text())
    allowed = {"__future__", "hashlib", "pathlib", "re"}
    for node in tree.body:
        if isinstance(node, ast.ImportFrom):
            assert node.module in allowed, node.module
        if isinstance(node, ast.Import):
            assert all(alias.name in allowed for alias in node.names)
    ns = {"__name__": "closed_renderer_body"}
    exec(compile(tree, str(path), "exec"), ns)
    return ns


class GitRendererTests(unittest.TestCase):
    def setUp(self):
        self.ns = extracted(BASE / "render_git_readonly.py")
        self.sources = {}
        for row in json.loads((BASE / "INPUTS.json").read_text())["files"]:
            original = Path(row["original_ref"]["path"]).read_bytes()
            copy = Path(row["copy_ref"]["path"]).read_bytes()
            self.assertEqual(copy, original)
            for ref, raw in ((row["copy_ref"], copy), (row["original_ref"], original)):
                self.assertEqual(ref["sha256"], hashlib.sha256(raw).hexdigest())
                self.assertEqual(ref["bytes"], len(raw))
            self.sources[row["name"]] = copy.decode()
        self.sources[self.ns["CONTEXT_PATH"]] = self.sources["contexte-v3.mjs"]
        self.definitions = {name: self.sources[name] for name in self.ns["REQUIRED_PATHS"]}
        self.definitions["trace-chrome.mjs"] = self.sources["trace-after-cdp-definition-only.mjs"]
        self.arguments = {"helper_source": self.sources["aux_node.mjs"],
            "helper_pin": self.ns["pin"](self.sources["aux_node.mjs"]),
            "trace_before_cdp": self.sources["trace-chrome.mjs"],
            "trace_before_cdp_pin": self.ns["pin"](self.sources["trace-chrome.mjs"])}

    def render(self, definitions=None, pins=None, **kwargs):
        inputs = definitions if definitions is not None else self.definitions
        return self.ns["render"](inputs, pins if pins is not None else {name: self.ns["pin"](text) for name, text in inputs.items()},
                                 **(self.arguments | kwargs))

    def test_exact_six_and_helper_only(self):
        result = self.render()
        self.assertEqual(set(result["changed_paths"]), set(self.ns["GIT_SITES"]) | {self.ns["HELPER_PATH"]})
        self.assertEqual(len(self.ns["GIT_SITES"]), 6)
        for path in self.definitions.keys() - self.ns["GIT_SITES"].keys():
            self.assertEqual(result["definitions"][path], self.definitions[path])

    def test_reverse_every_source_byte(self):
        result = self.render()
        for path, (before_import, before_call) in self.ns["GIT_SITES"].items():
            relative = "../auxiliary-ports/runtime/aux_node.mjs" if path.startswith("runtime/") else "../../auxiliary-ports/runtime/aux_node.mjs"
            after_import = f"import {{ownedGitHead}} from '{relative}';"
            restored = result["definitions"][path].replace(after_import, before_import).replace("ownedGitHead(repo)", before_call)
            self.assertEqual(restored, self.definitions[path])

    def test_physical_definition_preview_matches_actual_renderer(self):
        result = self.render()
        for name, source in result["definitions"].items():
            raw = (BASE / "preview-definition-only" / name).read_bytes()
            self.assertEqual(raw, source.encode())
            self.assertEqual(self.ns["pin"](raw.decode()), result["output_pins"][name])
        helper = (BASE / "preview-definition-only/auxiliary-ports/runtime/aux_node.mjs").read_bytes()
        self.assertEqual(helper, result["helper_source"].encode())
        self.assertEqual(self.ns["pin"](helper.decode()), result["helper_pin"])

    def test_all_old_helper_bytes_preserved(self):
        output = self.render()["helper_source"]
        addition = self.ns["OWNED_GIT_ADDITION"]
        self.assertEqual(output[:-len(addition)], self.sources["aux_node.mjs"])
        self.assertEqual(output[len(self.sources["aux_node.mjs"]):], addition)

    def test_cdp_precedes_git_and_trace_stays_exact(self):
        result = self.render()
        self.assertEqual(result["input_helper_pin"], self.ns["OLD_HELPER_PIN"])
        self.assertNotEqual(result["helper_pin"], result["input_helper_pin"])
        self.assertEqual(result["definitions"]["trace-chrome.mjs"], self.sources["trace-after-cdp-definition-only.mjs"])

    def test_real_cdp_renderer_body_composes(self):
        cdp = extracted(BASE / "preimages/render_direct_cdp.py")
        original = {name: self.sources[name] for name in cdp["REQUIRED_PATHS"]}
        # Normative definition-only identity; never emitted/admitted as A/B.
        cdp_result = cdp["render"](original, {name: cdp["pin"](text) for name, text in original.items()},
            helper_source=self.sources["aux_node.mjs"], helper_pin=self.arguments["helper_pin"],
            root="/private/tmp/therese-c17-direct-round-a-123456789abc", actor="/root",
            round_id="c17-direct-round-a-123456789abc", head="a" * 40)
        self.assertEqual(cdp_result["definitions"]["trace-chrome.mjs"], self.definitions["trace-chrome.mjs"])
        composed = self.render(cdp_result["definitions"] | {self.ns["CONTEXT_PATH"]: self.sources["contexte-v3.mjs"]})
        self.assertEqual(composed["definitions"]["trace-chrome.mjs"], cdp_result["definitions"]["trace-chrome.mjs"])

    def test_closed_flags_and_no_head_output(self):
        result = self.render()
        for key in ("RUNTIME_ENABLED", "OS_STARTUP_QUALIFIED"):
            self.assertIs(self.ns[key], False)
        for key in ("ADMISSION_TABLE", "CAPABILITIES"):
            self.assertEqual(self.ns[key], {})
        self.assertIs(result["runtime_enabled"], False)
        self.assertIs(result["os_startup_qualified"], False)
        self.assertEqual(result["admission_table"], {})
        self.assertEqual(result["capabilities"], {})
        self.assertNotIn("head", result)
        self.assertNotIn("round_id", result)

    def test_context_retains_before_and_after_reads(self):
        source = self.render()["definitions"][self.ns["CONTEXT_PATH"]]
        self.assertEqual(source.count("const head=()=>ownedGitHead(repo);"), 1)
        self.assertEqual(source.count("head()"), 2)
        self.assertIn("head_after:head()", source)
        self.assertIn("assert.equal(head(),contract.head", source)

    def test_no_recursion_or_cache_added(self):
        helper = self.sources["aux_node.mjs"]
        env_body = helper.split("export function environmentContext(", 1)[1].split("export function createAuxiliary(", 1)[0]
        physical_body = helper.split("export function gitHead(", 1)[1].split("export function environmentContext(", 1)[0]
        addition = self.ns["OWNED_GIT_ADDITION"]
        self.assertNotIn("ownedGitHead", env_body + physical_body)
        self.assertEqual(addition.count("environmentContext(environment)"), 1)
        self.assertEqual(addition.count("gitHead(snapshotRef, source)"), 1)
        self.assertNotIn("getAuxiliary", addition)
        self.assertNotIn("auxiliary =", addition)
        self.assertNotIn("catch", addition)
        self.assertNotIn("child_process", addition)

    def test_physical_reader_preserved_complete_and_bound(self):
        helper = self.render()["helper_source"]
        original = self.sources["aux_node.mjs"]
        for first, last in (("export function gitHead(", "export function environmentContext("),
                            ("export function environmentContext(", "export function createAuxiliary(")):
            self.assertEqual(helper.split(first, 1)[1].split(last, 1)[0], original.split(first, 1)[1].split(last, 1)[0])
        for anchor in ("context.source_checkout_ref?.path === `${context.root}/authorization/source-checkout.json`",
            "registry.binding_sha256 === environment.C17_SESSION_BINDING_SHA256",
            "context.round_id === environment.C17_SESSION_ROUND_ID",
            "gitHead(context.git_snapshot_ref, context.product_source_root) === context.head"):
            self.assertIn(anchor, original)

    def test_new_reader_has_exact_env_source_ref_head_links(self):
        addition = self.ns["OWNED_GIT_ADDITION"]
        for anchor in ("context.scope === 'runtime78_exact_round'", "AB_DIRECT_JOBS.includes(context.stage)",
            "context.product_source_root === source", "JSON.parse(environment.C17_AUX_GIT_SNAPSHOT_REF)",
            "same(snapshotRef, context.git_snapshot_ref)", "snapshotRef.path === `${context.root}/authorization/git-snapshot.json`",
            "head === context.head", "return head;"):
            self.assertEqual(addition.count(anchor), 1)

    def test_no_child_process_in_six_outputs(self):
        result = self.render()
        for path in self.ns["GIT_SITES"]:
            self.assertNotIn("child_process", result["definitions"][path])
            self.assertNotIn("execFileSync", result["definitions"][path])
            self.assertEqual(result["definitions"][path].count("ownedGitHead(repo)"), 1)

    def test_oracles_exit_codes_and_get_guard_unchanged(self):
        result = self.render()
        self.assertEqual(result["definitions"][self.ns["GUARD_PATH"]], self.definitions[self.ns["GUARD_PATH"]])
        for path in self.ns["RECIPE_PATHS"]:
            before, after = self.definitions[path], result["definitions"][path]
            for token in ("process.exitCode", "assert", "check(", "headless: false", "chromiumSandbox: true", "newContext"):
                self.assertEqual(before.count(token), after.count(token), (path, token))

    def test_missing_input(self):
        value = self.definitions.copy()
        value.pop(self.ns["CONTEXT_PATH"])
        with self.assertRaisesRegex(ValueError, "Exact eight"):
            self.render(value)

    def test_unlisted_input(self):
        with self.assertRaisesRegex(ValueError, "Exact eight"):
            self.render(self.definitions | {"unexpected.mjs": ""})

    def test_hash_mismatch(self):
        pins = {name: self.ns["pin"](text) for name, text in self.definitions.items()}
        pins[self.ns["CONTEXT_PATH"]]["sha256"] = "0" * 64
        with self.assertRaisesRegex(ValueError, "SHA/bytes"):
            self.render(pins=pins)

    def test_size_mismatch(self):
        pins = {name: self.ns["pin"](text) for name, text in self.definitions.items()}
        pins[self.ns["CONTEXT_PATH"]]["bytes"] += 1
        with self.assertRaisesRegex(ValueError, "SHA/bytes"):
            self.render(pins=pins)

    def test_new_helper_refused_as_old_cdp_input(self):
        changed = self.render()["helper_source"]
        with self.assertRaisesRegex(ValueError, "64555"):
            self.render(helper_source=changed, helper_pin=self.ns["pin"](changed))

    def test_helper_reader_mutated_even_repinned(self):
        changed = self.sources["aux_node.mjs"].replace("values.at(-1) === head", "true")
        with self.assertRaisesRegex(ValueError, "64555"):
            self.render(helper_source=changed, helper_pin=self.ns["pin"](changed))

    def test_cdp_not_applied_refused(self):
        with self.assertRaisesRegex(ValueError, "CDP-before-Git"):
            self.render(self.definitions | {"trace-chrome.mjs": self.sources["trace-chrome.mjs"]})

    def test_cdp_mutated_refused(self):
        altered = self.definitions["trace-chrome.mjs"].replace("options.headless!==false", "options.headless!==true")
        with self.assertRaisesRegex(ValueError, "CDP-before-Git"):
            self.render(self.definitions | {"trace-chrome.mjs": altered})

    def test_cdp_preimage_hash_mismatch(self):
        with self.assertRaisesRegex(ValueError, "pristine CDP"):
            self.render(trace_before_cdp_pin={"sha256": "0" * 64, "bytes": len(self.sources["trace-chrome.mjs"].encode())})

    def test_context_post_read_removed_refused(self):
        altered = self.definitions[self.ns["CONTEXT_PATH"]].replace("head_after:head()", "head_after:contract.head")
        with self.assertRaisesRegex(ValueError, "pre/post"):
            self.render(self.definitions | {self.ns["CONTEXT_PATH"]: altered})


def site_test(path, kind):
    def case(self):
        text = self.definitions[path]
        old_import, old_call = self.ns["GIT_SITES"][path]
        if kind == "duplicate":
            text += "\n" + old_call + ";\n"
        elif kind == "missing":
            text = text.replace(old_call, "contract.head")
        elif kind == "other-subprocess":
            text += "\nexecFileSync('other',[]);\n"
        elif kind == "rerender":
            text = self.render()["definitions"][path]
        with self.assertRaisesRegex(ValueError, "Unique pristine"):
            self.render(self.definitions | {path: text})
    return case


for index, path in enumerate(("runtime/recette-c17.mjs", "runtime/recette-facturation-p160-v2.mjs",
    "runtime/recette-crm-focus.mjs", "complements/instruments/b1713-clavier-v3.mjs",
    "complements/instruments/p162-colonnes-v3.mjs", "complements/instruments/contexte-v3.mjs")):
    for kind in ("duplicate", "missing", "other-subprocess", "rerender"):
        setattr(GitRendererTests, f"test_site_{index}_{kind.replace('-', '_')}", site_test(path, kind))
