// Prepared only. Actual environmentContext/ownedGitHead bodies with declared
// FS/publication/Git-reader doubles. No Git object/HEAD or checkout is generated.
// An opaque reader sentinel is deliberately NOT a Git HEAD or a live proof.
const clone = value => JSON.parse(JSON.stringify(value));
const assert = (ok, message) => {if (!ok) throw new Error('PureAssertionError: ' + message);};
const equal = (a, b) => JSON.stringify(a) === JSON.stringify(b);

function bodies(source) {
  const envStart = source.indexOf('export function environmentContext(');
  const envEnd = source.indexOf('export function createAuxiliary(', envStart);
  const ownedStart = source.indexOf('export function ownedGitHead(');
  assert(envStart >= 0 && envEnd > envStart && ownedStart > envEnd, 'exact source bodies');
  const environment = source.slice(envStart, envEnd).replace('export function', 'function');
  const owned = source.slice(ownedStart).replace('export function', 'function');
  const tables = source.slice(source.indexOf('export const JOBS'), source.indexOf('export const PROTOCOL')).replaceAll('export const ', 'const ');
  const sameStart = source.indexOf('const same = '), sameEnd = source.indexOf('export const monotonic', sameStart);
  const same = source.slice(sameStart, sameEnd);
  assert(!environment.includes('ownedGitHead'), 'no context recursion');
  assert(owned.match(/environmentContext\(environment\)/g)?.length === 1, 'one fresh context call');
  assert(owned.match(/gitHead\(snapshotRef, source\)/g)?.length === 1, 'one final physical reader call');
  return {environment, owned, tables, same};
}

function fixture(source) {
  const root = '/private/tmp/therese-c17-direct-round-a-123456789abc';
  const qa = '/private/tmp/therese-c17-definition-source-fixture/source';
  const head = 'opaque-reader-result-not-a-Git-HEAD';
  const ref = (path, char) => ({path, sha256: char.repeat(64), bytes: 101});
  const contextRef = ref(root + '/auxiliary/aux-chrome-recipe-general/context.json', 'c');
  const checkoutRef = ref(root + '/authorization/source-checkout.json', 'd');
  const gitRef = ref(root + '/authorization/git-snapshot.json', 'e');
  const context = {schema: 'c17-ab-auxiliary-context-v1', scope: 'runtime78_exact_round', root,
    round_id: 'c17-direct-round-a-123456789abc', round_name: 'A', stage: 'recipe-general', actor: '/root', head,
    product_source_root: qa, source_checkout_ref: checkoutRef, git_snapshot_ref: gitRef,
    source_script: 'runtime/recette-c17.mjs'};
  const checkout = {schema: 'c17-direct-round-source-checkout-v1', product_source_root: qa, head, git_head: head};
  const environment = {C17_AUX_CONTEXT_REF: JSON.stringify(contextRef), C17_AUX_GIT_SNAPSHOT_REF: JSON.stringify(gitRef),
    C17_SESSION_ROOT: root, C17_SESSION_STAGE: 'recipe-general', C17_SESSION_ACTOR: '/root',
    C17_SESSION_ROUND_ID: context.round_id, C17_SESSION_HEAD: head,
    C17_SESSION_DECISION_ID: 'normative-double-only', C17_SESSION_BINDING_SHA256: 'f'.repeat(64)};
  const registry = {schema: 'c17-g1-auxiliary-services-v1', scope: context.scope, stage: context.stage,
    actor: context.actor, round_id: context.round_id, head, decision_id: environment.C17_SESSION_DECISION_ID,
    binding_sha256: environment.C17_SESSION_BINDING_SHA256};
  const state = {root, qa, head, contextRef, checkoutRef, gitRef, context, checkout, environment, registry,
    reads: [], gitCalls: [], publishedCalls: [], fsCalls: []};
  const need = (ok, message) => {if (!ok) throw new Error(message);};
  const checked = (reference, bound = null) => {
    state.reads.push({ref: clone(reference), bound});
    if (equal(reference, state.contextRef)) return Buffer.from(JSON.stringify(state.context));
    if (equal(reference, state.checkoutRef)) return Buffer.from(JSON.stringify(state.checkout));
    throw new Error('Declared checked-reference double mismatch');
  };
  const published = (path, bound) => {
    state.publishedCalls.push({path, bound});
    need(path === state.root + '/auxiliary/aux-chrome-' + state.context.stage + '/services.json' && bound === state.root,
      'Declared publication double mismatch');
    return clone(state.registry);
  };
  const gitHead = (reference, requestedSource) => {
    state.gitCalls.push({ref: clone(reference), source: requestedSource});
    need(equal(reference, state.gitRef) && requestedSource === state.qa, 'Declared physical Git-reader double mismatch');
    return state.head;
  };
  const fs = {realpathSync: path => {state.fsCalls.push(path); return path;}};
  const process = {env: state.environment, argv: ['node', root + '/runtime/recette-c17.mjs']};
  const chunks = bodies(source);
  const build = new Function('checked', 'published', 'gitHead', 'need', 'fs', 'process',
    chunks.tables + '\n' + chunks.same + '\n' + chunks.environment + '\n' + chunks.owned
      + '\nreturn {environmentContext, ownedGitHead};');
  state.api = build(checked, published, gitHead, need, fs, process);
  return state;
}

function rejected(action, expected) {
  try {action();} catch (error) {
    if (error instanceof ReferenceError || error instanceof TypeError || error instanceof SyntaxError
      || error instanceof RangeError || String(error).includes('PureAssertionError:')) throw error;
    assert(error instanceof Error && String(error).includes(expected), 'exact business refusal ' + expected + ': ' + error);
    return;
  }
  throw new Error('PureAssertionError: expected refusal absent: ' + expected);
}

export function runCases(source) {
  const results = [];
  const run = (name, action) => {
    try {action(); results.push({name, passed: true, instrument_error: null});}
    catch (error) {results.push({name, passed: false, instrument_error: String(error)});}
  };
  run('actual owned body returns only physical-reader sentinel', () => {
    const f = fixture(source);
    assert(f.api.ownedGitHead(f.qa) === f.head, 'reader value, no substituted head');
    assert(f.gitCalls.length === 2, 'environment reader then final reader');
    assert(f.reads.length === 2 && f.publishedCalls.length === 1, 'fresh context/checkout/publication');
  });
  run('every invocation rereads context checkout registry and Git', () => {
    const f = fixture(source);
    f.api.ownedGitHead(f.qa);
    const first = {reads: f.reads.length, git: f.gitCalls.length, publication: f.publishedCalls.length};
    f.api.ownedGitHead(f.qa);
    assert(f.reads.length === first.reads * 2 && f.gitCalls.length === first.git * 2
      && f.publishedCalls.length === first.publication * 2, 'no cache');
  });
  run('changed physical-reader value is not cached', () => {
    const f = fixture(source); f.api.ownedGitHead(f.qa);
    f.head = 'another-opaque-reader-result-not-a-Git-HEAD';
    f.context.head = f.head; f.checkout.head = f.head; f.checkout.git_head = f.head;
    f.registry.head = f.head; f.environment.C17_SESSION_HEAD = f.head;
    assert(f.api.ownedGitHead(f.qa) === f.head && f.gitCalls.length === 4, 'fresh changed reader result');
  });
  run('B context without its exact B argv remains refused', () => {
    const f = fixture(source), old = f.root;
    f.root = old.replace('-a-', '-b-');
    f.context.root = f.root; f.context.round_name = 'B'; f.context.round_id = f.context.round_id.replace('-a-', '-b-');
    for (const item of [f.contextRef, f.checkoutRef, f.gitRef]) item.path = item.path.replace(old, f.root);
    f.environment.C17_AUX_CONTEXT_REF = JSON.stringify(f.contextRef);
    f.environment.C17_AUX_GIT_SNAPSHOT_REF = JSON.stringify(f.gitRef);
    f.environment.C17_SESSION_ROOT = f.root; f.environment.C17_SESSION_ROUND_ID = f.context.round_id;
    f.registry.round_id = f.context.round_id;
    // Rebuild so argv, another already validated field, is the exact B fixture.
    const chunks = bodies(source);
    // The ordinary fixture builder supplies a closed A argv; changing only env
    // does not authorize a new executable. Its refusal is kept as a negative.
    assert(chunks.environment.includes('process.argv.includes(`${context.root}/${context.source_script}`)'), 'exact argv guard retained');
    rejected(() => f.api.ownedGitHead(f.qa), 'Script Node direct A-B');
  });
  const envFields = ['C17_SESSION_ROOT', 'C17_SESSION_STAGE', 'C17_SESSION_ACTOR', 'C17_SESSION_ROUND_ID', 'C17_SESSION_HEAD'];
  for (const key of envFields) run('refuses changed env ' + key, () => {
    const f = fixture(source); f.environment[key] += '-different';
    rejected(() => f.api.ownedGitHead(f.qa), 'Contexte auxiliaire non prélié');
    assert(f.gitCalls.length === 0, 'identity refusal before physical reader');
  });
  for (const [key, value] of [['schema', 'other'], ['scope', 'WRAPPER_CANARY'], ['stage', 'unknown'],
    ['round_name', 'B'], ['round_id', 'c17-direct-round-b-123456789abc']]) run('refuses changed context ' + key, () => {
    const f = fixture(source); f.context[key] = value;
    rejected(() => f.api.ownedGitHead(f.qa), 'Contexte auxiliaire non prélié');
  });
  for (const [key, value] of [['schema', 'c17-wrapper-canary-source-checkout-v1'],
    ['product_source_root', '/private/tmp/therese-c17-another-source/source'],
    ['head', 'other-reader-value'], ['git_head', 'other-reader-value']]) run('refuses changed checkout ' + key, () => {
    const f = fixture(source); f.checkout[key] = value;
    rejected(() => f.api.ownedGitHead(f.qa), 'Contexte auxiliaire A-B autre checkout');
  });
  run('refuses requested source other than context', () => {
    const f = fixture(source);
    rejected(() => f.api.ownedGitHead('/private/tmp/therese-c17-other/source'), 'Git metadata hors source/site');
  });
  run('refuses checkout path outside exact current root', () => {
    const f = fixture(source); f.checkoutRef.path = f.root + '/historical/source-checkout.json';
    rejected(() => f.api.ownedGitHead(f.qa), 'Checkout/snapshot A-B non prélié');
  });
  run('refuses snapshot path outside exact current root', () => {
    const f = fixture(source); f.gitRef.path = f.root + '/historical/git-snapshot.json';
    f.environment.C17_AUX_GIT_SNAPSHOT_REF = JSON.stringify(f.gitRef);
    rejected(() => f.api.ownedGitHead(f.qa), 'Checkout/snapshot A-B non prélié');
  });
  for (const key of ['path', 'sha256', 'bytes']) run('refuses env snapshot ref mismatch ' + key, () => {
    const f = fixture(source), altered = clone(f.gitRef);
    altered[key] = key === 'bytes' ? altered[key] + 1 : altered[key] + '-changed';
    f.environment.C17_AUX_GIT_SNAPSHOT_REF = JSON.stringify(altered);
    rejected(() => f.api.ownedGitHead(f.qa), 'Git snapshot env autre');
    assert(f.gitCalls.length === 1, 'no final reader after env ref refusal');
  });
  for (const key of ['schema', 'scope', 'stage', 'actor', 'round_id', 'head', 'decision_id', 'binding_sha256']) run('refuses registry ' + key, () => {
    const f = fixture(source); f.registry[key] += '-changed';
    rejected(() => f.api.ownedGitHead(f.qa), 'Registre services root absent/différent');
    assert(f.gitCalls.length === 1, 'context physical read does not admit bad registry');
  });
  run('refuses changed source script', () => {
    const f = fixture(source); f.context.source_script = 'runtime/another-recipe.mjs';
    rejected(() => f.api.ownedGitHead(f.qa), 'Script Node direct A-B');
  });
  run('refuses changing physical head without context update', () => {
    const f = fixture(source); f.head = 'changed-reader-sentinel';
    rejected(() => f.api.ownedGitHead(f.qa), 'Contexte auxiliaire A-B autre checkout');
  });
  run('actual reader has no recursion or old cached auxiliary dependency', () => {
    const f = fixture(source), code = bodies(source);
    assert(!code.environment.includes('ownedGitHead') && !code.owned.includes('getAuxiliary'), 'no indirect cache/recursion');
    assert(code.owned.match(/gitHead\(/g)?.length === 1 && code.owned.match(/environmentContext\(/g)?.length === 1, 'exact fresh readers');
    assert(!code.owned.includes('catch') && !code.owned.includes('child_process'), 'no fallback');
    f.api.ownedGitHead(f.qa);
  });
  return {schema: 'c17-ab-git-javascript-prepared-cases-v1', scope: 'actual_new_body_with_declared_dependency_doubles_only',
    executed: true, dependency_mode: 'declared_fs_publication_physical_git_reader_doubles', results,
    passed: results.length > 0 && results.every(row => row.passed),
    limits: ['No physical Git object or HEAD is synthesized or qualified',
      'gitHead/checked/fs/publication dependencies are declared doubles; old physical reader remains byte-exact',
      'No Node/product/Chrome/G1/Session/process/socket invocation in preparation',
      'Field refusals are not a substitute for future root source/snapshot/binding authority and native A/B rounds']};
}
