"""Actual definition tests, no subprocess/socket/ctypes/G1/product import."""
from datetime import datetime, timezone
from hashlib import sha256
import importlib.util
import io
import json
import os
from pathlib import Path
import sys
import time
import unittest

BASE = Path(__file__).resolve().parent
OUT = Path(sys.argv[1]).resolve(strict=True)
assert OUT.parent == Path("/private/tmp") and OUT.name.startswith("therese-c17-ab-git-python-")
assert OUT.is_dir() and OUT != BASE
STARTED = datetime.now(timezone.utc).isoformat()
START_CLOCK = time.monotonic()
DENIED = []


def guard(event, args):
    forbidden = event.startswith(("subprocess.", "socket.", "ctypes.")) or event in (
        "os.fork", "os.forkpty", "os.posix_spawn", "os.system", "os.kill", "os.killpg")
    if event == "open":
        path, mode, flags = args
        writing = (isinstance(mode, str) and any(char in mode for char in "wax+")) or bool(flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND))
        if writing:
            forbidden |= not isinstance(path, (str, bytes, os.PathLike)) or not Path(path).resolve().is_relative_to(OUT)
    if event.startswith(("os.remove", "os.rmdir", "os.rename", "os.link", "os.symlink")):
        forbidden = True
    if forbidden:
        DENIED.append({"event": event})
        raise RuntimeError("Forbidden test operation: " + event)


sys.addaudithook(guard)


def ref(path):
    raw = path.read_bytes()
    return {"path": str(path), "sha256": sha256(raw).hexdigest(), "bytes": len(raw)}


def refs():
    paths = [BASE / "render_git_readonly.py", BASE / "test_render_git_readonly.py", Path(__file__).resolve(), BASE / "INPUTS.json"]
    for row in json.loads((BASE / "INPUTS.json").read_text())["files"]:
        paths.extend((Path(row["original_ref"]["path"]), Path(row["copy_ref"]["path"])))
    return [ref(path) for path in paths]


before = refs()
spec = importlib.util.spec_from_file_location("git_renderer_tests_only", BASE / "test_render_git_readonly.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
text = io.StringIO()
suite = unittest.defaultTestLoader.loadTestsFromTestCase(module.GitRendererTests)
result = unittest.TextTestRunner(stream=text, verbosity=2).run(suite)
after = refs()
with (OUT / "stdout.log").open("x") as stream:
    stream.write(text.getvalue())
with (OUT / "stderr.log").open("x") as stream:
    stream.write("")
receipt = {"schema": "c17-ab-git-python-definition-tests-v1", "scope": "pure_definition_tests_only",
    "actor": "/root/cycle17_gate_review", "round_id": None, "head": None,
    "started_at": STARTED, "completed_at": datetime.now(timezone.utc).isoformat(),
    "elapsed_seconds": time.monotonic() - START_CLOCK,
    "tests": result.testsRun, "failures": len(result.failures), "errors": len(result.errors), "skips": len(result.skipped),
    "pins_before": before, "pins_after": after, "pins_unchanged": before == after,
    "denied_events": DENIED, "stdout": ref(OUT / "stdout.log"), "stderr": ref(OUT / "stderr.log"),
    "passed": result.wasSuccessful() and before == after and not DENIED,
    "limits": ["Actual Python renderer AST bodies and historical definition fixtures only",
        "JavaScript ownedGitHead/environmentContext fixtures prepared, not executed",
        "No A/B HEAD, snapshot, authority, checkout, Session, native or lifecycle proof produced"]}
with (OUT / "receipt.json").open("x") as stream:
    stream.write(json.dumps(receipt, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"receipt": str(OUT / "receipt.json"), "tests": receipt["tests"], "passed": receipt["passed"]}))
raise SystemExit(0 if receipt["passed"] else 1)
