// Exécution pure de corps sélectionnés avec doubles, sans listener natif.
import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
const controls='/private/tmp/therese-c17-root-listener-pure-controls-hybPNml4';
const out='/private/tmp/therese-c17-listener-pure-root-jZjeZnUY';
assert.equal(import.meta.filename,controls+'/run-listener-pure.mjs');
assert.equal(process.argv[2],out);
const expected={
  'ownership-only.mjs':'ba7ecf684e5ac8025e9189795ae19df1fc1060d9cb1dcbf8f95059f9ca1cfa72',
  'trace-chrome.mjs':'df8c9db808d75060886d947f65b5033124cca97cf105de22f864e7e1b37b546b',
  'couverture-ecran-c17.mjs':'c9bc366e069bf1d64ff48a8888dd14f44785f3a54e0ac733a23c3900a14afec3',
  'pure_listener_cases.mjs':'38356ce8f1578a0c2cebf3cdc059d37d6ea44082d60352a3a73e689ff413c2f4',
  'aux_node.mjs':'64555c1d39590d944bce79a84479bc7deca7d1bdcdfd4552f842651bc307baf3',
  'node-pure.sb':'468a30e15b06a23ff8d45d1d15c8e45938ae306f3394810f92cf3e1521651039',
};
const ref=p=>{
  const stat=fs.lstatSync(p),data=fs.readFileSync(p);
  assert(stat.isFile()&&!stat.isSymbolicLink()&&stat.uid===process.getuid());
  assert.equal(fs.realpathSync(p),p);
  return {path:p,bytes:data.length,sha256:crypto.createHash('sha256').update(data).digest('hex')};
};
const snapshot=()=>Object.entries(expected).map(([name,sha])=>{
  const observed=ref(controls+'/'+name);assert.equal(observed.sha256,sha);return observed;
});
const before=snapshot(),started=new Date().toISOString();
const {runPure}=await import('./pure_listener_cases.mjs');
const read=name=>fs.readFileSync(controls+'/'+name,'utf8');
const result=await runPure({ownershipSource:read('ownership-only.mjs'),traceSource:read('trace-chrome.mjs'),
  coverageSource:read('couverture-ecran-c17.mjs'),auxiliarySource:read('aux_node.mjs')});
assert.equal(result.cases.length,6);
assert.equal(new Set(result.cases.map(x=>x.name)).size,6);
const after=snapshot();assert.deepEqual(after,before);
const receipt={schema:'c17-root-listener-selected-bodies-pure-v1',actor:'/root',
  started_at:started,completed_at:new Date().toISOString(),cases:result.cases,
  tests:result.cases.length,passed:result.status==='pass'&&result.cases.every(x=>x.passed===true),
  refs_before:before,refs_after:after,runner_ref:ref(import.meta.filename),
  scope:'selected_function_bodies_with_explicit_FS_publication_process_URL_doubles',
  native_listener:false,Chrome:false,G1:false,FULL:false,release:false};
fs.writeFileSync(out+'/receipt.json',JSON.stringify(receipt,null,2)+'\n',{flag:'wx',mode:0o600});
console.log(JSON.stringify({tests:receipt.tests,passed:receipt.passed,failed:receipt.cases.filter(x=>!x.passed)}));
if(!receipt.passed)process.exitCode=1;
