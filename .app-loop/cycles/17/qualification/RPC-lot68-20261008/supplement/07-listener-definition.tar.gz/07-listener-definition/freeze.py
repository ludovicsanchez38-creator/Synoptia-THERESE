"""Génère les seuls diffs/index dérivés, exclusivement dans ce dossier neuf."""
from __future__ import annotations

import difflib
from hashlib import sha256
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
CDP = Path("/private/tmp/therese-c17-ab-direct-cdp-n4yu8cV6")
ORIGIN_INDEX_SHA = "a68753294239bff31ac7ceb4c57f5fb763a0c5f6372805646850d7a5d09c5886"
SOURCES = {
    "ownership-only": (
        CDP / "preimages-complete/ownership-only.mjs",
        ROOT / "preimages/ownership-only.mjs",
        ROOT / "candidate/complements/instruments/ownership-only.mjs",
        "complements/instruments/ownership-only.mjs",
    ),
    "trace-chrome": (
        CDP / "preview-definition-only/trace-chrome.mjs",
        ROOT / "preimages/trace-chrome.mjs",
        ROOT / "candidate/trace-chrome.mjs",
        "trace-chrome.mjs",
    ),
    "couverture-ecran-c17": (
        CDP / "preimages-complete/runtime/couverture-ecran-c17.mjs",
        ROOT / "preimages/couverture-ecran-c17.mjs",
        ROOT / "candidate/runtime/couverture-ecran-c17.mjs",
        "runtime/couverture-ecran-c17.mjs",
    ),
}


def ref(path: Path) -> dict[str, object]:
    raw = path.read_bytes()
    return {"path": str(path), "sha256": sha256(raw).hexdigest(), "bytes": len(raw)}


def emit(path: Path, value: str) -> None:
    with path.open("x", encoding="utf-8", newline="") as output:
        output.write(value)


def main() -> None:
    if ref(CDP / "INDEX.json")["sha256"] != ORIGIN_INDEX_SHA:
        raise ValueError("Index CDP changé")
    all_refs = [ref(CDP / "INDEX.json")]
    changes = []
    for name, (origin, preimage, candidate, output_path) in SOURCES.items():
        if origin.read_bytes() != preimage.read_bytes():
            raise ValueError("Préimage non byte-exacte : " + name)
        before, after = preimage.read_text(), candidate.read_text()
        forward = "".join(difflib.unified_diff(before.splitlines(keepends=True), after.splitlines(keepends=True),
                                               fromfile="a/" + output_path, tofile="b/" + output_path))
        backward = "".join(difflib.unified_diff(after.splitlines(keepends=True), before.splitlines(keepends=True),
                                                fromfile="b/" + output_path, tofile="a/" + output_path))
        if not forward or not backward:
            raise ValueError("Delta ou inverse vide : " + name)
        forward_path = ROOT / "diffs" / (name + ".diff")
        backward_path = ROOT / "diffs" / (name + ".reverse.diff")
        emit(forward_path, forward)
        emit(backward_path, backward)
        changes.append({"name": name, "output_path": output_path, "origin": ref(origin),
                        "preimage": ref(preimage), "candidate": ref(candidate),
                        "diff": ref(forward_path), "reverse_diff": ref(backward_path)})
        all_refs += [ref(origin), ref(preimage), ref(candidate), ref(forward_path), ref(backward_path)]

    support_paths = [CDP / "preimages-complete/contexte-v3.mjs",
                     CDP / "preimages-complete/aux_node.mjs",
                     ROOT / "render_listener_port.py", ROOT / "tests/test_render_listener_port.py",
                     ROOT / "tests/pure_listener_cases.mjs", ROOT / "README.md", ROOT / "freeze.py"]
    all_refs += [ref(path) for path in support_paths]
    index = {
        "schema": "c17-ab-owned-listener-text-port-v1",
        "status": "prepared_static_not_executed",
        "source_index": ref(CDP / "INDEX.json"),
        "outputs": changes,
        "references": all_refs,
        "output_count": 3,
        "unchanged": [ref(support_paths[0]), ref(support_paths[1])],
        "pure_python_tests": {"command": "python3 -I -B -m unittest discover -s tests -p test_render_listener_port.py -v",
                              "observed_exit_code": 0, "observed_tests": 6},
        "js_tests": "prepared_not_executed",
        "native_runtime": "not_executed",
        "admission": False,
        "full": False,
    }
    emit(ROOT / "INDEX.json", json.dumps(index, ensure_ascii=False, indent=2) + "\n")


if __name__ == "__main__":
    main()
