# Port owned-listener A/B, préparation statique

Ce lot dérive exactement trois textes, sans les consommer dans une ronde :
`complements/instruments/ownership-only.mjs`, `trace-chrome.mjs` et
`runtime/couverture-ecran-c17.mjs`. Le gel CDP d'origine est
`/private/tmp/therese-c17-ab-direct-cdp-n4yu8cV6/INDEX.json` ; ses anciennes
définitions C16 et sa preview ne sont ni des résultats A/B ni une autorité.

Le port retire le `lsof` Node local de `ownership-only` et conserve l'API
effectivement appelée `verifierListenerPossede(port)`. Les anciens exports
`validerScanListener` et `creerVerificationListener` ne sont référencés par
aucun autre fichier du gel ; ils sont supprimés parce qu'ils ne valident que
le PID textuel d'un `lsof` non attribué. Le seul `lsof` admissible reste celui
du parent Session déjà préparé, qui fait deux scans globaux et contrôle la
birth, l'UID, le PGID et la filiation. Le helper `aux_node.mjs` ne change pas ;
il coalesce seulement les demandes concurrentes en vol, sans TTL entre deux
requêtes successives. Absence, tiers, divergence, délai ou réponse invalide
restent des refus, jamais une autorisation déduite d'un ancien reçu.

`contexte-v3.mjs` n'est pas édité. Son `await ownershipReady`, puis
`await verifierListener`, puis `fetchOriginal` reste l'ordre des cinq sites
complémentaires. Les trois recettes runtime et la couverture n'importent pas
ce contexte ; leur preload de trace, déjà commun aux neuf sites directs,
attend désormais le même rendez-vous avant chaque `fetch` Node de ces quatre
stages. Le helper écran partagé attend ce rendez-vous après sa politique
URL/verbe et avant tout `route.continue` HTTP ou `connectToServer` WebSocket.
Les refus avortent la route et restent dans la garde existante. Les autres
oracles, options Chrome, gestes, écrans, thèmes, largeurs, dénominateurs et
bornes ne sont pas modifiés.

Le renderer `render_listener_port.py` est pur : il accepte trois textes et
leurs SHA/bytes, plus le contexte et le helper inchangés, applique seulement
les ancres fermées, et renvoie trois textes. La preview locale emploie le
texte CDP figé pour `trace-chrome.mjs`. La composition future doit être
CDP → Git → listener, avec SHA explicites des trois véritables entrées après
Git ; si Git modifie l'une de ces préimages, ce renderer refuse et un nouveau
delta/revue est nécessaire. Il ne fait aucun rendu QA A/B implicite. En
particulier la couverture d'origine porte encore `17493`, l'ancien checkout
et l'ancien import Playwright : la préparation A/B effective devra rendre et
épingle ces valeurs dans un lot distinct avant lancement. Aucun ancien
succès listener n'est réétiqueté.

Les tests Python sont des contrôles purs de trois sorties, SHA, ancres et
ordre ; leur sortie réelle a été lue : 6 tests, exit 0. Le fichier
`tests/pure_listener_cases.mjs` prépare les contre-épreuves JS mais n'a pas
été exécuté ici : zéro émission si le rendez-vous refuse, deux observations
séquentielles, partage d'une observation seulement durant une concurrence,
absence de TTL, refus port tiers/birth divergente et garde HTTP/WS. Il ne
prouve ni noyau, ni hardlinks, ni vrai navigateur. Aucun Node, G1, service,
Chrome, port, profil utilisateur, admission A/B ou FULL n'a été lancé par ce
lot. Les tables restent neuf directs plus cinq enfants RPC ; les 27 étapes
et 78 obligations ne changent pas.

Les trois diffs avant/après et leurs inverses sont dans `diffs/`, chacun
relié à une préimage et une sortie SHA/bytes dans `INDEX.json`. `freeze.py`
génère uniquement ces dérivés, avec création exclusive ; il ne publie rien
dans le dépôt ni dans un dossier de ronde.
