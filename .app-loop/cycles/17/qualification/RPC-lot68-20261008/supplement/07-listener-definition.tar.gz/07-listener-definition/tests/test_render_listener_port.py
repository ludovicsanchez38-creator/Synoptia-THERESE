"""Contrôles purs du port, sans import Node, G1, navigateur ni socket."""
from __future__ import annotations

import importlib.util
from hashlib import sha256
from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[1]
MODULE = ROOT / "render_listener_port.py"
SPEC = importlib.util.spec_from_file_location("render_listener_port", MODULE)
assert SPEC and SPEC.loader
renderer = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(renderer)

PATHS = {
    "complements/instruments/ownership-only.mjs": "ownership-only.mjs",
    "trace-chrome.mjs": "trace-chrome.mjs",
    "runtime/couverture-ecran-c17.mjs": "couverture-ecran-c17.mjs",
}
CDP = Path("/private/tmp/therese-c17-ab-direct-cdp-n4yu8cV6/preimages-complete")


def ref(value: str) -> dict[str, object]:
    raw = value.encode()
    return {"sha256": sha256(raw).hexdigest(), "bytes": len(raw)}


class PortTest(unittest.TestCase):
    def setUp(self) -> None:
        self.definitions = {name: (ROOT / "preimages" / file).read_text()
                            for name, file in PATHS.items()}
        self.source_refs = {name: ref(value) for name, value in self.definitions.items()}
        self.helper = (CDP / "aux_node.mjs").read_text()
        self.context = (CDP / "contexte-v3.mjs").read_text()

    def render(self, *, definitions=None, refs=None, helper=None, context=None):
        helper = self.helper if helper is None else helper
        context = self.context if context is None else context
        return renderer.render(
            self.definitions if definitions is None else definitions,
            self.source_refs if refs is None else refs,
            helper_source=helper, helper_ref=ref(self.helper),
            context_source=context, context_ref=ref(context),
        )

    def test_three_outputs_equal_byte_exact_candidates(self) -> None:
        outputs = self.render()
        self.assertEqual(set(outputs), set(PATHS))
        for name, value in outputs.items():
            self.assertEqual(value.encode(), (ROOT / "candidate" / name).read_bytes())

    def test_sources_and_context_not_rewritten(self) -> None:
        before = dict(self.definitions)
        self.render()
        self.assertEqual(self.definitions, before)
        self.assertEqual((CDP / "contexte-v3.mjs").read_text(), self.context)
        self.assertIn("await ownershipReady;\n    await verifierListener(Number(u.port));\n    return fetchOriginal", self.context)

    def test_order_and_existing_oracles_are_intact(self) -> None:
        outputs = self.render()
        trace = outputs["trace-chrome.mjs"]
        self.assertLess(trace.index("await requestOwnedListener(Number(url.port))"),
                        trace.index("return fetchOriginal(input,options)"))
        coverage = outputs["runtime/couverture-ecran-c17.mjs"]
        self.assertLess(coverage.index("await requestOwnedListener(Number(new URL(requete.url()).port))"),
                        coverage.index("return route.continue()"))
        self.assertLess(coverage.index("await requestOwnedListener(5173)"),
                        coverage.index("return route.connectToServer()"))
        self.assertIn("const PLAFOND_GESTES_PAR_ECRAN = Number.POSITIVE_INFINITY;", coverage)
        self.assertIn("const BASE_JETABLE = 'http://127.0.0.1:5173/?port=17493';", coverage)
        self.assertIn("return url.origin === ORIGINE_BACKEND && methode === 'POST'", coverage)
        self.assertNotIn("node:child_process", outputs["complements/instruments/ownership-only.mjs"])
        self.assertNotIn("/usr/sbin/lsof", "\n".join(outputs.values()))

    def test_stale_or_unpinned_preimages_refused(self) -> None:
        value = dict(self.definitions)
        value["trace-chrome.mjs"] += "// autre source\n"
        with self.assertRaises(renderer.Refused):
            self.render(definitions=value)
        refs = dict(self.source_refs)
        refs["trace-chrome.mjs"] = {"sha256": "0" * 64, "bytes": 1}
        with self.assertRaises(renderer.Refused):
            self.render(refs=refs)
        value = dict(self.definitions)
        value.pop("trace-chrome.mjs")
        with self.assertRaises(renderer.Refused):
            self.render(definitions=value)

    def test_context_order_or_helper_changed_refused(self) -> None:
        context = self.context.replace("await verifierListener(Number(u.port));", "// garde retirée")
        with self.assertRaises(renderer.Refused):
            self.render(context=context)
        with self.assertRaises(renderer.Refused):
            self.render(helper=self.helper + "// autre helper\n")

    def test_duplicate_or_prepatched_anchor_refused(self) -> None:
        with self.assertRaises(renderer.Refused):
            renderer.once("a a", "a", "b")
        with self.assertRaises(renderer.Refused):
            renderer.once("b", "a", "c")


if __name__ == "__main__":
    unittest.main()
