// Préparation documentaire seulement. Aucun processus, réseau, import G1 ou lancement.
import fs from 'node:fs';
import crypto from 'node:crypto';
const out='/private/tmp/therese-c17-root-fresh8-authority-gpmq3Ovf';
const root='/private/tmp/therese-c17-wrapper-canary-2cf6bb68852b436796a525f4eb356573';
const currentHead='727578fe63beb7dc047e9d0a8d94af5764b36d3b';
const head='2d69e30c9c6dd18823ee6102271876003a6a67cc';
const need=(x,m)=>{if(!x)throw Error(m)};
need(fs.realpathSync(out)===out&&fs.lstatSync(out).uid===process.getuid()
  &&(fs.lstatSync(out).mode&0o077)===0&&fs.readdirSync(out).join(',')==='prepare-authority.mjs'
  &&!fs.existsSync(root),'Dossier neuf privé et future racine absente requis');
const ref=p=>{const s=fs.lstatSync(p),b=fs.readFileSync(p);need(s.isFile()&&!s.isSymbolicLink()&&fs.realpathSync(p)===p&&s.uid===process.getuid(),'Ref non canonique');return {path:p,sha256:crypto.createHash('sha256').update(b).digest('hex'),bytes:b.length};};
const checked=(p,sha,bytes)=>{const r=ref(p);need(r.sha256===sha&&r.bytes===bytes,'Input divergent '+p);return r;};
const save=(n,j)=>{fs.writeFileSync(out+'/'+n,JSON.stringify(j,null,2)+'\n',{flag:'wx',mode:0o600});return ref(out+'/'+n);};
const chrome=checked('/private/tmp/therese-c17-fresh-wrapper-builder-v7-cnR8Hm/profile/chrome.sb','c9101b2a356679057f3e116c72a2546f51e851ee997e404c6120cb59627580e8',1949);
const runner=checked('/private/tmp/therese-c17-test-runner-boundary-eUIHsp/INDEX.json','771565210b1ab41ca7e5a43c89fa63a034c57872515a698a12161e47adfe11b7',5567);
const registry=save('identity-registry.json',{schema:'c17-wrapper-canary-live-identity-registry-v1',round_id:root.split('/').at(-1),head,repo_head_observed:currentHead,historical_product_source_instrument_only:true,chrome_profile_ref:chrome,runner_boundary_index_ref:runner,actors:[{actor:'/root',observed_by:'collaboration.list_agents root running observed in actual execution immediately before this tool',observed_at_utc:new Date().toISOString(),role:'root orchestrateur, aucun PID futur ni ancien reviewer relabellé'}],OS_qualified:false,FULL:false,release:false});
const go={schema:'c17-root-fresh-wrapper-preparation-go-v1',status:'go_prepare_only',scope:'WRAPPER_CANARY',actor:'/root',root,head,repo_head_observed:currentHead,historical_source_WRAPPER_only_not_current_FULL:true,product_source_root:'/private/tmp/therese-c17-wrapper-source-kGvU1hdx/source',origin_kind:'root_tool_call',
  builder_ref:checked('/private/tmp/therese-c17-fresh-wrapper-builder-v8-pB5tPP/build_fresh_wrapper.py','5722336533fbecaa150e5aca1254e8dcce5f16afb5974952493c4752a0163012',69530),
  builder_index_ref:checked('/private/tmp/therese-c17-fresh-wrapper-builder-v8-pB5tPP/INDEX.json','278e5a8a9a0aa1cca8c2de02b9278c417416615ac8be492457a583516b2537ca',13620),
  web_profile_ref:checked('/private/tmp/therese-c17-web-root-metadata-POjxSafe/web.sb','51ff2e21500393704ea8709fb9bd177dc1f88793d1e92d09c68be70d905807ff',1780),chrome_profile_ref:chrome,runner_boundary_index_ref:runner,identity_registry_ref:registry,
  gpu_observation_ref:checked('/private/tmp/therese-c17-wrapper-canary-ea92e9f2c3a9485a88dc906c302f42ff/proofs/system-profiler-displays.raw','92d6e897ef52659540e9497649283da5bd4ff4c443c5d0d07f50bbb37d5bc4d0',186),gpu_observation_historical_only_not_native_qualification:true,
  pure_replay_ref:checked('/private/tmp/therese-c17-root-v8-62-replay2-O8OJJHON/receipt.json','fea5b4f1656b8d2178d2c201218e836b406bffd19fe83bba4ca3d119d5a9f8da',58227),
  chrome_qa_copy_ref:checked('/private/tmp/therese-c17-chrome-qa-copy-RoZmwsja/v3-receipt.json','f97793cb43454051da734685185cb5d4e5b5ffbabc516580287195ef3d32993c',17160),
  chrome_spctl_assessment_ref:checked('/private/tmp/therese-c17-chrome-policy-assess-WyJvs5Z0/receipt.json','92dbaaed5278671635b2a0d35f8cb4362ea99b589f0892a180c512fd48932c44',1346),
  independent_static_review_ref:checked('/private/tmp/therese-c17-root-fresh7-authority-bwVCOroK/V8-REVIEW-OBSERVATION.md','26fc432b7169be40b1ea726316347d2f10cca20df6e2f4e1c1eb5b9246ebaeaf',1069),independent_static_review_received:true,
  preparation_script_ref:ref(out+'/prepare-authority.mjs'),authority_is_exact_next_external_preparation_tool_not_this_JSON:true,native_runtime_GO_still_required:true,FULL:false,release:false};
const authority=save('prepare-go.json',go);
console.log(JSON.stringify({root,registry_ref:registry,authority_ref:authority,prepared_only:true,native:false,FULL:false,release:false}));
