"""Contrôleur préparatoire : un parent C direct et son unique enfant fork.

`activate` refuse toujours. Le runner relu doit appeler `_drive` avec le type
exact NativePort ; ce module seul ne crée aucun enfant.
"""

from __future__ import annotations

import json
import math
import errno
import os
import re
import signal
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Protocol

NATIVE_MEASUREMENT_ENABLED = False
CASES = frozenset(("fork-baseline", "fork-compiled-alpha"))
IDENTITY = ("pid", "ppid", "uid", "pgid", "start_sec", "start_usec")
READY_SCHEMA = "c17-seatbelt-composition-ready-v1"
RELEASE_SCHEMA = "c17-seatbelt-composition-release-v1"
RELEASED_SCHEMA = "c17-seatbelt-composition-gate-released-v1"
READY_KEYS = frozenset(("schema", "case", "nonce", *IDENTITY))
FORK_READY_SCHEMA = "c17-seatbelt-inheritance-child-ready-v1"
FORK_RELEASE_SCHEMA = "c17-seatbelt-inheritance-child-release-v1"
FORK_RELEASED_SCHEMA = "c17-seatbelt-inheritance-child-released-v1"
FORK_KEYS = frozenset(("schema", "case", "nonce", "pid", "ppid", "uid", "pgid"))
GATE_SECONDS = 5.0
FORK_GATE_SECONDS = 5.0
CASE_SECONDS = 5.0
CLEANUP_SECONDS = 8.0
TERM_GRACE_SECONDS = 1.0
TERMINAL_REAP_SECONDS = 28.0


def require(ok: bool, reason: str) -> None:
    if not ok:
        raise ValueError(reason)


@dataclass(frozen=True)
class Plan:
    root: Path
    binary: Path
    cwd: Path
    stdout_path: Path
    stderr_path: Path
    case: str
    nonce: str
    environment: dict[str, str]
    source_refs: tuple[dict[str, Any], ...]

    def validate(self) -> None:
        require(self.case in CASES, "cas hors table")
        require(type(self.nonce) is str and re.fullmatch(r"[0-9a-f]{32}", self.nonce) is not None,
                "nonce invalide")
        require(all(isinstance(p, Path) and p.is_absolute() for p in
                    (self.root, self.binary, self.cwd, self.stdout_path, self.stderr_path)),
                "chemins absolus requis")
        require(self.binary.is_relative_to(self.root) and self.cwd.is_relative_to(self.root),
                "binaire/cwd hors QA")
        require(self.stdout_path.is_relative_to(self.root) and self.stderr_path.is_relative_to(self.root)
                and self.stdout_path != self.stderr_path and self.stdout_path.name == "stdout.log"
                and self.stderr_path.name == "stderr.log", "sinks QA distincts")
        require(type(self.environment) is dict and self.environment == {
            "HOME": str(self.root / "home"),
            "TMPDIR": str(self.root / "tmp") + "/",
            "PATH": "/usr/bin:/bin",
        }, "environnement synthétique non fermé")
        require(type(self.source_refs) is tuple and len(self.source_refs) > 0,
                "préimages exactes requises")
        require(any(type(ref) is dict and ref.get("path") == str(self.binary)
                    and type(ref.get("bytes")) is int and type(ref.get("sha256")) is str
                    for ref in self.source_refs), "binaire non épinglé")

    def argv(self) -> tuple[str, ...]:
        self.validate()
        return (str(self.binary), "--reviewed-case", self.case, "--gate-nonce", self.nonce)


def identity(row: dict[str, Any], *, expected_binary: str | None = None) -> tuple[int, ...]:
    require(type(row) is dict and all(type(row.get(k)) is int for k in IDENTITY),
            "naissance libproc incomplète")
    require(row["pid"] > 1 and row["ppid"] > 0 and row["uid"] >= 0 and row["pgid"] > 0
            and row["start_sec"] > 0 and 0 <= row["start_usec"] < 1_000_000,
            "naissance libproc invalide")
    # BSD SRUN=2, SSLEEP=3. SIDL/SSTOP/SZOMB ne sont pas une gate vivante.
    require(type(row.get("status")) is int and row["status"] in (2, 3),
            "statut non vivant/incertain")
    if expected_binary is not None:
        require(row.get("executable") == expected_binary, "exécutable différent")
    return tuple(row[k] for k in IDENTITY)


def parse_ready(raw: bytes, plan: Plan, owner: dict[str, Any], child: dict[str, Any]) -> None:
    require(type(raw) is bytes and len(raw) <= 512 and raw.endswith(b"\n")
            and raw.count(b"\n") == 1, "ready non borné ou incomplet")

    def unique(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for key, value in pairs:
            require(key not in result, "clé ready dupliquée")
            result[key] = value
        return result

    row = json.loads(raw.decode("ascii"), object_pairs_hook=unique)
    require(type(row) is dict and frozenset(row) == READY_KEYS, "schéma ready divergent")
    require(row["schema"] == READY_SCHEMA and row["case"] == plan.case
            and row["nonce"] == plan.nonce, "ready cas/nonce divergent")
    require(all(type(row[k]) is int and row[k] == child[k] for k in IDENTITY),
            "ready naissance divergente")
    require(child["ppid"] == owner["pid"] and child["uid"] == owner["uid"]
            and child["pgid"] == child["pid"], "filiation/UID/PGID divergents")


def release_bytes(plan: Plan, child: dict[str, Any]) -> bytes:
    row = {"schema": RELEASE_SCHEMA, "case": plan.case, "nonce": plan.nonce,
           "pid": child["pid"], "start_sec": child["start_sec"],
           "start_usec": child["start_usec"]}
    return json.dumps(row, separators=(",", ":"), ensure_ascii=True).encode("ascii") + b"\n"


def parse_released(raw: bytes, plan: Plan, child: dict[str, Any]) -> None:
    require(type(raw) is bytes and len(raw) <= 512 and raw.endswith(b"\n")
            and raw.count(b"\n") == 1, "ACK gate incomplet")
    def unique(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
        row: dict[str, Any] = {}
        for key, value in pairs:
            require(key not in row, "ACK gate clé dupliquée")
            row[key] = value
        return row

    row = json.loads(raw.decode("ascii"), object_pairs_hook=unique)
    require(type(row) is dict and frozenset(row) == frozenset(
        ("schema", "case", "nonce", "pid", "start_sec", "start_usec")),
        "ACK gate champs divergents")
    require(all(type(row[k]) is int for k in ("pid", "start_sec", "start_usec")),
            "ACK gate entiers stricts requis")
    expected = {"schema": RELEASED_SCHEMA, "case": plan.case, "nonce": plan.nonce,
                "pid": child["pid"], "start_sec": child["start_sec"],
                "start_usec": child["start_usec"]}
    require(row == expected and raw == json.dumps(expected, separators=(",", ":"),
                                              ensure_ascii=True).encode("ascii") + b"\n",
            "ACK gate octets compacts exacts divergents")


def _closed_line(raw: bytes, *, limit: int = 512) -> dict[str, Any]:
    require(type(raw) is bytes and len(raw) <= limit and raw.endswith(b"\n")
            and raw.count(b"\n") == 1, "ligne protocolaire incomplète/non bornée")
    def unique(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
        row: dict[str, Any] = {}
        for key, value in pairs:
            require(key not in row, "clé protocolaire dupliquée")
            row[key] = value
        return row
    row = json.loads(raw.decode("ascii"), object_pairs_hook=unique)
    require(type(row) is dict, "ligne protocolaire non objet")
    return row


def parse_fork_ready(raw: bytes, plan: Plan) -> dict[str, Any]:
    """Déclaration du parent C après close(FD0), jamais une birth prouvée."""
    row = _closed_line(raw)
    require(frozenset(row) == FORK_KEYS and row["schema"] == FORK_READY_SCHEMA
            and row["case"] == plan.case and row["nonce"] == plan.nonce,
            "child-ready autre cas/nonce/champs")
    require(all(type(row[key]) is int for key in ("pid", "ppid", "uid", "pgid"))
            and row["pid"] > 1 and row["ppid"] > 1 and row["uid"] >= 0
            and row["pgid"] > 0, "child-ready entiers candidats invalides")
    return row


def parse_outer_apply(raw: bytes, direct: dict[str, Any], owner: dict[str, Any]) -> None:
    row = _closed_line(raw)
    require(frozenset(row) == frozenset(("event", "pid", "ppid", "uid", "rc",
                                        "errno", "diagnostic_only", "error"))
            and row["event"] == "outer_apply"
            and all(type(row[key]) is int for key in ("pid", "ppid", "uid", "rc", "errno"))
            and row["pid"] == direct["pid"] and row["ppid"] == owner["pid"]
            and row["uid"] == direct["uid"] and row["rc"] == 0
            and row["diagnostic_only"] is True and row["error"] == "",
            "OUTER parent non appliqué proprement")


def parse_parent_witness(raw: bytes, label: str) -> None:
    """Deux lectures du parent C après OUTER, avant tout fork."""
    require(label in ("A", "B"), "témoin parent hors table")
    row = _closed_line(raw)
    require(frozenset(row) == frozenset(("event", "phase", "witness", "open_ok",
                                        "open_errno", "read_count", "read_errno",
                                        "close_errno", "content_matches",
                                        "diagnostic_only", "native_qualification"))
            and row["event"] == "witness_read" and row["phase"] == "parent_outer"
            and row["witness"] == label and row["diagnostic_only"] is True
            and row["native_qualification"] is False
            and type(row["open_ok"]) is bool
            and type(row["content_matches"]) is bool
            and all(type(row[key]) is int for key in
                    ("open_errno", "read_count", "read_errno", "close_errno")),
            "témoin parent divergent")
    if label == "A":
        require(row["open_ok"] is True and row["open_errno"] == 0
                and row["read_count"] == 1 and row["read_errno"] == 0
                and row["close_errno"] == 0 and row["content_matches"] is True,
                "A parent non lisible exactement")
    else:
        require(row["open_ok"] is False and row["open_errno"] in (errno.EPERM, errno.EACCES)
                and row["read_count"] == -1 and row["read_errno"] == 0
                and row["close_errno"] == 0 and row["content_matches"] is False,
                "B parent non refusé explicitement")


def attribute_grandchild(port: Port, declared: dict[str, Any], direct: dict[str, Any],
                         plan: Plan) -> dict[str, Any]:
    candidate = port.read_identity(declared["pid"])
    identity(candidate, expected_binary=str(plan.binary))
    require(candidate["pid"] != direct["pid"] and direct["pgid"] == direct["pid"]
            and candidate["ppid"] == direct["pid"]
            and candidate["uid"] == direct["uid"]
            and candidate["pgid"] == direct["pgid"]
            and all(candidate[key] == declared[key]
                    for key in ("pid", "ppid", "uid", "pgid")),
            "grandchild non attribué ou déclaration divergente")
    return candidate


def fork_release_bytes(plan: Plan, grandchild: dict[str, Any]) -> bytes:
    row = {"schema": FORK_RELEASE_SCHEMA, "case": plan.case, "nonce": plan.nonce,
           **{key: grandchild[key] for key in ("pid", "ppid", "uid", "pgid")}}
    return json.dumps(row, separators=(",", ":"), ensure_ascii=True).encode("ascii") + b"\n"


def parse_fork_released(raw: bytes, plan: Plan, grandchild: dict[str, Any]) -> None:
    row = _closed_line(raw)
    expected = {"schema": FORK_RELEASED_SCHEMA, "case": plan.case,
                "nonce": plan.nonce,
                **{key: grandchild[key] for key in ("pid", "ppid", "uid", "pgid")}}
    require(frozenset(row) == FORK_KEYS
            and all(type(row[key]) is int for key in ("pid", "ppid", "uid", "pgid"))
            and row == expected
            and raw == json.dumps(expected, separators=(",", ":"),
                                  ensure_ascii=True).encode("ascii") + b"\n",
            "ACK2 exact divergent ; il ne prouve pas une naissance")


def parse_child_waitpid(raw: bytes, grandchild: dict[str, Any]) -> dict[str, Any]:
    row = _closed_line(raw)
    require(frozenset(row) == frozenset(("event", "pid", "wait_status", "exit_code",
                                        "signal", "reaped", "deadline_met"))
            and row["event"] == "child_waitpid" and type(row["pid"]) is int
            and row["pid"] == grandchild["pid"] and type(row["exit_code"]) is int
            and type(row["wait_status"]) is int and type(row["signal"]) is int
            and type(row["reaped"]) is bool and row["reaped"] is True
            and type(row["deadline_met"]) is bool,
            "waitpid child non prouvé par parent C")
    status = row["wait_status"]
    require(status >= 0 and (os.WIFEXITED(status) or os.WIFSIGNALED(status)),
            "waitpid statut non terminal")
    if os.WIFEXITED(status):
        require(row["exit_code"] == os.WEXITSTATUS(status) and row["signal"] == 0,
                "waitpid sortie/code incohérents")
    else:
        child_signal = os.WTERMSIG(status)
        require(row["signal"] == child_signal and row["exit_code"] == -child_signal,
                "waitpid signal/code incohérents")
    return row


class Port(Protocol):
    def now(self) -> float: ...
    def self_pid(self) -> int: ...
    def read_identity(self, pid: int) -> dict[str, Any]: ...
    def verify_sources(self, refs: tuple[dict[str, Any], ...]) -> bool: ...
    def open_sinks(self, plan: Plan) -> Any: ...
    def spawn(self, plan: Plan, sinks: Any) -> Any: ...
    def read_ready(self, handle: Any, sinks: Any, deadline: float) -> bytes: ...
    def read_gate_released(self, handle: Any, sinks: Any, deadline: float) -> bytes: ...
    def read_outer_apply(self, handle: Any, sinks: Any, deadline: float) -> bytes: ...
    def read_parent_witness(self, handle: Any, sinks: Any, deadline: float,
                            label: str) -> bytes: ...
    def read_fork_ready(self, handle: Any, sinks: Any, deadline: float) -> bytes: ...
    def read_fork_released(self, handle: Any, sinks: Any, deadline: float) -> bytes: ...
    def read_child_waitpid(self, handle: Any, sinks: Any) -> bytes: ...
    def release(self, handle: Any, payload: bytes) -> None: ...
    def close_gate(self, handle: Any) -> None: ...
    def poll(self, handle: Any) -> int | None: ...
    def wait_until(self, handle: Any, deadline: float) -> int | None: ...
    def signal_pid(self, pid: int, sig: signal.Signals) -> None: ...
    def close_sinks(self, sinks: Any) -> bool: ...


def _same_live(port: Port, owner: dict[str, Any], child: dict[str, Any],
               plan: Plan) -> bool:
    """Lecture fraîche avant release ou signal ; erreur = incertitude."""
    try:
        same_owner = identity(port.read_identity(owner["pid"]),
                              expected_binary=owner["executable"]) == identity(owner)
        same_child = identity(port.read_identity(child["pid"]),
                              expected_binary=str(plan.binary)) == identity(child)
        return same_owner and same_child
    except BaseException:
        # Pendant un signal aussi, l'interruption ou une lecture partielle
        # interdit d'adopter le PID comme cible sûre.
        return False


def _same_fork_tree(port: Port, owner: dict[str, Any], direct: dict[str, Any],
                    grandchild: dict[str, Any], plan: Plan) -> bool:
    """Aucune adoption d'un PID reparenté ou d'une autre naissance."""
    try:
        return (_same_live(port, owner, direct, plan)
                and identity(port.read_identity(grandchild["pid"]),
                             expected_binary=str(plan.binary)) == identity(grandchild)
                and grandchild["ppid"] == direct["pid"]
                and grandchild["pgid"] == direct["pgid"] == direct["pid"])
    except BaseException:
        return False


def _drive(plan: Plan, port: Port) -> dict[str, Any]:
    """Parent C direct, puis unique fork attribué avant sa seconde libération."""
    from native_port import NativePort

    require(NATIVE_MEASUREMENT_ENABLED and type(port) is NativePort,
            "NativePort exact requis pour cette mesure")
    plan.validate()
    started = port.now()
    require(type(started) in (int, float) and math.isfinite(started) and started >= 0,
            "horloge monotone invalide")
    gate1_deadline = started + GATE_SECONDS
    terminal_reap_deadline = started + TERMINAL_REAP_SECONDS
    fork_deadline: float | None = None
    case_deadline: float | None = None
    owner = port.read_identity(port.self_pid())
    identity(owner)
    require(type(owner.get("executable")) is str and owner["executable"].startswith("/"),
            "exécutable parent inconnu")
    sinks = handle = direct = grandchild = None
    parent_released = parent_confirmed = outer_observed = False
    parent_witnesses_observed = False
    child_released = child_confirmed = gate_closed = False
    direct_reaped = child_reaped_by_parent = stable = sources_unchanged = False
    returncode: int | None = None
    child_final: dict[str, Any] | None = None
    errors: list[str] = []
    signals: list[str] = []
    try:
        require(port.verify_sources(plan.source_refs), "préimages modifiées avant Popen")
        sinks = port.open_sinks(plan)
        require(port.now() <= gate1_deadline, "gate expiré avant Popen")
        handle = port.spawn(plan, sinks)
        # Le PID Popen n'est pas une naissance. Attribution native avant ready1.
        candidate = port.read_identity(handle.pid)
        identity(candidate, expected_binary=str(plan.binary))
        require(candidate["pid"] == handle.pid
                and candidate["ppid"] == owner["pid"] and candidate["uid"] == owner["uid"]
                and candidate["pgid"] == candidate["pid"], "enfant non attribué")
        direct = candidate
        raw = port.read_ready(handle, sinks, gate1_deadline)
        parse_ready(raw, plan, owner, direct)
        require(port.now() <= gate1_deadline, "gate dépassé")
        require(port.poll(handle) is None and _same_live(port, owner, direct, plan),
                "parent C changé avant release1")
        require(port.verify_sources(plan.source_refs), "préimages modifiées avant release")
        require(port.poll(handle) is None and _same_live(port, owner, direct, plan)
                and port.now() <= gate1_deadline,
                "gate1/naissance expirée après rehash, avant release")
        port.release(handle, release_bytes(plan, direct))
        parent_released = True
        parse_released(port.read_gate_released(handle, sinks, gate1_deadline),
                       plan, direct)
        require(port.now() <= gate1_deadline, "ACK gate hors borne")
        parent_confirmed = True

        # Nouvelle fenêtre fixe : OUTER, fork et ready2 doivent tenir ensemble.
        fork_deadline = port.now() + FORK_GATE_SECONDS
        parse_outer_apply(port.read_outer_apply(handle, sinks, fork_deadline), direct, owner)
        outer_observed = True
        parse_parent_witness(port.read_parent_witness(handle, sinks, fork_deadline, "A"), "A")
        parse_parent_witness(port.read_parent_witness(handle, sinks, fork_deadline, "B"), "B")
        require(port.now() <= fork_deadline, "témoins parent hors fenêtre5")
        parent_witnesses_observed = True
        declared = parse_fork_ready(port.read_fork_ready(handle, sinks, fork_deadline), plan)
        require(port.now() <= fork_deadline and port.poll(handle) is None
                and _same_live(port, owner, direct, plan),
                "parent C mort/changé avant attribution fork")
        # La déclaration C n'est qu'un indice PID, jamais une adoption du child.
        candidate = attribute_grandchild(port, declared, direct, plan)
        grandchild = candidate
        require(port.verify_sources(plan.source_refs), "préimages modifiées avant release2")
        require(port.poll(handle) is None
                and _same_fork_tree(port, owner, direct, grandchild, plan)
                and port.now() <= fork_deadline,
                "arbre fork changé ou fenêtre5 expirée avant release2")
        port.release(handle, fork_release_bytes(plan, grandchild))
        child_released = True
        parse_fork_released(port.read_fork_released(handle, sinks, fork_deadline),
                            plan, grandchild)
        require(port.now() <= fork_deadline, "ACK2 hors fenêtre5")
        child_confirmed = True
        port.close_gate(handle)
        gate_closed = True
        case_deadline = port.now() + CASE_SECONDS
        returncode = port.wait_until(handle, case_deadline)
        require(type(returncode) is int, "cas enfant expiré/code non entier")
        direct_reaped = True
        child_final = parse_child_waitpid(
            port.read_child_waitpid(handle, sinks), grandchild)
        child_reaped_by_parent = True
        require(returncode == 0 and child_final["exit_code"] == 0
                and child_final["wait_status"] == 0 and child_final["signal"] == 0
                and child_final["deadline_met"] is True,
                f"sonde parent/child exits {returncode}/{child_final['exit_code']}")
    except (Exception, KeyboardInterrupt, SystemExit) as exc:
        errors.append(f"{type(exc).__name__}:{exc}")
    finally:
        cleanup_start = port.now()
        cleanup_deadline = cleanup_start + CLEANUP_SECONDS
        if handle is not None:
            if not gate_closed:
                try:
                    # Writer fermé : sans release2, l'enfant gated lit EOF/timeout.
                    port.close_gate(handle)
                except Exception as exc:
                    errors.append(f"close_gate:{type(exc).__name__}:{exc}")
            if not direct_reaped:
                try:
                    waited = port.wait_until(handle, min(cleanup_deadline, cleanup_start + GATE_SECONDS))
                    if waited is not None:
                        returncode, direct_reaped = waited, True
                except Exception as exc:
                    errors.append(f"wait_parent:{type(exc).__name__}:{exc}")
            if not direct_reaped and direct is not None and grandchild is not None:
                # C parent reste propriétaire du waitpid. MAIN ne cible que PID
                # grandchild après relecture intégrale, jamais son PGID.
                for sig in (signal.SIGTERM, signal.SIGKILL):
                    if port.now() >= cleanup_deadline:
                        break
                    try:
                        polled = port.poll(handle)
                    except BaseException as exc:
                        errors.append(f"poll incertain:{type(exc).__name__}:{exc}")
                        break
                    if polled is not None:
                        try:
                            waited = port.wait_until(handle, cleanup_deadline)
                            if waited is not None:
                                returncode, direct_reaped = waited, True
                        except Exception as exc:
                            errors.append(f"reap parent:{type(exc).__name__}:{exc}")
                        break
                    if not _same_fork_tree(port, owner, direct, grandchild, plan):
                        errors.append("arbre fork incertain : aucun signal supplémentaire")
                        break
                    if port.now() >= cleanup_deadline:
                        errors.append("cleanup8 expiré après relecture : aucun signal tardif")
                        break
                    try:
                        port.signal_pid(grandchild["pid"], sig)
                        signals.append(f"grandchild:{sig.name}")
                        grace_deadline = (min(cleanup_deadline, port.now() + TERM_GRACE_SECONDS)
                                          if sig == signal.SIGTERM else cleanup_deadline)
                        waited = port.wait_until(handle, grace_deadline)
                        if waited is not None:
                            returncode, direct_reaped = waited, True
                            break
                    except Exception as exc:
                        errors.append(f"signal/wait:{type(exc).__name__}:{exc}")
                        break
            if not direct_reaped:
                # Enfant inconnu ou reparenté : aucune cible adoptée, attente seule.
                try:
                    waited = port.wait_until(handle, cleanup_deadline)
                    if waited is not None:
                        returncode, direct_reaped = waited, True
                except Exception as exc:
                    errors.append(f"wait_uncertain:{type(exc).__name__}:{exc}")
            if not direct_reaped:
                # Queue terminale : le watchdog propre du parent C est 23 s
                # après son démarrage. Les 5 s de pré-Popen donnent une borne
                # absolue started+28, sans nouveau signal/release/mesure.
                # Une sortie au-delà cleanup8 reste rouge quoi qu'il arrive.
                try:
                    waited = port.wait_until(handle, terminal_reap_deadline)
                    if waited is not None:
                        returncode, direct_reaped = waited, True
                except Exception as exc:
                    errors.append(f"terminal_reap:{type(exc).__name__}:{exc}")
            if direct_reaped and grandchild is not None and not child_reaped_by_parent:
                try:
                    child_final = parse_child_waitpid(
                        port.read_child_waitpid(handle, sinks), grandchild)
                    child_reaped_by_parent = True
                except Exception as exc:
                    errors.append(f"waitpid child non prouvé:{type(exc).__name__}:{exc}")
        if sinks is not None:
            try:
                stable = port.close_sinks(sinks)
            except Exception as exc:
                errors.append(f"close_sinks:{type(exc).__name__}:{exc}")
        try:
            sources_unchanged = port.verify_sources(plan.source_refs)
            if not sources_unchanged:
                errors.append("préimages modifiées après fermeture")
        except Exception as exc:
            errors.append(f"rehash final:{type(exc).__name__}:{exc}")
        ended = port.now()
        elapsed_bound_met = (type(ended) in (int, float) and math.isfinite(ended)
                             and ended <= cleanup_deadline)
        if not elapsed_bound_met:
            errors.append("cleanup deadline dépassée")
        if handle is not None and not direct_reaped:
            errors.append("parent C non reaped")
        if grandchild is not None and not child_reaped_by_parent:
            errors.append("grandchild non reaped prouvé par parent C")
    termination_proved = (handle is not None and direct is not None and grandchild is not None
                          and direct_reaped and child_reaped_by_parent)
    cleanup_deadline_met = elapsed_bound_met and (handle is None or termination_proved)
    if handle is not None and not termination_proved:
        errors.append("cleanup non prouvé dans la borne8")
    clean = (termination_proved and stable and sources_unchanged and parent_confirmed
             and outer_observed and parent_witnesses_observed
             and child_confirmed and returncode == 0 and child_final is not None
             and child_final["exit_code"] == 0 and child_final["wait_status"] == 0
             and child_final["signal"] == 0
             and child_final["deadline_met"] is True
             and not errors and not signals and cleanup_deadline_met)
    return {"schema": "c17-seatbelt-controller-native-one-fork-v1", "case": plan.case,
            "owner": owner, "direct_parent": direct, "grandchild": grandchild,
            "parent_release_written": parent_released,
            "parent_release_confirmed": parent_confirmed,
            "outer_apply_observed": outer_observed,
            "parent_outer_witnesses_observed": parent_witnesses_observed,
            "child_release_written": child_released,
            "child_release_confirmed": child_confirmed,
            "direct_returncode": returncode, "child_waitpid": child_final,
            "grandchild_reaped_by_parent": child_reaped_by_parent,
            "signals": signals, "errors": errors,
            "termination_proved": termination_proved, "clean": clean,
            "source_refs_unchanged": sources_unchanged,
            "cleanup_deadline_met": cleanup_deadline_met,
            "gate1_deadline_monotonic": gate1_deadline,
            "fork_gate_deadline_monotonic": fork_deadline,
            "case_deadline_monotonic": case_deadline,
            "cleanup_deadline_monotonic": cleanup_deadline,
            "terminal_reap_deadline_monotonic": terminal_reap_deadline,
            "actual_native_IO": getattr(type(port), "ACTUAL_NATIVE_IO", False) is True,
            "native_parent_started": handle is not None,
            "FULL": False, "Chrome_qualified": False}


def activate(*_args: Any, **_kwargs: Any) -> None:
    raise RuntimeError("Mesure native désactivée ; nouvelle dérivation et GO requis")
