/* LOT77 MAIN synthetic fork-only diagnostic, scoped native derivation.
 * Exact LOT76 preimage 8de3afdd3eccc89c65e60b11794f35866c95d3ebed95afb322f5cbc8ecff4f38.
 * New OUTER_FORK is NOT G1 or LOT76 OUTER. One fork; no exec/network/Mach.
 * Private API ABI and post-fork library safety are not general guarantees.
 * Only a separately reviewed MAIN supervisor may activate/compile/run later.
 */
#define _DARWIN_C_SOURCE 1 /* SDK declarations, not a policy or API activation. */
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <inttypes.h>
#include <libproc.h>
#include <poll.h>
#include <signal.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <sys/proc.h>
#include <sys/proc_info.h>
#include <time.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

static const bool NATIVE_MEASUREMENT_ENABLED = true;
static const char QA_ROOT[] = "/private/tmp/therese-c17-inheritance-main-Pkcez7OG";

/* Private APIs: declarations alone provide no support/composition guarantee. */
typedef struct sandbox_params_t sandbox_params_t;
typedef struct { char *builtin; const uint8_t *data; size_t size; } sandbox_profile_t;
extern sandbox_params_t *sandbox_create_params(void);
extern int sandbox_set_param(sandbox_params_t *, const char *, const char *);
extern void sandbox_free_params(sandbox_params_t *);
extern sandbox_profile_t *sandbox_compile_string(const char *, sandbox_params_t *, char **);
extern int sandbox_apply(sandbox_profile_t *);
extern void sandbox_free_profile(sandbox_profile_t *);
extern void sandbox_free_error(char *);
extern int sandbox_init_with_parameters(const char *, uint64_t, const char *const *, char **);
extern int sandbox_check(pid_t, const char *, int, ...);

static const char OUTER_FORK[] =
    "(version 1)\n"
    "(deny default)\n"
    "(allow file-read-metadata (literal \"/private/tmp/therese-c17-inheritance-main-Pkcez7OG/witnesses/a.txt\") (literal \"/private/tmp/therese-c17-inheritance-main-Pkcez7OG/witnesses/b.txt\"))\n"
    "(allow file-read-data (literal \"/private/tmp/therese-c17-inheritance-main-Pkcez7OG/witnesses/a.txt\"))\n"
    "(allow process-fork)\n";
static const char ALPHA[] =
    "(version 1)\n"
    "(deny default)\n"
    "(allow file-read-metadata (literal \"/private/tmp/therese-c17-inheritance-main-Pkcez7OG/witnesses/a.txt\") (literal \"/private/tmp/therese-c17-inheritance-main-Pkcez7OG/witnesses/b.txt\"))\n"
    "(allow file-read-data (literal \"/private/tmp/therese-c17-inheritance-main-Pkcez7OG/witnesses/b.txt\"))\n";

static void json_string(const char *value) {
    putchar('"');
    for (size_t i = 0; value && value[i] && i < 1024; ++i) {
        unsigned char c = (unsigned char)value[i];
        if (c == '"' || c == '\\') { putchar('\\'); putchar(c); }
        else if (c < 0x20) printf("\\u%04x", c);
        else putchar(c);
    }
    putchar('"');
}

/* BEGIN FD_CLEANUP: own PID only, typed SDK rows, fixed capacity. */
#define OWN_FD_CAPACITY 256
static int read_own_fds(struct proc_fdinfo rows[OWN_FD_CAPACITY]) {
    memset(rows, 0, OWN_FD_CAPACITY * sizeof(*rows));
    int bytes = proc_pidinfo(getpid(), PROC_PIDLISTFDS, 0, rows,
                            (int)(OWN_FD_CAPACITY * sizeof(*rows)));
    if (bytes <= 0 || bytes >= (int)(OWN_FD_CAPACITY * sizeof(*rows)) ||
        bytes % (int)sizeof(*rows) != 0) return -1;
    int count = bytes / (int)sizeof(*rows);
    for (int i = 0; i < count; ++i) {
        if (rows[i].proc_fd < 0) return -1;
        for (int j = 0; j < i; ++j)
            if (rows[j].proc_fd == rows[i].proc_fd) return -1;
    }
    return count;
}

static int close_inherited_fds(void) {
    struct proc_fdinfo rows[OWN_FD_CAPACITY];
    int count = read_own_fds(rows);
    if (count < 0) return -1;
    for (int i = 0; i < count; ++i) {
        if (rows[i].proc_fd >= 3 && close(rows[i].proc_fd)) return -1;
        /* No retry on EINTR/other error; never close a parent FD. */
    }
    count = read_own_fds(rows);
    if (count != 3) return -1;
    unsigned present = 0;
    for (int i = 0; i < count; ++i) {
        if (rows[i].proc_fd > 2) return -1;
        present |= 1u << (unsigned)rows[i].proc_fd;
    }
    return present == 7u ? 0 : -1; /* Exactly stdin, stdout and stderr. */
}
/* END FD_CLEANUP */

/* BEGIN FD0_GATE: typed SDK libproc, no fabricated identity. */
#define GATE_LIMIT_NS INT64_C(5000000000)
#define GATE_FRAME_BYTES 512
struct gate_birth {
    uint32_t pid, ppid, uid, pgid;
    uint64_t start_sec, start_usec;
};

static int read_gate_birth(pid_t pid, struct gate_birth *out) {
    struct proc_bsdinfo info;
    memset(&info, 0, sizeof(info));
    int count = proc_pidinfo(pid, PROC_PIDTBSDINFO, 0, &info, (int)sizeof(info));
    if (count != (int)sizeof(info) || info.pbi_pid != (uint32_t)pid ||
        (info.pbi_status != SRUN && info.pbi_status != SSLEEP) ||
        (info.pbi_flags & PROC_FLAG_INEXIT) || info.pbi_pid <= 1 ||
        info.pbi_ppid == 0 || info.pbi_pgid == 0 ||
        info.pbi_start_tvsec == 0 || info.pbi_start_tvusec >= 1000000) return -1;
    *out = (struct gate_birth){info.pbi_pid, info.pbi_ppid, info.pbi_uid,
        info.pbi_pgid, info.pbi_start_tvsec, info.pbi_start_tvusec};
    return 0;
}

static bool same_gate_birth(const struct gate_birth *a, const struct gate_birth *b) {
    return a->pid == b->pid && a->ppid == b->ppid && a->uid == b->uid &&
        a->pgid == b->pgid && a->start_sec == b->start_sec && a->start_usec == b->start_usec;
}

static bool gate_nonce_valid(const char *nonce) {
    if (!nonce || strlen(nonce) != 32) return false;
    for (size_t i = 0; i < 32; ++i)
        if (!((nonce[i] >= '0' && nonce[i] <= '9') ||
              (nonce[i] >= 'a' && nonce[i] <= 'f'))) return false;
    return true;
}

static int64_t gate_now_ns(void) {
    struct timespec now;
    if (clock_gettime(CLOCK_MONOTONIC, &now) || now.tv_sec < 0 ||
        now.tv_sec > (INT64_MAX - GATE_LIMIT_NS) / INT64_C(1000000000)) return -1;
    return (int64_t)now.tv_sec * INT64_C(1000000000) + now.tv_nsec;
}

static int fd0_gate(const char *case_name, const char *nonce) {
    int64_t start = gate_now_ns();
    if (start < 0 || !gate_nonce_valid(nonce)) return -1;
    const int64_t deadline = start + GATE_LIMIT_NS;
    struct stat channel;
    int flags = fcntl(STDIN_FILENO, F_GETFL);
    if (fstat(STDIN_FILENO, &channel) || !S_ISFIFO(channel.st_mode) || flags < 0 ||
        fcntl(STDIN_FILENO, F_SETFL, flags | O_NONBLOCK)) return -1;

    struct gate_birth child, owner, child_now, owner_now;
    if (read_gate_birth(getpid(), &child) || read_gate_birth(getppid(), &owner) ||
        child.pid != (uint32_t)getpid() || child.ppid != (uint32_t)getppid() ||
        child.ppid != owner.pid || child.uid != (uint32_t)getuid() ||
        child.uid != (uint32_t)geteuid() || child.uid != owner.uid ||
        child.pgid != child.pid || child.pgid != (uint32_t)getpgrp()) return -1;

    printf("{\"schema\":\"c17-seatbelt-composition-ready-v1\",\"case\":\"%s\","
           "\"nonce\":\"%s\",\"pid\":%u,\"ppid\":%u,\"uid\":%u,\"pgid\":%u,"
           "\"start_sec\":%" PRIu64 ",\"start_usec\":%" PRIu64 "}\n",
           case_name, nonce, child.pid, child.ppid, child.uid, child.pgid,
           child.start_sec, child.start_usec);
    if (fflush(stdout) || ferror(stdout)) return -1;

    char expected[GATE_FRAME_BYTES], received[GATE_FRAME_BYTES];
    int wanted = snprintf(expected, sizeof(expected),
        "{\"schema\":\"c17-seatbelt-composition-release-v1\",\"case\":\"%s\","
        "\"nonce\":\"%s\",\"pid\":%u,\"start_sec\":%" PRIu64 ",\"start_usec\":%" PRIu64 "}\n",
        case_name, nonce, child.pid, child.start_sec, child.start_usec);
    if (wanted <= 0 || wanted >= GATE_FRAME_BYTES) return -1;
    size_t used = 0;
    for (;;) {
        int64_t now = gate_now_ns();
        if (now < 0 || now >= deadline) return -1;
        int milliseconds = (int)((deadline - now + INT64_C(999999)) / INT64_C(1000000));
        struct pollfd pipe = {STDIN_FILENO, POLLIN, 0};
        int polled = poll(&pipe, 1, milliseconds);
        if (polled < 0 && errno == EINTR) continue;
        now = gate_now_ns();
        if (polled <= 0 || now < 0 || now >= deadline ||
            (pipe.revents & (POLLERR | POLLNVAL))) return -1;
        ssize_t count = read(STDIN_FILENO, received + used, sizeof(received) - used);
        if (count < 0 && (errno == EINTR || errno == EAGAIN)) continue;
        if (count <= 0) return -1; /* EOF never supplies a release. */
        used += (size_t)count;
        if (used >= sizeof(received)) return -1;
        if (memchr(received, '\n', used)) {
            if (used != (size_t)wanted || memcmp(received, expected, used)) return -1;
            /* One closed frame; any already queued additional byte is refused. */
            char extra;
            ssize_t more = read(STDIN_FILENO, &extra, 1);
            if (more != -1 || errno != EAGAIN) return -1;
            break;
        }
    }
    /* FD0 is retained exclusively for the second closed release after fork. */
    if (read_gate_birth(getpid(), &child_now) || read_gate_birth((pid_t)owner.pid, &owner_now) ||
        !same_gate_birth(&child, &child_now) || !same_gate_birth(&owner, &owner_now) ||
        getppid() != (pid_t)owner.pid) return -1;
    int64_t done = gate_now_ns();
    if (done < 0 || done >= deadline) return -1;
    printf("{\"schema\":\"c17-seatbelt-composition-gate-released-v1\",\"case\":\"%s\","
           "\"nonce\":\"%s\",\"pid\":%u,\"start_sec\":%" PRIu64 ",\"start_usec\":%" PRIu64 "}\n",
           case_name, nonce, child.pid, child.start_sec, child.start_usec);
    if (fflush(stdout) || ferror(stdout)) return -1;
    done = gate_now_ns();
    return done < 0 || done >= deadline ? -1 : 0;
}
/* END FD0_GATE */

static int witness_preflight(const char *path, char expected) {
    struct stat before, after;
    char canonical[PATH_MAX];
    if (!realpath(path, canonical) || strcmp(path, canonical) ||
        lstat(path, &before) || !S_ISREG(before.st_mode) || before.st_nlink != 1 ||
        before.st_uid != getuid()) return -1;
    int fd = open(path, O_RDONLY | O_NOFOLLOW);
    if (fd < 0) return -1;
    char c = 0;
    int result = fstat(fd, &after) || after.st_dev != before.st_dev ||
        after.st_ino != before.st_ino || after.st_size != before.st_size ||
        after.st_nlink != 1 || read(fd, &c, 1) != 1 || c != expected;
    if (close(fd)) result = 1;
    return result ? -1 : 0;
}

enum read_state { READ_OK, READ_DENIED, READ_UNEXPECTED };
static enum read_state probe_read(const char *phase, const char *label, const char *path, char expected) {
    errno = 0;
    int fd = open(path, O_RDONLY | O_NOFOLLOW);
    int open_errno = fd < 0 ? errno : 0;
    char c = 0;
    ssize_t n = -1;
    int read_errno = 0, close_errno = 0;
    if (fd >= 0) {
        errno = 0;
        n = read(fd, &c, 1);
        if (n < 0) read_errno = errno;
        errno = 0;
        if (close(fd)) close_errno = errno;
    }
    printf("{\"event\":\"witness_read\",\"phase\":"); json_string(phase);
    printf(",\"witness\":"); json_string(label);
    printf(",\"open_ok\":%s,\"open_errno\":%d,\"read_count\":%ld,"
           "\"read_errno\":%d,\"close_errno\":%d,\"content_matches\":%s,"
           "\"diagnostic_only\":true,\"native_qualification\":false}\n",
           fd >= 0 ? "true" : "false", open_errno, (long)n, read_errno,
           close_errno, n == 1 && c == expected ? "true" : "false");
    if (fflush(stdout) || ferror(stdout)) return READ_UNEXPECTED;
    if (fd >= 0 && n == 1 && c == expected && !close_errno) return READ_OK;
    if (fd < 0 && (open_errno == EPERM || open_errno == EACCES)) return READ_DENIED;
    return READ_UNEXPECTED; /* Missing/changed witness never stands in for denial. */
}


/* BEGIN LOT77_WATCHDOG: one-shot self timers, no signal to another process. */
#define PARENT_TIMER_SECONDS 23
#define CHILD_TIMER_SECONDS 10
#define PARENT_WAIT_LIMIT_NS INT64_C(18000000000)

static int prepare_parent_watchdog(int64_t *armed_ns) {
    struct sigaction chld, action, observed;
    sigset_t unblocked, current;
    struct itimerval previous, timer = {{0, 0}, {PARENT_TIMER_SECONDS, 0}};
    memset(&chld, 0, sizeof(chld));
    memset(&previous, 0, sizeof(previous));
    if (sigaction(SIGCHLD, NULL, &chld) || chld.sa_handler != SIG_DFL ||
        (chld.sa_flags & SA_NOCLDWAIT) || getitimer(ITIMER_REAL, &previous) ||
        previous.it_value.tv_sec || previous.it_value.tv_usec ||
        previous.it_interval.tv_sec || previous.it_interval.tv_usec) return -1;
    memset(&action, 0, sizeof(action));
    action.sa_handler = SIG_DFL;
    if (sigemptyset(&action.sa_mask) || sigemptyset(&unblocked) ||
        sigaddset(&unblocked, SIGALRM) || sigaction(SIGALRM, &action, NULL) ||
        sigprocmask(SIG_UNBLOCK, &unblocked, NULL)) return -1;
    *armed_ns = gate_now_ns(); /* Captured BEFORE arming; never reset by preparation. */
    if (*armed_ns < 0 || setitimer(ITIMER_REAL, &timer, NULL)) return -1;
    memset(&observed, 0, sizeof(observed));
    if (sigaction(SIGALRM, NULL, &observed) || observed.sa_handler != SIG_DFL ||
        sigprocmask(SIG_BLOCK, NULL, &current) || sigismember(&current, SIGALRM) != 0)
        return -1;
    return 0;
}

static int before_fork_budget(int64_t armed_ns, int64_t *fork_ns) {
    struct itimerval timer;
    memset(&timer, 0, sizeof(timer));
    *fork_ns = gate_now_ns();
    if (*fork_ns < 0 || *fork_ns < armed_ns ||
        *fork_ns - armed_ns > GATE_LIMIT_NS ||
        *fork_ns > INT64_MAX - PARENT_WAIT_LIMIT_NS ||
        getitimer(ITIMER_REAL, &timer) ||
        timer.it_interval.tv_sec || timer.it_interval.tv_usec ||
        timer.it_value.tv_sec < 18 || timer.it_value.tv_usec < 0 ||
        timer.it_value.tv_usec >= 1000000) return -1;
    /* Do not reuse a clock captured before the getitimer syscall. */
    int64_t fresh = gate_now_ns();
    if (fresh < *fork_ns || fresh < armed_ns || fresh - armed_ns > GATE_LIMIT_NS ||
        fresh > INT64_MAX - PARENT_WAIT_LIMIT_NS) return -1;
    *fork_ns = fresh;
    return 0;
}

static int arm_child_watchdog(void) {
    /* fork does not supply the child's own watchdog: arm it explicitly. */
    struct itimerval timer = {{0, 0}, {CHILD_TIMER_SECONDS, 0}};
    return setitimer(ITIMER_REAL, &timer, NULL);
}
/* END LOT77_WATCHDOG */

/* BEGIN CHILD_GATE: no proc_pidinfo, sandbox API or witness before release2. */
static int child_gate(const char *case_name, const char *nonce, pid_t parent_pid,
                      uid_t expected_uid, pid_t expected_pgid, int64_t fork_ns,
                      int64_t *released_ns) {
    const int64_t deadline = fork_ns + GATE_LIMIT_NS;
    if (!gate_nonce_valid(nonce) || getppid() != parent_pid ||
        getuid() != expected_uid || geteuid() != expected_uid ||
        getpgrp() != expected_pgid) return -1;
    char expected[GATE_FRAME_BYTES], received[GATE_FRAME_BYTES];
    int wanted = snprintf(expected, sizeof(expected),
        "{\"schema\":\"c17-seatbelt-inheritance-child-release-v1\",\"case\":\"%s\","
        "\"nonce\":\"%s\",\"pid\":%d,\"ppid\":%d,\"uid\":%u,\"pgid\":%d}\n",
        case_name, nonce, getpid(), parent_pid, (unsigned)expected_uid, expected_pgid);
    if (wanted <= 0 || wanted >= GATE_FRAME_BYTES) return -1;
    size_t used = 0;
    for (;;) {
        int64_t now = gate_now_ns();
        if (now < 0 || now >= deadline) return -1;
        int milliseconds = (int)((deadline - now + INT64_C(999999)) / INT64_C(1000000));
        struct pollfd channel = {STDIN_FILENO, POLLIN, 0};
        int polled = poll(&channel, 1, milliseconds);
        if (polled < 0 && errno == EINTR) continue;
        now = gate_now_ns();
        if (polled <= 0 || now < 0 || now >= deadline ||
            (channel.revents & (POLLERR | POLLNVAL))) return -1;
        ssize_t count = read(STDIN_FILENO, received + used, sizeof(received) - used);
        if (count < 0 && (errno == EINTR || errno == EAGAIN)) continue;
        if (count <= 0) return -1; /* EOF is a refusal, not release evidence. */
        used += (size_t)count;
        if (used >= sizeof(received)) return -1;
        if (memchr(received, '\n', used)) {
            if (used != (size_t)wanted || memcmp(received, expected, used)) return -1;
            char extra;
            ssize_t more = read(STDIN_FILENO, &extra, 1);
            if (more != -1 || errno != EAGAIN) return -1;
            break;
        }
    }
    if (getppid() != parent_pid || getuid() != expected_uid ||
        geteuid() != expected_uid || getpgrp() != expected_pgid ||
        close(STDIN_FILENO)) return -1;
    *released_ns = gate_now_ns();
    if (*released_ns < 0 || *released_ns >= deadline ||
        *released_ns > INT64_MAX - GATE_LIMIT_NS) return -1;
    printf("{\"schema\":\"c17-seatbelt-inheritance-child-released-v1\",\"case\":\"%s\","
           "\"nonce\":\"%s\",\"pid\":%d,\"ppid\":%d,\"uid\":%u,\"pgid\":%d}\n",
           case_name, nonce, getpid(), parent_pid, (unsigned)expected_uid, expected_pgid);
    if (fflush(stdout) || ferror(stdout)) return -1;
    int64_t done = gate_now_ns();
    return done < 0 || done >= deadline ? -1 : 0;
}
/* END CHILD_GATE */

static bool child_step_in_time(pid_t parent_pid, int64_t deadline) {
    int64_t now = gate_now_ns();
    return now >= 0 && now < deadline && getppid() == parent_pid;
}

static int child_measure(const char *case_name, pid_t parent_pid, int64_t released_ns,
                         const char *a, const char *b, sandbox_profile_t *compiled_alpha) {
    const int64_t deadline = released_ns + GATE_LIMIT_NS;
    if (!child_step_in_time(parent_pid, deadline)) return 86;
    enum read_state before_a = probe_read("inherited_outer", "A", a, 'A');
    if (!child_step_in_time(parent_pid, deadline)) return 86;
    enum read_state before_b = probe_read("inherited_outer", "B", b, 'B');
    if (!child_step_in_time(parent_pid, deadline) ||
        before_a != READ_OK || before_b != READ_DENIED) return 86;
    if (!strcmp(case_name, "fork-baseline")) {
        puts("{\"event\":\"case_finished\",\"observation\":\"inherited_outer_witnesses_observed\","
             "\"inherited_child_measured\":true,\"diagnostic_only\":true,"
             "\"native_qualification\":false,\"FULL\":false}");
        if (fflush(stdout) || ferror(stdout)) return 86;
        return child_step_in_time(parent_pid, deadline) ? 0 : 86;
    }
    if (!compiled_alpha || strcmp(case_name, "fork-compiled-alpha") ||
        !child_step_in_time(parent_pid, deadline)) return 86;
    errno = 0;
    int inner_rc = sandbox_apply(compiled_alpha);
    int inner_errno = errno;
    printf("{\"event\":\"inner_apply\",\"case\":\"fork-compiled-alpha\","
           "\"api\":\"sandbox_apply\",\"rc\":%d,\"errno\":%d,\"diagnostic_only\":true}\n",
           inner_rc, inner_errno);
    if (fflush(stdout) || ferror(stdout) || !child_step_in_time(parent_pid, deadline)) return 86;
    enum read_state after_a = probe_read("after_inner", "A", a, 'A');
    if (!child_step_in_time(parent_pid, deadline)) return 86;
    enum read_state after_b = probe_read("after_inner", "B", b, 'B');
    if (!child_step_in_time(parent_pid, deadline)) return 86;
    const bool intersection = after_a == READ_DENIED && after_b == READ_DENIED;
    const char *observation = after_a == READ_UNEXPECTED || after_b == READ_UNEXPECTED ?
        "witness_instrument_error" : inner_rc != 0 ? "inner_api_refused" :
        after_b == READ_OK ? "outer_denial_not_preserved" :
        after_a == READ_OK ? "inner_restriction_not_observed" :
        "witness_intersection_observed_not_general_proof";
    printf("{\"event\":\"case_finished\",\"observation\":"); json_string(observation);
    puts(",\"inherited_child_measured\":true,\"diagnostic_only\":true,"
         "\"native_qualification\":false,\"FULL\":false}");
    if (fflush(stdout) || ferror(stdout)) return 86;
    return inner_rc != 0 || !intersection ? 86 : 0;
}

static int parent_reap(pid_t child_pid, int64_t fork_ns, bool prelaunch_fault) {
    const int64_t deadline = fork_ns + PARENT_WAIT_LIMIT_NS;
    bool pending = prelaunch_fault, wait_failed = false;
    for (;;) {
        int64_t now = gate_now_ns();
        if (now < 0 || now >= deadline) pending = true;
        if (!wait_failed) {
            int status = 0;
            pid_t waited = waitpid(child_pid, &status, WNOHANG);
            if (waited == child_pid) {
                int64_t reaped_at = gate_now_ns();
                bool on_time = reaped_at >= 0 && reaped_at < deadline;
                int child_signal = WIFSIGNALED(status) ? WTERMSIG(status) : 0;
                int raw_code = WIFEXITED(status) ? WEXITSTATUS(status) :
                    child_signal ? -child_signal : 86;
                printf("{\"event\":\"child_waitpid\",\"pid\":%d,\"wait_status\":%d,"
                       "\"exit_code\":%d,\"signal\":%d,\"reaped\":true,\"deadline_met\":%s}\n",
                       child_pid, status, raw_code, child_signal, on_time ? "true" : "false");
                if (fflush(stdout) || ferror(stdout)) return 86;
                return pending || !on_time || child_signal || raw_code != 0 ? 86 : 0;
            }
            if (waited < 0 && errno == EINTR) continue; /* No deadline reset. */
            if (waited < 0 || waited > 0) {
                wait_failed = true; pending = true;
                fputs("cleanup_pending: exact child wait refused; no reap claimed\n", stderr);
                if (fflush(stderr) || ferror(stderr)) pending = true;
            }
        }
        /* Never return while the child may live. MAIN cleans CHILD FIRST.
         * The unchanged one-shot parent timer23 terminates this failure state.
         * This is not a hard preemption/atomic absence guarantee. */
        int delayed = poll(NULL, 0, 10);
        if (delayed < 0 && errno != EINTR) pending = true;
    }
}

int main(int argc, char **argv) {
    if (!NATIVE_MEASUREMENT_ENABLED) {
        fputs("prepared_only: no compilation/native authorization\n", stderr);
        return 2;
    }
    if (argc != 5 || strcmp(argv[1], "--reviewed-case") ||
        strcmp(argv[3], "--gate-nonce") || !gate_nonce_valid(argv[4]) ||
        (strcmp(argv[2], "fork-baseline") && strcmp(argv[2], "fork-compiled-alpha"))) return 2;
    if (close_inherited_fds()) return 86;
    int64_t armed_ns = -1;
    if (prepare_parent_watchdog(&armed_ns)) return 86;
    if (fd0_gate(argv[2], argv[4])) return 86;

    char canonical[PATH_MAX], a[PATH_MAX], b[PATH_MAX];
    struct stat root_stat;
    if (!realpath(QA_ROOT, canonical) || strcmp(canonical, QA_ROOT) ||
        lstat(QA_ROOT, &root_stat) || !S_ISDIR(root_stat.st_mode) ||
        root_stat.st_uid != getuid() || (root_stat.st_mode & 077) != 0) return 2;
    if (snprintf(a, sizeof(a), "%s/witnesses/a.txt", QA_ROOT) >= (int)sizeof(a) ||
        snprintf(b, sizeof(b), "%s/witnesses/b.txt", QA_ROOT) >= (int)sizeof(b)) return 2;
    if (witness_preflight(a, 'A') || witness_preflight(b, 'B')) return 2;
    int ambient = sandbox_check(getpid(), NULL, 0);
    if (ambient != 0) return 2; /* Never replace ambient confinement blindly. */

    sandbox_profile_t *compiled_alpha = NULL;
    const char *params[] = {"WITNESS_A", a, "WITNESS_B", b, NULL};
    char *error = NULL;
    if (!strcmp(argv[2], "fork-compiled-alpha")) {
        sandbox_params_t *p = sandbox_create_params();
        if (!p || sandbox_set_param(p, "WITNESS_A", a) ||
            sandbox_set_param(p, "WITNESS_B", b)) return 2;
        compiled_alpha = sandbox_compile_string(ALPHA, p, &error);
        sandbox_free_params(p);
        if (!compiled_alpha) {
            if (error) sandbox_free_error(error);
            return 2;
        }
        if (error) { sandbox_free_error(error); error = NULL; }
    }
    if (fflush(NULL) || ferror(stdout) || ferror(stderr)) return 86;
    errno = 0;
    int outer_rc = sandbox_init_with_parameters(OUTER_FORK, 0, params, &error);
    int outer_errno = errno;
    printf("{\"event\":\"outer_apply\",\"pid\":%d,\"ppid\":%d,\"uid\":%d,"
           "\"rc\":%d,\"errno\":%d,\"diagnostic_only\":true,\"error\":",
           getpid(), getppid(), getuid(), outer_rc, outer_errno);
    json_string(error); puts("}");
    if (fflush(stdout) || ferror(stdout)) return 86;
    if (error) { sandbox_free_error(error); error = NULL; }
    if (outer_rc != 0) return 86;

    enum read_state parent_a = probe_read("parent_outer", "A", a, 'A');
    enum read_state parent_b = probe_read("parent_outer", "B", b, 'B');
    if (parent_a != READ_OK || parent_b != READ_DENIED) return 86;

    pid_t parent_pid = getpid(), parent_pgid = getpgrp();
    uid_t parent_uid = getuid();
    if (parent_pid <= 1 || parent_pgid != parent_pid || parent_uid != geteuid()) return 86;
    int64_t fork_ns = -1;
    if (before_fork_budget(armed_ns, &fork_ns)) return 86; /* No child on budget refusal. */
    pid_t child_pid = fork(); /* The sole fork; no exec or additional child. */
    if (child_pid < 0) return 86;
    if (child_pid == 0) {
        if (arm_child_watchdog()) _exit(86); /* First guard after fork. */
        int64_t released_ns = -1;
        if (child_gate(argv[2], argv[4], parent_pid, parent_uid, parent_pgid,
                       fork_ns, &released_ns)) _exit(86);
        int code = child_measure(argv[2], parent_pid, released_ns, a, b, compiled_alpha);
        _exit(code); /* No inherited stdio/atexit handlers are replayed. */
    }
    bool prelaunch_fault = close(STDIN_FILENO) != 0;
    if (!prelaunch_fault) {
        printf("{\"schema\":\"c17-seatbelt-inheritance-child-ready-v1\",\"case\":\"%s\","
               "\"nonce\":\"%s\",\"pid\":%d,\"ppid\":%d,\"uid\":%u,\"pgid\":%d}\n",
               argv[2], argv[4], child_pid, parent_pid, (unsigned)parent_uid, parent_pgid);
        prelaunch_fault = fflush(stdout) || ferror(stdout);
    }
    /* No parent stdout until the exact child's waitpid proves reap. */
    return parent_reap(child_pid, fork_ns, prelaunch_fault);
}
