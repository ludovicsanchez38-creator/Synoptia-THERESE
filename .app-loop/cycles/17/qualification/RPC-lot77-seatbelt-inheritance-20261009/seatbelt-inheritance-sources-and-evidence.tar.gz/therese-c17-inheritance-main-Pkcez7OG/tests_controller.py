"""Tests de doubles LOT77 : aucun Popen, libproc, signal ni compilateur réel."""

from __future__ import annotations

import json
import os
import signal
import subprocess
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

def auditguard(event: str, _args: tuple) -> None:
    if event in ("subprocess.Popen", "os.system", "os.kill", "os.killpg",
                 "os.fork", "os.posix_spawn", "os.exec", "os.spawn",
                 "ctypes.dlopen", "socket.__new__"):
        raise AssertionError("effet OS interdit dans les tests purs: " + event)


sys.addaudithook(auditguard)
sys.path.insert(0, str(Path(__file__).resolve().parent))
import controller as c
import native_port
import native_main

ROOT = Path("/private/tmp/c17-inheritance-synthetic-only")
PLAN = c.Plan(ROOT, ROOT / "probe", ROOT / "cases/fork-baseline",
              ROOT / "cases/fork-baseline/stdout.log",
              ROOT / "cases/fork-baseline/stderr.log", "fork-baseline", "a" * 32,
              {"HOME": str(ROOT / "home"), "TMPDIR": str(ROOT / "tmp") + "/",
               "PATH": "/usr/bin:/bin"},
              ({"path": str(ROOT / "probe"), "bytes": 123, "sha256": "b" * 64},))
OWNER = {"pid": 500, "ppid": 1, "uid": 501, "pgid": 500,
         "start_sec": 1700000000, "start_usec": 10, "status": 2,
         "executable": "/opt/homebrew/bin/python3"}
DIRECT = {"pid": 501, "ppid": 500, "uid": 501, "pgid": 501,
          "start_sec": 1700000001, "start_usec": 20, "status": 3,
          "executable": str(PLAN.binary)}
FORK = {"pid": 502, "ppid": 501, "uid": 501, "pgid": 501,
        "start_sec": 1700000002, "start_usec": 30, "status": 2,
        "executable": str(PLAN.binary)}


def line(row: dict) -> bytes:
    return json.dumps(row, separators=(",", ":")).encode("ascii") + b"\n"


class FakePort:
    def __init__(self) -> None:
        self.t = 0.0
        self.source_checks = 0
        self.fork_reads = 0
        self.direct_reads = 0
        self.fork_deadlines: list[float] = []
        self.release_payloads: list[bytes] = []
        self.signals: list[tuple[int, signal.Signals]] = []
        self.gate_closed = False
        self.sinks_closed = False
        self.direct_dead_at_fork = False
        self.direct_relation_wrong = False
        self.direct_status_wrong = False
        self.direct_clock_late_on_recheck = False
        self.fork_unknown = False
        self.fork_reparented = False
        self.fork_pgid_wrong = False
        self.fork_status_wrong = False
        self.fork_birth_drift_on_recheck = False
        self.fork_clock_late_on_cleanup = False
        self.fork_ready_late = False
        self.fork_ack_late = False
        self.source_late_on_third = False
        self.source_late_on_second = False
        self.wait_code = 0
        self.wait_returns: list[int | None] | None = None
        self.wait_deadlines: list[float] = []
        self.tail_reap_at_deadline = False
        self.direct_reaped = False
        self.final = line({"event": "child_waitpid", "pid": FORK["pid"],
                           "wait_status": 0, "exit_code": 0, "signal": 0,
                           "reaped": True, "deadline_met": True})
        self.ready1 = line({"schema": c.READY_SCHEMA, "case": PLAN.case,
                            "nonce": PLAN.nonce,
                            **{key: DIRECT[key] for key in c.IDENTITY}})
        self.ack1 = line({"schema": c.RELEASED_SCHEMA, "case": PLAN.case,
                          "nonce": PLAN.nonce, "pid": DIRECT["pid"],
                          "start_sec": DIRECT["start_sec"],
                          "start_usec": DIRECT["start_usec"]})
        self.outer = line({"event": "outer_apply", "pid": DIRECT["pid"],
                           "ppid": OWNER["pid"], "uid": DIRECT["uid"],
                           "rc": 0, "errno": 0,
                           "diagnostic_only": True, "error": ""})
        self.parent_a = line({"event": "witness_read", "phase": "parent_outer",
                              "witness": "A", "open_ok": True, "open_errno": 0,
                              "read_count": 1, "read_errno": 0, "close_errno": 0,
                              "content_matches": True, "diagnostic_only": True,
                              "native_qualification": False})
        self.parent_b = line({"event": "witness_read", "phase": "parent_outer",
                              "witness": "B", "open_ok": False, "open_errno": 1,
                              "read_count": -1, "read_errno": 0, "close_errno": 0,
                              "content_matches": False, "diagnostic_only": True,
                              "native_qualification": False})
        self.ready2 = line({"schema": c.FORK_READY_SCHEMA, "case": PLAN.case,
                            "nonce": PLAN.nonce,
                            **{key: FORK[key] for key in ("pid", "ppid", "uid", "pgid")}})
        self.ack2 = line({"schema": c.FORK_RELEASED_SCHEMA, "case": PLAN.case,
                          "nonce": PLAN.nonce,
                          **{key: FORK[key] for key in ("pid", "ppid", "uid", "pgid")}})

    def now(self): return self.t
    def self_pid(self): return OWNER["pid"]

    def read_identity(self, pid):
        if pid == OWNER["pid"]: return OWNER.copy()
        if pid == DIRECT["pid"]:
            self.direct_reads += 1
            if self.direct_clock_late_on_recheck and self.direct_reads >= 3:
                self.t = 5.001
            row = DIRECT.copy()
            if self.direct_relation_wrong: row["ppid"] = 499
            if self.direct_status_wrong: row["status"] = 5
            return row
        if pid == FORK["pid"]:
            self.fork_reads += 1
            if self.fork_clock_late_on_cleanup and self.fork_reads >= 3:
                self.t = 100.0
            if self.fork_unknown: raise OSError("libproc child incertain")
            row = FORK.copy()
            if self.fork_reparented: row["ppid"] = 1
            if self.fork_pgid_wrong: row["pgid"] = FORK["pid"]
            if self.fork_status_wrong: row["status"] = 5
            if self.fork_birth_drift_on_recheck and self.fork_reads >= 2:
                row["start_usec"] += 1
            return row
        raise ProcessLookupError(pid)

    def verify_sources(self, refs):
        self.source_checks += 1
        if self.source_late_on_second and self.source_checks == 2:
            self.t = 5.001
        if self.source_late_on_third and self.source_checks == 3:
            self.t = 5.001
        return True

    def open_sinks(self, plan): return ("out", "err")
    def spawn(self, plan, sinks): return SimpleNamespace(pid=DIRECT["pid"])
    def read_ready(self, handle, sinks, deadline): return self.ready1
    def read_gate_released(self, handle, sinks, deadline): return self.ack1
    def read_outer_apply(self, handle, sinks, deadline): return self.outer
    def read_parent_witness(self, handle, sinks, deadline, label):
        return self.parent_a if label == "A" else self.parent_b
    def read_fork_ready(self, handle, sinks, deadline):
        self.fork_deadlines.append(deadline)
        if self.fork_ready_late: self.t = deadline + 0.001
        return self.ready2
    def read_fork_released(self, handle, sinks, deadline):
        self.fork_deadlines.append(deadline)
        if self.fork_ack_late: self.t = deadline + 0.001
        return self.ack2
    def read_child_waitpid(self, handle, sinks): return self.final
    def release(self, handle, payload): self.release_payloads.append(payload)
    def close_gate(self, handle): self.gate_closed = True
    def poll(self, handle):
        if self.direct_dead_at_fork and len(self.release_payloads) == 1: return 86
        return self.wait_code if self.direct_reaped else None
    def wait_until(self, handle, deadline):
        self.wait_deadlines.append(deadline)
        value = self.wait_returns.pop(0) if self.wait_returns is not None else self.wait_code
        if value is None:
            self.t = deadline
            return None
        if self.tail_reap_at_deadline and deadline == c.TERMINAL_REAP_SECONDS:
            self.t = deadline
        self.direct_reaped = True
        self.wait_code = value
        return value
    def signal_pid(self, pid, sig): self.signals.append((pid, sig))
    def close_sinks(self, sinks):
        self.sinks_closed = True
        return True


class ContractTests(unittest.TestCase):
    def drive(self, port: FakePort) -> dict:
        # Le vrai branchement _drive est testé, tous les effets OS sont interdits.
        with patch.object(c, "NATIVE_MEASUREMENT_ENABLED", True), \
             patch.object(native_port, "NativePort", FakePort), \
             patch("subprocess.Popen", side_effect=AssertionError("Popen interdit")), \
             patch("os.kill", side_effect=AssertionError("signal interdit")), \
             patch("os.open", side_effect=AssertionError("FD interdit")):
            return c._drive(PLAN, port)

    def test_clean_synthetic_two_births_two_releases_parent_waitpid(self):
        port = FakePort()
        result = self.drive(port)
        self.assertTrue(result["clean"])
        self.assertTrue(result["termination_proved"])
        self.assertTrue(result["outer_apply_observed"])
        self.assertTrue(result["parent_outer_witnesses_observed"])
        self.assertEqual(result["direct_parent"], DIRECT)
        self.assertEqual(result["grandchild"], FORK)
        self.assertEqual(port.release_payloads,
                         [c.release_bytes(PLAN, DIRECT), c.fork_release_bytes(PLAN, FORK)])
        self.assertTrue(port.gate_closed and port.sinks_closed)
        self.assertEqual(port.signals, [])
        self.assertFalse(result["actual_native_IO"])
        self.assertFalse(result["FULL"] or result["Chrome_qualified"])

    def test_child_pgid_is_parent_group_not_own_pid(self):
        self.assertEqual(FORK["pgid"], DIRECT["pid"])
        self.assertNotEqual(FORK["pgid"], FORK["pid"])
        port = FakePort(); port.fork_pgid_wrong = True
        result = self.drive(port)
        self.assertFalse(result["child_release_written"])
        self.assertIsNone(result["grandchild"])
        self.assertEqual(port.signals, [])

    def test_direct_parent_not_adopted_from_popen_pid_or_ready_alone(self):
        for key in ("direct_relation_wrong", "direct_status_wrong"):
            with self.subTest(key=key):
                port = FakePort(); setattr(port, key, True)
                result = self.drive(port)
                self.assertIsNone(result["direct_parent"])
                self.assertEqual(port.release_payloads, [])
                self.assertEqual(port.signals, [])

    def test_unknown_child_or_reparent_refuses_adoption_signal_and_release2(self):
        for key in ("fork_unknown", "fork_reparented", "fork_status_wrong"):
            with self.subTest(key=key):
                port = FakePort(); setattr(port, key, True)
                result = self.drive(port)
                self.assertFalse(result["child_release_written"])
                self.assertIsNone(result["grandchild"])
                self.assertEqual(port.signals, [])

    def test_unknown_birth_and_parent_alive_never_claims_closed(self):
        port = FakePort(); port.fork_unknown = True; port.wait_code = None
        result = self.drive(port)
        self.assertFalse(result["termination_proved"])
        self.assertFalse(result["clean"])
        self.assertFalse(result["cleanup_deadline_met"])
        self.assertIn("parent C non reaped", result["errors"])
        self.assertEqual(port.signals, [])
        self.assertEqual(port.wait_deadlines[-1], 28.0)

    def test_parent_dead_before_release2_closes_pipe_and_stays_red(self):
        port = FakePort(); port.direct_dead_at_fork = True
        result = self.drive(port)
        self.assertFalse(result["clean"])
        self.assertEqual(len(port.release_payloads), 1)
        self.assertTrue(port.gate_closed)
        self.assertEqual(port.signals, [])

    def test_outer_apply_red_prevents_child_attribution_or_release(self):
        port = FakePort()
        port.outer = port.outer.replace(b'"rc":0', b'"rc":-1')
        result = self.drive(port)
        self.assertFalse(result["outer_apply_observed"])
        self.assertFalse(result["child_release_written"])
        self.assertIsNone(result["grandchild"])

    def test_parent_outer_oracles_precede_child_ready_and_reject_missing_or_fake_denial(self):
        for key, replacement in (
            ("parent_a", b""),
            ("parent_b", line({"event": "witness_read", "phase": "parent_outer",
                               "witness": "B", "open_ok": False, "open_errno": 2,
                               "read_count": -1, "read_errno": 0, "close_errno": 0,
                               "content_matches": False, "diagnostic_only": True,
                               "native_qualification": False})),
        ):
            with self.subTest(key=key):
                port = FakePort(); setattr(port, key, replacement)
                result = self.drive(port)
                self.assertFalse(result["parent_outer_witnesses_observed"])
                self.assertFalse(result["child_release_written"])
                self.assertEqual(port.fork_reads, 0)

    def test_real_port_dispatches_parent_witnesses_before_ready2_ack2(self):
        port = native_port.NativePort.__new__(native_port.NativePort)
        port._plan = PLAN
        port._record = lambda *_args, **_kwargs: None
        ordinals: list[int] = []
        port._line = lambda _handle, _plan, ordinal, _deadline, _sinks: (
            ordinals.append(ordinal) or b"{}\n")
        handle = SimpleNamespace(pid=DIRECT["pid"])
        port.read_parent_witness(handle, (3, 4), 5.0, "A")
        port.read_parent_witness(handle, (3, 4), 5.0, "B")
        port.read_fork_ready(handle, (3, 4), 5.0)
        port.read_fork_released(handle, (3, 4), 5.0)
        self.assertEqual(ordinals, [3, 4, 5, 6])
        with self.assertRaises(ValueError):
            port.read_parent_witness(handle, (3, 4), 5.0, "C")

    def test_prepared_c_orders_parent_oracles_close0_ready2_and_stays_disabled(self):
        source = (Path(__file__).resolve().parent / "probe-prepared.c").read_text()
        anchors = (
            "static const bool NATIVE_MEASUREMENT_ENABLED = false;",
            'probe_read("parent_outer", "A"',
            'probe_read("parent_outer", "B"',
            "pid_t child_pid = fork();",
            "bool prelaunch_fault = close(STDIN_FILENO) != 0;",
            "c17-seatbelt-inheritance-child-ready-v1",
        )
        positions = [source.index(anchor) for anchor in anchors]
        self.assertEqual(positions, sorted(positions))
        child_branch = source.index("if (child_pid == 0)")
        self.assertLess(child_branch, source.index("arm_child_watchdog()", child_branch))
        self.assertLess(source.index("arm_child_watchdog()", child_branch),
                        source.index("child_gate(", child_branch))

    def test_third_source_rehash_cannot_extend_child_gate(self):
        port = FakePort(); port.source_late_on_third = True
        result = self.drive(port)
        self.assertFalse(result["child_release_written"])
        self.assertFalse(result["clean"])
        self.assertEqual(port.signals, [])

    def test_second_source_rehash_cannot_extend_parent_gate(self):
        port = FakePort(); port.source_late_on_second = True
        result = self.drive(port)
        self.assertFalse(result["parent_release_written"])
        self.assertFalse(result["clean"])

    def test_fresh_birth_after_rehash_cannot_extend_parent_gate(self):
        port = FakePort(); port.direct_clock_late_on_recheck = True
        result = self.drive(port)
        self.assertFalse(result["parent_release_written"])
        self.assertEqual(port.release_payloads, [])

    def test_second_gate_deadline_is_single_absolute_value(self):
        port = FakePort()
        result = self.drive(port)
        self.assertEqual(port.fork_deadlines, [5.0, 5.0])
        self.assertEqual(result["fork_gate_deadline_monotonic"], 5.0)
        self.assertEqual(result["case_deadline_monotonic"], 5.0)
        self.assertEqual(result["cleanup_deadline_monotonic"], 8.0)
        for key in ("fork_ready_late", "fork_ack_late"):
            late = FakePort(); setattr(late, key, True)
            self.assertFalse(self.drive(late)["clean"])

    def test_birth_drift_after_initial_attribution_refuses_release2(self):
        port = FakePort(); port.fork_birth_drift_on_recheck = True
        result = self.drive(port)
        self.assertIsNotNone(result["grandchild"])
        self.assertFalse(result["child_release_written"])
        self.assertEqual(port.signals, [])

    def test_ready_and_ack2_reject_duplicates_bools_reorder(self):
        for bad in (
            b'{"schema":"c17-seatbelt-inheritance-child-ready-v1","case":"fork-baseline",'
            b'"nonce":"' + b"a" * 32 + b'","pid":502,"ppid":501,"uid":501,"pgid":501,"pid":502}\n',
            line({"schema": c.FORK_READY_SCHEMA, "case": PLAN.case, "nonce": PLAN.nonce,
                  "pid": True, "ppid": 501, "uid": 501, "pgid": 501}),
        ):
            with self.subTest(bad=bad[:50]):
                port = FakePort(); port.ready2 = bad
                self.assertFalse(self.drive(port)["child_release_written"])
        for bad in (line({"schema": c.FORK_RELEASED_SCHEMA, "case": PLAN.case,
                          "nonce": PLAN.nonce, "pid": True, "ppid": 501,
                          "uid": 501, "pgid": 501}),
                    b'{"pid":502,"schema":"c17-seatbelt-inheritance-child-released-v1",'
                    b'"case":"fork-baseline","nonce":"' + b"a" * 32 +
                    b'","ppid":501,"uid":501,"pgid":501}\n'):
            with self.subTest(bad=bad[:50]):
                port = FakePort(); port.ack2 = bad
                self.assertFalse(self.drive(port)["child_release_confirmed"])

    def test_parent_final_signal_or_missing_reap_never_clean(self):
        for row in ({"event": "child_waitpid", "pid": 502, "wait_status": 14,
                     "exit_code": -14, "signal": 14, "reaped": True,
                     "deadline_met": True},
                    {"event": "child_waitpid", "pid": 502, "wait_status": 0,
                     "exit_code": 0, "signal": 0, "reaped": False,
                     "deadline_met": True}):
            with self.subTest(row=row):
                port = FakePort(); port.final = line(row)
                self.assertFalse(self.drive(port)["clean"])

    def test_wait_status_and_decoded_exit_must_agree(self):
        port = FakePort()
        port.final = line({"event": "child_waitpid", "pid": 502,
                           "wait_status": 256, "exit_code": 0, "signal": 0,
                           "reaped": True, "deadline_met": True})
        result = self.drive(port)
        self.assertFalse(result["clean"])
        self.assertFalse(result["termination_proved"])

    def test_cleanup_child_first_term_grace_then_rechecked_kill(self):
        port = FakePort(); port.wait_returns = [None, None, None, 86]
        port.final = line({"event": "child_waitpid", "pid": 502, "wait_status": 9,
                           "exit_code": -9, "signal": 9, "reaped": True,
                           "deadline_met": True})
        result = self.drive(port)
        self.assertFalse(result["clean"])
        self.assertEqual(port.signals, [(FORK["pid"], signal.SIGTERM),
                                        (FORK["pid"], signal.SIGKILL)])
        self.assertNotIn(DIRECT["pid"], [pid for pid, _sig in port.signals])

    def test_cleanup_libproc_spending_budget_blocks_late_signal(self):
        port = FakePort(); port.wait_returns = [None, None, None]
        port.fork_clock_late_on_cleanup = True
        result = self.drive(port)
        self.assertFalse(result["clean"])
        self.assertEqual(port.signals, [])

    def test_terminal_reap_queue_does_not_extend_cleanup_or_signal_again(self):
        port = FakePort()
        port.wait_returns = [None, None, None, None, None, 86]
        port.tail_reap_at_deadline = True
        port.final = line({"event": "child_waitpid", "pid": 502,
                           "wait_status": 9, "exit_code": -9, "signal": 9,
                           "reaped": True, "deadline_met": False})
        result = self.drive(port)
        self.assertEqual(port.wait_deadlines[-1], 28.0)
        self.assertEqual(result["terminal_reap_deadline_monotonic"], 28.0)
        self.assertTrue(result["termination_proved"])
        self.assertFalse(result["cleanup_deadline_met"])
        self.assertFalse(result["clean"])
        self.assertEqual(port.signals, [(FORK["pid"], signal.SIGTERM),
                                        (FORK["pid"], signal.SIGKILL)])

    def test_false_final_pid_or_missing_final_refuses_termination(self):
        for raw in (line({"event": "child_waitpid", "pid": 777,
                          "wait_status": 0, "exit_code": 0, "signal": 0,
                          "reaped": True, "deadline_met": True}), b""):
            with self.subTest(raw=raw):
                port = FakePort(); port.final = raw
                result = self.drive(port)
                self.assertFalse(result["termination_proved"])
                self.assertFalse(result["cleanup_deadline_met"])

    def test_contract_case_environment_and_no_group_signal_surface(self):
        self.assertEqual(PLAN.argv(), (str(PLAN.binary), "--reviewed-case", "fork-baseline",
                                       "--gate-nonce", "a" * 32))
        with self.assertRaises(ValueError):
            c.Plan(**{**PLAN.__dict__, "environment": {**PLAN.environment,
                    "DYLD_INSERT_LIBRARIES": "/tmp/evil"}}).validate()
        self.assertEqual(c.FORK_KEYS,
                         frozenset(("schema", "case", "nonce", "pid", "ppid", "uid", "pgid")))
        self.assertNotIn("signal_group", c.Port.__dict__)

    def test_trace_fault_blocks_spawn_or_release_before_effect(self):
        port = native_port.NativePort.__new__(native_port.NativePort)
        port.trace_fault = True
        with patch.object(native_port, "NATIVE_MEASUREMENT_ENABLED", True), \
             patch("subprocess.Popen") as popen:
            with self.assertRaisesRegex(ValueError, "trace fautive"):
                port.spawn(PLAN, (3, 4))
            popen.assert_not_called()
        port.trace_fault = False
        port._record = lambda *_args, **_kwargs: setattr(port, "trace_fault", True)
        with patch.object(native_port, "NATIVE_MEASUREMENT_ENABLED", True), \
             patch("subprocess.Popen") as popen:
            with self.assertRaisesRegex(ValueError, "trace fautive"):
                port.spawn(PLAN, (3, 4))
            popen.assert_not_called()
        writes: list[bytes] = []
        stdin = SimpleNamespace(write=lambda data: writes.append(data), flush=lambda: None)
        handle = SimpleNamespace(pid=501, stdin=stdin)
        port.trace_fault = True
        with patch.object(native_port, "NATIVE_MEASUREMENT_ENABLED", True):
            with self.assertRaisesRegex(ValueError, "trace fautive"):
                port.release(handle, b"frame\n")
        port.trace_fault = False
        with patch.object(native_port, "NATIVE_MEASUREMENT_ENABLED", True):
            with self.assertRaisesRegex(ValueError, "trace fautive"):
                port.release(handle, b"frame\n")
        self.assertEqual(writes, [])

    def test_preparation_runner_refuses_before_files_or_popen(self):
        self.assertFalse(c.NATIVE_MEASUREMENT_ENABLED)
        self.assertTrue(native_main.PREPARATION_ONLY)
        with patch("os.open", side_effect=AssertionError("FD interdit")), \
             patch("subprocess.Popen", side_effect=AssertionError("Popen interdit")):
            with self.assertRaisesRegex(ValueError, "préparatoire"):
                native_main.main()


if __name__ == "__main__":
    unittest.main()
