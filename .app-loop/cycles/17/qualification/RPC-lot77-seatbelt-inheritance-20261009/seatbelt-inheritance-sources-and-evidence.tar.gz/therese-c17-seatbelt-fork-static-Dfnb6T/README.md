# LOT77, sonde parent-enfant préparatoire uniquement

Sources sous /private/tmp/therese-c17-inheritance-main-Pkcez7OG.
C ec42972e1af05cdaf1c816116d7583d260455918d23f0e0b6b5288f5db1771c8,
26 078 octets, constante NATIVE_MEASUREMENT_ENABLED=false.
Aucune compilation, API C/libproc native, sonde, Chrome ou G1 exécuté par l'auteur.

## Contrat fermé

Deux cas : fork-baseline puis fork-compiled-alpha, seconde mesure seulement
après lecture MAIN d'un premier résultat vert. Stop au premier rouge.
Argv futur exact : probe --reviewed-case CASE --gate-nonce HEX32.
Source et binaire futur sous la même racine. Le binaire n'existe pas dans ce gel.

OUTER_FORK est un NOUVEAU profil synthétique deny-default : lecture de A,
metadata de A+B et process-fork, sur deux chemins QA littéraux seulement.
ALPHA deny-default : lecture B, metadata A+B. Aucun exec, réseau, Mach,
signal, process-info, subpath, IOKit ni écriture ajouté. Les chaînes C sont
les copies exactes des deux profils physiques. L'opération process-fork n'est
pas une limite kernel à un fork : le source pinné comporte un seul appel
explicite, contrôlé après OUTER. Aucune défense contre code hostile in-process
ni garantie du comportement interne des bibliothèques privées n'est revendiquée.
Ces profils ne sont ni G1 ni le même OUTER que LOT76.

Ordre : FD propres seulement0/1/2, watchdog parent, gate1 LOT76 conservant FD0,
préflight des deux témoins fermant chaque FD, refus ambient, précompile ALPHA
uniquement dans le cas compiled, OUTER, lectures PARENT A/B (READ_OK/READ_DENIED),
contrôle de budget juste avant fork, fork unique.
Enfant : son propre timer10 en premier garde, gate2, lectures fraîches A/B,
sandbox_apply du seul ALPHA déjà en mémoire si compiled, lectures après application,
case_finished, _exit sans atexit/stdio hérité. Ni sandbox_check, ni compilation,
ni proc_pidinfo enfant après OUTER.
Parent : close(FD0) puis child-ready ; ensuite aucune sortie stdout avant
waitpid exact de cet enfant. Final conserve wait_status et code brut négatif
de signal ; un signal ou dépassement reste rouge même si réapage est observé.

Gate1 ready/release/ACK reprend les schémas c17-seatbelt-composition-*-v1,
nonce et vraie naissance parent relue AVANT OUTER. Le seul delta est FD0 retenu.
Gate2/ready2/ACK2 ont exactement les sept clés ordonnées
schema,case,nonce,pid,ppid,uid,pgid. Schemas :
c17-seatbelt-inheritance-child-ready-v1 (émis par PARENT après close0),
c17-seatbelt-inheritance-child-release-v1 (écrit par MAIN),
c17-seatbelt-inheritance-child-released-v1 (ACK par enfant).
Compact ASCII JSON + LF, maximum512 octets, aucun suffixe ni EOF accepté.
Ready2 est une déclaration issue de fork, ACK2 une réception octet-exacte :
aucune naissance C n'est inventée. MAIN doit attribuer hors payload les deux
identités libproc complètes, statut2/3, exécutable et owner, et recontrôler
immédiatement avant release2. Child PGID hérité=parent PGID=parent PID,
jamais child PID. Les rechecks simples getpid/getppid/getuid/geteuid/getpgrp
dans C ne remplacent pas cette attribution externe.

Ordinals stdout :0ready1,1ACK1,2outer_apply,3parent_outer/A,
4parent_outer/B,5ready2,6ACK2, puis lectures enfant et final parent.
Final parent exact sept clés :
event=child_waitpid,pid,wait_status,exit_code,signal,reaped,deadline_met.

## Bornes et clôture à mesurer séparément

SIGALRM défaut/débloqué, SIGCHLD défaut sans SA_NOCLDWAIT, absence de timer
ambiant, ITIMER_REAL parent23 one-shot avant gate1. Immédiatement pré-fork :
getitimer rc0, interval0, restant>=18 s ; CLOCK_MONOTONIC relu APRES ce syscall,
écoulé<=5 s depuis AVANT armement, fork_ns=ce dernier clock.
Aucun réarmement parent. Le budget5 inclut gate1/préparation/OUTER/lectures :
une préparation lente refuse SANS enfant, sans promesse de réussir au pire.
Child setitimer10 one-shot immédiatement après fork, rc0 obligatoire.
Gate2<=fork_ns+5 ; expérience<=release2+5 ; parent WNOHANG exact jusqu'à
fork_ns+18, puis état rouge cleanup_pending restant vivant jusqu'au watchdog23
sans retour prématuré. Aucun signal C vers l'enfant.

MAIN doit démarrer son watchdog avant Popen, fermer son writer si parent
disparaît et nettoyer CHILD attribué AVANT parent, borné8 s, permettant au
parent de réaper. La mort parent ne ferme PAS spontanément le writer MAIN.
Si wait est refusé ou parent disparaît, ne pas revendiquer réapage par MAIN
grand-parent. Distinguer extinction physique, zombie, waitpid et clean.
Un enfant inconnu/divergent interdit signal/release et toute clôture verte.
Pas de préemption garantie d'un syscall/API privé, ni suppression atomique
de la course après dernier recheck ou avant signal. Un watchdog déclenché,
un réapage manquant, une trace/log instable ou un résidu garde le cas rouge,
arrête la série et empêche toute qualification suivante.

Source primaire XNU main kern_exit.c2730-2733 expose mac_proc_check_wait
avant réapage ; mac_policy.h2684-2687 avertit du risque de zombies sur refus.
Cela ne démontre pas la politique du noyau local :
https://raw.githubusercontent.com/apple-oss-distributions/xnu/main/bsd/kern/kern_exit.c
https://raw.githubusercontent.com/apple-oss-distributions/xnu/main/security/mac_policy.h
Le SDK lu fournit sigaction/sigprocmask, getitimer/setitimer et waitpid WNOHANG ;
SIGALRM=14. Les API sandbox privées et bibliothèques après fork restent
expérimentales, sans parité Chrome154 ni garantie de composition.

## Vérification réellement exécutée

50 tests Python de TEXTE C et mutations, outil87685e exit0, 0failure/error/skip,
0 tentative native/process/network. Sept pins avant/après égaux.
Reçu : /private/tmp/therese-c17-inheritance-c-pure-eTIaYL/receipt.json
SHA ba54777bb034e8fe8afdcfe434a354671e25c8a5c558861153eface82178b9aa.
Commande effective UV physique -I -B :
/Users/synoptia/.local/share/uv/python/cpython-3.13.5-macos-aarch64-none/bin/python3.13 -I -B /private/tmp/therese-c17-inheritance-main-Pkcez7OG/test_c_static.py --verify-static --actor /root/shared4_execution --output /private/tmp/therese-c17-inheritance-c-pure-eTIaYL

Deux rouges du validateur conservés, C inchangé :
eb594c :50,1failure/1error (compteur return incluant commentaire et ancre PID double) ;
f06bff :50,2failures (mutants recheck parent/deadline final non refusés).
Préimages tests et diffs exacts jointes ; reçus gardent leurs anciens pointeurs
d'origine, associés ici aux snapshots réellement préservés, jamais réécrits.
Les 40 mutations finales testent le validateur textuel, pas le compilateur/kernel.
Aucun test LOT76 n'est compté comme nouveau test LOT77.

La source LOT76 native8de3 et baseline/compiled-alpha rouges/verts sont seulement
des préimages/preuves historiques. LOT77 n'existe pas comme résultat natif.
FULL=false, Chrome/G1/inheritance qualifiés=false. Contrôleur/port/runner,
activation, binaire, manifeste/runtime et clôture sont propriétés MAIN/Env,
hors de ce gel C ; aucun GO ou autorité n'est auto-fabriqué.
