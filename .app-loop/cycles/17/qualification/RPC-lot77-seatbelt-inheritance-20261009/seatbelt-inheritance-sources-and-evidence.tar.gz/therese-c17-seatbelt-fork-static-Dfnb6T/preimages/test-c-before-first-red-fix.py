"""Real textual C/policy mutants only. No compilation or native API is invoked."""
from __future__ import annotations

import argparse
import ast
import contextlib
import hashlib
import io
import json
import os
from pathlib import Path
import re
import stat
import sys
import time
import unittest
from unittest import mock

ROOT = Path("/private/tmp/therese-c17-inheritance-main-Pkcez7OG")
PREIMAGE = Path("/private/tmp/therese-c17-seatbelt-fork-static-Dfnb6T/preimages/probe-native-lot76.c")
PREIMAGE_SHA = "8de3afdd3eccc89c65e60b11794f35866c95d3ebed95afb322f5cbc8ecff4f38"


def need(condition, message):
    if not condition:
        raise ValueError(message)


def body(source, name):
    match = re.search(r"\b" + re.escape(name) + r"\([^;]*?\)\s*\{(.*?)^\}", source, re.S | re.M)
    need(match is not None, "missing function " + name)
    return match.group(1)


def policy(name):
    a, b = str(ROOT / "witnesses/a.txt"), str(ROOT / "witnesses/b.txt")
    head = '(version 1)\n(deny default)\n'
    metadata = f'(allow file-read-metadata (literal "{a}") (literal "{b}"))\n'
    if name == "OUTER_FORK":
        return head + metadata + f'(allow file-read-data (literal "{a}"))\n(allow process-fork)\n'
    need(name == "ALPHA", "unknown policy")
    return head + metadata + f'(allow file-read-data (literal "{b}"))\n'


def embedded(source, name):
    match = re.search(r"static const char " + name + r"\[\] =\n(.*?);", source, re.S)
    need(match is not None, "missing embedded policy")
    strings = re.findall(r'"(?:\\.|[^"\\])*"', match.group(1))
    return "".join(ast.literal_eval(value) for value in strings)


def require(text, *tokens):
    for token in tokens:
        need(token in text, "missing guard " + token)


def order(text, *tokens):
    positions = [text.index(token) for token in tokens]
    need(positions == sorted(positions) and len(set(positions)) == len(positions), "guard order")


def validate_source(source):
    need("static const bool NATIVE_MEASUREMENT_ENABLED = false;" in source, "native disabled")
    need('static const char QA_ROOT[] = "' + str(ROOT) + '";' in source, "fixed witness root")
    need(embedded(source, "OUTER_FORK") == policy("OUTER_FORK"), "outer policy exact")
    need(embedded(source, "ALPHA") == policy("ALPHA"), "alpha policy exact")
    old = PREIMAGE.read_text()
    need(hashlib.sha256(old.encode()).hexdigest() == PREIMAGE_SHA, "LOT76 preimage")
    for name in ("read_own_fds", "close_inherited_fds", "read_gate_birth",
                 "same_gate_birth", "gate_nonce_valid", "gate_now_ns",
                 "witness_preflight", "probe_read"):
        need(body(source, name) == body(old, name), "preserved LOT76 body " + name)
    old_gate = body(old, "fd0_gate").replace(
        "    if (close(STDIN_FILENO)) return -1;\n",
        "    /* FD0 is retained exclusively for the second closed release after fork. */\n")
    need(body(source, "fd0_gate") == old_gate, "only gate1 change is retain FD0")
    stripped = re.sub(r"/\*.*?\*/|//[^\n]*", "", source, flags=re.S)
    stripped = re.sub(r'"(?:\\.|[^"\\])*"', '""', stripped)
    need(len(re.findall(r"\bfork\s*\(", stripped)) == 1, "exactly one fork call")
    for forbidden in ("execve", "execl", "execv", "posix_spawn", "system", "popen",
                      "socket", "connect", "bind", "kill", "raise", "exit"):
        need(not re.search(r"\b" + forbidden + r"\s*\(", stripped), "forbidden primitive " + forbidden)
    require(source, "#define GATE_LIMIT_NS INT64_C(5000000000)",
            "#define GATE_FRAME_BYTES 512", "#define PARENT_TIMER_SECONDS 23",
            "#define CHILD_TIMER_SECONDS 10", "#define PARENT_WAIT_LIMIT_NS INT64_C(18000000000)")
    watchdog = body(source, "prepare_parent_watchdog")
    require(watchdog, "chld.sa_handler != SIG_DFL", "(chld.sa_flags & SA_NOCLDWAIT)",
            "previous.it_value.tv_sec || previous.it_value.tv_usec",
            "previous.it_interval.tv_sec || previous.it_interval.tv_usec",
            "action.sa_handler = SIG_DFL", "sigaction(SIGALRM, &action, NULL)",
            "sigprocmask(SIG_UNBLOCK, &unblocked, NULL)", "sigismember(&current, SIGALRM) != 0",
            "setitimer(ITIMER_REAL, &timer, NULL)")
    order(watchdog, "*armed_ns = gate_now_ns()", "setitimer(ITIMER_REAL, &timer, NULL)")
    budget = body(source, "before_fork_budget")
    require(budget, "*fork_ns - armed_ns > GATE_LIMIT_NS", "getitimer(ITIMER_REAL, &timer)",
            "timer.it_value.tv_sec < 18", "timer.it_value.tv_usec < 0",
            "timer.it_value.tv_usec >= 1000000", "timer.it_interval.tv_sec || timer.it_interval.tv_usec",
            "fresh < *fork_ns", "fresh - armed_ns > GATE_LIMIT_NS",
            "fresh > INT64_MAX - PARENT_WAIT_LIMIT_NS")
    order(budget, "getitimer(ITIMER_REAL, &timer)", "int64_t fresh = gate_now_ns()", "*fork_ns = fresh")
    require(body(source, "arm_child_watchdog"), "{CHILD_TIMER_SECONDS, 0}",
            "return setitimer(ITIMER_REAL, &timer, NULL)")
    gate = body(source, "child_gate")
    require(gate, "deadline = fork_ns + GATE_LIMIT_NS", "getppid() != parent_pid",
            "getuid() != expected_uid", "geteuid() != expected_uid", "getpgrp() != expected_pgid",
            "c17-seatbelt-inheritance-child-release-v1",
            "c17-seatbelt-inheritance-child-released-v1",
            "if (count <= 0) return -1", "used >= sizeof(received)",
            "used != (size_t)wanted || memcmp(received, expected, used)",
            "if (more != -1 || errno != EAGAIN) return -1",
            "polled <= 0 || now < 0 || now >= deadline", "close(STDIN_FILENO)")
    for forbidden in ("proc_pidinfo(", "read_gate_birth(", "start_sec", "start_usec",
                      "sandbox_", "witness_preflight(", "probe_read("):
        need(forbidden not in gate, "no API/birth before release2")
    order(gate, "close(STDIN_FILENO)", "c17-seatbelt-inheritance-child-released-v1")
    main = body(source, "main")
    require(main, 'argc != 5', '!gate_nonce_valid(argv[4])',
            '(strcmp(argv[2], "fork-baseline") && strcmp(argv[2], "fork-compiled-alpha"))',
            "if (close_inherited_fds()) return 86", "if (prepare_parent_watchdog(&armed_ns)) return 86",
            "if (fd0_gate(argv[2], argv[4])) return 86", "if (ambient != 0) return 2",
            "if (outer_rc != 0) return 86", "parent_a != READ_OK || parent_b != READ_DENIED",
            "parent_pgid != parent_pid", "parent_uid != geteuid()",
            "if (before_fork_budget(armed_ns, &fork_ns)) return 86",
            "if (child_pid < 0) return 86",
            "if (arm_child_watchdog()) _exit(86)",
            "fork_ns, &released_ns)) _exit(86)", "_exit(code)")
    order(main, "if (!NATIVE_MEASUREMENT_ENABLED)", "prepare_parent_watchdog(&armed_ns)",
          "fd0_gate(argv[2], argv[4])", "witness_preflight(a, 'A')", "sandbox_check(getpid(), NULL, 0)",
          "sandbox_compile_string(ALPHA, p, &error)", "sandbox_init_with_parameters(OUTER_FORK",
          'probe_read("parent_outer", "A"', 'probe_read("parent_outer", "B"',
          "before_fork_budget(armed_ns, &fork_ns)", "child_pid = fork()")
    child_branch = main.split("if (child_pid == 0) {", 1)[1].split(
        "bool prelaunch_fault", 1)[0]
    order(child_branch, "if (arm_child_watchdog()) _exit(86)", "child_gate(",
          "child_measure(", "_exit(code)")
    need("proc_pidinfo" not in child_branch and "sandbox_check" not in child_branch,
         "no child introspection API")
    parent_branch = main.split("bool prelaunch_fault", 1)[1]
    order(parent_branch, "close(STDIN_FILENO)", "c17-seatbelt-inheritance-child-ready-v1",
          "fflush(stdout)", "return parent_reap(child_pid, fork_ns, prelaunch_fault)")
    need("read(STDIN_FILENO" not in parent_branch, "parent never consumes frame2")
    measure = body(source, "child_measure")
    require(measure, "deadline = released_ns + GATE_LIMIT_NS",
            'probe_read("inherited_outer", "A"', 'probe_read("inherited_outer", "B"',
            "before_a != READ_OK || before_b != READ_DENIED",
            'if (!strcmp(case_name, "fork-baseline"))',
            'strcmp(case_name, "fork-compiled-alpha")',
            "after_a == READ_DENIED && after_b == READ_DENIED",
            "inner_rc != 0 || !intersection ? 86 : 0")
    order(measure, 'probe_read("inherited_outer", "A"', 'probe_read("inherited_outer", "B"',
          'if (!strcmp(case_name, "fork-baseline"))', "sandbox_apply(compiled_alpha)",
          'probe_read("after_inner", "A"', 'probe_read("after_inner", "B"')
    for forbidden in ("sandbox_compile_", "sandbox_check(", "proc_pidinfo(", "read_gate_birth("):
        need(forbidden not in measure, "child only uses prepared apply")
    need(len(re.findall(r"\bchild_step_in_time\s*\(", measure)) >= 7, "measurement boundaries")
    reap = body(source, "parent_reap")
    require(reap, "deadline = fork_ns + PARENT_WAIT_LIMIT_NS",
            "now < 0 || now >= deadline", "waitpid(child_pid, &status, WNOHANG)",
            "if (waited == child_pid)", "waited < 0 && errno == EINTR",
            "wait_failed = true; pending = true", "WTERMSIG(status)", "-child_signal",
            "pending || !on_time || child_signal || raw_code != 0 ? 86 : 0")
    returns = re.findall(r"\breturn\b", reap)
    need(len(returns) == 2, "no parent early return before reap")
    order(reap, "if (waited == child_pid)", "bool on_time =", "child_waitpid", "return pending")
    need('"reaped\\":false' not in reap, "no false terminal row")
    need("setitimer(" not in reap and "alarm(" not in reap, "parent timer never reset")
    return True


MUTANTS = [
    ("enabled", "NATIVE_MEASUREMENT_ENABLED = false;", "NATIVE_MEASUREMENT_ENABLED = true;"),
    ("witness_root", 'QA_ROOT[] = "' + str(ROOT) + '"', 'QA_ROOT[] = "/Users/synoptia/.therese"'),
    ("fork_twice", "pid_t child_pid = fork();", "pid_t child_pid = fork(); fork();"),
    ("missing_gate1", "if (fd0_gate(argv[2], argv[4])) return 86;", "if (false) return 86;"),
    ("missing_watchdog", "if (prepare_parent_watchdog(&armed_ns)) return 86;", "if (false) return 86;"),
    ("parent_timer30", "#define PARENT_TIMER_SECONDS 23", "#define PARENT_TIMER_SECONDS 30"),
    ("child_timer30", "#define CHILD_TIMER_SECONDS 10", "#define CHILD_TIMER_SECONDS 30"),
    ("parent_wait30", "PARENT_WAIT_LIMIT_NS INT64_C(18000000000)", "PARENT_WAIT_LIMIT_NS INT64_C(30000000000)"),
    ("allow_sigchld_ignore", "chld.sa_handler != SIG_DFL", "chld.sa_handler != SIG_IGN"),
    ("missing_sigalrm_default", "action.sa_handler = SIG_DFL", "action.sa_handler = SIG_IGN"),
    ("sigalrm_blocked", "sigprocmask(SIG_UNBLOCK, &unblocked, NULL)", "sigprocmask(SIG_BLOCK, &unblocked, NULL)"),
    ("missing_mask_recheck", "sigismember(&current, SIGALRM) != 0", "false"),
    ("existing_timer", "previous.it_value.tv_sec || previous.it_value.tv_usec", "false"),
    ("periodic_timer", "{PARENT_TIMER_SECONDS, 0}", "{PARENT_TIMER_SECONDS, 1}"),
    ("stale_clock", "int64_t fresh = gate_now_ns();", "int64_t fresh = *fork_ns;"),
    ("fresh_clock_not_stored", "*fork_ns = fresh;", "*fork_ns = armed_ns;"),
    ("old_fork_window", "*fork_ns - armed_ns > GATE_LIMIT_NS", "*fork_ns - armed_ns > PARENT_WAIT_LIMIT_NS"),
    ("fresh_fork_window", "fresh - armed_ns > GATE_LIMIT_NS", "fresh - armed_ns > PARENT_WAIT_LIMIT_NS"),
    ("remaining_short", "timer.it_value.tv_sec < 18", "timer.it_value.tv_sec < 1"),
    ("ignore_getitimer_rc", "getitimer(ITIMER_REAL, &timer) ||", "false ||"),
    ("child_arm_ignored", "if (arm_child_watchdog()) _exit(86);", "arm_child_watchdog();"),
    ("child_release_ignored", "fork_ns, &released_ns)) _exit(86);", "fork_ns, &released_ns)) { }"),
    ("child_deadline_reset", "deadline = fork_ns + GATE_LIMIT_NS", "deadline = gate_now_ns() + GATE_LIMIT_NS"),
    ("child_eof_accepted", "if (count <= 0) return -1; /* EOF is", "if (count < 0) return -1; /* EOF is"),
    ("queued_extra_accepted", "if (more != -1 || errno != EAGAIN) return -1;\n            break;\n        }\n    }\n    if (getppid()", "if (false) return -1;\n            break;\n        }\n    }\n    if (getppid()"),
    ("frame2_pid_unchecked", "nonce, getpid(), parent_pid, (unsigned)expected_uid, expected_pgid);", "nonce, 1, parent_pid, (unsigned)expected_uid, expected_pgid);"),
    ("wrong_parent", "if (getppid() != parent_pid || getuid() != expected_uid", "if (false || getuid() != expected_uid"),
    ("missing_parent_b_guard", "parent_a != READ_OK || parent_b != READ_DENIED", "parent_a != READ_OK"),
    ("missing_child_b_guard", "before_a != READ_OK || before_b != READ_DENIED", "before_a != READ_OK"),
    ("inner_false_green", "inner_rc != 0 || !intersection ? 86 : 0", "!intersection ? 86 : 0"),
    ("weaken_intersection", "after_a == READ_DENIED && after_b == READ_DENIED", "after_b == READ_DENIED"),
    ("wait_any_pid", "waitpid(child_pid, &status, WNOHANG)", "waitpid(-1, &status, WNOHANG)"),
    ("blocking_wait", "waitpid(child_pid, &status, WNOHANG)", "waitpid(child_pid, &status, 0)"),
    ("early_return_parent", "bool pending = prelaunch_fault, wait_failed = false;", "bool pending = prelaunch_fault, wait_failed = false; return 86;"),
    ("fake_reap", "if (waited == child_pid)", "if (waited >= 0)"),
    ("fake_deadline", "bool on_time = reaped_at >= 0 && reaped_at < deadline;", "bool on_time = true;"),
    ("signal_code_lost", "child_signal ? -child_signal : 86", "child_signal ? 0 : 86"),
    ("return_in_child", "_exit(code);", "exit(code);"),
    ("fork_budget_skipped", "if (before_fork_budget(armed_ns, &fork_ns)) return 86;", "if (false) return 86;"),
    ("parent_fd0_kept", "bool prelaunch_fault = close(STDIN_FILENO) != 0;", "bool prelaunch_fault = false;"),
]


class StaticC(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.source = (ROOT / "probe-prepared.c").read_text()

    def test_actual_c_guards(self):
        self.assertTrue(validate_source(self.source))

    def test_two_physical_policies_literal_exact(self):
        self.assertEqual((ROOT / "policies/outer-fork.sb").read_text(), policy("OUTER_FORK"))
        self.assertEqual((ROOT / "policies/alpha.sb").read_text(), policy("ALPHA"))

    def test_embedded_profiles_match_physical(self):
        self.assertEqual(embedded(self.source, "OUTER_FORK"), (ROOT / "policies/outer-fork.sb").read_text())
        self.assertEqual(embedded(self.source, "ALPHA"), (ROOT / "policies/alpha.sb").read_text())

    def test_exact_private_synthetic_witnesses(self):
        self.assertEqual((ROOT / "witnesses/a.txt").read_bytes(), b"A:synthetic-witness-only\n")
        self.assertEqual((ROOT / "witnesses/b.txt").read_bytes(), b"B:synthetic-witness-only\n")

    def test_no_extra_policy_grants(self):
        for name in ("OUTER_FORK", "ALPHA"):
            text = policy(name)
            for token in ("allow default", "network", "mach-", "iokit", "process-info",
                          "signal", "file-write", "subpath", "process-exec"):
                self.assertNotIn(token, text)
        self.assertEqual(policy("OUTER_FORK").count("(allow process-fork)"), 1)
        self.assertNotIn("process-fork", policy("ALPHA"))

    def test_child_gate_has_no_birth_claim(self):
        text = body(self.source, "child_gate")
        for key in ("start_sec", "start_usec", "birth", "proc_pidinfo"):
            self.assertNotIn(key, text)

    def test_missing_witness_is_not_a_denial(self):
        text = body(self.source, "probe_read")
        self.assertIn("open_errno == EPERM || open_errno == EACCES", text)
        self.assertNotIn("ENOENT", text)

    def test_nothing_native_is_admitted_by_text(self):
        self.assertIn("NATIVE_MEASUREMENT_ENABLED = false;", self.source)
        self.assertIn('\\"native_qualification\\":false', self.source)
        self.assertIn('\\"FULL\\":false', self.source)

    def test_child_no_inherited_stdio_exit(self):
        branch = body(self.source, "main").split("if (child_pid == 0) {", 1)[1]
        self.assertIn("_exit(code)", branch)
        self.assertNotIn("return child_measure", branch)

    def test_parent_no_postfork_child_signal(self):
        text = body(self.source, "parent_reap")
        self.assertNotIn("kill(", text)
        self.assertNotIn("setitimer(", text)


def attach_mutant(name, old, new):
    def test(self):
        # Every mutation changes actual C source text; this is not native C execution.
        self.assertEqual(self.source.count(old), 1, name + " must have one real anchor")
        with self.assertRaises((ValueError, IndexError)):
            validate_source(self.source.replace(old, new, 1))
    setattr(StaticC, "test_mutant_" + name, test)


for _name, _old, _new in MUTANTS:
    attach_mutant(_name, _old, _new)


def reference(path):
    path = Path(path)
    before = path.lstat()
    need(path.resolve(strict=True) == path and stat.S_ISREG(before.st_mode)
         and before.st_uid == os.getuid() and before.st_nlink == 1, "noncanonical QA asset")
    data = path.read_bytes()
    after = path.lstat()
    keys = ("st_dev", "st_ino", "st_mode", "st_nlink", "st_uid", "st_gid",
            "st_size", "st_mtime_ns", "st_ctime_ns")
    need(all(getattr(before, key) == getattr(after, key) for key in keys), "asset changed during read")
    return {"path": str(path), "sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)}


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--verify-static", action="store_true")
    parser.add_argument("--compile", action="store_true")
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--actor")
    parser.add_argument("--output")
    args = parser.parse_args(argv)
    if args.compile or args.execute or not args.verify_static:
        print('{"prepared_only":true,"C_compiled":false,"native_started":false}')
        return 2
    need(args.actor in {"/root", "/root/shared4_execution", "/root/cycle17_gate_review"},
         "literal actual CLI actor required; not authority")
    need(args.output is not None, "exclusive private test output required")
    out = Path(args.output)
    observed = out.lstat()
    need(out.parent == Path("/private/tmp") and out.name.startswith("therese-c17-inheritance-c-pure-")
         and out.resolve(strict=True) == out and stat.S_ISDIR(observed.st_mode)
         and observed.st_uid == os.getuid() and stat.S_IMODE(observed.st_mode) == 0o700
         and not any(out.iterdir()), "empty private output")
    paths = [ROOT / name for name in ("probe-prepared.c", "test_c_static.py",
              "policies/outer-fork.sb", "policies/alpha.sb", "witnesses/a.txt", "witnesses/b.txt")]
    paths.append(PREIMAGE)
    before = [reference(path) for path in paths]
    attempts = []

    def denied(*a, **k):
        attempts.append("forbidden native/process/network entry point")
        raise AssertionError(attempts[-1])

    # Python test runner only, with all process/native/network entry points guarded.
    import ctypes
    import socket
    import subprocess
    guards = [mock.patch.object(subprocess, name, denied) for name in
              ("Popen", "run", "call", "check_call", "check_output")]
    guards += [mock.patch.object(os, name, denied) for name in
               ("system", "execve", "kill", "fork", "posix_spawn", "posix_spawnp") if hasattr(os, name)]
    guards += [mock.patch.object(ctypes, "CDLL", denied),
               mock.patch.object(socket, "socket", denied),
               mock.patch.object(socket, "create_connection", denied)]
    stream = io.StringIO()
    started = time.monotonic()
    with contextlib.ExitStack() as stack:
        for guard in guards:
            stack.enter_context(guard)
        result = unittest.TextTestRunner(stream=stream, verbosity=2).run(
            unittest.defaultTestLoader.loadTestsFromTestCase(StaticC))
    elapsed = time.monotonic() - started
    after = [reference(path) for path in paths]
    with (out / "returned-test-output.log").open("xb") as sink:
        sink.write(stream.getvalue().encode())
    receipt = {"schema": "c17-seatbelt-inheritance-C-static-tests-v1", "actor": args.actor,
               "scope": "real_C_text_and_mutants_only", "tests_run": result.testsRun,
               "failures": len(result.failures), "errors": len(result.errors), "skips": len(result.skipped),
               "elapsed_seconds": elapsed, "forbidden_attempts": attempts,
               "source_before": before, "source_after": after, "source_unchanged": before == after,
               "output_ref": reference(out / "returned-test-output.log"),
               "passed": result.wasSuccessful() and not attempts and before == after,
               "C_compiled": False, "Apple_profile_compiled": False, "native_started": False,
               "libproc_called": False, "G1_imported": False, "Chrome_started": False, "FULL": False}
    with (out / "receipt.json").open("x") as sink:
        json.dump(receipt, sink, indent=2, sort_keys=True)
        sink.write("\n")
    print(json.dumps({key: receipt[key] for key in
                     ("tests_run", "failures", "errors", "passed", "forbidden_attempts")}))
    return 0 if receipt["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
