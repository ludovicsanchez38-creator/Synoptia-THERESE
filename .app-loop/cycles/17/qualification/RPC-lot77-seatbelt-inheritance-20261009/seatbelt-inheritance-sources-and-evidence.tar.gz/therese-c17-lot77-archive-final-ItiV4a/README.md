# LOT77, collecteur préparatoire

Le collecteur reprend le format de LOT76 : une archive TAR.GZ, un `MANIFEST.json`
de références physiques et un `archive-receipt.json` obtenu après relecture sans
extraction. Il reste limité à 64 fichiers, 2 MiB par fichier, 16 MiB bruts et
16 MiB compressés. Aucun dossier n'est parcouru récursivement, aucun symlink ou
hardlink n'est suivi. La table C provient exclusivement des 25 `files` de
l'INDEX statique SHA `344b14cd…`, pas de ses `origin_refs`.
Les temps physiques observés sont conservés dans le manifeste ; le TAR emploie
un mtime neutre et ne prétend pas dater les mesures.

Les chemins supplémentaires sont littéraux : quatre sources Python préparées,
quatre sources activées distinctes, PLAN, contrôle C MAIN, revue Gate, manifest
runtime, compilation, deux cas et clôture. Le binaire Mach-O est vérifié contre
`NATIVE-SOURCES.json` et conservé comme ref physique dans le manifeste et le
reçu, mais ses octets sont exclus du TAR comme dans LOT76. L'archive conserve les
résultats rouges tels quels. Elle ne transforme aucun test pur ni canari en
qualification Chrome, G1 ou FULL. La première sortie outil Python 25 cas
`48e234` n'avait pas de reçu disque ; le rejeu MAIN ultérieur possède le reçu
`controller-main-pure.json` et le tool chunk `957cca`, archivés comme tels sans
fusion de leurs identités. L'INDEX Gate préparatoire exact, son futur
`NATIVE-REVIEW.json` terminal et le PREP-INDEX du premier collecteur sont des
entrées explicites ; l'ancien script reste intact.

`--plan` est une lecture seule qui signale les chemins manquants. `--create`
refuse tant que toutes les preuves terminales ne sont pas présentes et que MAIN
n'a pas donné la référence SHA/bytes exacte de `SERIES-CLOSURE.json`. La liste
`FINAL` (notamment le nom physique de la compilation et de la clôture) devra
être confirmée par MAIN avant collection ; si elle diffère, préparer un nouveau
gel du collecteur plutôt qu'un fallback libre. Exemple de commande future,
non exécutée ici :

```text
python3 -I -B archive_lot77.py --create /private/tmp/therese-c17-seatbelt-inheritance-archive-XXXXXX --closure-sha SHA64 --closure-bytes N
```

Le dossier de sortie doit déjà être privé (0700), canonique et vide. Ce gel ne
contient aucune archive et ne consomme aucune autorité native.
