"""Archive fermée LOT77 : sources et preuves, jamais autorité native.

La table C est les 25 refs `files` d'un INDEX SHA-épinglé, sans suivi de ses
`origin_refs`. Les autres chemins sont tous littéraux. `--plan` est lecture
seule ; `--create` exige les deux cas terminés et une ref de clôture fournie
explicitement par MAIN après sa revue. Aucun lancement d'instrument ici.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import tarfile
from typing import Any

TMP = Path("/private/tmp")
MAIN = TMP / "therese-c17-inheritance-main-Pkcez7OG"
STATIC = TMP / "therese-c17-seatbelt-fork-static-Dfnb6T"
GATE = TMP / "therese-c17-inheritance-review-Vviw9m3w"
MAIN_C_PURE = TMP / "therese-c17-inheritance-c-pure-UCBlDfNr"
BINARY = MAIN / "probe"
INDEX = STATIC / "INDEX.json"
INDEX_SHA256 = "344b14cd5fb55a0ed9a3993e8d27add225007b2a9bf9b98fc2534271e0423f99"
INDEX_BYTES = 11488
GATE_INDEX_SHA256 = "c5b052d145f7ddf23a41da55cccb7222c0a9bb5fecdd8318b1fdb894a463a7f0"
PREP_INDEX = TMP / "therese-c17-lot77-archive-prep-PL0U4s/PREP-INDEX.json"
PREP_INDEX_SHA256 = "d7073ec7d3747757d668978ed8b64eb57ddab6d3d781841200bfc5922154f833"

# Pas de parcours d'arbre, de `origin_refs`, de SDK, de dossier personnel.
ADDITIONAL = (
    MAIN / "controller.py",
    MAIN / "native_port.py",
    MAIN / "native_main.py",
    MAIN / "tests_controller.py",
    MAIN / "controller-native.py",
    MAIN / "native_port-native.py",
    MAIN / "native_main-active.py",
    MAIN / "probe-native.c",
    MAIN / "PLAN.json",
    MAIN / "ACTIVATION-INDEX.json",
    MAIN / "controller-main-pure.json",
    MAIN_C_PURE / "receipt.json",
    MAIN_C_PURE / "returned-test-output.log",
    GATE / "REVIEW.md",
    GATE / "observations.json",
    GATE / "INDEX.json",
    GATE / "NATIVE-REVIEW.json",
    PREP_INDEX,
)

# Tous restent obligatoires pour `--create`, même si `--plan` les signale absents.
FINAL = (
    MAIN / "NATIVE-SOURCES.json",
    MAIN / "compile-enabled.json",
    MAIN / "cases/fork-baseline/result.json",
    MAIN / "cases/fork-baseline/stdout.log",
    MAIN / "cases/fork-baseline/stderr.log",
    MAIN / "cases/fork-baseline/trace.jsonl",
    MAIN / "cases/fork-compiled-alpha/result.json",
    MAIN / "cases/fork-compiled-alpha/stdout.log",
    MAIN / "cases/fork-compiled-alpha/stderr.log",
    MAIN / "cases/fork-compiled-alpha/trace.jsonl",
    MAIN / "SERIES-CLOSURE.json",
)

MAX_FILES = 64
MAX_FILE_BYTES = 2 * 1024 * 1024
MAX_TOTAL_BYTES = 16 * 1024 * 1024
MAX_ARCHIVE_BYTES = 16 * 1024 * 1024


def need(ok: bool, reason: str) -> None:
    if not ok:
        raise ValueError(reason)


def stat_key(st: os.stat_result) -> tuple[int, ...]:
    # atime peut varier par lecture ; identité, mode, contenu et dates stables.
    return (st.st_dev, st.st_ino, st.st_uid, st.st_gid, st.st_mode, st.st_nlink,
            st.st_size, st.st_mtime_ns, st.st_ctime_ns)


def read_exact(path: Path, *, limit: int = MAX_FILE_BYTES) -> tuple[dict[str, Any], bytes]:
    need(path.is_absolute() and path.is_relative_to(TMP)
         and path.resolve(strict=True) == path, "chemin non canonique/hors TMP")
    before = path.lstat()
    need(stat.S_ISREG(before.st_mode) and before.st_uid == os.getuid()
         and before.st_nlink == 1 and 0 <= before.st_size <= limit,
         "fichier non régulier/propriétaire/exclusif/borné : " + str(path))
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        need(stat_key(os.fstat(fd)) == stat_key(before), "fichier changé à l'ouverture")
        parts: list[bytes] = []
        remaining = before.st_size
        while remaining:
            part = os.read(fd, min(remaining, 65536))
            need(bool(part), "lecture partielle")
            parts.append(part)
            remaining -= len(part)
        need(not os.read(fd, 1), "fichier allongé pendant lecture")
        need(stat_key(os.fstat(fd)) == stat_key(before)
             and stat_key(path.lstat()) == stat_key(before),
             "fichier changé pendant lecture")
    finally:
        os.close(fd)
    data = b"".join(parts)
    member = path.relative_to(TMP).as_posix()
    need(member and not member.startswith("/") and ".." not in Path(member).parts,
         "membre archive dangereux")
    row = {"path": str(path), "member": member, "sha256": hashlib.sha256(data).hexdigest(),
           "bytes": len(data), "mode": stat.S_IMODE(before.st_mode),
           "uid": before.st_uid, "gid": before.st_gid, "physical_stat": stat_key(before)}
    return row, data


def selected_paths() -> tuple[Path, ...]:
    index_row, raw = read_exact(INDEX)
    need(index_row["sha256"] == INDEX_SHA256 and index_row["bytes"] == INDEX_BYTES,
         "INDEX C divergent")
    need(read_exact(GATE / "INDEX.json")[0]["sha256"] == GATE_INDEX_SHA256,
         "INDEX Gate préparatoire divergent")
    need(read_exact(PREP_INDEX)[0]["sha256"] == PREP_INDEX_SHA256,
         "origine du collecteur précédent divergente")
    data = json.loads(raw)
    need(type(data) is dict and data.get("schema") == "c17-seatbelt-inheritance-C-static-index-v1"
         and data.get("root") == str(MAIN) and data.get("native_enabled") is False
         and type(data.get("files")) is list and len(data["files"]) == 25,
         "table C non fermée à 25 refs préparatoires")
    from_index: list[Path] = []
    for item in data["files"]:
        need(type(item) is dict and frozenset(item) == frozenset(("path", "sha256", "bytes"))
             and type(item["path"]) is str and type(item["sha256"]) is str
             and type(item["bytes"]) is int, "ref C mal formée")
        path = Path(item["path"])
        need(path.is_absolute() and path.is_relative_to(TMP), "ref C hors TMP")
        actual, _ = read_exact(path)
        need((actual["sha256"], actual["bytes"]) == (item["sha256"], item["bytes"]),
             "ref C changée : " + str(path))
        from_index.append(path)
    paths = (INDEX, *from_index, *ADDITIONAL, *FINAL,
             Path(__file__).resolve(), Path(__file__).resolve().parent / "README.md")
    need(len(paths) == len(set(paths)) and len(paths) <= MAX_FILES,
         "doublons ou table trop grande")
    return paths


def snapshot(*, complete: bool) -> tuple[list[dict[str, Any]], list[str]]:
    paths = selected_paths()
    missing = [str(path) for path in paths if not path.exists()]
    if complete:
        need(not missing, "preuves finales absentes : " + ", ".join(missing))
    rows = [read_exact(path)[0] for path in paths if path.exists()]
    need(len({row["member"] for row in rows}) == len(rows), "membres doublés")
    need(sum(row["bytes"] for row in rows) <= MAX_TOTAL_BYTES, "taille brute > 16 MiB")
    return rows, missing


def binary_ref(rows: list[dict[str, Any]]) -> dict[str, Any]:
    """Mach-O métadonnée seule ; ses octets ne deviennent jamais membre TAR."""
    row, _ = read_exact(BINARY)
    sources = next(item for item in rows if item["path"] == str(MAIN / "NATIVE-SOURCES.json"))
    _sources_row, raw = read_exact(Path(sources["path"]))
    data = json.loads(raw)
    need(type(data) is dict and data.get("schema") == "c17-seatbelt-inheritance-main-sources-v1"
         and data.get("root") == str(MAIN) and type(data.get("files")) is list,
         "NATIVE-SOURCES non fermé")
    matches = [item for item in data["files"] if type(item) is dict
               and item.get("path") == str(BINARY)]
    need(len(matches) == 1 and (matches[0].get("sha256"), matches[0].get("bytes"))
         == (row["sha256"], row["bytes"]), "binaire non lié au manifest neuf")
    return row


def exclusive_bytes(path: Path, data: bytes) -> None:
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC,
                 0o600)
    try:
        need(os.write(fd, data) == len(data), "écriture partielle")
        os.fsync(fd)
    finally:
        os.close(fd)


def tar_member(tar: tarfile.TarFile, row: dict[str, Any]) -> None:
    current, data = read_exact(Path(row["path"]))
    need(current == row, "source changée entre plan et archive")
    info = tarfile.TarInfo(row["member"])
    info.type = tarfile.REGTYPE
    info.mode, info.uid, info.gid = row["mode"], row["uid"], row["gid"]
    info.uname = info.gname = ""
    info.size = row["bytes"]
    tar.addfile(info, io.BytesIO(data))


def create(out: Path, closure_sha: str, closure_bytes: int) -> dict[str, Any]:
    need(len(closure_sha) == 64 and all(ch in "0123456789abcdef" for ch in closure_sha)
         and 0 < closure_bytes <= MAX_FILE_BYTES, "ref terminale invalide")
    rows, missing = snapshot(complete=True)
    need(not missing, "preuve finale absente")
    binary = binary_ref(rows)
    closure = next(row for row in rows if row["path"] == str(MAIN / "SERIES-CLOSURE.json"))
    need((closure["sha256"], closure["bytes"]) == (closure_sha, closure_bytes),
         "clôture terminale non épinglée par MAIN")
    need(out.parent == TMP and out.name.startswith("therese-c17-seatbelt-inheritance-archive-")
         and out.resolve(strict=True) == out and out.is_dir(), "sortie hors TMP privée")
    st = out.lstat()
    need(st.st_uid == os.getuid() and stat.S_IMODE(st.st_mode) == 0o700
         and not any(out.iterdir()), "sortie non vide/non privée")
    manifest = {"schema": "c17-seatbelt-inheritance-archive-manifest-v1",
                "scope": "sources_and_terminal_evidence_archival_only",
                "files": rows, "closure_ref": closure,
                "binary_ref_unarchived": binary,
                "controller_pure_tests": {"count": 25, "main_tool_chunk": "957cca",
                                          "earlier_tool_chunk": "48e234",
                                          "main_filesystem_receipt": str(MAIN / "controller-main-pure.json")},
                "FULL": False, "Chrome_qualified": False,
                "qualification_created_by_archive": False}
    manifest_path = out / "MANIFEST.json"
    exclusive_bytes(manifest_path, (json.dumps(manifest, sort_keys=True, indent=2) + "\n").encode())
    manifest_row, _ = read_exact(manifest_path)
    manifest_row["member"] = "MANIFEST.json"
    archive_path = out / "seatbelt-inheritance-sources-and-evidence.tar.gz"
    fd = os.open(archive_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW |
                 os.O_CLOEXEC, 0o600)
    try:
        with os.fdopen(fd, "wb", closefd=False) as stream:
            with gzip.GzipFile(fileobj=stream, mode="wb", mtime=0) as gz:
                with tarfile.open(fileobj=gz, mode="w|", format=tarfile.PAX_FORMAT) as tar:
                    for row in rows:
                        tar_member(tar, row)
                    # Le manifeste possède une seule entrée, hors liste des sources.
                    current, data = read_exact(manifest_path)
                    need(current["sha256"] == manifest_row["sha256"], "manifest muté")
                    info = tarfile.TarInfo("MANIFEST.json")
                    info.type = tarfile.REGTYPE
                    info.mode, info.uid, info.gid = current["mode"], current["uid"], current["gid"]
                    info.uname = info.gname = ""
                    info.size = len(data)
                    tar.addfile(info, io.BytesIO(data))
            stream.flush()
            os.fsync(fd)
    finally:
        os.close(fd)
    archive_row, _ = read_exact(archive_path, limit=MAX_ARCHIVE_BYTES)
    need(archive_row["bytes"] <= MAX_ARCHIVE_BYTES, "archive > 16 MiB")
    expected = {row["member"]: row for row in rows}
    expected["MANIFEST.json"] = manifest_row
    seen: set[str] = set()
    with tarfile.open(archive_path, mode="r:gz") as tar:
        for member in tar:
            need(member.isfile() and member.name in expected and member.name not in seen
                 and not member.name.startswith("/") and ".." not in Path(member.name).parts,
                 "membre inconnu/non régulier/doublé")
            row = expected[member.name]
            stream = tar.extractfile(member)
            need(stream is not None and member.size == row["bytes"], "membre illisible/taille")
            digest = hashlib.sha256()
            while chunk := stream.read(65536):
                digest.update(chunk)
            need(digest.hexdigest() == row["sha256"], "membre contenu divergent")
            seen.add(member.name)
    need(seen == set(expected), "table TAR incomplète")
    need(read_exact(archive_path, limit=MAX_ARCHIVE_BYTES)[0] == archive_row,
         "archive changée pendant la vérification")
    again, changed = snapshot(complete=True)
    need(not changed and again == rows and binary_ref(again) == binary,
         "sources/binaire changés après relecture archive")
    receipt = {"schema": "c17-seatbelt-inheritance-archive-receipt-v1",
               "archive": archive_row, "manifest": read_exact(manifest_path)[0],
               "binary_ref_unarchived": binary,
               "members_verified_without_extraction": len(seen),
               "sources_unchanged": True, "FULL": False,
               "native_authority_created": False}
    exclusive_bytes(out / "archive-receipt.json",
                    (json.dumps(receipt, sort_keys=True, indent=2) + "\n").encode())
    return receipt


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--plan", action="store_true")
    parser.add_argument("--create", type=Path)
    parser.add_argument("--closure-sha")
    parser.add_argument("--closure-bytes", type=int)
    args = parser.parse_args()
    need(args.plan != bool(args.create), "choisir plan OU create")
    if args.plan:
        need(args.closure_sha is None and args.closure_bytes is None,
             "aucune autorité terminale dans le plan")
        rows, missing = snapshot(complete=False)
        observed_binary = read_exact(BINARY)[0] if BINARY.exists() else None
        result = {"schema": "c17-seatbelt-inheritance-archive-plan-v1",
                  "selected_existing": len(rows), "missing_paths": missing,
                  "raw_bytes_existing": sum(row["bytes"] for row in rows),
                  "binary_ref_unarchived": observed_binary,
                  "archive_emitted": False,
                  "controller_pure_main_tool_chunk": "957cca",
                  "controller_pure_earlier_tool_chunk": "48e234",
                  "FULL": False}
    else:
        need(args.closure_sha is not None and args.closure_bytes is not None,
             "ref terminale explicite requise")
        result = create(args.create, args.closure_sha, args.closure_bytes)
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (ValueError, FileNotFoundError, KeyError) as error:
        print(json.dumps({"status": "refused", "reason": str(error), "archive_emitted": False}))
        raise SystemExit(2)
