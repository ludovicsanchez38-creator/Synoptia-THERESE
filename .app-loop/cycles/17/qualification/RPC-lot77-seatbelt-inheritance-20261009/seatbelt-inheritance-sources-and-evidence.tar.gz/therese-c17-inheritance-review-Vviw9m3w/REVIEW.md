# LOT77 : revue indépendante préparatoire

Acteur : /root/cycle17_gate_review. Lecture FS/source uniquement.

Avis favorable limité à la préparation finale C ec42972e et Python 6945b726 / 29adf629 / e0657d48, tests07ba6fc6. Aucun nouveau bloqueur statique trouvé. Les 25 fichiers et neuf origines de l'INDEX C344b14cd sont rehashés, ainsi que les sept références complémentaires. Les quatre paires de corps diff direct/inverse correspondent aux sources réelles ; les en-têtes temporels ne sont pas recomposés.

La queue terminale started+28 ne contient qu'une attente/réapage du parent direct déjà possédé. Les délais des gates et de l'expérience restent5/5/5, cleanup8 reste le seuil de clôture verte. Un parent réapé tardivement ou un enfant non attribué ne deviennent jamais clean par cette queue.

C, contrôleur et runner restent désactivés. Les 50 tests textuels sont appuyés par un reçu/log auteur lus ; les 25 doubles Python ont été annoncés par Env et leurs corps lus. Aucun test, C, compilateur, libproc, signal, G1 ou réseau n'a été exécuté par le relecteur. Les anciens rouges/snapshots gardent leur temporalité.

Les réserves sont dans observations.json : bibliothèques privées après fork non garanties par le manuel, snapshots non atomiques et non-préemption, enfant inconnu dont timer10 peut dépasser cleanup8, aucune clôture exhaustive si reap parent28/footer enfant manquant. Le manuel SDK physique est /Library/Developer/CommandLineTools/SDKs/MacOSX26.5.sdk/usr/share/man/man2/fork.2, SHAe9ab8f14,4666B, caveat125-136. Il distingue fork d'exec, sans prouver la sûreté de sandbox_apply après fork.

Ce diagnostic synthétique reste dans l'autorité QA ordinaire déjà demandée. Une modification substantielle de G1/broker ou une exception de frontière Chrome serait une autre décision. Ce reçu interprète les sources ; il ne constitue pas un GO. MAIN doit relire la dérivation active et sa compilation réelle, mesurer baseline, puis arrêter au premier rouge. Aucune qualification Chrome, inheritance générale, FULL ou release.

## Volet distinct : copies actives MAIN

Quatre copies actives rehashées et quatre diffs lus : C d5db75bb/26079B, controller3b424094/29091B, port49e406ba/15638B, runnerc4dc3b6a/10969B. Seuls commentaires/bools/table des neuf refs et chemins load_local changent. La table vise la source C active, pas le prepared=false comme source prétendue du futur binaire. Les alias controller/native_port sont chargés à partir de bytes rehashés avant exec. Profils, root, délais, cleanup8/queue28, oracles et filiation sont conservés.

Avis favorable limité à cette dérivation et sa compilation réelle future sous contrôle MAIN. Aucun binaire ou manifeste runtime n'a été qualifié par cette revue, et aucune sonde n'a été exécutée par moi. Baseline d'abord, second cas seulement après lecture du premier vert, arrêt au premier rouge.

Dernier readback FS prébaseline à02:32:08Z : compilation MAIN1940cd exit0 documentée dans df8ae590/1489B ; vrai binaire e6a7ae3e/36312B rehashé, mode755. Le manifeste f2ed24ef/2035B a neuf refs physiques exactes. Root/home/tmp sont700. Ce supplément constate SHA/taille et le reçu de compilation MAIN ; il ne mesure ni API, ni kernel, ni cas natif. Les résultats natifs ultérieurs relèvent d'une autre revue.
