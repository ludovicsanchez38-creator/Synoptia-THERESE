// MAIN : précontrôle, tests purs et compilation d'un microcanari isolé.
// Ne lance ni le canari natif, ni Chrome, ni G1. Les sorties sont exclusives.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawnSync } from 'node:child_process';

const PY = '/Users/synoptia/.local/share/uv/python/cpython-3.13.5-macos-aarch64-none/bin/python3.13';
const [action, gel, indexSha, qaRoot] = process.argv.slice(2);
const requireThat = (ok, msg) => { if (!ok) throw new Error(msg); };
requireThat(['pure', 'compile'].includes(action), 'Action fermée');
requireThat(/^\/private\/tmp\/therese-c17-mach-register-micro-[A-Za-z0-9-]+$/.test(gel), 'Gel fermé');
requireThat(/^[a-f0-9]{64}$/.test(indexSha), 'SHA requis');
const ref = (p) => {
  const s = fs.lstatSync(p);
  requireThat(fs.realpathSync(p) === p && s.isFile() && s.uid === process.getuid(), 'Référence non canonique/owner : ' + p);
  const b = fs.readFileSync(p);
  return { path: p, sha256: crypto.createHash('sha256').update(b).digest('hex'), bytes: b.length };
};
const same = (a,b) => a.path === b.path && a.sha256 === b.sha256 && a.bytes === b.bytes;
const indexRef = ref(path.join(gel, 'INDEX.json'));
requireThat(indexRef.sha256 === indexSha, 'INDEX différent');
const index = JSON.parse(fs.readFileSync(indexRef.path));
requireThat(index.schema === 'c17-mach-register-micro-preparation-index-v1' && index.compiled === false && index.native_executed === false, 'Gel non préparatoire');
// Les origines système appartiennent à root : contenu et cible canonique sont contrôlés séparément.
const originRef = (p) => {
  const s = fs.lstatSync(p);
  requireThat(fs.realpathSync(p) === p && s.isFile(), 'Origine non canonique/régulière : ' + p);
  const b = fs.readFileSync(p);
  return { path: p, sha256: crypto.createHash('sha256').update(b).digest('hex'), bytes: b.length };
};
const pins = [...index.files, ...index.origin_refs, ...index.proof_refs];
requireThat(index.files.length === 15 && index.origin_refs.length === 5 && index.proof_refs.length === 3 && pins.length === 23, 'Références fermées du successeur SDK');
const aliases = JSON.parse(fs.readFileSync(gel+'/SDK-ALIASES.json'));
requireThat(aliases.schema === 'c17-mach-register-sdk-alias-observation-v1' && aliases.symlinks.length === 2 && aliases.header_aliases.length === 4, 'Aliases SDK fermés');
const check = () => {
  requireThat(same(ref(indexRef.path), indexRef), 'INDEX muté');
  for (const item of pins) requireThat(same(originRef(item.path), item), 'Pin divergent : ' + item.path);
  requireThat(same(originRef(index.successor_of_index_ref.path),index.successor_of_index_ref), 'Préimage INDEX mutée');
  for (const link of aliases.symlinks) {
    const s = fs.lstatSync(link.path), text = fs.readlinkSync(link.path);
    requireThat(s.isSymbolicLink() && text === link.link_text && Buffer.byteLength(text) === link.link_text_bytes
      && s.size === link.lstat_bytes && s.uid === link.uid && s.gid === link.gid && s.nlink === link.nlink
      && s.dev === link.dev && s.ino === link.ino && (s.mode & 0o7777) === Number(link.mode)
      && fs.realpathSync(link.path) === link.resolved_target
      && crypto.createHash('sha256').update(text).digest('hex') === link.link_text_sha256, 'Lien SDK divergent : '+link.path);
  }
  for (const header of aliases.header_aliases) {
    const s = fs.lstatSync(header.canonical_target_ref.path), wanted = header.canonical_target_stat;
    requireThat(same(originRef(header.canonical_target_ref.path),header.canonical_target_ref)
      && fs.realpathSync(header.declared_alias_path) === header.canonical_target_ref.path
      && s.uid === wanted.uid && s.gid === wanted.gid && s.nlink === wanted.nlink && s.size === wanted.size
      && (s.mode & 0o7777) === Number(wanted.mode), 'Cible header SDK divergente');
  }
};
check();
const writeJson = (p,v) => fs.writeFileSync(p, JSON.stringify(v,null,2)+'\n', {flag:'wx',mode:0o600});
const env = { PATH:'/usr/bin:/bin', HOME:'/private/tmp', TMPDIR:'/private/tmp', LANG:'C', LC_ALL:'C', TZ:'UTC', PYTHONDONTWRITEBYTECODE:'1' };
const command = (argv, timeout=30000) => {
  const start = new Date().toISOString();
  const r = spawnSync(argv[0],argv.slice(1),{env,encoding:'utf8',timeout,maxBuffer:1024*1024});
  return {argv,started_at_utc:start,finished_at_utc:new Date().toISOString(),exit_code:r.status,signal:r.signal,error:r.error ? String(r.error) : null,stdout:r.stdout??'',stderr:r.stderr??''};
};
if (action === 'pure') {
  requireThat(qaRoot === undefined, 'Pas de root natif en mode pur');
  const out = fs.mkdtempSync('/private/tmp/therese-c17-mach-pure-main-');
  fs.chmodSync(out,0o700);
  const actual = command([PY,'-I','-B',gel+'/run_pure.py',out,'/root']);
  writeJson(out+'/main-command.json',actual);
  check();
  requireThat(actual.exit_code === 0 && actual.signal === null && actual.error === null, 'Tests purs rouges : '+out);
  const receipt = JSON.parse(fs.readFileSync(out+'/receipt.json'));
  requireThat(receipt.actor === '/root' && receipt.passed === true && receipt.tests === 35 && receipt.errors === 0 && receipt.failures === 0 && receipt.native_executed === false, 'Reçu pur divergent');
  console.log(JSON.stringify({action,out,index_ref:indexRef,receipt_ref:ref(out+'/receipt.json'),tests:receipt.tests,passed:true}));
} else {
  requireThat(/^\/private\/tmp\/therese-c17-mach-register-canary-[a-f0-9]{32}$/.test(qaRoot), 'Root fermé');
  requireThat(!fs.existsSync(qaRoot), 'Root déjà alloué');
  fs.mkdirSync(qaRoot,{mode:0o700});
  for (const relative of ['definitions','auxiliary','auxiliary/probe','auxiliary/probe/home','auxiliary/probe/tmp']) fs.mkdirSync(qaRoot+'/'+relative,{mode:0o700});
  for (const [src,dst] of [['profiles/chrome14.sb','definitions/chrome14.sb'],['profiles/candidate.sb','definitions/candidate.sb']]) {
    fs.copyFileSync(gel+'/'+src,qaRoot+'/'+dst,fs.constants.COPYFILE_EXCL);
    fs.chmodSync(qaRoot+'/'+dst,0o600);
    requireThat(fs.lstatSync(qaRoot+'/'+dst).nlink === 1 && ref(qaRoot+'/'+dst).sha256 === ref(gel+'/'+src).sha256, 'Copie profil divergente');
  }
  const binary = qaRoot+'/auxiliary/probe/mach-probe';
  const argv = ['/usr/bin/clang','-std=c11','-O2','-Wall','-Wextra','-Werror','-isysroot','/Library/Developer/CommandLineTools/SDKs/MacOSX.sdk',gel+'/probe.c','-o',binary];
  const actual = command(argv,30000);
  writeJson(qaRoot+'/compile-command.json',actual);
  check();
  requireThat(actual.exit_code === 0 && actual.signal === null && actual.error === null && actual.stderr === '', 'Compilation rouge : '+qaRoot);
  const binaryRef = ref(binary);
  requireThat(fs.lstatSync(binary).nlink === 1 && (fs.lstatSync(binary).mode & 0o111), 'Binaire non exécutable/lié');
  const receipt = {schema:'c17-main-mach-probe-compile-v1',actor:'/root',source_ref:ref(gel+'/probe.c'),binary_ref:binaryRef,...actual,native_executed:false,G1:false,FULL:false,release:false};
  writeJson(qaRoot+'/compile-receipt.json',receipt);
  const compileRef = ref(qaRoot+'/compile-receipt.json');
  const go = {schema:'c17-mach-register-canary-go-v1',actor:'/root',scope:'c17_exact_mach_register_microcanary_only',qa_root:qaRoot,native_microcanary_authorized:true,expires_at_unix:Date.now()/1000+115,definition_index_ref:indexRef,compiled_binary_ref:binaryRef,compile_receipt_ref:compileRef,authority_note:'GO humain QA existant ; lancement natif distinct par outil MAIN, ce JSON seul ne crée aucune autorité.'};
  writeJson(qaRoot+'/main-go.json',go);
  console.log(JSON.stringify({action,qa_root:qaRoot,index_ref:indexRef,compile_receipt_ref:compileRef,binary_ref:binaryRef,go_ref:ref(qaRoot+'/main-go.json'),expires_at_unix:go.expires_at_unix,native_executed:false}));
}
