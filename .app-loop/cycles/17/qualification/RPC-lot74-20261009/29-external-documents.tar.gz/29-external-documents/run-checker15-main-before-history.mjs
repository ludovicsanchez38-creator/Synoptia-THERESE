// Exécuteur MAIN fermé du checker en lecture seule. Aucun lancement de service.
import fs from 'node:fs';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
const gel='/private/tmp/therese-c17-wrapper15-static-controls-sdk-kIbm1V';
const root='/private/tmp/therese-c17-wrapper-canary-9c1f04187dd24519b220372284a739c9';
const node='/Users/synoptia/.nvm/versions/node/v22.19.0/bin/node';
const [mode,indexSHA]=process.argv.slice(2);
const need=(ok,msg)=>{if(!ok)throw Error(msg);};
need(process.argv.length===4&&['preflight','post'].includes(mode)&&/^[a-f0-9]{64}$/.test(indexSHA||''),'CLI fermée requise');
const ref=p=>{
  const a=fs.lstatSync(p),b=fs.readFileSync(p),z=fs.lstatSync(p);
  need(a.isFile()&&!a.isSymbolicLink()&&a.uid===501&&a.nlink===1&&fs.realpathSync(p)===p
    &&a.dev===z.dev&&a.ino===z.ino&&a.size===z.size&&a.mtimeMs===z.mtimeMs&&a.ctimeMs===z.ctimeMs,'Ref instable '+p);
  return {path:p,sha256:crypto.createHash('sha256').update(b).digest('hex'),bytes:b.length};
};
const same=(a,b)=>a.path===b.path&&a.sha256===b.sha256&&a.bytes===b.bytes;
const indexRef=ref(gel+'/INDEX.json');
need(indexRef.sha256===indexSHA,'INDEX différent du pin MAIN');
const index=JSON.parse(fs.readFileSync(indexRef.path));
const pins=new Map([[indexRef.path,indexRef]]);
const collect=x=>{
  if(Array.isArray(x))x.forEach(collect);
  else if(x&&typeof x==='object'){
    if(typeof x.path==='string'&&x.path.startsWith(gel+'/')&&/^[a-f0-9]{64}$/.test(x.sha256||'')&&Number.isSafeInteger(x.bytes)){
      const actual=ref(x.path);need(same(actual,x),'Pin du gel différent '+x.path);
      const old=pins.get(x.path);need(!old||same(old,x),'Pins contradictoires');pins.set(x.path,actual);
    }else Object.values(x).forEach(collect);
  }
};
collect(index);
const checker=ref(gel+'/verify-prepared-wrapper15.mjs'),helper=ref(gel+'/postbirth_checks.mjs');
need(checker.sha256==='394316979704ddf0d6e3d79881289db75bbed47de30a6c32bef7e58bd57fa46e'&&checker.bytes===59179
  &&helper.sha256==='a667171fe0957080dfa0b92c6eb5e315b579cd7263f139ae8a64399d4767e652'&&helper.bytes===12527
  &&pins.has(checker.path)&&pins.has(helper.path),'Checker/helper fermé non exact');
const out=fs.mkdtempSync('/private/tmp/therese-c17-checker15-main-'+mode+'-');fs.chmodSync(out,0o700);
const args=[checker.path,root,...(mode==='post'?['--post-birth']:[])];
const env={PATH:'/usr/bin:/bin',HOME:out,TMPDIR:out};
const command={executable:node,args,cwd:out,env,timeout_ms:60000,scope:'readonly_checker_not_native_qualification'};
const save=(name,data)=>{fs.writeFileSync(out+'/'+name,data,{flag:'wx',mode:0o600});return ref(out+'/'+name);};
const commandRef=save('command.json',JSON.stringify(command,null,2)+'\n');
const started=new Date().toISOString(),run=spawnSync(node,args,{cwd:out,env,timeout:60000,maxBuffer:1000000});
const stdoutRef=save('stdout.log',run.stdout||Buffer.alloc(0)),stderrRef=save('stderr.log',run.stderr||Buffer.alloc(0));
const after=[...pins.values()].map(x=>{const actual=ref(x.path);need(same(actual,x),'Gel changé pendant checker');return actual;});
let result=null,parseError=null;
try{result=JSON.parse((run.stdout||Buffer.alloc(0)).toString('utf8'));}catch(e){parseError=String(e);}
const status=mode==='post'?'post_birth_structural_verified_only':'prepared_only_static_verified';
const passed=run.status===0&&run.signal===null&&!run.error&&stderrRef.bytes===0&&!parseError
  &&result?.status===status&&result?.root===root&&result.native===false&&result.FULL===false&&result.release===false;
const receipt={schema:'c17-checker15-MAIN-readonly-receipt-v1',actor:'/root',mode,root,index_ref:indexRef,
  command_ref:commandRef,stdout_ref:stdoutRef,stderr_ref:stderrRef,started_at:started,finished_at:new Date().toISOString(),
  exit_code:run.status,signal:run.signal,error:run.error?String(run.error):null,parse_error:parseError,
  pins_before:[...pins.values()],pins_after:after,sources_unchanged:true,passed,checker_result:result,
  native_executed:false,native_qualification_claimed:false,FULL:false,release:false};
const receiptRef=save('receipt.json',JSON.stringify(receipt,null,2)+'\n');
console.log(JSON.stringify({out,receipt_ref:receiptRef,passed,exit_code:run.status,status:result?.status,
  refs:result?.refs,post_birth_proofs:result?.post_birth_proofs?.length,recorded_native_outcome:result?.recorded_native_outcome,
  native:false,FULL:false,release:false}));process.exitCode=passed?0:86;
