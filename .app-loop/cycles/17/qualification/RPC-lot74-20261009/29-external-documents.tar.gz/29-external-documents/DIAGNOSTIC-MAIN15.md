# ROOT15 : résultat natif rouge et diagnostic ciblé

MAIN a lancé l'instrument WRAPPER_CANARY, outil `1ca95b`, session48169,
terminal `fa672b`, code86. Racine QA exacte :
`/private/tmp/therese-c17-wrapper-canary-9c1f04187dd24519b220372284a739c9`.
Résultat `a2cb37382bbf4f64de44ab21525e78eccf73ed06c553f1ac2898cbb5a2b0840d` :
7 ACK sur15, aucun reçu parent complet, sources inchangées et transport RPC
fermé, mais `passed=false`, `owned_shutdown_proved=false`, clean faux et taint
vrai. Il ne s'agit ni d'une ronde FULL ni d'un bug produit attribué.

Le préflight complet MAIN a réellement passé `ba6de5`/`a82d3f`, 5085 refs,
reçu `bb31d944…` ; le premier préflight SDK rouge `ec1cc9`, reçu `c128ef99…`,
reste conservé. Le post-checker MAIN `195d24`/`6bd46e` passe seulement sa
relecture structurelle : 5124 refs, une seule naissance Chrome réelle,
reçu `fbaae339…`. Il restitue les booléens natifs rouges sans les changer.

Chrome14738, birth1791502221/753087, est attribué au parent14345.
Son nom exact OWN est dérivé après la naissance réellement recontrôlée.
Le précédent FATAL du bootstrap_check_in Mach n'est plus présent. Le stderr
`e7f2eb47…` (6605B), lu intégralement MAIN `06dde1`, annonce DevTools sur
127.0.0.1:17594. Un service-start G1 existe ; aucun start auxiliaire ne
prouve toutefois l'admission CDP double-scan achevée. Le septième ACK refuse
avec « CDP changé entre scans globaux » (`ebbe6b`). Chrome sort en -5, sans
timeout/interruption ni signal de cleanup, cleanup0.746534875s inférieur à8s.

Le même stderr distingue le lookup refusé du helper14909 vers le service
du parent14738, les échecs d'initialisation sandbox et les sorties GPU6,
puis le FATAL GPU inutilisable. Les PID14881 et14909 cités dans les logs
ne sont pas attribués au ledger : aucune adoption ou terminaison exhaustive
n'est revendiquée pour eux.

Diagnostic système MAIN `ebdf04`/`199d5c`, reçu `162ced71…`, 234 événements
dans la fenêtre Paris09/10 01:30:21–01:30:32. Le collecteur ne lit que les
huit identités Chrome attribuées et les messages système les nommant.
Lecture MAIN `d6a25c` : SIX `forbidden-sandbox-reinit`, chacun sur un fils
réellement attribué14904/14903/14915/14945/14942/14944, de01:30:26.086 à.398.
La revue indépendante constate toutefois que quatre timestamps kernel
précèdent leurs births libproc de16,347 à23,293ms. Son premier supplément
refuse réellement cette jointure temporelle, code1 (`a3b922`), et conserve
la préimage. Les six événements sont donc joints par PID/fenêtre, sans
tolérance inventée ni preuve de chronologie kernel après birth.
Le lookup14909 est une observation distincte. Aucun log privé global n'est
présenté comme preuve d'ownership. L'absence d'autres refus ne serait pas
une preuve exhaustive de confinement.

Sources primaires consultées pour comprendre les appels, pas pour affirmer
une parité de code avec le Chrome installé :
[Seatbelt](https://raw.githubusercontent.com/chromium/chromium/main/sandbox/mac/seatbelt.cc),
[SeatbeltExec](https://raw.githubusercontent.com/chromium/chromium/main/sandbox/mac/seatbelt_exec.cc),
[SandboxSerializer](https://raw.githubusercontent.com/chromium/chromium/main/sandbox/mac/sandbox_serializer.cc),
[profil commun](https://raw.githubusercontent.com/chromium/chromium/main/sandbox/policy/mac/common.sb).
Version physique de la copie QA154.0.8037.99, lue `54cba9`. Le tag correspondant
n'a pas pu être récupéré ; main upstream n'est pas assimilé à ce binaire.
Ces sources montrent les appels d'application de la politique interne et
le nom de service du parent ; elles ne valident pas un contournement local.

Conclusion bornée : six refus OS de réinitialisation nomment les PID de
nos enfants dans la fenêtre observée, avec la réserve temporelle ci-dessus.
Une règle de chemin ou de lookup ne traite pas à elle seule
ce refus. La causalité exclusive de chaque sortie GPU n'est pas établie.
Aucun --no-sandbox, retrait de sandbox G1, mode single-process, bypass GPU,
VM/UTM, permission système globale ou nouveau profil personnel n'est utilisé.
Un changement de lanceur/frontière de sécurité réclame une revue et une
décision explicites ; aucun résultat vert n'est fabriqué pour poursuivre FULL.

Après le terminal, trois lsof MAIN `374799`/`35db54`/`edc051` sont vides,
code1 sur17593/5173/17594. Cette observation ne supprime pas le taint ni les
limites de découverte des descendants. La release reste fermée.
