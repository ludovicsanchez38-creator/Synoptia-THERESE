# Revue externe MAIN du contrat SQL ROOT15

Contrat lu intégralement par MAIN, outil `2c3407` :
`/private/tmp/therese-c17-wrapper-canary-9c1f04187dd24519b220372284a739c9/complements/contrats-normalises-proposes.json`,
SHA-256 `84c2a3021d471cf28b2160f7f668aaa0cea2967437d5414a848fc7df56099b61`,
7 702 octets. Le document canonique généré n'est pas réécrit :
`root_reviewed=false` reste son état préparatoire historique.

Le scope est uniquement le canari instrument WRAPPER_CANARY, actor `/root`,
HEAD historique `2d69e30c9c6dd18823ee6102271876003a6a67cc` et source isolée
`/private/tmp/therese-c17-wrapper-source-kGvU1hdx/source`. Il ne s'agit ni de
la source QA fraîche HEAD91e0, ni d'une attestation FULL A/B actuelle.

Les oracles B1753 conservent la fermeture du registre et des tâches en fin
de test, puis leur absence avant le test suivant. Les synchronisations ne
changent aucune assertion produit. B1760 conserve les dix exports nouveaux
liés par nodeid/UUID/HTTP/PDF, la date réelle en en-tête et première ligne,
l'absence de l'ancienne date, le suffixe de première ligne reconnu et les
conditions monétaires/méthode/pénalité inchangées. Les factures émises
restent immuables. SQLCipher réel est requis pour le harness ; aucun runtime
plaintext n'est présenté comme cette preuve.

Les 36 références source/modes figurent explicitement dans le contrat. La
construction MAIN `1aa05c` puis `54d0fe`, code 0, ne valide ni ces oracles
par exécution, ni Chrome, ni G1, ni une ronde complète. Leur raccord physique
doit être revérifié par le checker de préparation avant un essai natif.

Avis : contrat admissible pour la seule préparation de cet instrument,
sans abaisser les oracles. Aucun résultat SQL natif, FULL ou release n'est
admis par cette relecture. Une revue externe ne transforme pas le champ
préparatoire `root_reviewed` et n'authentifie pas à elle seule un GO natif.
