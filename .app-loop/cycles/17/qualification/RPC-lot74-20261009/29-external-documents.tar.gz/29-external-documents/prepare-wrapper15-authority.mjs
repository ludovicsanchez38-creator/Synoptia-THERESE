// Autorité de préparation MAIN neuve. Aucun runtime lancé par ce script.
import fs from 'node:fs';
import crypto from 'node:crypto';
import { execFileSync } from 'node:child_process';
const repo = '/Users/synoptia/Desktop/Dev Synoptia/Synoptia-THERESE-c15-codex';
const currentHead = '91e0b942bfb24bfb77890960b2c4b97d04cbb750';
const gel = '/private/tmp/therese-c17-wrapper15-own-rendezvous-ky7lgh';
const root = '/private/tmp/therese-c17-wrapper-canary-9c1f04187dd24519b220372284a739c9';
const need = (v,msg) => { if (!v) throw new Error(msg); };
const ref = p => {
  const s = fs.lstatSync(p), b = fs.readFileSync(p), t = fs.lstatSync(p);
  need(s.isFile() && s.nlink === 1 && s.uid === process.getuid() && fs.realpathSync(p) === p
    && s.ino === t.ino && s.dev === t.dev && s.mtimeMs === t.mtimeMs && s.ctimeMs === t.ctimeMs, 'Référence instable/non canonique : '+p);
  return {path:p,sha256:crypto.createHash('sha256').update(b).digest('hex'),bytes:b.length};
};
const same = (a,b) => a.path === b.path && a.sha256 === b.sha256 && a.bytes === b.bytes;
const checked = v => { need(same(ref(v.path),v),'Pin différent : '+v.path); return v; };
need(!fs.existsSync(root),'Root déjà alloué');
need(execFileSync('/Applications/Xcode.app/Contents/Developer/usr/bin/git',['rev-parse','HEAD'],{cwd:repo,encoding:'utf8',timeout:10000}).trim() === currentHead,'HEAD documentaire changé');
const historical = checked({path:'/private/tmp/therese-c17-root-fresh14-controls-ZNqqLhtv/prepare-go.json',sha256:'782212defbfe9b332d252a937f17a8b11709bd2d158bc43a91658d5ee6e16f3e',bytes:5714});
const body = JSON.parse(fs.readFileSync(historical.path));
need(body.schema === 'c17-root-fresh-wrapper-preparation-go-v1' && body.head === '2d69e30c9c6dd18823ee6102271876003a6a67cc' && body.scope === 'WRAPPER_CANARY' && body.FULL === false && body.release === false,'Template historique autre scope');
const proposal = checked({path:gel+'/INDEX.json',sha256:'770af2012e00c5d911faa2024692b4bd1f347cf60c9cac5ca4761e037eea5a7f',bytes:17048});
const plan = JSON.parse(fs.readFileSync(proposal.path));
need(plan.schema === 'c17-wrapper15-own-rendezvous-preparation-index-v1' && plan.future_root === root && plan.passed === true
  && plan.tests === 38 && plan.CDP_seconds === 5 && plan.Chrome_startup_seconds === 50 && plan.cleanup_seconds === 8
  && plan.constructor_invoked === false && plan.native_executed === false && plan.FULL === false,'Plan15 divergente');
for (const row of [...plan.source_refs,...plan.origin_refs]) checked(row);
const review = checked({path:'/private/tmp/therese-c17-mach-wrapper15-review-LgdF9u/INDEX.json',sha256:'2f437eee557491715df57d632c81fbc57b2bcf2d0b3a0631ee08d6aeea0d3931',bytes:1637});
const reviewBody = JSON.parse(fs.readFileSync(review.path));
need(reviewBody.status === 'favorable_preparation_only_no_native_admission' && reviewBody.actor === '/root/environment_routes'
  && reviewBody.reviewed_index_refs.some(r=>same(r,proposal)),'Revue indépendante autre proposition');
checked(reviewBody.report_ref);
const mainPure = checked({path:'/private/tmp/therese-c17-wrapper15-main-pure-gdetsxm7/receipt.json',sha256:'4d5f51872a3aa70b9b57208dcaa404d93aecebccdcd3aa9bb30c579fc65483a9',bytes:17934});
const p = JSON.parse(fs.readFileSync(mainPure.path));
need(p.actor === '/root' && p.tests === 38 && p.passed === true && p.errors === 0 && p.failures === 0
  && p.sources_unchanged === true && p.native_executed === false && same(p.index_ref,proposal),'Rejeu MAIN absent');
const replace = new Set(['builder_ref','chrome_profile_ref','identity_registry_ref','builder_proposal_index_ref','profile_derivation_pure_ref','independent_static_review_ref','preparation_script_ref','historical_template_ref']);
for (const [name,value] of Object.entries(body)) if (name.endsWith('_ref') && value && !replace.has(name)) checked(value);
const out = fs.mkdtempSync('/private/tmp/therese-c17-root-fresh15-controls-');
fs.chmodSync(out,0o700);
const save = (name,value) => { fs.writeFileSync(out+'/'+name,JSON.stringify(value,null,2)+'\n',{flag:'wx',mode:0o600}); return ref(out+'/'+name); };
const registry = save('identity-registry.json',{schema:'c17-wrapper-canary-live-identity-registry-v1',round_id:root.split('/').at(-1),head:body.head,
  repo_head_observed:currentHead,historical_product_source_instrument_only:true,chrome_profile_ref:checked(plan.chrome_profile_ref),runner_boundary_index_ref:body.runner_boundary_index_ref,
  actors:[{actor:'/root',observed_by:'Actual collaboration.list_agents immediately before MAIN preparation',observed_at_utc:new Date().toISOString(),role:'Orchestrateur MAIN, aucun PID futur ni acteur historique adopté'}],OS_qualified:false,FULL:false,release:false});
Object.assign(body,{root,repo_head_observed:currentHead,builder_ref:checked(plan.builder_ref),chrome_profile_ref:checked(plan.chrome_profile_ref),builder_proposal_index_ref:proposal,
  identity_registry_ref:registry,profile_derivation_pure_ref:checked(plan.pure_green_receipt_ref),independent_static_review_ref:review,
  independent_MAIN_pure_test_observation:{tool_chunk:'8df2e6',tests:38,exit_code:0,sources_count:38,sources_unchanged:true,forbidden_attempts:0,G1_imported:false,native_executed:false,receipt_ref:mainPure},
  preparation_script_ref:ref(process.argv[1]),historical_template_ref:historical,historical_template_not_authority:true,
  native_runtime_GO_still_required:true,own_mach_micro_native_qualification_not_claimed:true});
const authority = save('prepare-go.json',body);
console.log(JSON.stringify({out,root,registry_ref:registry,authority_ref:authority,prepared_only:true,native:false,FULL:false,release:false}));
