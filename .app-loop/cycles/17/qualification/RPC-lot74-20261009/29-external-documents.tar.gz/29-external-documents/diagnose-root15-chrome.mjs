// Diagnostic MAIN15 seulement : logs des huit identités Chrome attribuées.
import fs from 'node:fs';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
const source='/private/tmp/therese-c17-wrapper-canary-9c1f04187dd24519b220372284a739c9/ledger/aux-chrome-rpc-all-runtime_ui-visual_capture-network_capture/receipt.json';
const need=(ok,msg)=>{if(!ok)throw Error(msg);};
const ref=p=>{const a=fs.lstatSync(p),b=fs.readFileSync(p),z=fs.lstatSync(p);
  need(a.isFile()&&a.nlink===1&&a.uid===501&&fs.realpathSync(p)===p&&a.dev===z.dev&&a.ino===z.ino&&a.size===z.size&&a.mtimeMs===z.mtimeMs&&a.ctimeMs===z.ctimeMs,'Référence instable');
  return {path:p,sha256:crypto.createHash('sha256').update(b).digest('hex'),bytes:b.length};};
const input=ref(source);need(input.sha256==='4fdb049dd3c3b94f52739ac80b746eaa285ecdf979ab598273037062666b6086'&&input.bytes===261632,'Brut Chrome autre');
const raw=JSON.parse(fs.readFileSync(source));
need(raw.root_identity.pid===14738&&raw.root_identity.start_sec===1791502221&&raw.root_identity.start_usec===753087
  &&raw.exit_code===-5&&raw.timed_out===false&&raw.interruption===null,'Identité/issue différentes');
const identities=raw.attributed.filter(x=>x.role===raw.role).map(x=>({pid:x.pid,ppid:x.ppid,uid:x.uid,pgid:x.pgid,start_sec:x.start_sec,start_usec:x.start_usec,attribution:x.attribution}));
const pids=[14738,14895,14903,14904,14915,14942,14944,14945];
need(identities.length===8&&identities.every((x,i)=>x.pid===pids[i]&&x.uid===501&&x.pgid===14738),'Ensemble Chrome attribué divergent');
const own=pids.map(x=>'processID == '+x).join(' OR ');
const names=pids.map(x=>'eventMessage CONTAINS "('+x+')"').join(' OR ');
const predicate='('+own+' OR ((process == "kernel" OR process == "sandboxd" OR process == "syspolicyd" OR process == "amfid" OR process == "taskgated") AND ('+names+' OR eventMessage CONTAINS "MachPortRendezvousServer.14738")))';
const args=['show','--style','json','--start','2026-10-09 01:30:21','--end','2026-10-09 01:30:32','--predicate',predicate];
const out=fs.mkdtempSync('/private/tmp/therese-c17-root15-chrome14738-log-');fs.chmodSync(out,0o700);
const save=(name,value)=>{fs.writeFileSync(out+'/'+name,value,{flag:'wx',mode:0o600});return ref(out+'/'+name);};
const started=new Date().toISOString();
const run=spawnSync('/usr/bin/log',args,{cwd:out,env:{PATH:'/usr/bin:/bin:/usr/sbin:/sbin',LANG:'en_US.UTF-8'},timeout:15000,maxBuffer:2000000});
const stdout=save('stdout.json',run.stdout||Buffer.alloc(0)),stderr=save('stderr.log',run.stderr||Buffer.alloc(0));
let events=null,parseError=null;try{events=JSON.parse((run.stdout||Buffer.alloc(0)).toString('utf8'));}catch(e){parseError=String(e);}
need(ref(source).sha256===input.sha256,'Brut modifié pendant diagnostic');
const passed=run.status===0&&!run.signal&&!run.error&&!parseError&&Array.isArray(events);
const receipt={schema:'c17-root15-targeted-system-log-v1',actor:'/root',input_ref:input,script_ref:ref(process.argv[1]),
  scope:'Huit identités Chrome attribuées seulement et messages système les nommant ; fenêtre01:30:21–01:30:32 Paris',
  identities,stderr_only_PIDs_not_adopted:[14881,14909],executable:'/usr/bin/log',args,started_at:started,completed_at:new Date().toISOString(),
  stdout_ref:stdout,stderr_ref:stderr,exit_code:run.status,signal:run.signal,error:run.error?String(run.error):null,parse_error:parseError,
  event_count:passed?events.length:0,passed,diagnostic_only:true,profile_changed:false,G1_imported:false,native_relaunched:false,FULL:false,release:false};
const r=save('receipt.json',JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify({out,receipt_ref:r,passed,event_count:receipt.event_count}));process.exitCode=passed?0:86;
