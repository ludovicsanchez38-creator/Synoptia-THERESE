"""Rejouer les vrais tests purs du gel15, avec sorties MAIN séparées."""
from pathlib import Path
import contextlib
import hashlib
import json
import os
import socket
import subprocess
import sys
import tempfile
import time
import unittest

D = Path('/private/tmp/therese-c17-wrapper15-own-rendezvous-ky7lgh')
INDEX_SHA = '770af2012e00c5d911faa2024692b4bd1f347cf60c9cac5ca4761e037eea5a7f'

def ref(p):
    p = Path(p)
    if p.resolve(strict=True) != p or not p.is_file():
        raise ValueError('Référence non canonique')
    b = p.read_bytes()
    return {'path': str(p), 'sha256': hashlib.sha256(b).hexdigest(), 'bytes': len(b)}

index_ref = ref(D / 'INDEX.json')
if index_ref['sha256'] != INDEX_SHA:
    raise ValueError('Gel changé')
index = json.loads((D / 'INDEX.json').read_text())
# Liste physique actuelle explicite, sans adopter le pointeur original historique.
pins = [*index['source_refs'], *index['origin_refs']]
historical = index['first_red_test_snapshot']
original = historical['original_record']
snapshot = historical['preserved_snapshot']
if (original['path'] != str(D/'tests/test_wrapper15_static.py')
        or snapshot['path'] != str(D/'preimages/test-wrapper15-first-red.py')
        or original['sha256'] != snapshot['sha256'] or original['bytes'] != snapshot['bytes']
        or ref(snapshot['path']) != snapshot or snapshot not in pins):
    raise ValueError('Jointure historique fermée divergente')
if len(pins) != 38 or len({p['path'] for p in pins}) != 38 or any(ref(p['path']) != p for p in pins):
    raise ValueError('Pins du gel divergents')
out = Path(tempfile.mkdtemp(prefix='therese-c17-wrapper15-main-pure-', dir='/private/tmp'))
out.chmod(0o700)
attempts = []
def deny(name):
    def fail(*args, **kwargs):
        attempts.append(name)
        raise RuntimeError('Pur MAIN : ' + name)
    return fail
for owner, names in ((subprocess, ('Popen', 'run', 'check_output')), (socket, ('socket',)), (os, ('system', 'execve', 'kill', 'fork', 'posix_spawn'))):
    for name in names: setattr(owner, name, deny(name))
def audit(event, args):
    if event.startswith(('subprocess.', 'socket.', 'ctypes.dlopen')) or event in ('os.system','os.fork','os.posix_spawn','os.exec','os.kill'):
        raise RuntimeError('Appel non pur : ' + event)
    if event == 'open' and len(args) >= 3 and isinstance(args[0], (str, bytes)) and isinstance(args[2], int) and args[2] & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC):
        if out not in Path(os.fsdecode(args[0])).resolve().parents:
            raise RuntimeError('Écriture hors sortie MAIN')
sys.addaudithook(audit)
started = time.monotonic()
with (out/'stdout.log').open('x') as stdout, (out/'stderr.log').open('x') as stderr, contextlib.redirect_stdout(stdout):
    suite = unittest.defaultTestLoader.discover(str(D/'tests'))
    result = unittest.TextTestRunner(stream=stderr, verbosity=2).run(suite)
after = [ref(p['path']) for p in pins]
bad_imports = [n for n in sys.modules if n == 'runtime_session' or n == 'app' or n.startswith('app.')]
passed = result.wasSuccessful() and after == pins and ref(index_ref['path']) == index_ref and not attempts and not bad_imports
receipt = {'schema':'c17-wrapper15-main-pure-v1','actor':'/root','actual_command':[sys.executable,*sys.argv],
           'tests':result.testsRun,'errors':len(result.errors),'failures':len(result.failures),'skips':len(result.skipped),
           'passed':passed,'elapsed_seconds':time.monotonic()-started,'index_ref':index_ref,'pins_before':pins,'pins_after':after,
           'sources_unchanged':after==pins,'forbidden_attempts':attempts,'forbidden_imports':bad_imports,
           'stdout_ref':ref(out/'stdout.log'),'stderr_ref':ref(out/'stderr.log'),
           'synthetic_fixtures_only':True,'native_executed':False,'constructor_invoked':False,'G1_imported':False,'FULL':False,'release':False}
with (out/'receipt.json').open('x') as f: json.dump(receipt,f,sort_keys=True,indent=2); f.write('\n')
print(json.dumps({'receipt_ref':ref(out/'receipt.json'),'passed':passed,'tests':result.testsRun}))
raise SystemExit(0 if passed else 1)
