# Microcanari Mach, observation MAIN réelle

Essai réel MAIN `6550df`, code 0, après compilation `3c8f5f` sans modifier
`-Wall -Wextra -Werror`. Gel courant :
`/private/tmp/therese-c17-mach-register-micro-receive-p0pLSYvc/INDEX.json`,
SHA `d91a160390d8c2924e1deecb0625b040e48b28963ac758db5abbae21c9ad5382`.
Le changement C porte uniquement sur la suppression du RECEIVE acquis,
via l'API du SDK ; aucun droit SEND/guard n'est deviné ni désactivé.
Le premier refus compile `1e7f1e26…` reste conservé, comme les gels SDK
précédents et leurs réserves documentaires.

Racine isolée :
`/private/tmp/therese-c17-mach-register-canary-baa235510ca54c1a921e9f9bf268ccb3`.
Compilation physique : reçu `3f7327d2…`, binaire `96952c2d…`, 36 792 octets.
Les quarante tests purs sont réellement rejoués par MAIN `8e580b`, reçu
`e07ab534…`. Ils sont distincts de cette mesure native et non additionnés
aux quarante de l'auteur. GO MAIN frais `a2bc0880…`, scope micro seulement.

Lecture du résultat MAIN `2041fe` et des gates/releases `8286dc` :

| Mode | Identité du fils réel | Mesure |
| --- | --- | --- |
| Baseline | PID9713, parent9712, UID501, PGID9713, birth1791500997/520995 | Son nom propre est refusé1100, aucun port. |
| Candidat | PID9717, parent9712, UID501, PGID9717, birth1791500997/931678 | Son nom propre est admis0, RECEIVE acquis, suppression0, type après suppression15. |

Le parent réel est PID9712, birth1791500997/438832. Les deux négatifs du
candidat, nom du PID parent et suffixe du nom propre, sont refusés1100
sans port. Le paramètre unique OWN_RENDEZVOUS_SERVICE est dérivé du vrai
PID du fils après attribution et seulement ajouté à sa commande effective.
La baseline n'a pas ce paramètre. Les gates et releases joignent nonce,
mode et naissances parent/fils exacts.

Les deux handles directs sont reaped avec code0, sans timeout, stderr,
signal de cleanup, interruption ou erreur. Bornes mesurées0,410s et0,066s,
inférieures à8s. Pins et identité du parent relus inchangés par le runner.
MAIN `fe1b20` rehash31 références physiques uniques, zéro écart.

Résultat : `micro-result.json`, SHA
`d04beebef9482aeaa0c5881a8e14ae30f6d7f03ad0726a5a38d5d0f9cce2c673`,
20 293 octets, `passed=true`. La portée est seulement la règle Mach exacte
mesurée sur ces deux sondes. Ce n'est pas une qualification Chrome154,
CDP, G1, A/B, FULL, de plateau ou de release. Les permissions sont héritées
par les descendants ; le nom contenant un PID n'authentifie pas le PID
d'un appelant. Ni purge globale launchd ni inventaire hostile exhaustif de
descendants n'est prouvé. Aucun profil personnel ou port17293 n'est utilisé.
