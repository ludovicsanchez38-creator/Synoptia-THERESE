"""Audit indépendant, en lecture seule et sans extraction, de l'archive source QA."""
from __future__ import annotations

import gzip
import hashlib
import json
from pathlib import Path, PurePosixPath
import stat
import tarfile


ROOT = Path("/private/tmp/therese-c17-source-qa-archive-8cusdice")
PROOFS = Path("/private/tmp/therese-c17-direct-source-c8a0bbba3ee44b8e876cf836f2414c95/proofs")
RECIPE = Path("/private/tmp/therese-c17-fresh-source-recipe-v2-iMu968")
POLICY = Path("/private/tmp/therese-c17-documentary-main-policy-y0BHoBxb/policy.json")
PINS = {
    "receipt.json": ("3f2000d485a559d5ae72fe291fa25e34bf641488abeb7e9282e36cd8dfb33eaf", 1078),
    "SELECTION.json": ("29c85528af3fc82568c60f6e8550b35429f5b6654cdcfaab7a3911500a210818", 30133),
    "source-qa-evidence.tar.gz": ("bab6b66a868bb7d361e32f3d8a389bbaf588ae0edee1f153ffb7cd5d3a174a68", 6963011),
}


def require(condition: bool, why: str) -> None:
    if not condition:
        raise ValueError(why)


def digest(path: Path, expected_size: int, expected_hash: str) -> None:
    before = path.lstat()
    require(stat.S_ISREG(before.st_mode) and before.st_nlink == 1
            and path.resolve(strict=True) == path and before.st_size == expected_size,
            f"stat: {path}")
    sha = hashlib.sha256()
    count = 0
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1 << 20), b""):
            sha.update(chunk)
            count += len(chunk)
            require(count <= expected_size, f"croissance: {path}")
    after = path.lstat()
    require((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns,
             before.st_ctime_ns, before.st_nlink) ==
            (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns,
             after.st_ctime_ns, after.st_nlink), f"stat changée: {path}")
    require(count == expected_size and sha.hexdigest() == expected_hash, f"SHA: {path}")


def refs(value: object):
    if isinstance(value, dict):
        if set(value) == {"path", "sha256", "bytes"}:
            yield value
        else:
            for child in value.values():
                yield from refs(child)
    elif isinstance(value, list):
        for child in value:
            yield from refs(child)


def main() -> None:
    for name, (sha, size) in PINS.items():
        digest(ROOT / name, size, sha)
    receipt = json.loads((ROOT / "receipt.json").read_bytes())
    selection = json.loads((ROOT / "SELECTION.json").read_bytes())
    require(receipt["status"] == "archive_verified" and receipt["FULL"] is False
            and receipt["A_B_admitted"] is False and receipt["release"] is False,
            "reçu statut")
    require(receipt["member_count"] == 95 and receipt["total_input_bytes"] == 32_592_096
            and receipt["uncompressed_tar_bytes"] == 32_665_600,
            "reçu nombres")
    require(selection["member_count"] == 95 and selection["total_input_bytes"] == 32_592_096
            and selection["expected_head"] == receipt["expected_head"], "sélection nombres")

    source_index = json.loads((PROOFS / "INDEX.json").read_bytes())
    recipe_index = json.loads((RECIPE / "INDEX.json").read_bytes())
    proof_prefix = str(PROOFS) + "/"
    recipe_prefix = str(RECIPE) + "/"
    proof_refs = {}
    for ref in refs(source_index):
        if ref["path"].startswith(proof_prefix):
            require(ref["path"] not in proof_refs or ref == proof_refs[ref["path"]],
                    "preuve contradictoire")
            proof_refs[ref["path"]] = ref
    require(len(proof_refs) == 64, "64 preuves")
    recipe_refs = {}
    for ref in recipe_index["files"]:
        require(ref["path"].startswith(recipe_prefix) and ref["path"] not in recipe_refs,
                "recette dupliquée/hors racine")
        recipe_refs[ref["path"]] = ref
    require(len(recipe_refs) == 28, "28 recettes")
    selected = selection["members"]
    expected_names = ["source-proofs/INDEX.json"]
    expected_names.extend("source-proofs/" + path[len(proof_prefix):]
                          for path in sorted(proof_refs))
    expected_names.extend(["policy/policy.json", "recipe-v2/INDEX.json"])
    expected_names.extend("recipe-v2/" + path[len(recipe_prefix):]
                          for path in sorted(recipe_refs))
    names = [row["name"] for row in selected]
    require(names == expected_names and len(names) == len(set(names)) == 95,
            "sélection non exacte")
    for row in selected:
        name, ref = row["name"], row["origin_ref"]
        parts = PurePosixPath(name)
        require(not parts.is_absolute() and ".." not in parts.parts and
                name == str(parts) and parts.parts[0] in
                ("source-proofs", "policy", "recipe-v2"), "membre non fermé")
        if name.startswith("source-proofs/") and name != "source-proofs/INDEX.json":
            require(ref == proof_refs[ref["path"]], "preuve source join")
        if name.startswith("recipe-v2/") and name != "recipe-v2/INDEX.json":
            require(ref == recipe_refs[ref["path"]], "recette join")
        digest(Path(ref["path"]), ref["bytes"], ref["sha256"])
    require(sum(row["origin_ref"]["bytes"] for row in selected) == 32_592_096,
            "volume sélection")

    archive = ROOT / "source-qa-evidence.tar.gz"
    decompressed = 0
    with gzip.open(archive, "rb") as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b""):
            decompressed += len(chunk)
            require(decompressed <= 64_000_000, "gzip trop grand")
    require(decompressed == 32_665_600, "taille flux tar")
    with tarfile.open(archive, "r:gz") as tar:
        entries = tar.getmembers()
        require(len(entries) == 95 and [entry.name for entry in entries] == names,
                "tar membres/ordre")
        for entry, row in zip(entries, selected):
            ref = row["origin_ref"]
            require(entry.type == tarfile.REGTYPE and entry.isfile()
                    and entry.mode == 0o600 and entry.uid == entry.gid == entry.mtime == 0
                    and entry.uname == entry.gname == entry.linkname == ""
                    and entry.size == ref["bytes"], "tar metadata")
            payload = tar.extractfile(entry)
            require(payload is not None, "tar membre illisible")
            sha = hashlib.sha256()
            count = 0
            with payload:
                for chunk in iter(lambda: payload.read(1 << 20), b""):
                    count += len(chunk)
                    require(count <= ref["bytes"], "tar membre trop grand")
                    sha.update(chunk)
            require(count == ref["bytes"] and sha.hexdigest() == ref["sha256"],
                    "tar contenu")
    print(json.dumps({"archive_verified_independently": True, "members": 95,
                      "source_bytes": 32_592_096, "tar_stream_bytes": decompressed,
                      "compressed_bytes": 6_963_011, "extracted": False,
                      "FULL": False, "release": False}, sort_keys=True))


if __name__ == "__main__":
    main()
