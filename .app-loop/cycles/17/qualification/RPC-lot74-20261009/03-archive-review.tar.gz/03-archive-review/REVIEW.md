# Revue indépendante de l'archive source QA

J'ai exécuté **seulement** `audit_readonly.py` avec Python 3.13 `-I -B` ; exit 0. Ce lecteur n'écrit rien et n'extrait aucun membre. La sortie retournée par l'outil indiquait 95 membres, 32 592 096 octets de sources, 32 665 600 octets de flux tar et 6 963 011 octets compressés. Cette sortie n'a pas été recopiée sous forme d'un faux reçu brut. MAIN a rejoué le même lecteur séparément, code 0 selon son outil, sans lui attribuer mon exécution.

Références rehashées : reçu `3f2000d485a559d5ae72fe291fa25e34bf641488abeb7e9282e36cd8dfb33eaf`/1 078 B, sélection `29c85528af3fc82568c60f6e8550b35429f5b6654cdcfaab7a3911500a210818`/30 133 B et gzip `bab6b66a868bb7d361e32f3d8a389bbaf588ae0edee1f153ffb7cd5d3a174a68`/6 963 011 B, tous sous `/private/tmp/therese-c17-source-qa-archive-8cusdice`.

Le lecteur reconstruit la sélection depuis l'INDEX source QA et l'INDEX recette, sans utiliser la fonction de sélection du producteur : 64 références sous `proofs/`, 28 fichiers de recette et 3 entrées épinglées font exactement 95 chemins ordonnés et 32 592 096 B. Chaque origine est rehashée avec `lstat` régulier, chemin canonique et `nlink=1`. Le gzip est lu jusqu'à sa fin pour le CRC, sans extraction ; chaque membre tar est régulier, sans lien, porte les métadonnées neutres attendues et a le SHA/taille de sa référence. Aucun checkout Git, venv ou `node_modules` n'est copié ou parcouru.

Le statut `archive_verified` prouve cet emballage fermé, pas un HEAD actuel après un futur commit documentaire, pas l'admission A/B, FULL ou la release. La source QA reste historiquement au HEAD `91e0b942bfb24bfb77890960b2c4b97d04cbb750` ; une divergence future du dépôt devra être affichée et non retargetée.
