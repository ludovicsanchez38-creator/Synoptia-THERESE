"""Lance uniquement les tests purs, sorties neuves séparées du gel."""
from pathlib import Path
import contextlib
import hashlib
import json
import os
import sys
import time
import unittest

D = Path(__file__).resolve().parent


def ref(path):
    data = path.read_bytes()
    return {"path": str(path), "sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)}


def main():
    if len(sys.argv) != 3 or sys.argv[2] not in ("/root", "/root/cycle17_gate_review"):
        raise ValueError("sortie et acteur exécutant explicites requis")
    out = Path(sys.argv[1])
    if out.resolve(strict=True) != out or not out.is_dir() or out == D or D in out.parents:
        raise ValueError("sortie privée indépendante requise")
    def audit(event, args):
        if event.startswith(("subprocess.", "socket.", "ctypes.dlopen")) or event in ("os.system", "os.fork", "os.posix_spawn", "os.exec"):
            raise RuntimeError("test pur: processus/socket/native interdits: " + event)
        if event == "open" and len(args) >= 3 and isinstance(args[0], (str, bytes)):
            flags = args[2]
            if isinstance(flags, int) and flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC):
                path = Path(os.fsdecode(args[0])).resolve()
                if out not in path.parents:
                    raise RuntimeError("écriture hors sortie pure")
    sys.addaudithook(audit)
    paths = [D / n for n in ("contract.py", "probe.c", "run_micro.py", "tests_pure.py", "run_pure.py", "profiles/chrome14.sb", "profiles/candidate.sb")]
    before = [ref(p) for p in paths]
    sys.path.insert(0, str(D))
    import tests_pure
    started = time.monotonic()
    with (out / "stdout.log").open("x") as stdout, (out / "stderr.log").open("x") as stderr, contextlib.redirect_stdout(stdout):
        result = unittest.TextTestRunner(stream=stderr, verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(tests_pure))
    after = [ref(p) for p in paths]
    receipt = {"schema": "c17-mach-register-pure-tests-v1", "scope": "synthetic_contract_fixtures_only",
               "actor": sys.argv[2], "actor_origin": "explicit_executor_argument_not_authentication",
               "tests": result.testsRun, "failures": len(result.failures),
               "errors": len(result.errors), "skips": len(result.skipped), "passed": result.wasSuccessful() and before == after,
               "elapsed_seconds": time.monotonic() - started, "pins_before": before, "pins_after": after,
               "pins_unchanged": before == after, "stdout_ref": ref(out / "stdout.log"), "stderr_ref": ref(out / "stderr.log"),
               "process_socket_native_guard": True, "C_compiled": False, "native_executed": False, "G1_imported": False,
               "Mach_refusals_qualified": False, "Chrome154_qualified": False, "CDP_qualified": False, "FULL": False}
    with (out / "receipt.json").open("x") as stream:
        json.dump(receipt, stream, sort_keys=True, indent=2)
        stream.write("\n")
    print(json.dumps({"receipt_ref": ref(out / "receipt.json"), "passed": receipt["passed"]}))
    return 0 if receipt["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
