# Microcanari Mach exact, préparation fermée

Ce dossier ne contient aucun binaire compilé et aucun résultat Mach natif.
Il ne modifie ni ROOT14, ni G1, ni une table d'admission FULL.

Le profil candidat est le profil Chrome14 byte-exact de 2 499 octets plus
une seule règle de 69 octets :

```lisp
(allow mach-register (global-name (param "OWN_RENDEZVOUS_SERVICE")))
```

Le paramètre ne vient ni d'un PID prévu, ni d'un argument libre du parent.
Le gate C calcule lui-même le nom
`com.google.Chrome.MachPortRendezvousServer.<getpid()>`.
Le contrôleur capture auparavant la naissance réelle de son enfant direct
avec libproc, puis vérifie le rendez-vous C et sa propre identité. Le gate
relit naissance, filiation, UID et PGID juste avant `execv(sandbox-exec)`.
Le PID est conservé à travers les deux execs. La sonde ne relit pas libproc
à l'intérieur de Seatbelt : elle publie la naissance pré-exec jointe au gate,
et contrôle ses PID/PPID/UID/PGID actuels.

Le format du nom et l'appel check-in correspondent au
[code Chromium publié](https://raw.githubusercontent.com/chromium/chromium/main/base/apple/mach_port_rendezvous_mac.cc).
Cela ne démontre pas la parité avec le binaire Chrome154 installé.
Les valeurs 1100 et 15 sont vérifiées dans les en-têtes SDK locaux pinnés
dans CONTRACT.json. Le [wrapper Apple publié](https://raw.githubusercontent.com/apple-oss-distributions/launchd/main/liblaunch/libbootstrap.c)
est une référence d'API, pas un test de l'OS actuel.

## Deux futurs enfants directs

1. Baseline Chrome14 : check-in sur son propre nom, refus brut 1100 requis.
2. Candidat : propre nom accepté avec code0 et droit receive réel ; autre
   PID, qui est le PID réel du contrôleur Python propriétaire, refus1100 ;
   suffixe propre `.c17-denied`, refus1100.

Un code1102, un signal, un timeout, un port inattendu ou un stderr non vide
est un rouge instrument. Aucun de ces états ne remplace un refus1100.
La sonde ne cherche pas de port distant, ne fait aucun lookup/register
supplémentaire, fork, socket ou appel réseau. Elle détruit seulement le
droit receive renvoyé à sa propre tâche, jamais bootstrap_port ni
mach_task_self. L'oracle exige destruction0 puis KERN_INVALID_NAME15.
Il n'affirme pas une purge globale du namespace launchd.

## Rendez-vous, bornes et fermeture

Les publications ready/release/reçus utilisent pending exclusif, écriture,
fsync, fermeture, hardlink exclusif. Rien n'est écrasé ou supprimé.
Le gate relit la libération exacte liée au nonce, au mode, à la naissance
réelle de l'enfant et à celle de son parent. Sa lecture exige un fichier
régulier propriétaire avec deux liens et la taille exacte.

Le contrôleur attribue l'enfant immédiatement après Popen, avant de lire un
ready éventuellement invalide. Ready est attendu au plus2s. Le gate attend
une release au plus3s et possède une alarme autonome5s. La sonde remplace
cette alarme par2s. Le parent attend la sonde3s, puis d'abord l'auto-exit,
au plus5s et jamais au-delà du budget total8s. Un résultat positif exige
chaque enfant reaped et elapsed fini dans [0,8].

Si l'auto-exit ne suffit pas, seuls SIGTERM/SIGKILL sur la naissance directe
exactement revérifiée, exécutable gate ou sandbox-exec et propriétaire
encore vivant peuvent être tentés. Toute tentative de signal empêche un
résultat positif. Une identité non démontrée n'est jamais une cible.
Le reçu rouge conserve un éventuel enfant non reaped ; MAIN doit alors
attester sa clôture avant de déclarer la campagne terminée. Ni une absence
de PID étrangère, ni une erreur libproc ne prouve cette clôture.

Les répertoires root, auxiliary, probe, home et tmp doivent être canoniques,
UID propriétaire, mode0700. L'environnement enfant est construit avec sept
clés exactes, sans héritage. Les deux flux sont exclusifs et séparés.

## Préparation et commandes futures, non exécutées ici

Après revue indépendante, MAIN choisit une racine neuve de la seule forme :
`/private/tmp/therese-c17-mach-register-canary-<32 hex minuscules>`.
Il crée les répertoires0700 et copie exactement les deux profils sous
`ROOT/definitions/`. Aucun root de cette forme n'a été alloué ici.

Commande de compilation proposée, aucun lancement par l'auteur :

```text
/usr/bin/clang -std=c11 -O2 -Wall -Wextra -Werror -isysroot /Library/Developer/CommandLineTools/SDKs/MacOSX.sdk /private/tmp/therese-c17-mach-register-micro-X7sJY7wM/probe.c -o <ROOT>/auxiliary/probe/mach-probe
```

MAIN devra publier un vrai reçu compile
`c17-main-mach-probe-compile-v1` avec source_ref, binary_ref, argv exact,
exit_code0 et signalnull. Un binaire absent, une commande différente ou un
sourceSHA divergent sont refusés avant libproc/Popen.

Une décision native distincte, réellement autorisée par MAIN, doit ensuite
être pinnée dans `--go-ref` : schema
`c17-mach-register-canary-go-v1`, actor=/root, scope
`c17_exact_mach_register_microcanary_only`, qa_root exact, autorisation
native explicite, expires_at_unix frais au plus120s, definition_index_ref,
compiled_binary_ref et compile_receipt_ref. La chaîne actor en JSON
n'authentifie pas une autorisation : le vrai appel outil MAIN reste requis.

```text
<Python QA physique> -I -B /private/tmp/therese-c17-mach-register-micro-X7sJY7wM/run_micro.py --run --root <ROOT> --go-ref <JSON de référence à la vraie décision>
```

Sans ces entrées, le runner refuse avant tout chargement libproc/Popen.
Avant l'appel Python, MAIN doit rehash physiquement cet INDEX et toutes
ses définitions dans ce dossier privé0700. Le contrat local est importé
avant load_go : le contrôle interne post-import ne protège pas contre un
module hostile remplacé avant lancement. Cette confiance repose donc sur
le préflight externe réel et sur les pins après, pas sur un JSON actor.
Il écrit micro-result.json, deux reçus/flux/rendez-vous quand exécutés,
les pins avant/après, les naissances, les codes bruts et sa fermeture.
Le natif peut échouer pour un défaut de compilation ou de startup encore
non mesuré ; aucune réussite pure n'anticipe son résultat.

## Tests réellement exécutés

Commande auteur :

```text
python3 -I -B /private/tmp/therese-c17-mach-register-micro-X7sJY7wM/run_pure.py /private/tmp/therese-c17-mach-register-pure-final-KMLpkzVs /root/cycle17_gate_review
```

Résultat réel outil126a1e : 35 méthodes, zéro erreur/échec/saut, sept pins
avant/après identiques. Reçu6474747b…/3 875 octets. Les fixtures de codes et
naissances sont explicitement synthétiques. Les derniers contrôles sont
AST et bornes du vrai corps de préparation, pas des refus kernel.
La garde Python interdit subprocess, socket et chargement ctypes, avec
écritures seulement dans la sortie pure. Ce n'est pas un canari Seatbelt.

L'essai antérieur34 vert, reçu9b15f527…, reste historique, avant le raccord
Python -I. Il n'est pas additionné au dénominateur35. Le refus d'import a été
détecté statiquement, non observé en campagne native. Deux préimages du
runner et les diffs exacts conservent ce chemin de préparation.
Le premier rendu du diff ISOLATED-IMPORT omettait ses deux lignes finales
de contexte vides. Ce refus de comparaison byte-exacte a été conservé ;
le diff courant est maintenant égal au diff calculé sur les deux préimages.
Ce défaut de sérialisation n'a entraîné aucun essai natif ni premier rouge Mach.

## Limites d'admission

La permission de nom Mach exact est héritée par les descendants. Elle ne
vérifie pas l'identité du demandeur ; le nom incorpore un PID contrôlé mais
n'est pas un mécanisme d'authentification kernel de ce PID.
Le profil conserve ses anciennes règles réseau/UI/IOKit inchangées.
La sonde ne les utilise pas volontairement ; le microcanari ne prouve pas
leur isolation totale, ni des descendants hostiles, ni une garantie temps
réel sous suspension externe.

Compilation, démarrage Seatbelt, vrais codes Mach, Chrome154, CDP,
G1, FULL, plateau et release restent non qualifiés. Aucun droit Mach
global, préfixe, regex ou canal personnel n'a été ajouté.
