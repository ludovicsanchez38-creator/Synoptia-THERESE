"""Exécuteur futur autonome. Sans --run et GO ROOT physique, aucun libproc/Popen."""
from __future__ import annotations

import argparse
import errno
import hashlib
import json
import os
from pathlib import Path
import signal
import stat
import sys
import time

DEFINITIONS = Path(__file__).resolve().parent
sys.path.insert(0, str(DEFINITIONS))  # Contrat local exact même sous Python -I.
from contract import (BASE_SHA, RULE, admitted_child, canonical_root, child_environment,
                      evaluate, expected_command, finite_bound, identity_tuple, release_bytes, require)

SCOPE = "c17_exact_mach_register_microcanary_only"


def reference(path: Path) -> dict:
    require(path.resolve(strict=True) == path and stat.S_ISREG(path.lstat().st_mode), "ref non canonique/régulière")
    data = path.read_bytes()
    return {"path": str(path), "sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)}


def read_ref(value: dict) -> bytes:
    require(isinstance(value, dict) and set(value) == {"path", "sha256", "bytes"}, "ref exacte absente")
    path = Path(value["path"])
    require(reference(path) == value, "SHA/taille/path")
    return path.read_bytes()


def publish(path: Path, data: bytes) -> dict:
    require(path.parent.resolve(strict=True) == path.parent, "parent sortie canonique")
    pending = Path(str(path) + ".pending")
    with pending.open("xb") as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    os.link(pending, path)  # Exclusif, jamais rename/overwrite d'une preuve.
    return reference(path)


def publish_json(path: Path, value: dict) -> dict:
    return publish(path, (json.dumps(value, sort_keys=True, indent=2) + "\n").encode())


def load_go(root: Path, value: dict) -> tuple[dict, list[dict]]:
    go = json.loads(read_ref(value))
    require(go.get("schema") == "c17-mach-register-canary-go-v1" and go.get("actor") == "/root"
            and go.get("scope") == SCOPE and go.get("qa_root") == str(root)
            and go.get("native_microcanary_authorized") is True, "GO exact absent")
    expiry = go.get("expires_at_unix")
    require(type(expiry) in (int, float) and time.time() < expiry <= time.time() + 120, "GO périmé/borne")
    index_ref = go.get("definition_index_ref")
    require(isinstance(index_ref, dict) and index_ref.get("path") == str(DEFINITIONS / "INDEX.json"), "INDEX autre gel")
    index = json.loads(read_ref(index_ref))
    require(index.get("schema") == "c17-mach-register-micro-preparation-index-v1"
            and index.get("compiled") is False and index.get("native_executed") is False, "définition pas préparation pure")
    pins = [index_ref]
    for item in index["files"]:
        read_ref(item)
        require(Path(item["path"]).parent == DEFINITIONS or Path(item["path"]).parent.parent == DEFINITIONS, "définition externe")
        pins.append(item)
    binary_ref = go.get("compiled_binary_ref")
    require(isinstance(binary_ref, dict) and binary_ref.get("path") == str(root / "auxiliary/probe/mach-probe"), "binaire autre cible")
    read_ref(binary_ref)
    binary_stat = Path(binary_ref["path"]).lstat()
    require(binary_stat.st_uid == os.getuid() and binary_stat.st_nlink == 1 and binary_stat.st_mode & 0o111, "binaire owner/exec/link")
    compile_ref = go.get("compile_receipt_ref")
    compile_raw = json.loads(read_ref(compile_ref))
    source_ref = reference(DEFINITIONS / "probe.c")
    require(compile_raw.get("schema") == "c17-main-mach-probe-compile-v1"
            and compile_raw.get("source_ref") == source_ref and compile_raw.get("binary_ref") == binary_ref
            and compile_raw.get("exit_code") == 0 and compile_raw.get("signal") is None,
            "compile physique exacte absente")
    require(compile_raw.get("argv") == ["/usr/bin/clang", "-std=c11", "-O2", "-Wall", "-Wextra", "-Werror",
            "-isysroot", "/Library/Developer/CommandLineTools/SDKs/MacOSX.sdk", str(DEFINITIONS / "probe.c"),
            "-o", str(root / "auxiliary/probe/mach-probe")], "commande compile différente")
    pins += [binary_ref, compile_ref, value]
    base = (root / "definitions/chrome14.sb").read_bytes()
    candidate = (root / "definitions/candidate.sb").read_bytes()
    require(hashlib.sha256(base).hexdigest() == BASE_SHA and candidate == base + RULE.encode(), "profil différent/élargi")
    require(base == (DEFINITIONS / "profiles/chrome14.sb").read_bytes()
            and candidate == (DEFINITIONS / "profiles/candidate.sb").read_bytes(), "copie profil inexacte")
    pins += [reference(root / "definitions/chrome14.sb"), reference(root / "definitions/candidate.sb")]
    return go, pins


def native_reader():
    # Appelé seulement après GO et validation des fichiers, jamais dans les tests purs.
    import ctypes

    class Info(ctypes.Structure):
        _fields_ = [(k, ctypes.c_uint32) for k in ("flags", "status", "xstatus", "pid", "ppid", "uid", "gid",
                     "ruid", "rgid", "svuid", "svgid", "reserved")] + [("comm", ctypes.c_char * 16),
                     ("name", ctypes.c_char * 32)] + [(k, ctypes.c_uint32) for k in ("nfiles", "pgid", "jobc", "tdev", "tpgid")] + [
                     ("nice", ctypes.c_int32), ("start_sec", ctypes.c_uint64), ("start_usec", ctypes.c_uint64)]

    lib = ctypes.CDLL("/usr/lib/libproc.dylib", use_errno=True)
    lib.proc_pidinfo.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_uint64, ctypes.c_void_p, ctypes.c_int]
    lib.proc_pidinfo.restype = ctypes.c_int
    lib.proc_pidpath.argtypes = [ctypes.c_int, ctypes.c_void_p, ctypes.c_uint32]
    lib.proc_pidpath.restype = ctypes.c_int

    def read(pid: int) -> dict:
        info = Info()
        ctypes.set_errno(0)
        count = lib.proc_pidinfo(pid, 3, 0, ctypes.byref(info), ctypes.sizeof(info))
        if count == 0 and ctypes.get_errno() == errno.ESRCH:
            raise ProcessLookupError(pid)
        require(count == ctypes.sizeof(info), "libproc refus/errno incertain, jamais absence")
        path_buffer = ctypes.create_string_buffer(4096)
        ctypes.set_errno(0)
        require(lib.proc_pidpath(pid, path_buffer, len(path_buffer)) > 0, "exécutable illisible")
        result = {k: int(getattr(info, k)) for k in ("pid", "ppid", "uid", "pgid", "start_sec", "start_usec")}
        result["executable"] = path_buffer.value.decode()
        identity_tuple(result)
        return result

    return read


def run(root: Path, go: dict, pins: list[dict]) -> dict:
    import subprocess
    import uuid

    read = native_reader()
    owner = read(os.getpid())
    require(owner["uid"] == os.getuid(), "owner UID")
    folder = root / "auxiliary/probe"
    for p in (root, root / "auxiliary", folder, folder / "home", folder / "tmp"):
        require(p.resolve(strict=True) == p and p.is_dir() and p.lstat().st_uid == owner["uid"]
                and stat.S_IMODE(p.lstat().st_mode) == 0o700, "dossier QA privé0700")
    slots = folder / "slots"
    slots.mkdir(mode=0o700)  # Refus si l'ancien canari a déjà alloué ses sorties.
    receipts, signals, interruptions, errors = [], [], [], []
    for mode in ("baseline", "candidate"):
        slot = slots / mode
        slot.mkdir(mode=0o700)
        stdout_path, stderr_path = slot / "stdout.log", slot / "stderr.log"
        nonce = uuid.uuid4().hex
        process = None
        child = None
        gate_ref = release_ref = None
        returncode = None
        timed_out = False
        started = time.monotonic()
        out = err = None
        failure = None
        try:
            require(time.time() < go["expires_at_unix"], "GO expiré avant FD/Popen")
            out = stdout_path.open("xb")
            try:
                err = stderr_path.open("xb")
            except BaseException:
                out.close()
                out = None
                raise
            command = [str(folder / "mach-probe"), "gate", str(root), mode, nonce, str(owner["pid"]), str(owner["uid"])]
            process = subprocess.Popen(command, cwd=folder, env=child_environment(root), stdin=subprocess.DEVNULL,
                                       stdout=out, stderr=err, start_new_session=True, close_fds=True)
            # Attribution indépendante avant de consommer un ready potentiellement invalide.
            child = read(process.pid)
            admitted_child(child, owner)
            require(child["executable"] == str(folder / "mach-probe"), "binaire gate réel différent")
            gate_path = slot / "ready.json"
            ready_deadline = started + 2
            while not gate_path.exists():
                require(process.poll() is None and time.monotonic() < ready_deadline, "gate absent/mort/timeout")
                time.sleep(0.01)
            gate_ref = reference(gate_path)
            raw_gate = json.loads(read_ref(gate_ref))
            require(identity_tuple(read(process.pid)) == identity_tuple(child), "birth gate changée")
            require(child["executable"] == str(folder / "mach-probe") and raw_gate.get("schema") == "c17-mach-register-gate-ready-v1"
                    and raw_gate.get("mode") == mode and raw_gate.get("nonce") == nonce
                    and all(raw_gate.get(k) == child[k] for k in ("pid", "ppid", "uid", "pgid", "start_sec", "start_usec"))
                    and raw_gate.get("parent_start_sec") == owner["start_sec"]
                    and raw_gate.get("parent_start_usec") == owner["start_usec"], "gate/birth réelle divergente")
            require(identity_tuple(read(owner["pid"])) == identity_tuple(owner)
                    and identity_tuple(read(process.pid)) == identity_tuple(child) and process.poll() is None,
                    "birth changée avant libération")
            require(all(reference(Path(v["path"])) == v for v in pins), "entrée modifiée avant sandbox")
            release_ref = publish(slot / "release.txt", release_bytes(child, owner, mode, nonce))
            try:
                returncode = process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                timed_out = True
                raise ValueError("sonde timeout, pas un refus Mach qualifié")
            require(returncode == 0, "sonde exit nonzero/signal")
        except BaseException as exc:
            failure = {"type": type(exc).__name__, "message": str(exc)}
            errors.append({"mode": mode, **failure})
            if isinstance(exc, (KeyboardInterrupt, SystemExit)):
                interruptions.append(type(exc).__name__)
        finally:
            if process is not None and process.poll() is None:
                # Alarme C5s, attente sans signal bornée par le budget total8s.
                try:
                    process.wait(timeout=max(0.0, min(5.0, started + 8.0 - time.monotonic())))
                except subprocess.TimeoutExpired:
                    if child is not None:
                        for sig in (signal.SIGTERM, signal.SIGKILL):
                            try:
                                current = read(process.pid)
                                require(identity_tuple(current) == identity_tuple(child)
                                        and current["executable"] in (str(folder / "mach-probe"), "/usr/bin/sandbox-exec")
                                        and identity_tuple(read(owner["pid"])) == identity_tuple(owner), "signal identité incertaine")
                                os.kill(process.pid, sig)
                                signals.append({"mode": mode, "identity": child, "signal": sig.name})
                                process.wait(timeout=max(0.0, min(1.0, started + 8.0 - time.monotonic())))
                                break
                            except ProcessLookupError:
                                process.wait(timeout=max(0.0, min(1.0, started + 8.0 - time.monotonic())))
                                break
                            except subprocess.TimeoutExpired:
                                continue
                            except BaseException as exc:
                                errors.append({"mode": mode, "cleanup_error": str(exc)})
                                break
                    else:
                        errors.append({"mode": mode, "cleanup_error": "process sans birth admise, aucun signal autorisé"})
            if process is not None and process.poll() is None:
                errors.append({"mode": mode, "cleanup_error": "handle direct non reaped, aucun succès de fermeture"})
            for stream in (out, err):
                if stream is not None:
                    try:
                        stream.flush()
                        os.fsync(stream.fileno())
                    except BaseException as exc:
                        errors.append({"mode": mode, "archive_error": str(exc)})
                    finally:
                        try:
                            stream.close()
                        except BaseException as exc:
                            errors.append({"mode": mode, "archive_close_error": str(exc)})
        raw = None
        if failure is None:
            try:
                require(stderr_path.stat().st_size == 0 and stdout_path.stat().st_size <= 8192, "flux stderr/budget")
                raw = json.loads(stdout_path.read_text())
                evaluate(raw, mode, child, owner)
            except BaseException as exc:
                failure = {"type": type(exc).__name__, "message": str(exc)}
                errors.append({"mode": mode, **failure})
        receipt = {"mode": mode, "gate_ref": gate_ref, "release_ref": release_ref, "owner": owner, "child": child,
                   "expected_sandbox_command": expected_command(root, mode, child) if child else None,
                   "environment": child_environment(root), "cwd": str(folder), "raw": raw, "error": failure,
                   "returncode": process.returncode if process else None, "reaped": process is not None and process.returncode is not None,
                   "timed_out": timed_out, "elapsed_seconds": time.monotonic() - started,
                   "stdout_ref": reference(stdout_path) if stdout_path.exists() else None,
                   "stderr_ref": reference(stderr_path) if stderr_path.exists() else None}
        receipt["receipt_ref"] = publish_json(slot / "receipt.json", receipt)
        receipts.append(receipt)
        if failure is not None:
            break
    changed = [v["path"] for v in pins if reference(Path(v["path"])) != v]
    owner_unchanged = identity_tuple(read(owner["pid"])) == identity_tuple(owner)
    passed = (len(receipts) == 2 and not errors and not signals and not interruptions and not changed and owner_unchanged
              and all(r["reaped"] and finite_bound(r["elapsed_seconds"], 8) for r in receipts))
    result = {"schema": "c17-mach-register-micro-result-v1", "scope": SCOPE, "actor": "/root", "root": str(root),
              "passed": passed, "owner": owner, "runs": receipts, "cleanup_signals": signals, "interruptions": interruptions,
              "errors": errors, "pins_before": pins, "pins_after": [reference(Path(v["path"])) for v in pins],
              "pins_unchanged": not changed, "owner_unchanged": owner_unchanged, "FULL": False, "G1": False,
              "Chrome154_qualified": False, "CDP_qualified": False, "release": False,
              "limits": ["Droits Mach hérités par descendants: nom exact, pas identité de l'appelant.",
                         "Seulement deux enfants directs et leur wait; aucune exhaustivité de descendants.",
                         "Destruction des droits de la propre tâche, aucune preuve globale de purge du namespace launchd.",
                         "Le profil Chrome14 conserve ses anciennes règles réseau; aucun appel réseau dans cette sonde."]}
    publish_json(root / "micro-result.json", result)
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", action="store_true")
    parser.add_argument("--root")
    parser.add_argument("--go-ref")
    args = parser.parse_args()
    require(args.run and args.root and args.go_ref, "Exécution fermée: --run + GO ROOT physique requis")
    root = canonical_root(args.root)
    go, pins = load_go(root, json.loads(args.go_ref))
    result = run(root, go, pins)
    print(json.dumps({"result_ref": reference(root / "micro-result.json"), "passed": result["passed"]}))
    return 0 if result["passed"] else 86


if __name__ == "__main__":
    raise SystemExit(main())
