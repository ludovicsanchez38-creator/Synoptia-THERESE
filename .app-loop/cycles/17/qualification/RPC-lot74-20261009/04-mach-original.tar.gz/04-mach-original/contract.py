"""Contrat pur. Ne charge ni libproc, ni G1, ni un processus natif."""
from __future__ import annotations

import math
import re
from pathlib import Path

BASE_SHA = "2ecae3a24ec871a44827b3f712ced1ef5e84d8f778906c37b3a5b51bb374dcdf"
RULE = '(allow mach-register (global-name (param "OWN_RENDEZVOUS_SERVICE")))\n'
PREFIX = "com.google.Chrome.MachPortRendezvousServer."
ROOT_PATTERN = re.compile(r"/private/tmp/therese-c17-mach-register-canary-[0-9a-f]{32}")
IDENTITY_KEYS = ("pid", "ppid", "uid", "pgid", "start_sec", "start_usec")


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def canonical_root(value: str) -> Path:
    require(type(value) is str and ROOT_PATTERN.fullmatch(value) is not None, "root fermé")
    root = Path(value)
    require(root.resolve(strict=True) == root and root.is_dir(), "root canonique absent")
    return root


def identity_tuple(value: dict) -> tuple[int, ...]:
    require(isinstance(value, dict) and all(type(value.get(k)) is int for k in IDENTITY_KEYS), "birth incomplète")
    require(value["pid"] > 1 and value["ppid"] > 0 and value["pgid"] > 0
            and value["uid"] >= 0 and value["start_sec"] > 0 and 0 <= value["start_usec"] < 1_000_000,
            "birth invalide")
    return tuple(value[k] for k in IDENTITY_KEYS)


def admitted_child(child: dict, owner: dict) -> None:
    identity_tuple(child)
    identity_tuple(owner)
    require(child["pid"] != owner["pid"] and child["ppid"] == owner["pid"]
            and child["uid"] == owner["uid"] and child["pgid"] == child["pid"], "filiation/UID/PGID")


def release_bytes(child: dict, owner: dict, mode: str, nonce: str) -> bytes:
    admitted_child(child, owner)
    require(mode in ("baseline", "candidate") and re.fullmatch(r"[0-9a-f]{32}", nonce) is not None, "mode/nonce")
    return (f"C17-MACH-RELEASE-1\nnonce={nonce}\nmode={mode}\n"
            f"pid={child['pid']}\nppid={child['ppid']}\nuid={child['uid']}\npgid={child['pgid']}\n"
            f"start_sec={child['start_sec']}\nstart_usec={child['start_usec']}\n"
            f"parent_start_sec={owner['start_sec']}\nparent_start_usec={owner['start_usec']}\n"
            f"service={PREFIX}{child['pid']}\n").encode("ascii")


def child_environment(root: Path) -> dict[str, str]:
    folder = root / "auxiliary/probe"
    return {"HOME": str(folder / "home"), "CFFIXED_USER_HOME": str(folder / "home"),
            "TMPDIR": str(folder / "tmp"), "PATH": "/usr/bin:/bin", "LANG": "C", "LC_ALL": "C", "TZ": "UTC"}


def expected_command(root: Path, mode: str, child: dict) -> list[str]:
    identity_tuple(child)
    require(mode in ("baseline", "candidate"), "mode")
    folder = root / "auxiliary/probe"
    args = ["/usr/bin/sandbox-exec", "-D", f"AUXILIARY_ROOT={folder}", "-D", f"HOME_ROOT={folder / 'home'}",
            "-D", f"TMP_ROOT={folder / 'tmp'}", "-D", f"AUXILIARY_PARENT={root / 'auxiliary'}", "-D", f"QA_ROOT={root}"]
    if mode == "candidate":
        args += ["-D", f"OWN_RENDEZVOUS_SERVICE={PREFIX}{child['pid']}"]
    args += ["-f", str(root / "definitions" / ("chrome14.sb" if mode == "baseline" else "candidate.sb")),
             str(folder / "mach-probe"), "probe", mode, str(child["pid"]), str(child["ppid"]), str(child["uid"]),
             str(child["pgid"]), str(child["start_sec"]), str(child["start_usec"])]
    return args


def evaluate(raw: dict, mode: str, child: dict, owner: dict) -> None:
    admitted_child(child, owner)
    require(raw.get("schema") == "c17-mach-register-probe-raw-v1" and raw.get("mode") == mode, "raw schéma/mode")
    require(all(type(raw.get(k)) is int and raw[k] == child[k] for k in IDENTITY_KEYS), "raw identité")
    expected = [("own", PREFIX + str(child["pid"]))]
    if mode == "candidate":
        expected += [("other_pid", PREFIX + str(owner["pid"])), ("suffix", PREFIX + str(child["pid"]) + ".c17-denied")]
    rows = raw.get("outcomes")
    require(isinstance(rows, list) and len(rows) == len(expected), "cas absents/en trop")
    for row, (label, name) in zip(rows, expected):
        require(isinstance(row, dict) and row.get("label") == label and row.get("name") == name, "nom exact")
        allow = mode == "candidate" and label == "own"
        if allow:
            require(type(row.get("port_value")) is int and row["port_value"] > 0
                    and row.get("bootstrap_code") == 0 and type(row.get("bootstrap_code")) is int
                    and row.get("port_valid") is True and type(row.get("type_code")) is int and row["type_code"] == 0
                    and row.get("receive_right") is True and type(row.get("destroy_code")) is int and row["destroy_code"] == 0
                    and type(row.get("after_destroy_type_code")) is int and row["after_destroy_type_code"] == 15,
                    "port propre non acquis/détruit")
        else:
            require(row.get("bootstrap_code") == 1100 and type(row.get("bootstrap_code")) is int
                    and type(row.get("port_value")) is int and row["port_value"] == 0 and row.get("port_valid") is False
                    and row.get("receive_right") is False and row.get("type_code") is None
                    and row.get("destroy_code") is None and row.get("after_destroy_type_code") is None,
                    "refus exact1100 absent ou port inattendu")


def finite_bound(value: object, upper: float) -> bool:
    return type(value) in (int, float) and math.isfinite(value) and 0 <= value <= upper
