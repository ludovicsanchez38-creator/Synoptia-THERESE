"""Supplement ROOT15 review using existing files only, not a runtime test."""
from __future__ import annotations

import datetime as dt
import difflib
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import xml.etree.ElementTree as ET

OUT = Path(__file__).resolve().parent
ROOT = Path('/private/tmp/therese-c17-wrapper-canary-9c1f04187dd24519b220372284a739c9')
SYSTEM = Path('/private/tmp/therese-c17-root15-chrome14738-log-QS4RpE')
PINS: dict[str, dict] = {}


def need(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def pin(path: str | Path, expected: dict | None = None) -> dict:
    p = Path(path)
    s = p.lstat()
    need(p.resolve() == p and stat.S_ISREG(s.st_mode), 'Noncanonical/nonregular: ' + str(p))
    body = p.read_bytes()
    row = {'path': str(p), 'sha256': hashlib.sha256(body).hexdigest(), 'bytes': len(body)}
    if expected is not None:
        need(row == {k: expected[k] for k in row}, 'Pin mismatch: ' + str(p))
    if str(p) in PINS:
        need(PINS[str(p)] == row, 'Changed during review: ' + str(p))
    PINS[str(p)] = row
    return row


def read(path: str | Path, expected: dict | None = None) -> dict:
    pin(path, expected)
    return json.loads(Path(path).read_bytes())


def publish(name: str, value: object) -> dict:
    body = (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode()
    p = OUT / name
    fd = os.open(p, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(body)
        stream.flush()
        os.fsync(stream.fileno())
    return {'path': str(p), 'sha256': hashlib.sha256(body).hexdigest(), 'bytes': len(body)}


review = read(OUT / 'receipt.json', {'path': str(OUT / 'receipt.json'),
    'sha256': '6b3a327b794cae2e2ccc73cb99e70077629d77feee8febcc009073088c4c844f', 'bytes': 88604})
need(review['review_checks_passed'] is True and review['campaign_qualification'] is False,
     'Closure receipt has another scope')
records = review['chrome_attributed_records']
by_pid = {row['pid']: row for row in records}
need(set(by_pid) == {14738, 14895, 14903, 14904, 14915, 14942, 14944, 14945}, 'Eight finite Chrome identities')
parent = by_pid[14738]
for row in records:
    if row['pid'] != parent['pid']:
        need(row['ppid'] == parent['pid'] and row['uid'] == parent['uid']
             and row['pgid'] == parent['pgid']
             and row['parent_birth'] == [parent['pid'], parent['start_sec'], parent['start_usec']],
             'Child identity does not join captured parent')

controls = read(ROOT / 'runtime/calibration/test-runner-rpc/test-runner-controls.json')
xml_observations = []
for label, code, failures, classname, name in (
        ('pytest-positive', 1, 1, 'test_temoin_c17', 'test_temoin_c17'),
        ('pytest-negative', 0, 0, 'test_temoin_c17', 'test_temoin_c17'),
        ('vitest-positive', 1, 1, 'calibrationC17.test.ts', 'détecte le défaut puis l’état sain'),
        ('vitest-negative', 0, 0, 'calibrationC17.test.ts', 'détecte le défaut puis l’état sain')):
    control = controls['controls'][label]
    ref = pin(control['xml'])
    need(ref['sha256'] == control['sha256'], 'XML SHA differs from original oracle')
    tree = ET.fromstring(Path(control['xml']).read_bytes())
    suites, cases = list(tree.iter('testsuite')), list(tree.iter('testcase'))
    need(len(suites) == len(cases) == 1, 'XML suite/case missing or duplicated')
    suite, case = suites[0], cases[0]
    counts = {key: int(suite.attrib[key]) for key in ('tests', 'failures', 'errors', 'skipped')}
    need(counts == control['counts'] == {'tests': 1, 'failures': failures, 'errors': 0, 'skipped': 0}, 'XML counts')
    need(case.attrib['classname'] == classname and case.attrib['name'] == name
         and len(case.findall('failure')) == failures and not case.findall('error')
         and not case.findall('skipped'), 'XML actual oracle structure')
    need(control['exit_code'] == code and control['pass'] is True, 'Original oracle exit changed')
    if failures:
        failure = case.find('failure')
        need(failure is not None and failure.attrib.get('message') and failure.text, 'Failure has no evidence')
    ack = next(row for row in review['acks'] if row['job'] == 'rpc-test-' + label)
    need(ack['state'] == 'complete' and ack['exit_code'] == code, 'XML vs actual ACK')
    xml_observations.append({'label': label, 'xml_ref': ref, 'exit_code': code,
        'counts': counts, 'classname': classname, 'name': name})
for path, sha in controls['witnesses'].items():
    need(pin(path)['sha256'] == sha, 'Witness changed')

logs = read(ROOT / 'runtime/calibration/logs-rpc/logs-controls.json')
log_ref = pin(logs['raw_log'])
need(log_ref['sha256'] == logs['raw_log_sha256'], 'Log oracle SHA')
log_rows = [json.loads(line) for line in Path(logs['raw_log']).read_text().splitlines()]
need(len(log_rows) == 3 and all(isinstance(row, dict) for row in log_rows), 'JSON log record structure')
healthy = [row for row in log_rows if row.get('message') == 'TEMOIN-C17-SAIN'
    and row.get('level') == 'INFO' and row.get('extra', {}).get('calibration_run') == logs['run_id']]
injected = [row for row in log_rows if row.get('message') == 'TEMOIN-C17-ERREUR-INJECTEE'
    and row.get('level') == 'ERROR' and row.get('extra', {}).get('calibration_run') == logs['run_id']]
need(len(healthy) == len(injected) == 1 and logs['negative_control'] == {
    'pass': True, 'healthy_markers': 1, 'records': 2} and logs['positive_control'] == {
    'pass': True, 'correlated_errors': 1, 'records': 3}, 'Logs original oracles do not match raw JSON')
need(logs['data_dir'] == str(ROOT / 'profiles/service/logs-rpc') and logs['run_id'] == 'logs-rpc', 'Log data scope')

construction = read(ROOT / 'fresh-wrapper-construction.json')
core = read(construction['core18_ref']['path'], construction['core18_ref'])
need(len(core['copies']) == 18 and core['FULL'] is False and core['admission'] is False
     and core['native_executed'] is False, 'Preparation is not a native result')
for row in core['copies']:
    pin(row['input']['path'], row['input'])
    pin(row['output']['path'], row['output'])
    if row['derivation'] == 'byte_exact':
        need(Path(row['input']['path']).read_bytes() == Path(row['output']['path']).read_bytes(), 'Core copy changed')
delta_refs = [pin(row['path'], row) for row in construction['deltas']]
need(len(delta_refs) == 6, 'Six definition deltas')
# Recreate the combined G1+gate diff from the physical canonical preimages.
# No parsing/importing/executing of either instrument.
sections = []
for filename, before_label, after_label in (
        ('runtime_session.py', 'frozen_definition', 'fresh_root_copy'),
        ('runtime_launch_gate.py', 'frozen_runtime_launch_gate.py', 'fresh_runtime_launch_gate.py')):
    row = next(row for row in core['copies'] if Path(row['output']['path']).name == filename)
    sections.append(''.join(difflib.unified_diff(Path(row['input']['path']).read_text().splitlines(True),
        Path(row['output']['path']).read_text().splitlines(True), fromfile=before_label, tofile=after_label)))
need(''.join(sections).encode() == Path(delta_refs[0]['path']).read_bytes(), 'G1+gate exact diff does not reconstruct')

system = read(SYSTEM / 'receipt.json', {'path': str(SYSTEM / 'receipt.json'),
    'sha256': '162ced7181e05550bc86e83cdfd54314e7ae0e478ac71402effef9575fee7621', 'bytes': 4029})
need(system['exit_code'] == 0 and system['signal'] is None and system['error'] is None
     and system['diagnostic_only'] is True and system['profile_changed'] is False, 'MAIN log collection outcome')
pin(system['input_ref']['path'], system['input_ref'])
pin(system['script_ref']['path'], system['script_ref'])
for row in system['identities']:
    original = by_pid[row['pid']]
    need(all(original[key] == row[key] for key in ('pid', 'ppid', 'uid', 'pgid', 'start_sec', 'start_usec', 'attribution')),
         'System collection was not targeted at actual attributed births')
pin(system['stdout_ref']['path'], system['stdout_ref'])
pin(system['stderr_ref']['path'], system['stderr_ref'])
events = json.loads(Path(system['stdout_ref']['path']).read_bytes())
need(len(events) == system['event_count'] == 234, 'System raw event count')
reinit = []
for event in events:
    if 'forbidden-sandbox-reinit' not in event.get('eventMessage', ''):
        continue
    match = re.fullmatch(r'Sandbox: Google Chrome Helper\((\d+)\) deny\(1\) forbidden-sandbox-reinit', event['eventMessage'])
    need(match is not None and event['processID'] == 0 and event['processImagePath'] == '/kernel', 'Reinit kernel format')
    pid = int(match.group(1))
    need(pid in by_pid and pid != 14738, 'Kernel PID not in finite admitted children')
    timestamp = dt.datetime.strptime(event['timestamp'], '%Y-%m-%d %H:%M:%S.%f%z')
    birth = by_pid[pid]['start_sec'] + by_pid[pid]['start_usec'] / 1_000_000
    need(timestamp.strftime('%Y-%m-%d %H:%M:%S') == '2026-10-09 01:30:26',
         'Kernel observation outside targeted window')
    reinit.append({'timestamp': event['timestamp'], 'threadID': event['threadID'],
        'kernel_processID': event['processID'], 'eventMessage': event['eventMessage'],
        'PID_named_in_event_recorded_identity': by_pid[pid],
        'event_minus_recorded_birth_seconds': round(timestamp.timestamp() - birth, 6),
        'timestamp_after_recorded_birth': timestamp.timestamp() >= birth,
        'kernel_event_birth_identity_proved': False})
need(len(reinit) == 6 and {row['PID_named_in_event_recorded_identity']['pid'] for row in reinit}
     == {14903, 14904, 14915, 14942, 14944, 14945}, 'Six distinct recorded helpers expected')

changes = []
for path, before in PINS.items():
    body = Path(path).read_bytes()
    if hashlib.sha256(body).hexdigest() != before['sha256'] or len(body) != before['bytes']:
        changes.append(path)
need(not changes, 'Sources or raw records changed during supplement')
refs_ref = publish('SUPPLEMENT-REFS.json', {'refs': list(PINS.values())})
receipt = publish('supplement.json', {'schema': 'c17-independent-root15-oracles-and-system-review-v1',
    'reviewer_actor': '/root/cycle17_gate_review', 'root': str(ROOT),
    'closure_review_ref': pin(OUT / 'receipt.json'), 'refs_ref': refs_ref,
    'reviewed_at': dt.datetime.now(dt.timezone.utc).isoformat(), 'review_checks_passed': True,
    'verified_physical_refs': len(PINS), 'before_after_changes': changes,
    'XML_observations': xml_observations, 'logs': {'raw_ref': log_ref,
        'healthy_correlated': len(healthy), 'error_correlated': len(injected), 'records': len(log_rows)},
    'definition_delta_refs': delta_refs, 'G1_gate_diff_exact_reconstruction': True,
    'finite_parent_children_joined': len(records), 'MAIN_system_receipt_ref': pin(SYSTEM / 'receipt.json'),
    'kernel_reinit_observations': reinit,
    'kernel_join_method': 'PID named by kernel event and targeted window only; no kernel birth proof or clock tolerance invented.',
    'kernel_vs_libproc_chronology_consistent': all(row['timestamp_after_recorded_birth'] for row in reinit),
    'analytical_chronology_RED_preserved': True,
    'lookup_PID14909_not_adopted': True, 'Crashpad_PID14881_not_adopted': True,
    'permission_grant_suggested': False, 'single_OS_cause_proved': False,
    'profile_or_native_run_by_reviewer': False, 'G1_imported': False, 'FULL': False, 'release': False,
    'limits': ['Finite attributed children only, not hostile exhaustive capture.',
        'Kernel forbidden-sandbox-reinit is a measured separate nested-policy failure, not a path permission oracle.',
        'No Chromium main/tag parity with Chrome154 physical binary is asserted.',
        'Definition reconstruction and witness oracles do not qualify the unfinished WRAPPER campaign.']})
print(json.dumps({'receipt_ref': receipt, 'review_checks_passed': True, 'kernel_reinit_events': len(reinit)}))
