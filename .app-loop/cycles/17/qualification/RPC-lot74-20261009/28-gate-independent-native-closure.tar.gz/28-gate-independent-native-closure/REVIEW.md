# ROOT15 : revue indépendante de clôture

Acteur : `/root/cycle17_gate_review`. Lecture seule après notification terminale de MAIN. ROOT15 et ses anciens gels restent intacts. Aucun processus QA, Chrome, G1, libproc, réseau, signal ou collecteur de logs lancé par le relecteur.

## Verdict

Clôture physique des seules identités enregistrées et publications vérifiées. Campagne WRAPPER toujours rouge : exit 86, sept ACK sur quinze, aucun des quatre reçus parents finaux, huit travaux RPC manquants. `passed=false`, `owned_shutdown_proved=false`, `clean=false`, taint vrai, FULL/A-B/release faux. Aucun résultat historique ni aucune réussite de feuille ne remplace ces lacunes.

Le lecteur de clôture réel `ba748f` a vérifié 224 références, dont les 79 sources directes, sans écart avant/après. Le supplément `e418f3` vérifie 60 références supplémentaires ou communes, dont les quatre XML, les logs, les dix-huit copies de définition, les six diffs et la collecte système de MAIN. L'union contient 259 chemins physiques distincts, dont le reçu analytique de clôture. Ce n'est pas une nouvelle traversée ou qualification de tout le graphe historique.

## Clôture et attribution

Le résultat original est `a2cb37382bbf4f64de44ab21525e78eccf73ed06c553f1ac2898cbb5a2b0840d`, 2 778 octets. Il conserve `source_unchanged=true`, `rpc_transport_closed=true`, erreurs de transport vides et aucun job actif, sans passage de gate.

Services et Session : nettoyage physique des cibles exactes déclaré terminé, aucun résidu attribué, aucune ambiguïté ni erreur, handles restants vides. Durées réelles 0,898676250 s et 0,759455500 s, chacune dans la borne de 8 s. Session fermée et handlers restaurés. Les drapeaux globaux demeurent `clean=false`, `log_stability_tainted=true`, `log_stability_proved=false`.

Deux passes sur les trois ports 17593, 5173 et 17594 sont présentes dans chacun des reçus d'absence services/Session : douze observations lsof au total, rc 1, PID vides, stdout/stderr vides. Les diagnostics ont leurs vrais launch, birth, UID, PGID, filiation et rôle. Ces observations sont des mesures conservées, pas une sonde actuelle du relecteur.

Les 45 occurrences de signaux copiées dans trois reçus représentent 15 événements uniques. Elles se joignent aux naissances backend 14367, Vite 14372 et descendant Vite 14375, UID 501, PGID et rôle exacts. Signaux observés : SIGSTOP, SIGTERM, SIGCONT. Aucun signal contrôleur adressé à Chrome. Le lecteur ne réadopte aucun PID depuis un log.

Les 37 paires pending/publication ont le même inode/dev, nlink 2, UID 501, chemins canoniques réguliers et octets égaux. Les gate/release rejoignent argv template, argv effectif et identité. Le paramètre propre au Chrome est exactement `com.google.Chrome.MachPortRendezvousServer.14738`, dérivé de son PID capturé, jamais d'un PID prévu.

## Feuilles, ACK et oracles

Six ACK ordinaires : logs 0, test-runner 0, pytest positif/négatif 1/0, Vitest positif/négatif 1/0. Leurs exits correspondent aux reçus feuille, sans signal ni taint. Les quatre XML physiques ont chacun une suite et un testcase exacts, zéro error/skip, une failure pour chaque positif et aucune pour les négatifs. Les trois records JSON du log contiennent un témoin sain INFO et une erreur injectée ERROR, tous deux corrélés à `logs-rpc`. Ces témoins d'instrument ne qualifient pas le produit ou la campagne.

Le septième ACK est une erreur avant le lancement de la feuille Node `runtime_ui-visual_capture-network_capture`. Il n'a ni code métier, ni reçu feuille, ni preuve de terminaison feuille. La chaîne causale préservée dit `CDP changé entre scans globaux`, pas un simple dépassement de délai. Les quatre parents finaux, screen, les quatre feuilles screen et les trois SQL ne sont pas réalisés.

La readiness conservée précède la campagne : Vite HTTP 200, onboarding terminé, données/DB QA, identité offline loopback-only, observations listener avant et après HTTP. Cela ne prouve ni UI complète ni parcours runtime78.

## Chrome et causes mesurées

Chrome 14738, birth 1791502221/753087, PPID 14345, UID 501, PGID 14738 : lancé et released, exit -5, aucun timeout/interruption, signaux contrôleur vides, nettoyage 0,746534875 s. Le reçu G1 `service-start.json` existe. L'absence de `auxiliary/<name>/start.json` indique que l'admission CDP à deux scans n'a pas été achevée ; elle n'efface pas le lancement G1.

Différence matérielle avec ROOT14 : le fatal de register propre au parent n'apparaît plus, et stderr annonce effectivement DevTools sur 127.0.0.1:17594. Cette annonce seule ne satisfait pas les doubles scans CDP. Stderr complet `e7f2eb473c20a5c4caf45d02f5627f7cc7084700095172b78bdc63ce92d044b3`, 6 605 octets, conserve un lookup refusé 1100 du PID 14909 vers le nom exact du parent, des échecs de sandbox imbriquée EPERM, des exits GPU 6, puis le fatal GPU inutilisable.

La collecte système réelle de MAIN `162ced7181e05550bc86e83cdfd54314e7ae0e478ac71402effef9575fee7621` contient 234 événements. Six lignes kernel nomment les helpers 14904, 14903, 14915, 14945, 14942, 14944 et leur refus `forbidden-sandbox-reinit`, entre 01:30:26.086101 et .398756 Paris. Ces PID figurent dans les sept descendants Chrome effectivement enregistrés.

Réserve temporelle conservée : quatre timestamps kernel précèdent les births libproc correspondantes de 16,347 à 23,293 ms. Le premier lecteur de supplément a donc réellement refusé la jointure « événement après birth » (`a3b922`, code 1). Préimage et diagnostic sont conservés. Le supplément final rapporte les six événements par PID/fenêtre et leurs écarts bruts ; il ne fabrique pas de tolérance ni de naissance kernel démontrée. L'origine de cet écart n'est pas établie ici.

Huit identités Chrome sont enregistrées au total, parent et sept enfants. Crashpad 14881 et lookup 14909 apparaissent uniquement dans stderr et ne sont pas dans ce ledger : aucune adoption, signal ou garantie de terminaison individuelle n'est revendiquée pour eux. Le kernel et le ledger ne constituent pas une capture exhaustive de descendants hostiles ou courts.

## Limites et prochaine décision

La réinitialisation de sandbox est un refus système réellement mesuré, distinct du lookup exact. Rien ici ne démontre qu'un nouveau droit de fichier ou un lookup suffirait à rendre Chrome opérationnel. Aucun changement de délai, profil, permission, désactivation de sandbox, single-process ou contournement GPU n'est proposé ou exécuté. Aucune parité du code Chromium amont avec le binaire Chrome154 physique n'est affirmée. Le design de confinement imbriqué doit être examiné séparément avant un nouvel essai autorisé.

La revue est favorable à la conservation archivale de ce rouge et de sa clôture bornée. Elle n'est pas une qualification native, FULL ou release.
