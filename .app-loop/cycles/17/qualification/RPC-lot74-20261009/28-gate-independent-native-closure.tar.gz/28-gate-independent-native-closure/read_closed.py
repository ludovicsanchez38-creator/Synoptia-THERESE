"""Read-only ROOT15 closure audit. No process, network, G1 or kernel imports.

Run only after MAIN's terminal notification. Outputs are exclusive, in this
independent directory. This reader cannot qualify a campaign or a release.
"""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import math
import os
from pathlib import Path
import stat
import sys

ROOT = Path('/private/tmp/therese-c17-wrapper-canary-9c1f04187dd24519b220372284a739c9')
OUT = Path(__file__).resolve().parent
QA = '/private/tmp/therese-c17-wrapper-source-kGvU1hdx/source'
HEAD = '2d69e30c9c6dd18823ee6102271876003a6a67cc'
RESULT_SHA = 'a2cb37382bbf4f64de44ab21525e78eccf73ed06c553f1ac2898cbb5a2b0840d'
ACTOR = '/root/cycle17_gate_review'
if sys.argv[1:] != ['--MAIN-terminal-notified']:
    raise SystemExit('Closed: MAIN terminal notification is required before any ROOT15 read.')

pins: dict[str, dict] = {}
jsons: dict[str, dict] = {}
errors: list[str] = []


def need(value: bool, message: str) -> None:
    if not value:
        raise ValueError(message)


def pin(path: str | Path, expected: dict | None = None) -> dict:
    p = Path(path)
    s = p.lstat()
    need(p.resolve() == p and stat.S_ISREG(s.st_mode), f'Noncanonical/nonregular: {p}')
    body = p.read_bytes()
    row = {'path': str(p), 'sha256': hashlib.sha256(body).hexdigest(), 'bytes': len(body)}
    if expected is not None:
        need(row == {k: expected[k] for k in row}, f'Physical pin mismatch: {p}')
    if str(p) in pins:
        need(pins[str(p)] == row, f'Changed during audit: {p}')
    else:
        pins[str(p)] = row
    return row


def read(path: str | Path, expected: dict | None = None) -> dict:
    pin(path, expected)
    row = json.loads(Path(path).read_bytes())
    need(isinstance(row, dict), f'Expected JSON object: {path}')
    jsons[str(path)] = row
    return row


def collect_refs(value: object) -> None:
    if isinstance(value, list):
        for child in value:
            collect_refs(child)
    elif isinstance(value, dict):
        if set(value) == {'path', 'sha256', 'bytes'}:
            p = Path(value['path'])
            # Current runtime records only. Historical definitions are not
            # recursively interpreted as current physical dependencies.
            if p.is_relative_to(ROOT):
                pin(p, value)
            return
        for child in value.values():
            collect_refs(child)


def identity(row: dict) -> tuple:
    keys = ('pid', 'start_sec', 'start_usec', 'ppid', 'uid', 'pgid')
    need(all(type(row.get(k)) is int for k in keys), 'Incomplete recorded birth identity')
    need(row['pid'] > 0 and row['uid'] == 501 and 0 <= row['start_usec'] < 1_000_000, 'Bad birth/UID')
    return tuple(row[k] for k in keys)


def cleanup(row: dict) -> None:
    c = row['cleanup']
    need(c['clean'] is True and c['termination_of_exact_targets_proved'] is True,
         'Exact target termination not proved')
    need(c['remaining_attributed'] == c['ambiguities'] == c['errors'] == [], 'Cleanup remains red')
    need(row['cleanup_error'] is None and row['cleanup_deadline_met'] is True, 'Cleanup error/deadline')
    elapsed = row['cleanup_elapsed_seconds']
    need(type(elapsed) in (int, float) and math.isfinite(elapsed) and 0 <= elapsed <= 8, 'Cleanup outside 8s')


def publish_output(name: str, value: object) -> dict:
    p = OUT / name
    body = (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode()
    fd = os.open(p, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(body)
        stream.flush()
        os.fsync(stream.fileno())
    return {'path': str(p), 'sha256': hashlib.sha256(body).hexdigest(), 'bytes': len(body)}


report: dict = {'schema': 'c17-independent-root15-closure-review-v1', 'reviewer_actor': ACTOR,
    'root': str(ROOT), 'reviewed_at': dt.datetime.now(dt.timezone.utc).isoformat(),
    'MAIN_terminal_notification_received': True, 'scope': 'actual_closed_records_readonly',
    'campaign_qualification': False, 'FULL': False, 'round_A_or_B': False, 'release': False,
    'runtime_launched_by_reviewer': False, 'G1_imported': False, 'OS_probe_or_signal': False,
    'current_process_liveness_proved_by_reviewer': False,
    'historical_reference_graph_requalified': False}
try:
    result = read(ROOT / 'wrapper-canary-result.json')
    need(pins[str(ROOT / 'wrapper-canary-result.json')]['sha256'] == RESULT_SHA, 'Other result bytes')
    need(result['qa_root'] == str(ROOT) and result['head'] == HEAD and result['actor'] == '/root', 'Other campaign')
    need(result['passed'] is False and result['runner_exit'] == 86 and result['owned_shutdown_proved'] is False,
         'Original instrument RED changed')
    need(result['FULL'] is False and result['round_A_or_B'] is False and result['density_or_78'] is False,
         'Scope promoted')
    need(result['source_unchanged'] is True and result['rpc_transport_closed'] is True, 'Sources/transport')
    need(result['transport_errors'] == result['transport_final']['errors'] == []
         and result['transport_final']['active'] == 0, 'Transport not closed')
    source = read(ROOT / 'authorization/source-refs.json')
    need(len(source['source_refs']) == 79 and len({r['path'] for r in source['source_refs']}) == 79, 'Source catalogue')
    for r in source['source_refs']:
        pin(r['path'], r)
    binding = read(ROOT / 'binding.json')
    decision = read(ROOT / 'decision.json')
    need(len(binding['rpc_descriptors']) == 15, 'RPC descriptor denominator changed')
    starts = [ROOT / 'runtime/readiness.json', ROOT / 'wrapper-canary-result.json']
    for folder in ('ledger', 'session-rpc', 'session-events'):
        starts.extend(sorted((ROOT / folder).rglob('*.json')))
    for p in sorted(set(starts)):
        read(p)
    for j in list(jsons.values()):
        collect_refs(j)
    stops = [read(result[key]['path'], result[key]) for key in ('service_stop_ref', 'session_stop_ref')]
    for row in stops:
        cleanup(row)
        need(row['remaining_handles'] == [], 'Remaining handles')
        need(row['clean'] is False and row['log_stability_tainted'] is True and row['log_stability_proved'] is False,
             'Original global taint/clean changed')
    need(stops[0]['services_stopped'] is True and stops[1]['session_closed'] is True
         and stops[1]['interrupt_handlers_restored'] is True and stops[1]['interrupt_restore_error'] is None,
         'Services/session/handler closure missing')
    # Do not rely on a guessed schema: actual recorded stage bodies are selected
    # by the required structural fields and their physical receipt paths.
    stage_rows = [j for p, j in jsons.items() if p.endswith('/receipt.json')
                  and all(k in j for k in ('attributed', 'root_identity', 'launch_attempted', 'released', 'cleanup'))]
    need(stage_rows, 'No recorded launched stages')
    records: dict[tuple, dict] = {}
    for j in stage_rows:
        cleanup(j)
        need(j['termination_proved'] is True and j['output_archived'] is True, 'Stage termination/archive')
        root_id = j['root_identity']
        need(j['launch_attempted'] is True and j['released'] is True and root_id is not None, 'No released birth')
        need(sum(identity(r) == identity(root_id) for r in j['attributed']) == 1, 'Birth missing/duplicate')
        for r in j['attributed']:
            key = identity(r)
            if key in records:
                need(all(records[key].get(k) == r.get(k) for k in ('role', 'parent_birth', 'attribution')), 'Identity alias')
            records[key] = r
        gate = read(j['gate_ref']['path'], j['gate_ref'])
        release = read(j['release_ref']['path'], j['release_ref'])
        need(all(gate[k] == root_id[k] for k in ('pid', 'ppid', 'uid', 'pgid')) and gate['command'] == j['command'], 'Gate join')
        need(release['identity'] == root_id and release['gate'] == gate, 'Release join')
        if j.get('mode') == 'chrome':
            template = j['command']; at = template.index('-f')
            expected = template[:at] + ['-D', 'OWN_RENDEZVOUS_SERVICE=com.google.Chrome.MachPortRendezvousServer.' + str(root_id['pid'])] + template[at:]
            need(j['effective_command'] == release['effective_command'] == expected
                 and release['command_template'] == template, 'Chrome own-PID parameter')
    signal_joins = []
    for p, j in jsons.items():
        for event in j.get('cleanup', {}).get('signals', []):
            candidates = [r for r in records.values() if [r['pid'], r['start_sec'], r['start_usec']] == event['identity']]
            need(len(candidates) == 1 and event['signal'] in {'SIGSTOP', 'SIGTERM', 'SIGCONT', 'SIGKILL'}, 'Unknown signal identity')
            r = candidates[0]
            need(all(event[k] == r[k] for k in ('uid', 'pgid', 'role')), 'Signal UID/PGID/role mismatch')
            signal_joins.append({'receipt': p, 'signal': event, 'recorded_identity': r})
    hardlinks = []
    for folder in ('ledger', 'session-rpc', 'session-events'):
        for pending in sorted((ROOT / folder).rglob('*.pending')):
            published = Path(str(pending)[:-len('.pending')]); a = pending.lstat(); b = published.lstat()
            need(stat.S_ISREG(a.st_mode) and stat.S_ISREG(b.st_mode) and pending.resolve() == pending
                 and published.resolve() == published and a.st_uid == b.st_uid == 501
                 and (a.st_dev, a.st_ino) == (b.st_dev, b.st_ino) and a.st_nlink == b.st_nlink == 2
                 and pending.read_bytes() == published.read_bytes(), 'Publication pair mismatch')
            pin(pending); pin(published)
            hardlinks.append({'pending': str(pending), 'published': str(published), 'dev': a.st_dev,
                              'inode': a.st_ino, 'nlink': a.st_nlink})
    port_observations = []
    for stop in stops:
        ports = read(stop['ports_absence_receipt']['path'], stop['ports_absence_receipt'])
        need(stop['ports_absence_proved'] is True and ports['ports_absence_proved'] is True,
             'Ports absence not proved')
        need(ports['residuals'] == ports['ambiguities'] == ports['attribution_errors'] == []
             and ports['ports_absent'] == [17593, 5173] and ports['auxiliary_ports_absent'] == [17594], 'Ports scope')
        owner = ports['owner']; identity(owner)
        need(len(ports['scans']) == 2, 'Two scans missing')
        for rows in ports['scans']:
            need([r['port'] for r in rows] == [17593, 5173, 17594], 'Three exact ports missing')
            for r in rows:
                ident = r['identity']; identity(ident)
                need(ident['role'] == 'diagnostic-lsof' and ident['parent_birth'] == [owner['pid'], owner['start_sec'], owner['start_usec']]
                     and ident['ppid'] == owner['pid'] and ident['pgid'] == ident['pid'], 'Diagnostic ownership')
                need(r['argv'] == ['/usr/sbin/lsof', '-nP', '-iTCP:' + str(r['port']), '-sTCP:LISTEN', '-F', 'p']
                     and r['launch'] == [QA + '/.venv-conforme/bin/python', '-I', '-B', str(ROOT / 'g1/lsof_gate.py'), str(r['port'])]
                     and r['returncode'] == 1 and r['pids'] == [] and r['stdout'] == r['stderr'] == '', 'Absence scan invalid')
                port_observations.append(r)
    ack_rows = []
    for p in sorted((ROOT / 'session-rpc/ack').glob('*.json')):
        a = read(p)
        # The immutable request ID, not a filename prefix, is authoritative.
        job = a['id']; need(job in binding['rpc_descriptors'], 'ACK outside prebound fifteen')
        if a['state'] == 'complete':
            need(a['termination_proved'] is True and a['tainted'] is False and a['signals'] == [], 'ACK lifecycle')
            leaf = read(a['receipt_ref']['path'], a['receipt_ref'])
            need(a['exit_code'] == leaf['exit_code'], 'ACK raw exit mismatch')
        else:
            need(a['state'] == 'error' and a['tainted'] is True, 'ACK error reclassified')
        ack_rows.append({'ref': pin(p), 'job': job, 'state': a['state'], 'exit_code': a.get('exit_code'),
                         'instrument_error': a.get('instrument_error'), 'receipt_ref': a.get('receipt_ref')})
    need(len(ack_rows) == result['rpc_audit']['observed'] == 7
         and len({a['job'] for a in ack_rows}) == 7 and result['rpc_audit']['expected'] == 15, 'ACK observed/expected')
    chrome = next(j for j in stage_rows if j.get('mode') == 'chrome')
    need(chrome['root_identity']['pid'] == 14738 and chrome['exit_code'] == -5 and chrome['timed_out'] is False
         and chrome['interruption'] is None and chrome['cleanup']['signals'] == [], 'Chrome outcome changed')
    stderr_ref = pin(chrome['stderr_path']); chrome_log = Path(chrome['stderr_path']).read_text()
    report.update({'original_result_ref': pin(ROOT / 'wrapper-canary-result.json'), 'original_result': result,
        'source_count': 79, 'stage_receipts': [{'name': j['name'], 'root_identity': j['root_identity'],
            'exit_code': j['exit_code'], 'raw_stable': j['raw_stable'], 'tainted': j['log_stability_tainted'],
            'cleanup_elapsed_seconds': j['cleanup_elapsed_seconds']} for j in stage_rows],
        'stop_refs': [result['service_stop_ref'], result['session_stop_ref']],
        'cleanup_seconds': [j['cleanup_elapsed_seconds'] for j in stops],
        'physical_cleanup_of_recorded_identities_checked': True, 'original_taint_clean_preserved': True,
        'signal_joins': signal_joins, 'unique_signal_events': len({json.dumps(r['signal'], sort_keys=True) for r in signal_joins}),
        'publication_pairs': hardlinks, 'ports_observations': port_observations, 'acks': ack_rows,
        'missing_RPC_jobs': sorted(set(binding['rpc_descriptors']) - {a['job'] for a in ack_rows}),
        'chrome_stderr_ref': stderr_ref, 'chrome_identity': chrome['root_identity'],
        'chrome_attributed_records': [r for r in records.values() if r['role'].startswith('auxiliary-')],
        'unattributed_PID_mentions_not_adopted': [p for p in (14881, 14909) if not any(r['pid'] == p for r in records.values())],
        'DevTools_17594_announced_in_log': 'DevTools listening on ws://127.0.0.1:17594/' in chrome_log,
        'child_lookup_denied1100_observed': 'bootstrap_look_up com.google.Chrome.MachPortRendezvousServer.14738: Permission denied (1100)' in chrome_log,
        'nested_sandbox_EPERM_text_observed': 'sandbox initialization failed: Operation not permitted' in chrome_log,
        'GPU_unusable_FATAL_observed': "GPU process isn't usable. Goodbye." in chrome_log,
        'single_OS_cause_proved': False, 'native_qualified': False})
except Exception as exc:
    errors.append(f'{type(exc).__name__}: {exc}')

changes = []
for p, before in list(pins.items()):
    try:
        body = Path(p).read_bytes()
        if hashlib.sha256(body).hexdigest() != before['sha256'] or len(body) != before['bytes']:
            changes.append(p)
    except OSError as exc:
        changes.append(f'{p}: {exc}')
report.update({'review_checks_passed': not errors and not changes, 'review_errors': errors,
               'before_after_changes': changes, 'verified_physical_refs': len(pins),
               'ref_scope': 'current raw ROOT15 graph plus direct 79 source refs; no historical graph reinterpretation',
               'limit': 'Finite recorded attribution only; no current liveness syscall or exhaustive hostile descendants assurance.'})
refs_ref = publish_output('CHECKED-REFS.json', {'refs': list(pins.values())})
report['checked_refs_ref'] = refs_ref
receipt_ref = publish_output('receipt.json', report)
print(json.dumps({'receipt': receipt_ref, 'refs': len(pins), 'review_checks_passed': report['review_checks_passed'],
                  'review_errors': errors, 'campaign_qualification': False, 'FULL': False}, ensure_ascii=False))
raise SystemExit(0 if report['review_checks_passed'] else 1)
