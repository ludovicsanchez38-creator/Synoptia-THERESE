# Checker ROOT15, successeur SDK strict

Auteur : /root/shared4_execution. Préparation uniquement. ROOT15 est construite par MAIN, mais aucun checker ni runtime ROOT15 n'a été exécuté par cet auteur.

## Delta fermé

La préimage `preimage-checker53.mjs` est byte-exacte au checker 791fce2e du gel 53. Le helper post-birth reste byte-exact a667171f. Le seul ajout fonctionnel accepte quatre headers SDK canoniques UID0/GID0, modes, nlink1, SHA et tailles exacts. Il ne crée aucune exemption générale pour UID0 ou les liens.

Les quatre seuls chemins historiques sont contrôlés physiquement : parent SDK alias exact et bootstrap symlink exact, les trois autres aliases réguliers doivent partager dev/inode avec la cible canonique. Les références JSON historiques ne sont pas réécrites. Quatre origines exactes sont jointes (INDEX initial et sa copie SDK, CONTRACT initial et sa copie SDK), soit seize pointeurs fermés. Chaque observation est historique, typée et non qualifiante.

Les six routes historiques ROOT14 et les deux routes du premier rouge ROOT15 restent strictes, sans nouvel ignore. Le gel 53, ses rouges et ses 53 tests restent préservés. Ici les mêmes 53 cas ont réellement été rejoués avec vingt cas SDK supplémentaires : 73 PASS, zéro erreur/échec/skip, trois pins égaux avant/après. Les fichiers de sortie sont le texte retourné par l'outil, pas des sinks stdout/stderr directs. Les FS/identités SDK des tests sont des doubles explicitement synthétiques ; seuls cinq textes de définition ROOT15 sont lus pour les comparaisons textuelles.

## Invocations MAIN seules

Préflight strict avant runtime :

```sh
/Users/synoptia/.nvm/versions/node/v22.19.0/bin/node /private/tmp/therese-c17-wrapper15-static-controls-sdk-kIbm1V/verify-prepared-wrapper15.mjs /private/tmp/therese-c17-wrapper-canary-9c1f04187dd24519b220372284a739c9
```

Après fermeture réelle seulement :

```sh
/Users/synoptia/.nvm/versions/node/v22.19.0/bin/node /private/tmp/therese-c17-wrapper15-static-controls-sdk-kIbm1V/verify-prepared-wrapper15.mjs /private/tmp/therese-c17-wrapper-canary-9c1f04187dd24519b220372284a739c9 --post-birth
```

Post-birth exige la naissance réellement released, ses gate/release hardlinks et les commandes template/effective exactes. Une tentative ayant birth mais refus avant release reste refusée. Aucun Chrome fictif n'est exigé pour un résultat rouge ; une prétention verte exige cinq closures réelles. Les booléens natifs, taints et clean du résultat sont conservés, jamais convertis par le checker. Ni ces tests ni ce gel ne qualifient Chrome, Mach, G1, FULL, deux rondes ou une release.

Les différences directes/inverses sous `diffs/` reconstruisent les deux fichiers exactement. Aucune source du dépôt, ancienne preuve, profil, racine ROOT15, décision, admission ou permission n'est modifiée.

Deux essais rouges du contrôle complémentaire des différences sont conservés : mauvais arguments de mon appel au helper pur, puis appel correct réellement vert. Ils n'ont changé aucun code du checker, helper ou tests et n'ont exécuté aucun préflight.
