# Compatibilité des huit entrées fraîches avec FULL v3

Avis favorable uniquement au raccord d’entrées. Aucun adaptateur ni alias
de schéma n’est nécessaire. L’INDEX source894b59d7… porte exactement les
huit clés lues par le constructeur487688bc… et son lecteur de dépendances.

Le HEAD91e0 est joint aux vrais rawcommit/tree et au manifeste4821 lignes.
Python149/4pth et Node3/427 correspondent aux chemins, schémas, locks,
versions et références physiques attendus. Les références figurent dans
receipt.json ; chaque référence a été rehashée à la préparation du rapport.

Méthode : lecture de code et de données, calculs SHA/JSON et stat uniquement.
Aucun constructeur, import G1/produit, processus QA, A/B ou natif exécuté.
Les corps de tous les fichiers Git et des dépendances ne sont pas tous
revalidés ici : revue physique distincte d’Env. Ces entrées ne produisent
aucune attestation A/B, autorité, binding ou admission Chrome/FULL.
