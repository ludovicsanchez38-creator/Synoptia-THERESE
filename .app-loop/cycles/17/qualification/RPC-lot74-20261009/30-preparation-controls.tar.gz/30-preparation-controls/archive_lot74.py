"""Contrôleur préparé LOT74. Aucun --execute avant GO root exact."""
from __future__ import annotations

import argparse
from dataclasses import dataclass
import gzip
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
import tarfile
import tempfile
import time


HERE = Path(__file__).resolve().parent
PLAN_PATH = HERE / "PLAN.json"
PER_FILE = 3_000_000
SPECIAL_FILE = 8_000_000
TOTAL_ARCHIVES = 24_000_000
MAX_RAW_ROW = 16_000_000
CHUNK = 1 << 20
ROOT15_PREPARED = (
    "fresh-wrapper-construction.json", "runtime78-rpc-instruments-preparation.json",
    "support-preparation.json", "campaign-sentinel.txt",
    "authorization/root-origin.json", "authorization/root-go.json",
    "authorization/auxiliary-physical.json", "authorization/auxiliary-overlay.json",
    "authorization/chrome-copy-fresh-after.json",
    "authorization/chrome-copy-fresh-before.json",
    "authorization/external-preparation-authority.json",
    "authorization/chrome-files.json", "authorization/core-preparation.json",
    "authorization/source-refs.json", "authorization/chrome-preparation.json",
    "authorization/support-go.json", "authorization/source-files.json",
    "authorization/support-origin.json", "authorization/instruments-go.json",
    "authorization/support-binding.json", "authorization/source-checkout.json",
    "authorization/identity-registry.json", "authorization/instruments-binding.json",
    "authorization/runner-boundary/INDEX.json",
    "authorization/runner-boundary/source/runner_boundary.py",
    "authorization/runner-boundary/proofs/returned-output.log",
    "authorization/runner-boundary/proofs/pure-test-receipt.json",
    "authorization/runner-boundary/tests/test_runner_boundary.py",
    "authorization/runner-boundary/diffs/wrapper_blueprint.py.diff",
    "authorization/runner-boundary/diffs/calibrate-test-runner.py.diff",
)
ROOT15_NATIVE = Path(
    "/private/tmp/therese-c17-wrapper-canary-9c1f04187dd24519b220372284a739c9"
)


class Refusal(ValueError):
    pass


def require(condition: bool, message: str) -> None:
    if not condition:
        raise Refusal(message)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def ref_shape(value: object) -> dict:
    require(isinstance(value, dict) and set(value) == {"path", "sha256", "bytes"},
            "ref non exacte")
    assert isinstance(value, dict)
    require(isinstance(value["path"], str) and value["path"].startswith("/")
            and isinstance(value["sha256"], str) and len(value["sha256"]) == 64
            and all(c in "0123456789abcdef" for c in value["sha256"])
            and type(value["bytes"]) is int and 0 <= value["bytes"] <= SPECIAL_FILE,
            "ref type/taille invalide")
    return value


def within(root: Path, path: Path) -> str:
    require(path.is_absolute() and path == path.resolve(strict=True), "chemin non canonique")
    try:
        relative = path.relative_to(root)
    except ValueError as exc:
        raise Refusal("chemin hors racine") from exc
    pure = PurePosixPath(relative.as_posix())
    require(str(pure) == relative.as_posix() and pure.parts and
            all(part not in ("", ".", "..") for part in pure.parts), "relatif non fermé")
    return str(pure)


@dataclass(frozen=True)
class Item:
    path: Path
    name: str
    data: bytes
    digest: str
    dev: int
    ino: int
    nlink: int

    def ref(self) -> dict:
        return {"path": str(self.path), "sha256": self.digest, "bytes": len(self.data)}


def read_item(root: Path, path: Path, *, expected: dict | None = None,
              special_sha: str | None = None) -> Item:
    name = within(root, path)
    before = path.lstat()
    require(stat.S_ISREG(before.st_mode) and before.st_uid == os.getuid(), "type/UID")
    is_event = root.name == "therese-c17-mach-register-canary-baa235510ca54c1a921e9f9bf268ccb3" \
        and (name == "micro-result.json" or
             (name.startswith("auxiliary/probe/slots/") and
              path.name in ("ready.json", "release.txt", "receipt.json")))
    is_event = is_event or (root == ROOT15_NATIVE and
                           (name == "session-rpc/plan.json" or
                            (name.startswith("session-rpc/ack/") and
                             name.endswith(".json"))))
    require(before.st_nlink == (2 if is_event else 1), "hardlink inattendu")
    if is_event:
        pending = Path(str(path) + ".pending")
        pstat = pending.lstat()
        require(stat.S_ISREG(pstat.st_mode) and pending.resolve(strict=True) == pending
                and (pstat.st_dev, pstat.st_ino, pstat.st_nlink) ==
                    (before.st_dev, before.st_ino, 2), "publication hardlink divergente")
    limit = SPECIAL_FILE if special_sha is not None else PER_FILE
    require(before.st_size <= limit, "fichier supérieur à sa borne")
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        opened = os.fstat(fd)
        require((opened.st_dev, opened.st_ino, opened.st_size, opened.st_nlink) ==
                (before.st_dev, before.st_ino, before.st_size, before.st_nlink),
                "inode changée à ouverture")
        parts = []
        size = 0
        while True:
            part = os.read(fd, CHUNK)
            if not part:
                break
            size += len(part)
            require(size <= before.st_size, "croissance lecture")
            parts.append(part)
        data = b"".join(parts)
        closed = os.fstat(fd)
        require((closed.st_dev, closed.st_ino, closed.st_size, closed.st_mtime_ns,
                 closed.st_ctime_ns, closed.st_nlink) ==
                (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns,
                 before.st_ctime_ns, before.st_nlink), "mutation pendant lecture")
    finally:
        os.close(fd)
    after = path.lstat()
    require((after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns,
             after.st_ctime_ns, after.st_nlink) ==
            (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns,
             before.st_ctime_ns, before.st_nlink), "mutation après lecture")
    digest = sha(data)
    if expected is not None:
        ref_shape(expected)
        require(expected == {"path": str(path), "sha256": digest, "bytes": len(data)},
                "ref épinglée différente")
    if special_sha is not None:
        require(digest == special_sha and len(data) == 6_963_011,
                "exception archive95 différente")
    return Item(path, name, data, digest, before.st_dev, before.st_ino, before.st_nlink)


def read_anchor(root: Path, row: dict) -> tuple[Item, dict | None]:
    anchor = read_item(root, root / row["anchor"])
    require(anchor.digest == row["anchor_sha256"], "ancre SHA différente")
    if row["anchor"].endswith(".json"):
        body = json.loads(anchor.data)
        require(isinstance(body, dict), "ancre JSON non objet")
    else:
        body = None
    return anchor, body


def select(row: dict) -> list[Item]:
    root = Path(row["root"])
    require(str(root).startswith("/private/tmp/therese-c17-")
            and root.resolve(strict=True) == root and root.is_dir(), "racine non privée")
    anchor, body = read_anchor(root, row)
    selector = row["selector"]
    refs: list[dict] = []
    paths: list[Path] = []
    if selector == "index_files":
        assert body is not None
        refs = body[row["index_key"]]
        require(isinstance(refs, list), "table index non liste")
    elif selector == "gate_independent_closure":
        assert body is not None
        require(body.get("schema") == "c17-independent-root15-review-index-v1"
                and body.get("reviewer_actor") == "/root/cycle17_gate_review"
                and body.get("root") == str(ROOT15_NATIVE)
                and body.get("status") == "closed_instrument_RED_preserved"
                and body.get("campaign_qualification") is False
                and body.get("FULL") is False and body.get("release") is False
                and body.get("runtime_launched_by_reviewer") is False
                and body.get("G1_imported") is False
                and body.get("OS_probe_or_signal") is False
                and body.get("unique_rechecked_physical_refs") == 259
                and body.get("all_physical_refs_unchanged") is True
                and body.get("first_analytical_chronology_red_preserved") is True
                and body.get("kernel_birth_chronology_proved") is False
                and body.get("actual_reader_calls") == [
                    {"tool_chunk": "ba748f", "exit_code": 0,
                     "scope": "FS-only actual closure review"},
                    {"tool_chunk": "a3b922", "exit_code": 1,
                     "scope": "FS-only supplement first chronology refusal"},
                    {"tool_chunk": "e418f3", "exit_code": 0,
                     "scope": "FS-only supplement with transparent measured chronology inconsistency"},
                ], "revue Gate non conforme")
        refs = body.get("files")
        require(isinstance(refs, list) and len(refs) == 9,
                "neuf refs Gate exigées")
    elif selector == "index_refs":
        assert body is not None
        refs = [body[row["index_key"]]]
    elif selector == "source_archive":
        assert body is not None
        require(body.get("status") == "archive_verified" and body.get("member_count") == 95
                and body.get("total_input_bytes") == 32_592_096
                and body.get("FULL") is False and body.get("release") is False,
                "archive95 non vérifiée")
        refs = [body["selection_ref"], body["archive_ref"]]
    elif selector == "mach_native":
        assert body is not None
        require(body.get("passed") is True and body.get("scope") ==
                "c17_exact_mach_register_microcanary_only" and body.get("FULL") is False
                and body.get("release") is False and len(body.get("runs", [])) == 2,
                "micro natif non clos")
        refs = [ref for ref in body["pins_after"] if ref["path"].startswith(str(root) + "/")]
        refs += [run[key] for run in body["runs"]
                 for key in ("receipt_ref", "gate_ref", "release_ref", "stdout_ref", "stderr_ref")]
    elif selector == "pure_receipt_logs":
        assert body is not None
        require(body.get("passed") is True and body.get("tests") == 38,
                "pures WRAPPER15 non conformes")
        refs = [body["stdout_ref"], body["stderr_ref"]]
    elif selector == "checker_receipt_logs":
        assert body is not None
        require(body.get("schema") == "c17-checker15-MAIN-readonly-receipt-v1"
                and body.get("mode") == row["expected_mode"]
                and body.get("exit_code") == row["expected_exit_code"]
                and body.get("passed") is row["expected_passed"]
                and body.get("native_executed") is False
                and (body.get("checker_result") or {}).get("status") ==
                    row["expected_checker_status"], "checker15 reçu non conforme")
        refs = [body["command_ref"], body["stdout_ref"], body["stderr_ref"]]
    elif selector == "root15_native_red":
        assert body is not None
        require(root == ROOT15_NATIVE and body.get("schema") ==
                "c17-wrapper-canary-instrument-result-v1"
                and body.get("passed") is False and body.get("runner_exit") == 86
                and body.get("scope") == "WRAPPER_CANARY"
                and body.get("classification") ==
                    "instrument_error_or_incomplete_not_product_bug"
                and body.get("owned_shutdown_proved") is False
                and body.get("rpc_transport_closed") is True
                and body.get("source_unchanged") is True
                and body.get("FULL") is False
                and body.get("rpc_audit", {}).get("expected") == 15
                and body.get("rpc_audit", {}).get("observed") == 7,
                "ROOT15 rouge non identique")
        manifest_ref = row["native_selection_ref"]
        ref_shape(manifest_ref)
        manifest_path = Path(manifest_ref["path"])
        require(manifest_path == HERE / "ROOT15-SELECTED-REFS.json",
                "manifest natif hors contrôleur")
        manifest_item = read_item(HERE, manifest_path, expected=manifest_ref)
        manifest = json.loads(manifest_item.data)
        require(manifest.get("schema") == "c17-lot74-root15-native-red-selection-v1"
                and manifest.get("root") == str(root)
                and manifest.get("status") == "terminal_native_red_exit86_not_product_bug"
                and manifest.get("result_ref") ==
                    {"path": str(anchor.path), "sha256": anchor.digest,
                     "bytes": len(anchor.data)}
                and manifest.get("expected_ack_count") == 7
                and manifest.get("expected_rpc_receipt_count") == 6
                and manifest.get("expected_port_scans") == 3
                and manifest.get("expected_listener_observations") == 6,
                "table native ROOT15 divergente")
        absent = root / manifest["expected_prelaunch_absent"]
        require(absent == root / "ledger/rpc-all-runtime_ui-visual_capture-network_capture/receipt.json"
                and not absent.exists() and not absent.is_symlink(),
                "birth/receipt prelaunch fabriqué")
        raw_refs = manifest["selection_refs"]
        require(isinstance(raw_refs, list) and len(raw_refs) == 51,
                "cardinalité native")
        require(len({ref["path"] for ref in raw_refs}) == 51,
                "ref native dupliquée")
        require(sum(ref["bytes"] for ref in raw_refs) ==
                manifest["expected_total_bytes"] == 3_008_716,
                "taille native différente")
        require(sum("/session-rpc/ack/" in ref["path"] for ref in raw_refs) == 7
                and sum("/ledger/ports-absence-" in ref["path"] for ref in raw_refs) == 3
                and sum("/ledger/listener-observation-" in ref["path"] for ref in raw_refs) == 6,
                "familles natives incomplètes")
        for ref in raw_refs:
            require(set(ref) == {"path", "sha256", "bytes", "nlink", "uid"}
                    and ref["nlink"] in (1, 2) and ref["uid"] == os.getuid(),
                    "ref native physique")
            ref_shape({key: ref[key] for key in ("path", "sha256", "bytes")})
        refs = [{key: ref[key] for key in ("path", "sha256", "bytes")}
                for ref in raw_refs[1:]]
        require(raw_refs[0]["path"] == str(anchor.path)
                and raw_refs[0]["sha256"] == anchor.digest
                and raw_refs[0]["bytes"] == len(anchor.data),
                "ancre ROOT15 hors table native")
    elif selector == "root15_diagnostic_receipt":
        assert body is not None
        require(body.get("schema") == "c17-root15-targeted-system-log-v1"
                and body.get("diagnostic_only") is True
                and body.get("passed") is True
                and body.get("event_count") == 234
                and body.get("native_relaunched") is False
                and body.get("profile_changed") is False
                and body.get("stdout_ref") == row["private_raw_ref"]
                and body.get("stderr_ref", {}).get("bytes") == 0,
                "diagnostic système non exact")
    elif selector == "root15_prepared_exact":
        assert body is not None
        require(body.get("status") == "prepared_only_native_tool_GO_required"
                and body.get("FULL") is False and body.get("runtime_executed") is False,
                "ROOT15 non préparé seul")
        paths = [root / relative for relative in ROOT15_PREPARED if relative != row["anchor"]]
    elif selector == "root15_controls_exact":
        paths = [root / "identity-registry.json"]
    elif selector == "anchor_only":
        assert body is not None
        if row.get("class") == "historical_red":
            require(body.get("status") in ("failed", None) or body.get("exit_code") != 0,
                    "ancien rouge devenu vert")
    else:
        raise Refusal("sélecteur inconnu")
    for ref in refs:
        ref_shape(ref)
        path = Path(ref["path"])
        within(root, path)
        paths.append(path)
    items = [anchor]
    seen = {anchor.path}
    ref_by_path = {Path(ref["path"]): ref for ref in refs}
    require(len(ref_by_path) == len(refs) or selector == "mach_native", "refs dupliquées")
    for path in sorted(set(paths)):
        require(path not in seen, "ref répétée avec ancre")
        seen.add(path)
        special = None
        if selector == "source_archive" and path.name == "source-qa-evidence.tar.gz":
            special = "bab6b66a868bb7d361e32f3d8a389bbaf588ae0edee1f153ffb7cd5d3a174a68"
        items.append(read_item(root, path, expected=ref_by_path.get(path), special_sha=special))
    require(len(items) == row["expected_files"], "cardinalité ligne")
    require(sum(len(item.data) for item in items) <= MAX_RAW_ROW,
            "ligne >16MB avant compression")
    return items


def select_external(plan: dict) -> list[Item]:
    cwd = Path("/Users/synoptia/Documents/Codex/2026-09-04/on")
    require(cwd.resolve(strict=True) == cwd, "cwd non canonique")
    result = []
    for ref in plan["external_documents_exact"]:
        ref_shape(ref)
        result.append(read_item(cwd, Path(ref["path"]), expected=ref))
    require(len(result) == 10 and len({item.path for item in result}) == 10,
            "documents externes autres")
    return result


def tar_archive(path: Path, items: list[Item], prefix: str,
                *, archive_limit: int) -> dict:
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, "wb") as target:
        with gzip.GzipFile(fileobj=target, mode="wb", filename="", mtime=0,
                           compresslevel=6) as zipped:
            with tarfile.open(fileobj=zipped, mode="w|", format=tarfile.USTAR_FORMAT) as tar:
                for item in items:
                    name = f"{prefix}/{item.name}"
                    pure = PurePosixPath(name)
                    require(not pure.is_absolute() and str(pure) == name
                            and ".." not in pure.parts, "membre tar non sûr")
                    info = tarfile.TarInfo(name)
                    info.size = len(item.data)
                    info.mode = 0o600
                    info.uid = info.gid = info.mtime = 0
                    info.uname = info.gname = ""
                    info.type = tarfile.REGTYPE
                    import io
                    tar.addfile(info, io.BytesIO(item.data))
        target.flush()
        os.fsync(target.fileno())
    require(path.stat().st_size <= archive_limit, "archive compressée hors borne")
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(CHUNK), b""):
            digest.update(chunk)
    with gzip.open(path, "rb") as compressed:
        total = 0
        for chunk in iter(lambda: compressed.read(CHUNK), b""):
            total += len(chunk)
            require(total <= 20_000_000, "flux tar hors borne")
    with tarfile.open(path, "r:gz") as tar:
        stored = tar.getmembers()
        require([entry.name for entry in stored] == [f"{prefix}/{item.name}" for item in items],
                "tar ordre/membres")
        for entry, item in zip(stored, items):
            require(entry.type == tarfile.REGTYPE and entry.size == len(item.data)
                    and entry.mode == 0o600 and entry.uid == entry.gid == entry.mtime == 0
                    and entry.uname == entry.gname == entry.linkname == "", "tar metadata")
            stream = tar.extractfile(entry)
            require(stream is not None, "tar illisible")
            with stream:
                require(sha(stream.read()) == item.digest, "tar contenu")
    return {"path": str(path), "sha256": digest.hexdigest(), "bytes": path.stat().st_size}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--inspect", action="store_true")
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()
    require(args.inspect != args.execute, "choisir inspect OU execute")
    plan = json.loads(PLAN_PATH.read_bytes())
    require(plan.get("schema") == "c17-lot74-evidence-archive-plan-v2"
            and len(plan.get("rows", [])) == 28 and plan.get("FULL") is False
            and plan.get("A_B_admitted") is False and plan.get("release") is False,
            "plan non fermé")
    require(plan.get("gate_closure_review_index_ref") ==
            {"path": "/private/tmp/therese-c17-independent-root15-review-MdWBfuS1/INDEX.json",
             "sha256": "2e478bd9cb5a792b5ba76a7935c2d84c3fb449d11c9da3385d95e863b4645dc4",
             "bytes": 3090}, "revue Gate absente")
    if args.execute:
        raise Refusal("GO archive et revue Gate closure absents de ce gel ; aucune émission")
    rows = [(row, select(row)) for row in plan["rows"]]
    docs = select_external(plan)
    names = [row["id"] for row, _ in rows]
    require(len(names) == len(set(names)) == 28, "id lignes dupliqués")
    selected_count = sum(len(items) for _, items in rows) + len(docs)
    selected_bytes = sum(len(item.data) for _, items in rows for item in items)
    selected_bytes += sum(len(item.data) for item in docs)
    require(selected_bytes <= TOTAL_ARCHIVES, "sélection totale >24MB")
    material = [{"row": row["id"], "name": item.name,
                 "sha256": item.digest, "bytes": len(item.data)}
                for row, items in rows for item in items]
    material += [{"row": "29-external-documents", "name": item.name,
                  "sha256": item.digest, "bytes": len(item.data)} for item in docs]
    selection_sha256 = sha(json.dumps(material, sort_keys=True,
                                      separators=(",", ":")).encode("utf-8"))
    require(plan.get("prepared_selection_sha256") == selection_sha256,
            "sélection préparée modifiée")
    print(json.dumps({"status": "prepared_after_gate_closure_review_not_executed", "rows": 28,
                      "selected_files": selected_count, "selected_bytes": selected_bytes,
                      "prepared_selection_sha256": selection_sha256,
                      "source_qa_archive_exact_exception": True, "native15_red_included": True,
                      "archive_created": False, "FULL": False, "release": False},
                     sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
