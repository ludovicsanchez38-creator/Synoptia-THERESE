# Revue indépendante du successeur micro SDK et de WRAPPER15

Lecture seule. Aucun profil compilé, aucune sonde Mach, aucun Chrome, G1 complet, constructeur, service ou canari natif lancé par le relecteur.

## Microcanari, successeur SDK

Référence : `/private/tmp/therese-c17-mach-register-micro-sdk-GhSw1pr1/INDEX.json`, SHA-256 `c542f8c44302a67eb43657accc0896b1259f09db697a7974185ff5cea595fddb`, 5 876 octets. Ses 15 fichiers locaux, cinq origines et trois preuves, puis l'INDEX, donnent 24 objets physiques : tous sont réguliers, canoniques et concordent en SHA-256/taille. Les sept fichiers exécutables/profils sont byte-exacts avec l'ancien gel c4909875 ; `CONTRACT.diff` reconstruit exactement son nouveau contrat depuis la préimage conservée.

La réserve de l'ancien `servers/bootstrap.h` n'est pas effacée. Le nouveau contrat pointe quatre headers canoniques réguliers sous `MacOSX26.5.sdk`. `SDK-ALIASES.json`, SHA-256 `a713b648cd1caae5d7091ad2b28e0766124b83703128b9e902e27e821290fa63`, distingue deux liens : `MacOSX.sdk` → `MacOSX26.5.sdk` et `servers/bootstrap.h` → `../bootstrap.h`. Les textes, SHA des textes, tailles `lstat` de 14 octets, cibles résolues et quatre stats de cibles ont été vérifiés. Le code et la commande proposée continuent d'utiliser l'alias SDK littéral ; MAIN doit recontrôler alias et cibles immédiatement avant une éventuelle compilation.

Le reçu pur nouveau `aeb65a73f29fddd35b3a3e80c5a226a480a3049caaff07c4655665fbfc1138cc` confirme le rejeu des mêmes 35 cas, zéro erreur/échec/saut et sept pins avant/après stables. Aucun résultat kernel, syntaxe Seatbelt compilée, Chrome ou G1 n'en découle. Le préflight externe des définitions avant l'import de `contract.py` reste une dépendance réelle ; un champ JSON `actor=/root` n'authentifie pas une décision.

## WRAPPER15

Référence : `/private/tmp/therese-c17-wrapper15-own-rendezvous-ky7lgh/INDEX.json`, SHA-256 `770af2012e00c5d911faa2024692b4bd1f347cf60c9cac5ca4761e037eea5a7f`, 17 048 octets. Les 33 références locales et cinq origines rehashées concordent. Les six diffs aller et six inverses, appliqués à des sorties temporaires séparées, reconstruisent exactement leurs cibles et préimages ; les gels antérieurs sont inchangés. Le profil passe de 2 499 à 2 568 octets par l'unique règle paramétrée `mach-register`, sans autre droit.

Le code dérive `OWN_RENDEZVOUS_SERVICE` seulement après `Popen`, `admit_root` et relecture de birth. La valeur contient le PID de l'enfant Chrome admis, et reste absente de l'argv template et de l'environnement libre. La release hardlink relie template, commande effective et identité ; le gate recroise PID/PPID/UID/PGID, stage/mode/binding et commande avant `execve`. Les reçus service et la clôture auxiliaire conservent les deux commandes. Ce raccord est borné à ROOT15, WRAPPER_CANARY et cinq stages Chrome ; les modes web/SQL ne reçoivent pas cette règle. Les bornes 5 s CDP, 50 s démarrage Chrome et 8 s cleanup restent déclarées inchangées.

Le premier reçu pur `87d194cb513bdaa81ea0bc818e36414e7c0cc661f994dd717855674421b500ed` garde quatre erreurs de fixture AST, sans tentative native ; la fixture préimage est conservée. Le reçu auteur final `42c4b33c0baa2e50ef30da5ff914ad4ba826ec676788468745ffe043b6f216fb` annonce 38/38 cas sans erreur, 19 pins avant/après égaux et fixtures explicitement synthétiques. Le rejeu MAIN indépendant `4d5f51872a3aa70b9b57208dcaa404d93aecebccdcd3aa9bb30c579fc65483a9` confirme les mêmes 38 cas purs ; son premier préflight générique a refusé un pointeur historique avant test, sans mutation du gel, puis MAIN a employé la table fermée des 38 références.

Limites : la racine ROOT15 n'existait pas lors de cette revue. HEAD/source canari demeurent historiques `2d69e30c9c6dd18823ee6102271876003a6a67cc` et `wrapper-source-kGvU1hdx/source`, non la nouvelle source QA HEAD `91e0b942bfb24bfb77890960b2c4b97d04cbb750`. Les 38 tests sont des doubles/branches extraites, pas une preuve Mach, libproc, Chrome, G1 physique, A/B, FULL ou release. Une autorité MAIN et des contrôles de préparation distincts restent nécessaires avant tout essai natif.
