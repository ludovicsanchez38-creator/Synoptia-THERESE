# ROOT15 checker : pointeur historique premier rouge

Auteur : /root/shared4_execution. Préparation uniquement, aucune exécution du checker ou de ROOT15 par cet auteur.

Successeur strict du gel SDK73 `9bae0f34`, préimage checker `39431697` conservée. Le helper `a667171f` reste byte-exact. Une seule route historique supplémentaire : INDEX WRAPPER15 `770af201` /17048 B, pointeur `/first_red_test_snapshot/original_record`. La référence enregistrée du test rouge99b142 est reliée à sa vraie préimage99b142, au test courantae708 et au premier reçu87d194 (38 tests, quatre erreurs, exit1, passedfalse). Le JSON et tous ses pins historiques restent inchangés.

Le contrôle exige les trois clés des références, l'origine entière, les tailles/SHA exacts, la préimage canonique régulière UID501/GID0/mode100644/nlink1 et le test courant exact. La seule observation nouvelle est typée historique, non qualifiante, attendue exactement une fois. Les deux routes du reçu rouge, les six routes ROOT14, les seize SDK et les autres gardes restent inchangées. Toute route non listée garde le collecteur strict ordinaire.

Le préflight MAIN rouge `c128ef99` sous `therese-c17-checker15-main-preflight-AEByWY` est conservé et joint comme origine, jamais renommé en réussite. Aucune tentative native15 n'est déduite de cet essai.

88 tests réellement purs PASS `1b74fc` : les 73 anciens cas sont rejoués, quinze contrôles supplémentaires exécutent le vrai corps collect avec l'INDEX770af COMPLET physiquement lu. Les mutations sont des doubles explicites et ne modifient pas l'INDEX, reçu, archive ou test. Trois pins restent égaux avant/après. Sortie enregistrée : texte retourné par l'outil, pas stdout/stderr directs. Ni preuve OS des doubles, ni qualification Mach/Chrome/G1/FULL/release.

## MAIN seul

Préflight avant runtime :

```sh
/Users/synoptia/.nvm/versions/node/v22.19.0/bin/node /private/tmp/therese-c17-wrapper15-static-controls-history-TnzSGa/verify-prepared-wrapper15.mjs /private/tmp/therese-c17-wrapper-canary-9c1f04187dd24519b220372284a739c9
```

Post-birth explicite après fermeture réelle uniquement : même commande avec `--post-birth`. Le résultat rouge/taint/cleanfalse reste rouge ; une naissance avant release refusée n'est pas transformée en preuve released. Aucun profil, délai, source79, G1/gate, ROOT15, admission ou permission n'est changé. Le port FULL attend séparément.
