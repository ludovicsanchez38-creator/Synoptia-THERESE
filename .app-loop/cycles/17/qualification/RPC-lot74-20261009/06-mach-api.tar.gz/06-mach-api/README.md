# Microcanari Mach : successeur RECEIVE, fermé

Le gel SDK c542f8c4 reste intact. Son rouge de compilation MAIN
1e7f1e26…/1 226 octets est conservé : `-Werror` refuse l’API dépréciée.
Aucune compilation et aucun appel Mach/Seatbelt n’ont été effectués ici.

## Delta exact

Le C change une seule ligne dans le même garde de droit acquis et de ports
protégés :

```c
destroyed = mach_port_mod_refs(mach_task_self(), port, MACH_PORT_RIGHT_RECEIVE, -1);
```

Le SDK26.5 canonique déclare cette API sans annotation de dépréciation
(mach/mach_port.h, lignes193–201). Les sources primaires Apple publiées
[mach_port.c](https://raw.githubusercontent.com/apple-oss-distributions/xnu/main/osfmk/ipc/mach_port.c)
et [ipc_right.c](https://raw.githubusercontent.com/apple-oss-distributions/xnu/main/osfmk/ipc/ipc_right.c)
décrivent la suppression de la référence RECEIVE par delta -1. Le nom
peut rester si d’autres droits subsistent. Un port guarded peut être refusé.
Cette lecture amont ne prouve pas la version du kernel local.

Ce choix ne devine ni guard ni nombre de SEND et ne supprime aucun droit
SEND/dead-name. Le contrôle réel après l’appel demeure
`mach_port_type == KERN_INVALID_NAME (15)`. Un autre retour ou signal reste
rouge. Le champ brut `destroy_code` est conservé, sans changement de schéma.

`contract.py`, runner, environnement, délais, profils, rendez-vous et
oracles sont byte-exacts. Les trois préimages et API.diff rendent le delta
reconstructible. Les deux aliases SDK restent des observations typées,
les références de contenu sont physiques et canoniques.

## Pures réellement exécutés

Outil 44f59b : exit0, 40 tests, zéro erreur/échec/saut, sept pins égaux,
0,006909 s. Ce sont les mêmes35 cas rejoués (assertion API mise à jour) et
cinq contrôles purs ajoutés. Les codes/naissances des fixtures sont
synthétiques. Aucune simulation n’est présentée comme refus du kernel.

Reçu : /private/tmp/therese-c17-mach-register-receive-pure-CIN8JV21/receipt.json
SHA08aae6c5…/3 993 octets. Garde subprocess/socket/ctypes active, sorties
indépendantes du gel. Aucun import de G1.

## Commandes futures MAIN, non exécutées ici

```text
/usr/bin/clang -std=c11 -O2 -Wall -Wextra -Werror -isysroot /Library/Developer/CommandLineTools/SDKs/MacOSX.sdk /private/tmp/therese-c17-mach-register-micro-receive-p0pLSYvc/probe.c -o <ROOT>/auxiliary/probe/mach-probe
<Python QA physique> -I -B /private/tmp/therese-c17-mach-register-micro-receive-p0pLSYvc/run_micro.py --run --root <ROOT> --go-ref <ref JSON décision réelle>
```

Racine neuve privée de forme therese-c17-mach-register-canary-<32 hex>,
copie exclusive des deux profils et vrai reçu de compilation requis.
Le GO externe MAIN distinct et ses refs/TTL≤120 s demeurent obligatoires.
L’import local du contrat précède le load_go interne : MAIN doit rehash
le gel physiquement avant Python, ce n’est pas une authentification JSON.

Le launcher MAIN existant est encore borné à35 tests et15/5/3 refs du
prédécesseur SDK. Pour ce successeur, son nouveau gel devra exiger
40 tests et15/6/4 refs, plus le predecessor INDEX exact. Aucune baisse
des contrôles canoniques, aliases, flags, compilation ou GO n’est proposée.

Le profil reste baseline2ecae3 + seule règle de69 octets, permissions
inchangées. La permission Mach exacte reste héritée par descendants.
Portée : deux enfants directs futurs uniquement. Pas de preuve hostile
exhaustive, Chrome154, CDP, G1, FULL, release ou admission runtime.
