"""Fixtures synthétiques et vrais corps purs; aucune preuve Mach native."""
import copy
import ast
import hashlib
import unittest
from pathlib import Path
from unittest import mock

import contract as c

D = Path(__file__).resolve().parent
OWNER = {"pid": 2100, "ppid": 1000, "uid": 501, "pgid": 2100, "start_sec": 1700000000, "start_usec": 10}
CHILD = {"pid": 2101, "ppid": 2100, "uid": 501, "pgid": 2101, "start_sec": 1700000001, "start_usec": 20}
ROOT = Path("/private/tmp/therese-c17-mach-register-canary-" + "a" * 32)


def denied(label, name):
    return {"label": label, "name": name, "bootstrap_code": 1100, "port_value": 0, "port_valid": False,
            "type_code": None, "receive_right": False, "destroy_code": None, "after_destroy_type_code": None}


def fixture(mode):
    own = c.PREFIX + str(CHILD["pid"])
    rows = [denied("own", own)]
    if mode == "candidate":
        rows[0] = {"label": "own", "name": own, "bootstrap_code": 0, "port_value": 12345, "port_valid": True,
                   "type_code": 0, "receive_right": True, "destroy_code": 0, "after_destroy_type_code": 15}
        rows += [denied("other_pid", c.PREFIX + str(OWNER["pid"])), denied("suffix", own + ".c17-denied")]
    return {"schema": "c17-mach-register-probe-raw-v1", "mode": mode, **CHILD, "outcomes": rows}


class PureContract(unittest.TestCase):
    def reject(self, field, value, row=0):
        raw = fixture("candidate")
        raw["outcomes"][row][field] = value
        with self.assertRaises(ValueError):
            c.evaluate(raw, "candidate", CHILD, OWNER)

    def test_01_baseline_exact_denial(self):
        c.evaluate(fixture("baseline"), "baseline", CHILD, OWNER)

    def test_02_candidate_exact_three_cases(self):
        c.evaluate(fixture("candidate"), "candidate", CHILD, OWNER)

    def test_03_other_pid_not_permitted(self):
        self.reject("bootstrap_code", 0, 1)

    def test_04_suffix_not_permitted(self):
        self.reject("bootstrap_code", 0, 2)

    def test_05_unknown_service_not_denial(self):
        self.reject("bootstrap_code", 1102, 1)

    def test_06_own_not_privileged_not_success(self):
        self.reject("bootstrap_code", 1100)

    def test_07_missing_receive_right(self):
        self.reject("receive_right", False)

    def test_08_failed_destroy(self):
        self.reject("destroy_code", 5)

    def test_09_still_live_right(self):
        self.reject("after_destroy_type_code", 0)

    def test_10_port_returned_on_denial(self):
        self.reject("port_value", 12345, 2)

    def test_11_boolean_is_not_numeric_code(self):
        for key in ("bootstrap_code", "type_code", "destroy_code", "after_destroy_type_code"):
            with self.subTest(key=key):
                self.reject(key, False)

    def test_12_boolean_port_not_zero(self):
        self.reject("port_value", False, 1)

    def test_13_rows_missing(self):
        raw = fixture("candidate"); raw["outcomes"].pop()
        with self.assertRaises(ValueError): c.evaluate(raw, "candidate", CHILD, OWNER)

    def test_14_rows_duplicate(self):
        raw = fixture("candidate"); raw["outcomes"].append(copy.deepcopy(raw["outcomes"][0]))
        with self.assertRaises(ValueError): c.evaluate(raw, "candidate", CHILD, OWNER)

    def test_15_wrong_name(self):
        self.reject("name", c.PREFIX + "9999")

    def test_16_wrong_mode(self):
        with self.assertRaises(ValueError): c.evaluate(fixture("candidate"), "baseline", CHILD, OWNER)

    def test_17_changed_birth(self):
        raw = fixture("candidate"); raw["start_usec"] += 1
        with self.assertRaises(ValueError): c.evaluate(raw, "candidate", CHILD, OWNER)

    def test_18_wrong_parent(self):
        child = {**CHILD, "ppid": 2222}
        with self.assertRaises(ValueError): c.release_bytes(child, OWNER, "candidate", "b" * 32)

    def test_19_wrong_uid(self):
        with self.assertRaises(ValueError): c.admitted_child({**CHILD, "uid": 502}, OWNER)

    def test_20_wrong_pgid(self):
        with self.assertRaises(ValueError): c.admitted_child({**CHILD, "pgid": 2100}, OWNER)

    def test_21_bad_nonce(self):
        with self.assertRaises(ValueError): c.release_bytes(CHILD, OWNER, "candidate", "../x")

    def test_22_release_exact_actual_fields(self):
        value = c.release_bytes(CHILD, OWNER, "candidate", "b" * 32).decode()
        self.assertIn("pid=2101\n", value); self.assertIn("parent_start_usec=10\n", value)
        self.assertTrue(value.endswith("service=" + c.PREFIX + "2101\n"))

    def test_23_candidate_exact_name_parameter(self):
        args = c.expected_command(ROOT, "candidate", CHILD)
        self.assertEqual(args.count("OWN_RENDEZVOUS_SERVICE=" + c.PREFIX + "2101"), 1)
        self.assertNotIn("OWN_RENDEZVOUS_SERVICE=" + c.PREFIX + "2100", args)
        self.assertEqual(args[-9:], [str(ROOT / "auxiliary/probe/mach-probe"), "probe", "candidate", "2101", "2100", "501", "2101", "1700000001", "20"])

    def test_24_baseline_no_register_parameter(self):
        self.assertFalse(any(x.startswith("OWN_RENDEZVOUS_SERVICE=") for x in c.expected_command(ROOT, "baseline", CHILD)))

    def test_25_environment_no_inheritance(self):
        env = c.child_environment(ROOT)
        self.assertEqual(set(env), {"HOME", "CFFIXED_USER_HOME", "TMPDIR", "PATH", "LANG", "LC_ALL", "TZ"})
        self.assertEqual(env["HOME"], str(ROOT / "auxiliary/probe/home"))

    def test_26_bad_root_before_filesystem(self):
        with self.assertRaises(ValueError): c.canonical_root("/private/tmp/not-qa")

    def test_27_canonical_fixture_is_declared_synthetic(self):
        with mock.patch.object(Path, "resolve", return_value=ROOT), mock.patch.object(Path, "is_dir", return_value=True):
            self.assertEqual(c.canonical_root(str(ROOT)), ROOT)

    def test_28_profile_single_exact_delta(self):
        baseline = (D / "profiles/chrome14.sb").read_bytes()
        self.assertEqual(hashlib.sha256(baseline).hexdigest(), c.BASE_SHA)
        self.assertEqual((D / "profiles/candidate.sb").read_bytes(), baseline + c.RULE.encode())

    def test_29_bounds_refuse_nan_inf_bool(self):
        for value in (True, float("nan"), float("inf"), -1, 8.01):
            self.assertFalse(c.finite_bound(value, 8))
        self.assertTrue(c.finite_bound(8, 8))

    def test_30_native_source_is_not_runtime_evidence(self):
        source = (D / "probe.c").read_text()
        self.assertIn("argc != 9", source)
        self.assertEqual(source.count("bootstrap_check_in("), 1)
        self.assertEqual(source.count("mach_port_mod_refs(mach_task_self(), port, MACH_PORT_RIGHT_RECEIVE, -1)"), 1)
        self.assertNotIn("mach_port_destroy(", source)
        for forbidden in ("bootstrap_look_up(", "bootstrap_register(", "fork(", "socket(", "connect(", "system("):
            self.assertNotIn(forbidden, source)
        self.assertIn("getpid()", source); self.assertIn("proc_pidinfo(", source)

    def test_31_attribution_precedes_untrusted_ready_parse(self):
        tree = ast.parse((D / "run_micro.py").read_text())
        run = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "run")
        assignments = [n for n in ast.walk(run) if isinstance(n, ast.Assign)]
        child_line = next(n.lineno for n in assignments if any(isinstance(t, ast.Name) and t.id == "child" for t in n.targets)
                          and isinstance(n.value, ast.Call) and isinstance(n.value.func, ast.Name) and n.value.func.id == "read")
        raw_line = next(n.lineno for n in assignments if any(isinstance(t, ast.Name) and t.id == "raw_gate" for t in n.targets))
        self.assertLess(child_line, raw_line)

    def test_32_cleanup_wait_uses_gate5_and_total8(self):
        tree = ast.parse((D / "run_micro.py").read_text())
        run = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "run")
        waits = [n for n in ast.walk(run) if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr == "wait"]
        expression = next(n.keywords[0].value for n in waits if n.keywords and isinstance(n.keywords[0].value, ast.Call)
                          and ast.unparse(n.keywords[0].value).startswith("max(0.0, min(5.0"))
        class Clock:
            value = 0
            @classmethod
            def monotonic(cls): return cls.value
        for now, expected in ((10, 5), (13, 5), (17, 1), (18, 0), (19, 0)):
            Clock.value = now
            actual = eval(compile(ast.Expression(expression), "actual-cleanup-bound", "eval"), {"time": Clock, "started": 10})
            self.assertEqual(actual, expected)

    def test_33_signal_requires_canonical_birth_and_exec(self):
        source = (D / "run_micro.py").read_text()
        self.assertIn('identity_tuple(current) == identity_tuple(child)', source)
        self.assertIn('current["executable"] in (str(folder / "mach-probe"), "/usr/bin/sandbox-exec")', source)
        self.assertIn('process sans birth admise, aucun signal autorisé', source)

    def test_34_private_root_directories_before_slots(self):
        source = (D / "run_micro.py").read_text()
        self.assertLess(source.index('stat.S_IMODE(p.lstat().st_mode) == 0o700'), source.index('slots.mkdir(mode=0o700)'))

    def test_35_isolated_python_resolves_only_local_contract_first(self):
        tree = ast.parse((D / "run_micro.py").read_text())
        insert = next(n for n in tree.body if isinstance(n, ast.Expr) and isinstance(n.value, ast.Call)
                      and ast.unparse(n.value.func) == "sys.path.insert")
        contract_import = next(n for n in tree.body if isinstance(n, ast.ImportFrom) and n.module == "contract")
        self.assertLess(insert.lineno, contract_import.lineno)
        self.assertEqual(ast.unparse(insert.value), "sys.path.insert(0, str(DEFINITIONS))")


    def test_36_only_receive_minus_one_no_guard_guess(self):
        source = (D / "probe.c").read_text()
        call = "destroyed = mach_port_mod_refs(mach_task_self(), port, MACH_PORT_RIGHT_RECEIVE, -1);"
        self.assertEqual(source.count(call), 1)
        for forbidden in ("mach_port_destruct(", "mach_port_deallocate(", "mach_port_unguard(", "MACH_PORT_RIGHT_SEND", "MACH_PORT_RIGHT_DEAD_NAME"):
            self.assertNotIn(forbidden, source)

    def test_37_same_protective_guard_precedes_drop(self):
        source = (D / "probe.c").read_text()
        block = source.split("static bool outcome(", 1)[1].split("static int probe(", 1)[0]
        guard = "if (receive && port != bootstrap_port && port != mach_task_self()) {"
        call = "destroyed = mach_port_mod_refs(mach_task_self(), port, MACH_PORT_RIGHT_RECEIVE, -1);"
        self.assertEqual(block.count(guard), 1)
        self.assertEqual(block.count(call), 1)
        self.assertLess(block.index(guard), block.index(call))
        self.assertLess(block.index(call), block.index("after_code = mach_port_type(mach_task_self(), port, &after);"))
        self.assertIn("clean = destroyed == KERN_SUCCESS && after_code == KERN_INVALID_NAME;", block)

    def test_38_c_reconstructed_preimage_diff_is_single_call(self):
        old = (D / "preimages/probe-before-api.c").read_text()
        new = (D / "probe.c").read_text()
        before = "destroyed = mach_port_destroy(mach_task_self(), port);"
        after = "destroyed = mach_port_mod_refs(mach_task_self(), port, MACH_PORT_RIGHT_RECEIVE, -1);"
        self.assertEqual(old.count(before), 1)
        self.assertEqual(new, old.replace(before, after))
        self.assertEqual(old, new.replace(after, before))

    def test_39_residual_name_and_api_errors_stay_red(self):
        for code in (0, 5, 17):
            with self.subTest(after_type=code):
                self.reject("after_destroy_type_code", code)
        for code in (4, 17):
            with self.subTest(cleanup_code=code):
                self.reject("destroy_code", code)

    def test_40_pure_oracle_module_unchanged(self):
        self.assertEqual(
            hashlib.sha256((D / "contract.py").read_bytes()).hexdigest(),
            "655461bf0e940943a6791c1a7f364f3bb418ea94e5cbcc032ef5428b32cd671e",
        )
        self.assertEqual(
            hashlib.sha256((D / "run_micro.py").read_bytes()).hexdigest(),
            "bdd1efe42cdeb49f9a9c3aef960ca748b2131d8532c20544d98a066e264fdfad",
        )


if __name__ == "__main__":
    unittest.main()
