/* Sonde autonome libSystem/libproc. Compilation et exécution réservées à MAIN. */
#include <errno.h>
#include <fcntl.h>
#include <libproc.h>
#include <limits.h>
#include <mach/mach.h>
#include <servers/bootstrap.h>
#include <signal.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/proc_info.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

#define PREFIX "com.google.Chrome.MachPortRendezvousServer."

static void die(const char *message) { fprintf(stderr, "instrument: %s\n", message); exit(73); }
static double monotonic_now(void) {
    struct timespec ts;
    if (clock_gettime(CLOCK_MONOTONIC, &ts) != 0) die("clock_gettime");
    return (double)ts.tv_sec + (double)ts.tv_nsec / 1000000000.0;
}
static uint64_t number(const char *s) {
    char *end = NULL; errno = 0;
    if (!s[0] || strspn(s, "0123456789") != strlen(s)) die("decimal");
    unsigned long long n = strtoull(s, &end, 10);
    if (errno || !end || *end) die("decimal range");
    return (uint64_t)n;
}
static struct proc_bsdinfo birth(pid_t pid) {
    struct proc_bsdinfo info; memset(&info, 0, sizeof(info)); errno = 0;
    int count = proc_pidinfo(pid, PROC_PIDTBSDINFO, 0, &info, (int)sizeof(info));
    if (count != (int)sizeof(info) || info.pbi_pid != (uint32_t)pid || info.pbi_start_tvsec == 0)
        die("birth unavailable, never treated as absence");
    return info;
}
static void exclusive_publication(const char *path, const char *text) {
    char pending[PATH_MAX]; if (snprintf(pending, sizeof(pending), "%s.pending", path) >= (int)sizeof(pending)) die("pending path");
    int fd = open(pending, O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW, 0600);
    if (fd < 0) die("pending exclusive");
    size_t length = strlen(text), offset = 0;
    while (offset < length) { ssize_t n = write(fd, text + offset, length - offset); if (n <= 0) { close(fd); die("write"); } offset += (size_t)n; }
    if (fsync(fd) != 0) { close(fd); die("fsync"); }
    if (close(fd) != 0 || link(pending, path) != 0) die("closed publication");
}
static void path(char *out, size_t size, const char *root, const char *suffix) {
    if (snprintf(out, size, "%s/%s", root, suffix) >= (int)size) die("path size");
}
static int gate(int argc, char **argv) {
    if (argc != 7) die("gate argc");
    if (signal(SIGALRM, SIG_DFL) == SIG_ERR) die("gate alarm handler");
    alarm(5); /* Auto-exit de la seule tâche même avant le rendez-vous. */
    const char *root = argv[2], *mode = argv[3], *nonce = argv[4];
    const char *root_prefix = "/private/tmp/therese-c17-mach-register-canary-";
    if (strncmp(root, root_prefix, strlen(root_prefix)) || strlen(root + strlen(root_prefix)) != 32
        || strspn(root + strlen(root_prefix), "0123456789abcdef") != 32
        || strlen(nonce) != 32 || strspn(nonce, "0123456789abcdef") != 32
        || (strcmp(mode, "baseline") && strcmp(mode, "candidate"))) die("root/mode/nonce fermé");
    char canonical[PATH_MAX];
    if (!realpath(root, canonical) || strcmp(root, canonical)) die("root canonical");
    pid_t parent = getppid(); uid_t uid = getuid(); pid_t pid = getpid();
    if (number(argv[5]) != (uint64_t)parent || number(argv[6]) != (uint64_t)uid || getpgrp() != pid) die("parent/UID/PGID");
    struct proc_bsdinfo me = birth(pid), owner = birth(parent);
    if (me.pbi_ppid != (uint32_t)parent || me.pbi_uid != uid || me.pbi_pgid != (uint32_t)pid || owner.pbi_uid != uid) die("birth parent");
    char ready[PATH_MAX], release[PATH_MAX], buffer[2048], expected[2048];
    snprintf(buffer, sizeof(buffer), "{\"schema\":\"c17-mach-register-gate-ready-v1\",\"mode\":\"%s\",\"nonce\":\"%s\",\"pid\":%d,\"ppid\":%d,\"uid\":%u,\"pgid\":%d,\"start_sec\":%llu,\"start_usec\":%llu,\"parent_start_sec\":%llu,\"parent_start_usec\":%llu}\n", mode, nonce, pid, parent, uid, getpgrp(), (unsigned long long)me.pbi_start_tvsec, (unsigned long long)me.pbi_start_tvusec, (unsigned long long)owner.pbi_start_tvsec, (unsigned long long)owner.pbi_start_tvusec);
    char slot[128]; snprintf(slot, sizeof(slot), "auxiliary/probe/slots/%s/ready.json", mode); path(ready, sizeof(ready), root, slot);
    snprintf(slot, sizeof(slot), "auxiliary/probe/slots/%s/release.txt", mode); path(release, sizeof(release), root, slot);
    exclusive_publication(ready, buffer);
    snprintf(expected, sizeof(expected), "C17-MACH-RELEASE-1\nnonce=%s\nmode=%s\npid=%d\nppid=%d\nuid=%u\npgid=%d\nstart_sec=%llu\nstart_usec=%llu\nparent_start_sec=%llu\nparent_start_usec=%llu\nservice=" PREFIX "%d\n", nonce, mode, pid, parent, uid, getpgrp(), (unsigned long long)me.pbi_start_tvsec, (unsigned long long)me.pbi_start_tvusec, (unsigned long long)owner.pbi_start_tvsec, (unsigned long long)owner.pbi_start_tvusec, pid);
    double expires = monotonic_now() + 3.0;
    bool released = false;
    while (monotonic_now() < expires) {
        int fd = open(release, O_RDONLY | O_NOFOLLOW);
        if (fd >= 0) {
            struct stat st; if (fstat(fd, &st) != 0 || !S_ISREG(st.st_mode) || st.st_uid != uid || st.st_nlink != 2 || st.st_size != (off_t)strlen(expected)) { close(fd); die("release inode/type/owner/size"); }
            ssize_t n = read(fd, buffer, sizeof(buffer) - 1); close(fd);
            if (n != (ssize_t)strlen(expected)) die("release length");
            buffer[n] = '\0';
            if (strcmp(buffer, expected) || monotonic_now() >= expires) die("release payload/deadline");
            released = true; break;
        }
        if (errno != ENOENT) die("release refusal");
        struct timespec wait = {0, 10000000}; nanosleep(&wait, NULL);
    }
    if (!released) die("gate timeout auto-exit");
    struct proc_bsdinfo again = birth(pid), parent_again = birth(parent);
    if (again.pbi_pid != me.pbi_pid || again.pbi_ppid != me.pbi_ppid || again.pbi_uid != me.pbi_uid
        || again.pbi_pgid != me.pbi_pgid || again.pbi_start_tvsec != me.pbi_start_tvsec
        || again.pbi_start_tvusec != me.pbi_start_tvusec || parent_again.pbi_start_tvsec != owner.pbi_start_tvsec
        || parent_again.pbi_start_tvusec != owner.pbi_start_tvusec || parent_again.pbi_uid != owner.pbi_uid
        || parent_again.pbi_pid != owner.pbi_pid || parent_again.pbi_ppid != owner.pbi_ppid
        || parent_again.pbi_pgid != owner.pbi_pgid) die("birth changed");
    char folder[PATH_MAX], home[PATH_MAX], temp[PATH_MAX], auxparent[PATH_MAX], profile[PATH_MAX], binary[PATH_MAX];
    path(folder, sizeof(folder), root, "auxiliary/probe"); path(home, sizeof(home), root, "auxiliary/probe/home");
    path(temp, sizeof(temp), root, "auxiliary/probe/tmp"); path(auxparent, sizeof(auxparent), root, "auxiliary");
    path(profile, sizeof(profile), root, !strcmp(mode, "baseline") ? "definitions/chrome14.sb" : "definitions/candidate.sb");
    path(binary, sizeof(binary), root, "auxiliary/probe/mach-probe");
    if (!realpath(argv[0], canonical) || strcmp(canonical, binary)) die("own binary canonical");
    char af[PATH_MAX+32], hf[PATH_MAX+32], tf[PATH_MAX+32], ap[PATH_MAX+32], qr[PATH_MAX+32], service[160];
    snprintf(af, sizeof(af), "AUXILIARY_ROOT=%s", folder); snprintf(hf, sizeof(hf), "HOME_ROOT=%s", home);
    snprintf(tf, sizeof(tf), "TMP_ROOT=%s", temp); snprintf(ap, sizeof(ap), "AUXILIARY_PARENT=%s", auxparent);
    snprintf(qr, sizeof(qr), "QA_ROOT=%s", root); snprintf(service, sizeof(service), "OWN_RENDEZVOUS_SERVICE=" PREFIX "%d", pid);
    char pids[24], parents[24], uids[24], pgids[24], sec[24], usec[24];
    snprintf(pids, sizeof(pids), "%d", pid); snprintf(parents, sizeof(parents), "%d", parent); snprintf(uids, sizeof(uids), "%u", uid); snprintf(pgids, sizeof(pgids), "%d", pid);
    snprintf(sec, sizeof(sec), "%llu", (unsigned long long)me.pbi_start_tvsec); snprintf(usec, sizeof(usec), "%llu", (unsigned long long)me.pbi_start_tvusec);
    char *args[40]; int i=0; args[i++]="/usr/bin/sandbox-exec"; args[i++]="-D"; args[i++]=af; args[i++]="-D"; args[i++]=hf; args[i++]="-D"; args[i++]=tf; args[i++]="-D"; args[i++]=ap; args[i++]="-D"; args[i++]=qr;
    if (!strcmp(mode, "candidate")) { args[i++]="-D"; args[i++]=service; }
    args[i++]="-f"; args[i++]=profile; args[i++]=binary; args[i++]="probe"; args[i++]=(char *)mode; args[i++]=pids; args[i++]=parents; args[i++]=uids; args[i++]=pgids; args[i++]=sec; args[i++]=usec; args[i]=NULL;
    /* L'alarme garde reste active à travers exec; la sonde la remplace par2s. */
    execv(args[0], args);
    die("exec sandbox-exec");
    return 73;
}
static bool outcome(const char *label, const char *name) {
    mach_port_t port = MACH_PORT_NULL; mach_port_type_t type = 0, after = 0;
    kern_return_t code = bootstrap_check_in(bootstrap_port, name, &port);
    bool valid = MACH_PORT_VALID(port), receive = false, clean = true;
    kern_return_t typed = -1, destroyed = -1, after_code = -1;
    if (valid) {
        typed = mach_port_type(mach_task_self(), port, &type); receive = typed == KERN_SUCCESS && (type & MACH_PORT_TYPE_RECEIVE) != 0;
        if (receive && port != bootstrap_port && port != mach_task_self()) {
            destroyed = mach_port_mod_refs(mach_task_self(), port, MACH_PORT_RIGHT_RECEIVE, -1);
            after_code = mach_port_type(mach_task_self(), port, &after);
        }
        clean = destroyed == KERN_SUCCESS && after_code == KERN_INVALID_NAME;
    }
    printf("{\"label\":\"%s\",\"name\":\"%s\",\"bootstrap_code\":%d,\"port_value\":%u,\"port_valid\":%s,\"receive_right\":%s,\"type_code\":", label, name, code, port, valid ? "true":"false", receive ? "true":"false");
    if (valid) printf("%d,\"destroy_code\":%d,\"after_destroy_type_code\":%d}", typed, destroyed, after_code);
    else printf("null,\"destroy_code\":null,\"after_destroy_type_code\":null}");
    return clean;
}
static int probe(int argc, char **argv) {
    if (argc != 9 || (strcmp(argv[2], "baseline") && strcmp(argv[2], "candidate"))) die("probe argc/mode");
    if (number(argv[3]) != (uint64_t)getpid() || number(argv[4]) != (uint64_t)getppid()
        || number(argv[5]) != getuid() || number(argv[6]) != (uint64_t)getpgrp()) die("probe identity");
    /* Un blocage MIG doit tuer cette seule tâche, jamais être qualifié comme refus. */
    if (signal(SIGALRM, SIG_DFL) == SIG_ERR) die("probe alarm handler");
    alarm(2);
    char own[128], other[128], suffix[128];
    snprintf(own, sizeof(own), PREFIX "%d", getpid()); snprintf(other, sizeof(other), PREFIX "%d", getppid());
    snprintf(suffix, sizeof(suffix), PREFIX "%d.c17-denied", getpid());
    printf("{\"schema\":\"c17-mach-register-probe-raw-v1\",\"mode\":\"%s\",\"pid\":%d,\"ppid\":%d,\"uid\":%u,\"pgid\":%d,\"start_sec\":%llu,\"start_usec\":%llu,\"outcomes\":[", argv[2], getpid(), getppid(), getuid(), getpgrp(), (unsigned long long)number(argv[7]), (unsigned long long)number(argv[8]));
    bool clean = outcome("own", own);
    if (!strcmp(argv[2], "candidate")) { printf(","); clean = outcome("other_pid", other) && clean; printf(","); clean = outcome("suffix", suffix) && clean; }
    printf("]}\n"); int flush = fflush(stdout); alarm(0);
    if (flush != 0 || !clean) return 73;
    return 0;
}
int main(int argc, char **argv) {
    if (argc < 2) die("mode absent");
    if (!strcmp(argv[1], "gate")) return gate(argc, argv);
    if (!strcmp(argv[1], "probe")) return probe(argc, argv);
    die("mode inconnu"); return 73;
}
