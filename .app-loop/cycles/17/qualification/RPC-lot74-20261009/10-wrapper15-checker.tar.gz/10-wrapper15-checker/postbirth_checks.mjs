// Validation de données seulement. Aucun accès FS, process, socket ou G1.
const need=(ok,why)=>{if(!ok)throw Error(why);};
const ROOT='/private/tmp/therese-c17-wrapper-canary-9c1f04187dd24519b220372284a739c9';
const QA='/private/tmp/therese-c17-wrapper-source-kGvU1hdx/source';
const CHROME='/private/tmp/therese-c17-chrome-qa-copy-RoZmwsja/Google Chrome.app/Contents/MacOS/Google Chrome';
export const JOBS=Object.freeze(['rpc-all-runtime_ui-visual_capture-network_capture',
  'rpc-screen-negative','rpc-screen-positive-visual','rpc-screen-positive-network','rpc-screen-restored']);
const fields=['pid','start_sec','start_usec','ppid','uid','pgid'];
export function equal(a,b){
  if(a===b)return true;
  if(Array.isArray(a)||Array.isArray(b))return Array.isArray(a)&&Array.isArray(b)
    &&a.length===b.length&&a.every((x,i)=>equal(x,b[i]));
  if(a&&b&&typeof a==='object'&&typeof b==='object'){
    const left=Object.keys(a).sort(),right=Object.keys(b).sort();
    return equal(left,right)&&left.every(k=>equal(a[k],b[k]));
  }
  return false;
}
// Deux sections de diff fermées, sans fuzz ni suppression de contexte.
export function applyExactUnifiedSections(diff, sections){
  need(typeof diff==='string'&&Array.isArray(sections)&&sections.length===2,'Deux sections exactes requises');
  const lines=diff.match(/[^\n]*\n|[^\n]+$/g)||[];
  let cursor=0;
  const outputs=[];
  for(const section of sections){
    need(lines[cursor++]==='--- '+section.from+'\n'&&lines[cursor++]==='+++ '+section.to+'\n',
      'Headers diff inconnus/ordre divergent');
    const old=section.before.match(/[^\n]*\n|[^\n]+$/g)||[],out=[];
    let oldAt=0,hunks=0;
    while(cursor<lines.length&&!lines[cursor].startsWith('--- ')){
      const h=/^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@[^\n]*\n$/.exec(lines[cursor++]);
      need(h,'Hunk diff mal formé');
      const pos=Number(h[1])===0?0:Number(h[1])-1,oc=h[2]===undefined?1:Number(h[2]);
      const np=Number(h[3])===0?0:Number(h[3])-1,nc=h[4]===undefined?1:Number(h[4]);
      need(pos>=oldAt&&pos<=old.length,'Position diff hors préimage');
      out.push(...old.slice(oldAt,pos));oldAt=pos;
      need(out.length===np,'Position nouvelle diff divergente');
      let consumed=0,added=0;
      while(cursor<lines.length&&!lines[cursor].startsWith('@@ ')
        &&!lines[cursor].startsWith('--- ')){
        const line=lines[cursor++],tag=line[0],body=line.slice(1);
        need([' ','-','+'].includes(tag),'Ligne diff non admise');
        if(tag!=='+' ){need(old[oldAt]===body,'Préimage/contexte diff différent');oldAt++;consumed++;}
        if(tag!=='-'){out.push(body);added++;}
      }
      need(consumed===oc&&added===nc,'Cardinalité hunk divergente');hunks++;
    }
    need(hunks>0,'Section diff vide');out.push(...old.slice(oldAt));outputs.push(out.join(''));
  }
  need(cursor===lines.length,'Section diff supplémentaire');
  return outputs;
}
export function validateExecutionMode(files,postBirth){
  need(Array.isArray(files)&&typeof postBirth==='boolean','Mode/fichiers invalides');
  const native=['binding.json','decision.json','runtime/readiness.json','runtime/pile-reprise.json',
    'runtime/services-running.json','wrapper-canary-result.json'];
  if(!postBirth)need(!native.some(n=>files.includes(n)),'État natif prématuré : préflight strict');
  else need(['binding.json','decision.json','wrapper-canary-result.json'].every(n=>files.includes(n)),
    'Post-birth exige binding/décision/résultat physiques');
  return postBirth?'post_birth_structural_only':'preflight_prepared_only';
}
const birth=x=>x&&fields.every(k=>Number.isSafeInteger(x[k]))&&x.pid>0&&x.start_sec>0
  &&x.start_usec>=0&&x.start_usec<1000000&&x.ppid>0&&x.uid===501&&x.pgid>0;
const sameBirth=(a,b)=>birth(a)&&birth(b)&&fields.every(k=>a[k]===b[k]);
export function chromeTemplate(root,name,spec){
  need(root===ROOT&&JOBS.some(j=>name==='aux-chrome-'+j),'ROOT/stage Chrome inconnu');
  need(spec&&spec.mode==='chrome'&&spec.role==='auxiliary-'+name&&spec.timeout_seconds===50
    &&spec.combine_stderr===false&&spec.cwd===root&&Array.isArray(spec.argv)&&spec.argv[0]===CHROME
    &&spec.env&&spec.env.HOME===root+'/auxiliary/'+name+'/home'
    &&spec.env.CFFIXED_USER_HOME===spec.env.HOME&&spec.env.TMPDIR===root+'/auxiliary/'+name+'/tmp'
    &&spec.env.MAC_CHROMIUM_TMPDIR===spec.env.TMPDIR
    &&!Object.hasOwn(spec.env,'OWN_RENDEZVOUS_SERVICE'),'Spec Chrome non préliée exacte');
  need(spec.argv.every(x=>typeof x==='string'&&x.length>0&&!x.includes('\0')
    &&!x.includes('OWN_RENDEZVOUS_SERVICE')),'Paramètre pré-birth/argv libre interdit');
  return ['/usr/bin/sandbox-exec','-D','AUXILIARY_ROOT='+root+'/auxiliary/'+name,
    '-D','HOME_ROOT='+spec.env.HOME,'-D','TMP_ROOT='+spec.env.TMPDIR,
    '-D','AUXILIARY_PARENT='+root+'/auxiliary','-D','QA_ROOT='+root,
    '-D','SOURCE_ROOT='+QA,'-D','PREPARATION_ROOT='+root+'/g1',
    '-D','NODE_ROOT=/Users/synoptia/.nvm/versions/node/v22.19.0',
    '-D','PYTHON_ROOT=/Users/synoptia/.local/share/uv/python/cpython-3.13.5-macos-aarch64-none',
    '-f',root+'/g1/chrome.sb',...spec.argv];
}
export function validatePostBirthBundle(x){
  const {root,head,bindingSHA,decisionID,job,row,bindingSpec,raw,gate,release,start=null,stop=null,closure=null}=x;
  need(root===ROOT&&head==='2d69e30c9c6dd18823ee6102271876003a6a67cc'
    &&JOBS.includes(job)&&/^[a-f0-9]{64}$/.test(bindingSHA)&&typeof decisionID==='string'&&decisionID,
    'Contexte post-birth inconnu');
  const name='aux-chrome-'+job,role='auxiliary-'+name;
  need(row?.name===name&&row.job===job&&row.role===role&&row.port===17594&&row.deadline===50
    &&row.profile===root+'/auxiliary/'+name+'/profile'&&row.executable===CHROME
    &&equal(row.argv,bindingSpec.argv)&&equal(row.env,bindingSpec.env)
    &&row.cwd===bindingSpec.cwd&&row.stdout===bindingSpec.stdout_path&&row.stderr===bindingSpec.stderr_path,
    'Descriptor/prebinding Chrome divergent');
  const template=chromeTemplate(root,name,bindingSpec),id=raw?.root_identity,owner=raw?.owner;
  need(birth(id)&&birth(owner)&&id.pgid===id.pid&&id.ppid===owner.pid&&id.uid===owner.uid
    &&id.role===role&&id.attribution==='popen_child_before_workload'
    &&equal(id.parent_birth,[owner.pid,owner.start_sec,owner.start_usec]),'Naissance/owner non réellement jointe');
  need(Array.isArray(raw.attributed)&&raw.attributed.filter(r=>sameBirth(r,id)).length===1
    &&raw.attributed.some(r=>equal(r,id)),'Naissance absente/double/divergente du ledger');
  need(raw.name===name&&raw.stage_id===name&&raw.role===role&&raw.mode==='chrome'
    &&raw.actor==='/root'&&raw.round_id===root.split('/').at(-1)&&raw.qa_root===root&&raw.head===head
    &&raw.round_name==='WRAPPER_CANARY'&&raw.execution_scope==='g1_rpc_real_instrument_wrappers_canary_only'
    &&raw.launch_attempted===true&&raw.released===true&&sameBirth(id,raw.verified_before_release)
    &&raw.timeout_seconds===50&&raw.deadline_scope==='startup_admission_only_not_service_lifetime',
    'Entry/raw sans naissance libérée ou autre scope');
  const at=template.indexOf('-f');
  const effective=[...template.slice(0,at),'-D',
    'OWN_RENDEZVOUS_SERVICE=com.google.Chrome.MachPortRendezvousServer.'+id.pid,...template.slice(at)];
  need(equal(raw.command,template)&&equal(raw.workload_command,bindingSpec.argv)&&equal(raw.argv,bindingSpec.argv)
    &&equal(raw.effective_command,effective)
    &&equal(raw.launch_command,[QA+'/.venv-conforme/bin/python','-I','-B',root+'/g1/runtime_launch_gate.py',
      root+'/ledger/'+name+'/gate.json',...template]),'Template/argv effectif/launch altéré');
  need(gate?.pid===id.pid&&gate.ppid===id.ppid&&gate.uid===id.uid&&gate.pgid===id.pgid
    &&equal(gate.command,template)&&gate.qa_root===root&&gate.actor==='/root'
    &&gate.round_id===raw.round_id&&gate.head===head&&gate.stage===name
    &&gate.decision_id===decisionID&&gate.binding_sha256===bindingSHA
    &&gate.publication_protocol==='exclusive-pending-fsync-hardlink-v1','Gate autre naissance/template/contexte');
  need(release&&Object.keys(release).sort().join(',')===
    'command_template,effective_command,gate,identity,mode,publication_protocol,stage,verified_before_release'
    &&release.publication_protocol===gate.publication_protocol&&equal(release.gate,gate)
    &&equal(release.identity,id)&&sameBirth(release.verified_before_release,id)
    &&equal(release.verified_before_release,raw.verified_before_release)
    &&release.mode==='chrome'&&release.stage===name&&equal(release.command_template,template)
    &&equal(release.effective_command,effective),'Release effective non exacte/naissance divergente');
  need(raw.stdout_path===bindingSpec.stdout_path&&raw.stderr_path===bindingSpec.stderr_path
    &&raw.stdout_path!==raw.stderr_path&&raw.environment
    &&Object.entries(bindingSpec.env).every(([k,v])=>raw.environment[k]===v)
    &&!Object.hasOwn(raw.environment,'OWN_RENDEZVOUS_SERVICE'),'Sinks/env effectifs divergents');
  const extras={QA_ROOT:root,C17_RUNTIME_MODULE_DIR:root+'/g1',C17_SESSION_ACTOR:'/root',
    C17_SESSION_ROUND_ID:raw.round_id,C17_SESSION_HEAD:head,C17_SESSION_STAGE:name,
    C17_SESSION_ROOT:root,C17_SESSION_EVENTS:root+'/session-events',C17_SESSION_DECISION_ID:decisionID,
    C17_SESSION_BINDING_SHA256:bindingSHA,C17_SESSION_ROUND_NAME:'WRAPPER_CANARY'};
  need(equal(Object.keys(raw.environment).sort(),[...Object.keys(bindingSpec.env),...Object.keys(extras),
    'C17_SESSION_DECISION_REF','C17_SESSION_BINDING_REF','C17_SESSION_OUTER_DEADLINE_MONOTONIC'].sort())
    &&Object.entries(extras).every(([k,v])=>raw.environment[k]===v)
    &&equal(JSON.parse(raw.environment.C17_SESSION_DECISION_REF),raw.admission)
    &&equal(JSON.parse(raw.environment.C17_SESSION_BINDING_REF),raw.binding)
    &&raw.binding.sha256===bindingSHA&&raw.admission.path===root+'/decision.json'
    &&raw.binding.path===root+'/binding.json'
    &&Number.isFinite(raw.started_monotonic)&&raw.started_monotonic>0
    &&raw.outer_deadline_monotonic===raw.started_monotonic+50
    &&Number(raw.environment.C17_SESSION_OUTER_DEADLINE_MONOTONIC)===raw.outer_deadline_monotonic,
    'Environment complet/deadline/admission divergents');
  need(raw.termination_proved===true&&raw.output_archived===true
    &&Array.isArray(raw.output_archive_errors)&&raw.output_archive_errors.length===0
    &&raw.cleanup&&raw.cleanup.remaining_attributed?.length===0
    &&raw.cleanup.ambiguities?.length===0&&raw.cleanup.errors?.length===0
    &&raw.cleanup_deadline_met===true&&Number.isFinite(raw.cleanup_elapsed_seconds)
    &&raw.cleanup_elapsed_seconds>=0&&raw.cleanup_elapsed_seconds<=8,
    'Brut Chrome sans terminaison/archivage/nettoyage borné');
  for(const [kind,record] of [['start',start],['stop',stop],['closure',closure]]){
    if(record===null)continue;
    need(record.actor==='/root'&&record.round_id===raw.round_id&&record.head===head
      &&record.binding_sha256===bindingSHA&&equal(record.root_identity,id)
      &&equal(record.command_template,template)&&equal(record.effective_command,effective),
      'Reçu '+kind+' template/argv effectif/birth divergent');
  }
  need(closure===null||(start!==null&&stop!==null&&closure.job===job&&closure.scope==='WRAPPER_CANARY'),
    'Closure sans deux reçus joints');
  return {job,name,identity:id,template_preserved:true,effective_command_verified:true,
    OWN_RENDEZVOUS_SERVICE:'com.google.Chrome.MachPortRendezvousServer.'+id.pid,
    start_present:start!==null,stop_present:stop!==null,closure_present:closure!==null,
    proof_scope:'post_birth_structural_only',native_pass_claimed:false,FULL:false};
}
export function preserveNativeOutcome(result,session){
  need(result?.schema==='c17-wrapper-canary-instrument-result-v1'&&result.scope==='WRAPPER_CANARY'
    &&result.qa_root===ROOT&&result.head==='2d69e30c9c6dd18823ee6102271876003a6a67cc'
    &&result.actor==='/root'&&result.FULL===false&&result.round_A_or_B===false&&result.density_or_78===false
    &&typeof result.passed==='boolean'&&typeof result.owned_shutdown_proved==='boolean'
    &&session?.qa_root===ROOT&&typeof session.clean==='boolean'
    &&typeof session.log_stability_tainted==='boolean','Résultat/fermeture post-birth inconnus');
  return {recorded_native_passed:result.passed,recorded_owned_shutdown_proved:result.owned_shutdown_proved,
    recorded_global_clean:session.clean,recorded_global_taint:session.log_stability_tainted,
    recorded_runner_exit:result.runner_exit,classification:result.classification,
    native_qualification_claimed:false,FULL:false,release:false};
}
