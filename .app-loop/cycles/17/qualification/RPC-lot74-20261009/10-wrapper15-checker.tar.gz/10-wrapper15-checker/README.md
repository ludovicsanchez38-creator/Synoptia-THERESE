# Checker indépendant WRAPPER15

Acteur : /root/shared4_execution.
Périmètre : préparation du checker et tests purs. ROOT15 a été construite par MAIN, pas par cet auteur. Aucun checker complet, constructeur, G1, Chrome, profil Apple ou service n'a été exécuté par ce lot.

## Commandes réservées à MAIN après lecture et pins

Préflight strict, avant tout natif :
`/Users/synoptia/.nvm/versions/node/v22.19.0/bin/node /private/tmp/therese-c17-wrapper15-static-controls-3q3erZ/verify-prepared-wrapper15.mjs /private/tmp/therese-c17-wrapper-canary-9c1f04187dd24519b220372284a739c9`

Relecture distincte, seulement après fin réelle avec résultat et fermeture Session :
`/Users/synoptia/.nvm/versions/node/v22.19.0/bin/node /private/tmp/therese-c17-wrapper15-static-controls-3q3erZ/verify-prepared-wrapper15.mjs /private/tmp/therese-c17-wrapper-canary-9c1f04187dd24519b220372284a739c9 --post-birth`

Le préflight refuse binding/décision/readiness/résultat natifs, y compris leurs chemins présents par lstat. --post-birth est explicite ; il exige résultat, binding, décision et reçu Session clos. Aucun mode ne consomme un GO natif.

## Dérivation exacte

Préimage checker14 : 20d143335b8795adc2a0ffd587a3b9865704b793f644564aee2c68c5556b2ec6, 37787 octets. Les diff direct/inverse sont complets.
Six pointeurs historiques WRAPPER14 before/after restent byte-identiques avec leurs deux origines et trois snapshots. Deux pointeurs supplémentaires, uniquement source_before/3 et source_after/3 du premier rouge15 87d194cb…, vérifient la préimage exacte du test38. Aucune exemption générique ni ancien résultat changé.

Le checker compare l'intégralité G1 à la preview15 pinnée, avec le seul slot WRAPPER exact, et le gate à sa preview byte-exacte. Les deux préimages physiques et le premier diff comprenant G1 puis gate sont reconstruits sans fuzz. La chaîne du profil reste contrôlée ; seul ajout15 : mach-register global-name param OWN_RENDEZVOUS_SERVICE, profil1684af7c…/2568 octets. Les sources79, core18, overlay28/19, base11, SQL36, Git3579, cinq jobs, ports et 5/50/8 restent vérifiés. HEAD canari2d69 reste historique ; documentaire91e0 et source FULL fraîche ne sont pas assimilés.

## Preuves post-naissance

Les cinq noms autorisés sont parcourus, mais seuls les Chrome réellement enregistrés produisent une preuve. Une gate/release sans brut, ou une birth enregistrée sans release exacte, est refusée. Aucune cinquième naissance fictive n'est exigée sur un rouge. Les vrais liens gate/pending et release/pending doivent partager dev/inode avec nlink2 et UID501. Les birth/owner/rechecks, template, paramètre PID unique, argv effectif, environnement complet, sinks et bruts sont recroisés. Les start/stop/closure présents sont joints. Un rouge CDP peut n'avoir aucun start/closure : il reste uniquement structurel. Une birth non libérée ne peut pas passer ce mode.

Les valeurs result.passed, owned_shutdown_proved, Session.clean et taint sont rendues inchangées. Aucun verdict structurel ne constitue un PASS natif, une admission A/B, FULL ou release. Un résultat vert déclaré sans cinq closures réelles est refusé.

## Tests observés

Commande pure :
`env -i PATH=/usr/bin:/bin HOME=/private/tmp/therese-c17-wrapper15-static-controls-3q3erZ TMPDIR=/private/tmp/therese-c17-wrapper15-static-controls-3q3erZ C17_ACTOR=/root/shared4_execution /Users/synoptia/.nvm/versions/node/v22.19.0/bin/node /private/tmp/therese-c17-wrapper15-static-controls-3q3erZ/tests/test_checker15.mjs`

Premier retour2aa466 : 43 tests, 1 échec, sameRef manquant dans le double VM, pas un défaut G1 ni une calibration. Préimage test et sortie retournée conservées.
Retour5465a0 : 52 tests, zéro échec, intermédiaire conservé avec ses deux snapshots exacts.
Retourc0490c : 53 tests, zéro échec/erreur/saut, 3 pins before/after inchangés. Le vrai collect et le vrai corps post-birth ont tourné dans une FS double explicitement synthétique. Un contrôle lit cinq textes de définition physiques ROOT15 et reconstruit G1+gate sans import. Ce n'est ni une scan OS ni une exécution du checker complet.
Les logs sont des textes retournés par l'outil, pas des sinks stdout/stderr directs. Aucun flux manquant n'est inventé.
