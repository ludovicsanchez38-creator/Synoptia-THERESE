import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
import vm from 'node:vm';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {JOBS,equal,chromeTemplate,validatePostBirthBundle,preserveNativeOutcome,
  applyExactUnifiedSections,validateExecutionMode} from '../postbirth_checks.mjs';

// Fixtures de données explicitement synthétiques, aucun PID/kernel/signal réel.
const HERE=path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const ROOT='/private/tmp/therese-c17-wrapper-canary-9c1f04187dd24519b220372284a739c9';
const QA='/private/tmp/therese-c17-wrapper-source-kGvU1hdx/source';
const HEAD='2d69e30c9c6dd18823ee6102271876003a6a67cc';
const clone=x=>JSON.parse(JSON.stringify(x));
const tests=[];
function test(name,fn){tests.push([name,fn]);}
function fixture(){
  const job=JOBS[0],name='aux-chrome-'+job,role='auxiliary-'+name,folder=ROOT+'/auxiliary/'+name;
  const argv=['/private/tmp/therese-c17-chrome-qa-copy-RoZmwsja/Google Chrome.app/Contents/MacOS/Google Chrome',
    '--user-data-dir='+folder+'/profile','--remote-debugging-port=17594','--remote-debugging-address=127.0.0.1'];
  const env={HOME:folder+'/home',CFFIXED_USER_HOME:folder+'/home',TMPDIR:folder+'/tmp',MAC_CHROMIUM_TMPDIR:folder+'/tmp'};
  const spec={argv,env,cwd:ROOT,role,mode:'chrome',timeout_seconds:50,combine_stderr:false,
    stdout_path:folder+'/stdout.log',stderr_path:folder+'/stderr.log'};
  const row={name,role,job,executable:argv[0],argv,env,cwd:ROOT,port:17594,deadline:50,
    profile:folder+'/profile',stdout:spec.stdout_path,stderr:spec.stderr_path,
    start_path:folder+'/start.json',stop_path:folder+'/stop.json'};
  const owner={pid:500,start_sec:1000,start_usec:100,ppid:1,uid:501,pgid:500};
  const id={pid:501,start_sec:1001,start_usec:200,ppid:500,uid:501,pgid:501,status:2,
    role,parent_birth:[500,1000,100],attribution:'popen_child_before_workload'};
  const template=chromeTemplate(ROOT,name,spec),at=template.indexOf('-f');
  const effective=[...template.slice(0,at),'-D','OWN_RENDEZVOUS_SERVICE=com.google.Chrome.MachPortRendezvousServer.501',...template.slice(at)];
  const bindingSHA='b'.repeat(64),decisionID=ROOT.split('/').at(-1);
  const admission={path:ROOT+'/decision.json',sha256:'d'.repeat(64),bytes:2};
  const binding={path:ROOT+'/binding.json',sha256:bindingSHA,bytes:2};
  const raw={schema:'c17-runtime78-owned-stage-receipt-v1',name,stage_id:name,role,mode:'chrome',
    actor:'/root',round_id:decisionID,qa_root:ROOT,head:HEAD,round_name:'WRAPPER_CANARY',
    execution_scope:'g1_rpc_real_instrument_wrappers_canary_only',root_identity:id,owner,attributed:[id],
    launch_attempted:true,released:true,verified_before_release:clone(id),timeout_seconds:50,
    deadline_scope:'startup_admission_only_not_service_lifetime',command:template,argv,workload_command:argv,
    effective_command:effective,launch_command:[QA+'/.venv-conforme/bin/python','-I','-B',ROOT+'/g1/runtime_launch_gate.py',
      ROOT+'/ledger/'+name+'/gate.json',...template],stdout_path:spec.stdout_path,stderr_path:spec.stderr_path,
    environment:{...env,QA_ROOT:ROOT,C17_RUNTIME_MODULE_DIR:ROOT+'/g1',C17_SESSION_ACTOR:'/root',
      C17_SESSION_ROUND_ID:decisionID,C17_SESSION_HEAD:HEAD,C17_SESSION_STAGE:name,C17_SESSION_ROOT:ROOT,
      C17_SESSION_EVENTS:ROOT+'/session-events',C17_SESSION_DECISION_ID:decisionID,C17_SESSION_BINDING_SHA256:bindingSHA,
      C17_SESSION_ROUND_NAME:'WRAPPER_CANARY',C17_SESSION_DECISION_REF:JSON.stringify(admission),
      C17_SESSION_BINDING_REF:JSON.stringify(binding),C17_SESSION_OUTER_DEADLINE_MONOTONIC:'150'},
    admission,binding,started_monotonic:100,outer_deadline_monotonic:150,termination_proved:true,output_archived:true,
    output_archive_errors:[],cleanup:{remaining_attributed:[],ambiguities:[],errors:[]},cleanup_elapsed_seconds:0.2,
    cleanup_deadline_met:true,cleanup_attempt:1};
  const gate={pid:501,ppid:500,uid:501,pgid:501,command:template,qa_root:ROOT,actor:'/root',
    round_id:decisionID,head:HEAD,stage:name,decision_id:decisionID,binding_sha256:bindingSHA,
    publication_protocol:'exclusive-pending-fsync-hardlink-v1'};
  const release={publication_protocol:gate.publication_protocol,gate:clone(gate),identity:clone(id),mode:'chrome',
    stage:name,command_template:template,effective_command:effective,verified_before_release:clone(id)};
  return {root:ROOT,head:HEAD,bindingSHA,decisionID,job,row,bindingSpec:spec,raw,gate,release};
}
test('fixture synthetic: PID réel non revendiqué, template distinct et dérivé',()=>{
  const x=fixture(),r=validatePostBirthBundle(x);assert.equal(r.native_pass_claimed,false);
  assert.equal(r.OWN_RENDEZVOUS_SERVICE,'com.google.Chrome.MachPortRendezvousServer.501');
  assert.notDeepEqual(x.raw.command,x.raw.effective_command);
});
const mutations=[
  ['mauvais PID effectif',x=>x.raw.effective_command[x.raw.effective_command.indexOf('-f')-1]='OWN_RENDEZVOUS_SERVICE=com.google.Chrome.MachPortRendezvousServer.502'],
  ['paramètre doublé',x=>x.raw.effective_command.splice(x.raw.effective_command.indexOf('-f'),0,'-D','OWN_RENDEZVOUS_SERVICE=com.google.Chrome.MachPortRendezvousServer.501')],
  ['template paramétré avant birth',x=>x.raw.command.splice(x.raw.command.indexOf('-f'),0,'-D','OWN_RENDEZVOUS_SERVICE=x')],
  ['mode SQL',x=>x.raw.mode='sql'],['stage autre',x=>x.raw.stage_id='backend'],
  ['ROOT autre',x=>x.root=ROOT+'x'],['HEAD actuel emprunté',x=>x.head='9'.repeat(40)],
  ['naissance release divergente',x=>x.release.identity.start_usec++],
  ['naissance recheck divergente',x=>x.raw.verified_before_release.start_usec++],
  ['PPID gate différent',x=>x.gate.ppid++],['UID étranger',x=>x.raw.root_identity.uid=0],
  ['PGID autre',x=>x.raw.root_identity.pgid++],['rôle inconnu',x=>x.raw.root_identity.role='persistent-backend'],
  ['sans birth libérée',x=>x.raw.released=false],['birth absente ledger',x=>x.raw.attributed=[]],
  ['birth double ledger',x=>x.raw.attributed.push(clone(x.raw.root_identity))],
  ['borne 51',x=>x.bindingSpec.timeout_seconds=51],['CDP différent',x=>x.row.port=17595],
  ['sink divergent',x=>x.raw.stdout_path+='x'],['clé libre dans release',x=>x.release.extra=true],
  ['env supplémentaire',x=>x.raw.environment.UNKNOWN='1'],['OWN dans env',x=>x.raw.environment.OWN_RENDEZVOUS_SERVICE='x'],
  ['deadline effective différente',x=>x.raw.environment.C17_SESSION_OUTER_DEADLINE_MONOTONIC='151'],
  ['gate contexte différent',x=>x.gate.binding_sha256='0'.repeat(64)],
  ['launch gate argv différent',x=>x.raw.launch_command[2]='-S'],
  ['cleanup non terminé',x=>x.raw.termination_proved=false],['FD non archivé',x=>x.raw.output_archived=false],
  ['cleanup 8s dépassé',x=>x.raw.cleanup_elapsed_seconds=8.01],['cleanup ambigu',x=>x.raw.cleanup.ambiguities=['x']],
];
for(const [name,mutate] of mutations)test('refus '+name,()=>{const x=fixture();mutate(x);assert.throws(()=>validatePostBirthBundle(x));});
test('start/stop/closure présents conservent le même template et birth',()=>{
  const x=fixture(),record={actor:'/root',round_id:x.raw.round_id,head:HEAD,binding_sha256:x.bindingSHA,
    root_identity:clone(x.raw.root_identity),command_template:clone(x.raw.command),effective_command:clone(x.raw.effective_command)};
  x.start=clone(record);x.stop=clone(record);x.closure={...clone(record),job:x.job,scope:'WRAPPER_CANARY'};
  assert.equal(validatePostBirthBundle(x).closure_present,true);
  x.stop.effective_command.at(-1);x.stop.effective_command.push('--other');assert.throws(()=>validatePostBirthBundle(x));
});
test('closure sans start/stop refusée',()=>{const x=fixture();x.closure={job:x.job};assert.throws(()=>validatePostBirthBundle(x));});
const redResult=()=>({schema:'c17-wrapper-canary-instrument-result-v1',scope:'WRAPPER_CANARY',qa_root:ROOT,
  actor:'/root',head:HEAD,FULL:false,round_A_or_B:false,density_or_78:false,passed:false,owned_shutdown_proved:false,
  runner_exit:86,classification:'instrument_error_not_product'});
const redSession=()=>({qa_root:ROOT,clean:false,log_stability_tainted:true});
test('RED/taint/cleanfalse restent inchangés',()=>{
  const r=preserveNativeOutcome(redResult(),redSession());assert.equal(r.recorded_native_passed,false);
  assert.equal(r.recorded_owned_shutdown_proved,false);assert.equal(r.recorded_global_clean,false);
  assert.equal(r.recorded_global_taint,true);assert.equal(r.recorded_runner_exit,86);assert.equal(r.native_qualification_claimed,false);
});
test('résultat FULL ou autre ROOT refusé',()=>{const r=redResult();r.FULL=true;assert.throws(()=>preserveNativeOutcome(r,redSession()));});
test('préflight strict refuse toute naissance/résultat natif, post explicite requiert trois fichiers',()=>{
  assert.equal(validateExecutionMode([],false),'preflight_prepared_only');
  for(const n of ['binding.json','decision.json','runtime/readiness.json','wrapper-canary-result.json'])
    assert.throws(()=>validateExecutionMode([n],false));
  assert.throws(()=>validateExecutionMode(['binding.json','decision.json'],true));
  assert.equal(validateExecutionMode(['binding.json','decision.json','wrapper-canary-result.json'],true),'post_birth_structural_only');
});

const diff='--- old-g1\n+++ new-g1\n@@ -1 +1 @@\n-a\n+b\n--- old-gate\n+++ new-gate\n@@ -1 +1 @@\n-c\n+d\n';
const sections=[{from:'old-g1',to:'new-g1',before:'a\n'},{from:'old-gate',to:'new-gate',before:'c\n'}];
test('deux diffs G1+gate exacts sans fuzz',()=>assert.deepEqual(applyExactUnifiedSections(diff,sections),['b\n','d\n']));
for(const [label,change] of [['préimage',()=>[{...sections[0],before:'x\n'},sections[1]]],
  ['section supplémentaire',()=>null],['hunk cardinalité',()=>null]])test('diff refuse '+label,()=>{
  const altered=label==='section supplémentaire'?diff+diff:label==='hunk cardinalité'?diff.replace('@@ -1 +1 @@','@@ -1,2 +1 @@'):diff;
  assert.throws(()=>applyExactUnifiedSections(altered,change()||sections));
});

// Exécute le vrai corps collect du checker dans une FS double uniquement.
const checker=fs.readFileSync(HERE+'/verify-prepared-wrapper15.mjs','utf8');
function archivalDouble(){
  const refsByPath=new Map(),payloads=new Map();
  const ref=p=>{assert(refsByPath.has(p),'ref synthetic inconnue '+p);return clone(refsByPath.get(p));};
  const c={need:(v,m)=>assert(v,m),ref,read:p=>clone(payloads.get(p)),fs:{lstatSync:()=>({isFile:()=>true,
    isSymbolicLink:()=>false,uid:501,gid:0,mode:0o100644,nlink:1}),realpathSync:p=>p}};
  vm.createContext(c);
  vm.runInContext(checker.slice(checker.indexOf('function sameRef('),checker.indexOf("const qa=")),c);
  const body=checker.slice(checker.indexOf('const refs=new Map()'),checker.indexOf('const construction='));
  vm.runInContext(body+'\nglobalThis.api={collect,refs,historicalObservations,historicalWrapper14PureOrigins,historicalWrapper14Sources};',c);
  for(const [origin,d] of c.api.historicalWrapper14PureOrigins){
    refsByPath.set(origin,{path:origin,sha256:d.sha256,bytes:d.bytes});
    payloads.set(origin,{schema:'c17-wrapper14-chromium-tmp-pure-tests-v1',actor:'/root/shared4_execution',tests:d.tests,
      passed:d.passed,errors:d.errors,exit_code:d.exit_code,failures:0,skipped:0,sources_unchanged:true,
      source_before:Array(18).fill('synthetic'),source_after:Array(18).fill('synthetic'),forbidden_attempts:[],forbidden_imports:[],
      G1_imported:false,constructor_invoked:false,native_executed:false,profile_compiled:false,FULL:false,release:false});
  }
  for(const s of c.api.historicalWrapper14Sources.values()){
    refsByPath.set(s.current.path,s.current);refsByPath.set(s.archive,{path:s.archive,sha256:s.original.sha256,bytes:s.original.bytes});
  }
  return {c,refsByPath,payloads};
}
test('six anciennes routes before/after exactes inchangées',()=>{
  const {c}=archivalDouble();let count=0;
  for(const [origin,d] of c.api.historicalWrapper14PureOrigins)for(const [pointer,label] of d.routes){
    c.api.collect(clone(c.api.historicalWrapper14Sources.get(label).original),origin,pointer);count++;
  }
  assert.equal(count,6);assert.equal(c.api.historicalObservations.length,6);
  assert(c.api.historicalObservations.some(x=>x.historical_passed===false&&x.historical_errors===1));
});
test('route non prévue ne devient pas une exemption',()=>{
  const {c}=archivalDouble(),[origin]=c.api.historicalWrapper14PureOrigins.keys(),s=c.api.historicalWrapper14Sources.get('test');
  c.api.collect(clone(s.original),origin,'/source_before/0');
  assert.equal(c.api.historicalObservations.length,0);assert.equal(c.api.refs.get(s.original.path).sha256,s.original.sha256);
});
test('origine/snapshot courant/archive modifié est refusé',()=>{
  for(const variant of ['origin','current','archive']){
    const {c,refsByPath}=archivalDouble(),[origin,d]=c.api.historicalWrapper14PureOrigins.entries().next().value;
    const [pointer,label]=d.routes.entries().next().value,s=c.api.historicalWrapper14Sources.get(label);
    const p=variant==='origin'?origin:variant==='current'?s.current.path:s.archive;
    refsByPath.set(p,{...refsByPath.get(p),sha256:'f'.repeat(64)});
    assert.throws(()=>c.api.collect(clone(s.original),origin,pointer));
  }
});
test('CLI post-birth distinct, garde préflight nativement présent dans corps réel',()=>{
  assert(checker.includes("const postBirth=process.argv[3]==='--post-birth';"));
  assert(checker.includes('validateExecutionMode(nativeNames.filter(n=>present(root+\'/\'+n)),postBirth);'));
  assert(checker.includes("if(result.passed===true)need(postBirthProofs.length===5"));
  assert(checker.includes('recordedNative=preserveNativeOutcome(result,session);'));
  assert(checker.includes("native:false,FULL:false,release:false"));
});

// Le vrai corps post-birth du checker tourne sur des fichiers EN MÉMOIRE.
function physicalDouble(withBirth=true){
  const x=fixture(),files=new Map();let inode=10;
  const put=(p,data)=>{const payload=typeof data==='string'?data:JSON.stringify(data);
    files.set(p,{payload,ino:inode++,nlink:1});return ref(p);};
  const ref=p=>{const f=files.get(p);assert(f,'fichier synthetic absent '+p);return {path:p,
    sha256:crypto.createHash('sha256').update(f.payload).digest('hex'),bytes:Buffer.byteLength(f.payload)};};
  const hardPut=(p,data)=>{const r=put(p,data),entry=files.get(p);entry.nlink=2;files.set(p+'.pending',entry);return r;};
  const read=p=>JSON.parse(files.get(p).payload);
  const auxiliary={auxiliary_descriptors:{}};
  const commands={};
  for(const job of JOBS){
    const replacement=JSON.parse(JSON.stringify(x.row).replaceAll(x.job,job));
    auxiliary.auxiliary_descriptors[job]=replacement;
    commands[replacement.name]=JSON.parse(JSON.stringify(x.bindingSpec).replaceAll(x.job,job));
  }
  for(let i=0;i<21;i++)commands['synthetic-extra-'+i]={};
  const table={source_refs:Array.from({length:79},(_,i)=>({path:ROOT+'/synthetic/'+i,sha256:'1'.repeat(64),bytes:0}))};
  const construction={root_go_ref:{path:ROOT+'/root-go.json',sha256:'a'.repeat(64),bytes:1}};
  const common={actor:'/root',qa_root:ROOT,round_id:x.decisionID,round_name:'WRAPPER_CANARY',head:HEAD};
  const binding={...common,schema:'c17-g1-real-wrappers-canary-binding-v1',commands,
    auxiliary_descriptors:auxiliary.auxiliary_descriptors,source_refs:table.source_refs};
  const bindingRef=put(ROOT+'/binding.json',binding);
  const decision={...common,schema:'c17-g1-real-wrappers-canary-decision-v1',scope:'g1_rpc_real_instrument_wrappers_canary_only',
    binding:bindingRef,decision_id:x.decisionID,root_authorization_origin:construction.root_go_ref,instruments:table.source_refs};
  const decisionRef=put(ROOT+'/decision.json',decision);
  const session={...redSession(),session_closed:true};
  const sessionRef=put(ROOT+'/ledger/session-close-1.json',session);
  const result={...redResult(),session_stop_ref:sessionRef};put(ROOT+'/wrapper-canary-result.json',result);
  if(withBirth){
    x.bindingSHA=bindingRef.sha256;x.raw.binding=bindingRef;x.raw.admission=decisionRef;
    x.raw.environment.C17_SESSION_BINDING_SHA256=bindingRef.sha256;
    x.raw.environment.C17_SESSION_BINDING_REF=JSON.stringify(bindingRef);
    x.raw.environment.C17_SESSION_DECISION_REF=JSON.stringify(decisionRef);
    x.gate.binding_sha256=bindingRef.sha256;x.release.gate=clone(x.gate);
    const gp=ROOT+'/ledger/'+x.row.name+'/gate.json';
    x.raw.gate_ref=hardPut(gp,x.gate);x.raw.gate_pending_ref=ref(gp+'.pending');
    x.raw.release_ref=hardPut(gp+'.release',x.release);x.raw.release_pending_ref=ref(gp+'.release.pending');
    x.raw.stdout=put(x.raw.stdout_path,'');x.raw.stderr=put(x.raw.stderr_path,'');
    put(ROOT+'/ledger/'+x.row.name+'/receipt.json',x.raw);
  }
  const c={root:ROOT,head:HEAD,postBirth:true,construction,auxiliary,table,chromeJobs:[...JOBS],
    path,ref,read,equal,validatePostBirthBundle,preserveNativeOutcome,
    need:(v,m)=>assert(v,m),present:p=>files.has(p)||[...files.keys()].some(q=>q.startsWith(p+'/')),
    collect:()=>{},fs:{
      lstatSync:p=>{const f=files.get(p);assert(f,'stat synthetic absent '+p);return {isFile:()=>true,isSymbolicLink:()=>false,
        uid:501,dev:1,ino:f.ino,nlink:f.nlink,size:Buffer.byteLength(f.payload)};},
      realpathSync:p=>p,readdirSync:p=>[...new Set([...files.keys()].filter(q=>q.startsWith(p+'/')).map(q=>q.slice(p.length+1).split('/')[0]))]},
  };
  vm.createContext(c);
  vm.runInContext(checker.slice(checker.indexOf('function sameRef('),checker.indexOf("const qa=")),c);
  const start=checker.indexOf('if(postBirth){'),end=checker.indexOf('\nfor(let i=0;i<pending.length;i++)',start);
  const source='const postBirthProofs=[];let recordedNative=null;\n'+checker.slice(start,end)+
    '\nglobalThis.observed={postBirthProofs,recordedNative};';
  return {files,put,ref,run:()=>vm.runInContext(source,c),c,x};
}
test('vrai lecteur post-birth : un seul Chrome réel déclaré synthétique, quatre absents non inventés',()=>{
  const f=physicalDouble();f.run();assert.equal(f.c.observed.postBirthProofs.length,1);
  assert.equal(f.c.observed.recordedNative.recorded_native_passed,false);
  assert.equal(f.c.observed.recordedNative.recorded_global_taint,true);
});
test('vrai lecteur post-birth : zéro birth avec résultat rouge ne fabrique rien',()=>{
  const f=physicalDouble(false);f.run();assert.equal(f.c.observed.postBirthProofs.length,0);
  assert.equal(f.c.observed.recordedNative.native_qualification_claimed,false);
});
for(const [label,mutate] of [
  ['gate sans brut',f=>f.files.delete(ROOT+'/ledger/'+f.x.row.name+'/receipt.json')],
  ['release manquante',f=>f.files.delete(ROOT+'/ledger/'+f.x.row.name+'/gate.json.release')],
  ['pending sans hardlink',f=>{const p=ROOT+'/ledger/'+f.x.row.name+'/gate.json.pending';f.files.set(p,{...f.files.get(p),ino:999});}],
  ['birth enregistrée divergente',f=>{const p=ROOT+'/ledger/'+f.x.row.name+'/receipt.json',r=JSON.parse(f.files.get(p).payload);r.root_identity.start_usec++;f.put(p,r);}],
  ['binding divergent',f=>{const p=ROOT+'/binding.json',r=JSON.parse(f.files.get(p).payload);r.commands.extra={};f.put(p,r);}],
  ['session sans reçu fermé',f=>{const p=ROOT+'/ledger/session-close-1.json',r=JSON.parse(f.files.get(p).payload);r.session_closed=false;f.put(p,r);}],
  ['résultat vert sans cinq closures',f=>{const p=ROOT+'/wrapper-canary-result.json',r=JSON.parse(f.files.get(p).payload);r.passed=true;f.put(p,r);}],
])test('vrai lecteur refuse '+label,()=>{const f=physicalDouble();mutate(f);assert.throws(()=>f.run());});

const pins=[HERE+'/verify-prepared-wrapper15.mjs',HERE+'/postbirth_checks.mjs',fileURLToPath(import.meta.url)]
  .map(p=>({path:p,sha256:crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex'),bytes:fs.statSync(p).size}));
let failures=0;
for(const [name,fn] of tests){try{fn();console.log('PASS '+name);}catch(e){failures++;console.log('FAIL '+name+' '+e.stack);}}
const after=pins.map(r=>({path:r.path,sha256:crypto.createHash('sha256').update(fs.readFileSync(r.path)).digest('hex'),bytes:fs.statSync(r.path).size}));
assert.deepEqual(after,pins,'Sources pures mutées pendant les tests');
console.log(JSON.stringify({schema:'c17-wrapper15-checker-pure-tests-v1',actor:process.env.C17_ACTOR,
  tests:tests.length,failures,errors:0,skipped:0,passed:failures===0,source_before:pins,source_after:after,
  synthetic_fixtures:true,checker_executed:false,ROOT15_scanned:false,G1_imported:false,native_executed:false,
  profile_compiled:false,constructor_invoked:false,admission_created:false,FULL:false,release:false}));
process.exitCode=failures?1:0;
