// Audit statique root réutilisable : aucun processus enfant ni réseau.
import fs from 'node:fs';
import crypto from 'node:crypto';
import path from 'node:path';
import {validatePostBirthBundle,preserveNativeOutcome,applyExactUnifiedSections,validateExecutionMode,equal} from './postbirth_checks.mjs';
const root=process.argv[2];
const postBirth=process.argv[3]==='--post-birth';
if(process.argv.length>4||process.argv[3]!==undefined&&!postBirth)throw Error('Mode explicite inconnu');
const need=(x,m)=>{if(!x)throw Error(m);};
need(root==='/private/tmp/therese-c17-wrapper-canary-9c1f04187dd24519b220372284a739c9'
  &&/^\/private\/tmp\/therese-c17-wrapper-canary-[a-f0-9]{32}$/.test(root),'Racine WRAPPER15 exacte requise');
function sameRef(a,b){
  const exact=x=>x!==null&&typeof x==='object'&&!Array.isArray(x)
    &&Object.keys(x).sort().join(',')==='bytes,path,sha256'
    &&typeof x.path==='string'&&x.path.startsWith('/')
    &&typeof x.sha256==='string'&&/^[a-f0-9]{64}$/.test(x.sha256)
    &&Number.isSafeInteger(x.bytes)&&x.bytes>=0;
  return exact(a)&&exact(b)&&a.path===b.path&&a.sha256===b.sha256&&a.bytes===b.bytes;
}
const qa='/private/tmp/therese-c17-wrapper-source-kGvU1hdx/source';
const head='2d69e30c9c6dd18823ee6102271876003a6a67cc';
need(process.getuid()===501,'UID utilisateur 501 exact requis');
const systemProfiles=new Map([
  ['/System/Library/Sandbox/Profiles/com.apple.GameOverlayUI.sb',
    {sha256:'6320ed0b8a6933b3c62cbfc8c3149a9f1dcc0a968cbfbc6f99a1270ab2c99257',bytes:10845}],
  ['/System/Library/Sandbox/Profiles/com.apple.gputoolsserviced.sb',
    {sha256:'fb1381764287e32128b8d6db40353059667ca4a2a64e7b778d1ef5773bb51841',bytes:7234}],
  ['/System/Library/Sandbox/Profiles/appsandbox-common.sb',
    {sha256:'b9ffebd2141aca32c609f4a707f5a6b980ae4be45299ee3f3c18534b69cb7cea',bytes:32355}],
]);
const ref=p=>{
  const s=fs.lstatSync(p),b=fs.readFileSync(p);
  const sha256=crypto.createHash('sha256').update(b).digest('hex');
  const expectedSystem=systemProfiles.get(p);
  const ownerExact=expectedSystem
    ? s.uid===0&&s.gid===0&&s.mode===0o100644&&s.nlink===1
      &&sha256===expectedSystem.sha256&&b.length===expectedSystem.bytes
    : s.uid===501;
  need(s.isFile()&&!s.isSymbolicLink()&&ownerExact&&fs.realpathSync(p)===p,'Ref non canonique ou propriétaire non admis '+p);
  return {path:p,sha256,bytes:b.length};
};
const oldBuilder14Ref=ref('/private/tmp/therese-c17-wrapper14-chromium-tmp-SYH6Mx/build_fresh_wrapper.py');
const builderRef=ref('/private/tmp/therese-c17-wrapper15-own-rendezvous-ky7lgh/build_fresh_wrapper.py');
const oldBuilder14IndexRef=ref('/private/tmp/therese-c17-wrapper14-chromium-tmp-SYH6Mx/INDEX.json');
const builderProposalIndexRef=ref('/private/tmp/therese-c17-wrapper15-own-rendezvous-ky7lgh/INDEX.json');
const historicalBuilderIndexRef=ref('/private/tmp/therese-c17-fresh-wrapper-builder-v10-ynPAzC/INDEX.json');
need(builderRef.sha256==='2ca68c3967325a1143ef0dedcda031fe2ecd31fe4c50fa91e11a408b8155c794'
  &&builderRef.bytes===106356
  &&builderProposalIndexRef.sha256==='770af2012e00c5d911faa2024692b4bd1f347cf60c9cac5ca4761e037eea5a7f'
  &&builderProposalIndexRef.bytes===17048
  &&oldBuilder14Ref.sha256==='b2e3a75cf1a2a090087f967115c105f098b28cd602744a5d951f502277c09e02'
  &&oldBuilder14Ref.bytes===93120
  &&oldBuilder14IndexRef.sha256==='e135223b023a771e3080f7ecb280ad350098783afbeeb5133d3221b6880ed7e6'
  &&oldBuilder14IndexRef.bytes===14704
  &&historicalBuilderIndexRef.sha256==='ad4cbc19f3c156f0b0d4ff2e3d36b31eccc9bda109cb18cc6c77194aefce1007'
  &&historicalBuilderIndexRef.bytes===8012,'Constructeur/propositions WRAPPER15/14 différents');
const read=p=>JSON.parse(fs.readFileSync(p));
const refs=new Map(),pending=[],historicalObservations=[];
const historicalG1ReceiptPaths=new Set([
  '/private/tmp/therese-c17-g1-26-pure-rgpjt79j/receipt.json',
  '/private/tmp/therese-c17-g1-26-pure-bmy35r8g/receipt.json',
  '/private/tmp/therese-c17-g1-26-pure-we_pel56/receipt.json',
]);
const historicalCrashIndex='/private/tmp/therese-c17-chrome-rootdomain-h5whIv/INDEX.json';
const historicalCrashRef={
  path:'/Users/synoptia/Library/Logs/DiagnosticReports/Google Chrome-2026-10-08-143832.000.ips',
  sha256:'2e1d81e295a1a75af7498e1698b4284c53206f7a031058ebd3331aad6fc8a3b3',
  bytes:31835,
};
const historicalCrashOrigins=new Map([
  [historicalCrashIndex,{pointer:'/origin_refs/4',
    sha256:'c0f542c377d37efd8e88103e2d760fdc126b785793f167755a319f0f5fb8d3c6',
    bytes:2605,kind:'diagnostic_index'}],
  ['/private/tmp/therese-c17-root-v10-71-replay-v3-zRFPBqd5/receipt.json',
    {pointer:'/source_refs/267',
      sha256:'c0864b435265a4c485c78837207184d3964e966689eb97785fe3ab4ff9e3f8e5',
      bytes:68793,kind:'pure_replay_green',source_refs:307,passed:true,errors:0}],
  ['/private/tmp/therese-c17-root-v10-71-replay-v2-eaECHtDi/receipt.json',
    {pointer:'/source_refs/267',
      sha256:'1955d363f88493a62d6423baeed094f10ab53fbb6ced7eaac94251ba73cdfb57',
      bytes:66947,kind:'pure_replay_red',source_refs:303,passed:false,errors:3}],
]);
const archivalCrashPath='/private/tmp/therese-c17-root-close6-I9BhiHpZ/chrome25577.ips';
const historicalWrapper14PureOrigins=new Map([
  ['/private/tmp/therese-c17-wrapper14-chromium-tmp-SYH6Mx/proofs/pure-ip_4qaah/receipt.json',{
    sha256:'517977ab83a493bfb153355be4d4c86a4e53eab9b475ba0a24812dc0a5ae9dc1',bytes:10863,
    tests:23,passed:true,errors:0,exit_code:0,
    routes:new Map([
      ['/source_before/1','test'],['/source_after/1','test'],
    ]),
  }],
  ['/private/tmp/therese-c17-wrapper14-chromium-tmp-SYH6Mx/proofs/pure-lb53c5ys/receipt.json',{
    sha256:'c764bd31f06477e55ea62a0a31134324b2b28ace4b4ae3793f6299f8137b9371',bytes:8908,
    tests:1,passed:false,errors:1,exit_code:1,
    routes:new Map([
      ['/source_before/1','test'],['/source_after/1','test'],
      ['/source_before/2','runner'],['/source_after/2','runner'],
    ]),
  }],
]);
const historicalWrapper14Sources=new Map([
  ['test',{
    original:{path:'/private/tmp/therese-c17-wrapper14-chromium-tmp-SYH6Mx/tests/test_wrapper14_static.py',
      sha256:'1ee928ff417b04d30079375f4cda965d09f3928a0b23a909b9e94cab55b70370',bytes:15345},
    current:{path:'/private/tmp/therese-c17-wrapper14-chromium-tmp-SYH6Mx/tests/test_wrapper14_static.py',
      sha256:'0e5d6843c601f59b0e0d044d173ed1f6fe43ce71ecd14a62c8fe8f8da6cc30aa',bytes:16647},
    archive:'/private/tmp/therese-c17-wrapper14-chromium-tmp-SYH6Mx/preimages/test-before-compose-body.py',
  }],
  ['runner',{
    original:{path:'/private/tmp/therese-c17-wrapper14-chromium-tmp-SYH6Mx/run_pure.py',
      sha256:'2aa86648ec8adfb9fc0bb8baba85a54e9872d9b454491afdf860a222f16f4cb6',bytes:4349},
    current:{path:'/private/tmp/therese-c17-wrapper14-chromium-tmp-SYH6Mx/run_pure.py',
      sha256:'7767596480f237c2931e8d91e4a285df41e52ee54bc4de99baced1843e18e9b6',bytes:4440},
    archive:'/private/tmp/therese-c17-wrapper14-chromium-tmp-SYH6Mx/preimages/run_pure-before-mock-import.py',
  }],
]);
const historicalWrapper15PureOrigin='/private/tmp/therese-c17-wrapper15-own-rendezvous-ky7lgh/proofs/pure-0efgw3f_/receipt.json';
const historicalWrapper15PureRoutes=new Set(['/source_before/3','/source_after/3']);
const historicalWrapper15Test={
  original:{path:'/private/tmp/therese-c17-wrapper15-own-rendezvous-ky7lgh/tests/test_wrapper15_static.py',
    sha256:'99b142bb651970f889d5901187adac97a3acbc23a54b44028069afe63faddd44',bytes:28171},
  current:{path:'/private/tmp/therese-c17-wrapper15-own-rendezvous-ky7lgh/tests/test_wrapper15_static.py',
    sha256:'ae708b276074bf1d6e92ee48830879d0808e6ecb107690fc5d86c49f4961c092',bytes:28665},
  archive:'/private/tmp/therese-c17-wrapper15-own-rendezvous-ky7lgh/preimages/test-wrapper15-first-red.py',
};
const pointerChild=(pointer,key)=>pointer+'/'+String(key).replace(/~/g,'~0').replace(/\//g,'~1');
const collect=(x,origin='direct',pointer='')=>{
  if(Array.isArray(x))x.forEach((y,i)=>collect(y,origin,pointerChild(pointer,i)));
  else if(x&&typeof x==='object'){
    if(x.schema==='c17-g1-26-pure-tests-v1'&&historicalG1ReceiptPaths.has(origin)){
      // Ce reçu observe le passé : son contenu est pinné, ses snapshots ne sont
      // pas des exigences sur les mêmes chemins physiques après le successeur.
      need(x.pins_before.length===11&&JSON.stringify(x.pins_before)===JSON.stringify(x.pins_after)
        &&x.pins_unchanged===true&&x.passed===true&&x.native_OS_qualification===false
        &&x.FULL_admission===false,'Reçu historique G1 inattendu '+JSON.stringify({origin,count:x.pins_before?.length,unchanged:x.pins_unchanged,passed:x.passed,native:x.native_OS_qualification,FULL:x.FULL_admission,equal:JSON.stringify(x.pins_before)===JSON.stringify(x.pins_after)}));
      historicalObservations.push({origin,kind:'pure_test_observation',refs:x.pins_before.length});
      for(const [k,v] of Object.entries(x))if(!['pins_before','pins_after'].includes(k))collect(v,origin,pointerChild(pointer,k));
    }else if(historicalCrashOrigins.has(origin)&&pointer===historicalCrashOrigins.get(origin).pointer){
      const expectedOrigin=historicalCrashOrigins.get(origin);
      need(sameRef(x,historicalCrashRef),'Rapport historique non exactement épinglé');
      const originRef=ref(origin);
      need(originRef.sha256===expectedOrigin.sha256&&originRef.bytes===expectedOrigin.bytes,
        'Origine historique non exacte');
      let evidenceRef=null;
      if(expectedOrigin.kind==='diagnostic_index'){
        const index=read(origin);
        need(index.origin_refs?.length===5&&sameRef(index.origin_refs[4],historicalCrashRef),
          'Pointeur du rapport historique non exact');
        evidenceRef=ref('/private/tmp/therese-c17-chrome-rootdomain-h5whIv/EVIDENCE.json');
        need(evidenceRef.sha256==='57253794719541add1642bc011ff0437248eb922eb798ec4b6132a8ff81c5f6a'
          &&evidenceRef.bytes===803,'Preuve historique non exacte');
        const evidence=read(evidenceRef.path);
        need(evidence.diagnostic_only===true&&evidence.chrome_pid===25577
          &&evidence.origin_crash_report===historicalCrashRef.path,'Observation historique hors diagnostic');
      }else{
        const receipt=read(origin);
        need(receipt.schema==='c17-root-v10-71-pure-replay-v1'&&receipt.actor==='/root'
          &&receipt.tests===71&&receipt.unchanged===true
          &&receipt.passed===expectedOrigin.passed&&receipt.errors===expectedOrigin.errors
          &&receipt.failures===0&&receipt.skipped===0
          &&receipt.root_built===false&&receipt.G1_imported===false
          &&receipt.native_workload_executed===false&&receipt.FULL===false&&receipt.release===false
          &&Array.isArray(receipt.forbidden_attempts)&&receipt.forbidden_attempts.length===0
          &&receipt.source_refs?.length===expectedOrigin.source_refs
          &&sameRef(receipt.source_refs[267],historicalCrashRef),
          'Reçu de tests purs historique inattendu ou réétiqueté');
        if(expectedOrigin.kind==='pure_replay_green'){
          need(Array.isArray(receipt.fixture_entries_after_cleanup)
            &&receipt.fixture_entries_after_cleanup.length===0
            &&sameRef(receipt.earlier_red_receipt_ref,{
              path:'/private/tmp/therese-c17-root-v10-71-replay-v2-eaECHtDi/receipt.json',
              sha256:'1955d363f88493a62d6423baeed094f10ab53fbb6ced7eaac94251ba73cdfb57',
              bytes:66947}),
            'Reçu vert historique détaché du rouge');
        }
      }
      let oldPathAbsent=false;
      try{fs.lstatSync(historicalCrashRef.path);}catch(error){oldPathAbsent=error?.code==='ENOENT';}
      need(oldPathAbsent,'Rapport historique non absent avec ENOENT');
      const archivedStat=fs.lstatSync(archivalCrashPath);
      need(archivedStat.isFile()&&!archivedStat.isSymbolicLink()
        &&archivedStat.uid===501&&archivedStat.gid===0&&archivedStat.mode===0o100600
        &&archivedStat.nlink===1&&fs.realpathSync(archivalCrashPath)===archivalCrashPath,
        'Copie archivale non canonique ou métadonnées inattendues');
      const archivedRef=ref(archivalCrashPath);
      need(archivedRef.sha256===historicalCrashRef.sha256&&archivedRef.bytes===historicalCrashRef.bytes,
        'Copie archivale différente du rapport historique');
      const old=refs.get(archivedRef.path);
      need(!old||sameRef(old,archivedRef),'Pins contradictoires copie archivale');
      if(!old){refs.set(archivedRef.path,archivedRef);pending.push(archivedRef);}
      historicalObservations.push({kind:'historical_crash_report_archival_byte_match',
        origin:originRef,origin_kind:expectedOrigin.kind,origin_pointer:pointer,evidence:evidenceRef,
        pure_replay_passed:expectedOrigin.passed??null,pure_replay_errors:expectedOrigin.errors??null,
        original_ref:historicalCrashRef,original_path_absent_ENOENT:oldPathAbsent,
        archival_ref:archivedRef,archival_metadata:{uid:archivedStat.uid,gid:archivedStat.gid,
          mode:archivedStat.mode,nlink:archivedStat.nlink},measured_at:new Date().toISOString(),
        close6_receipt_provenance_claimed:false});
    }else if(historicalWrapper14PureOrigins.get(origin)?.routes.has(pointer)){
      const expectedOrigin=historicalWrapper14PureOrigins.get(origin);
      const expected=historicalWrapper14Sources.get(expectedOrigin.routes.get(pointer));
      need(sameRef(x,expected.original),'Snapshot pur historique WRAPPER14 différent');
      const originRef=ref(origin),receipt=read(origin);
      need(originRef.sha256===expectedOrigin.sha256&&originRef.bytes===expectedOrigin.bytes,
        'Origine du snapshot pur WRAPPER14 non exacte');
      need(receipt.schema==='c17-wrapper14-chromium-tmp-pure-tests-v1'
        &&receipt.actor==='/root/shared4_execution'
        &&receipt.tests===expectedOrigin.tests&&receipt.passed===expectedOrigin.passed
        &&receipt.errors===expectedOrigin.errors&&receipt.exit_code===expectedOrigin.exit_code
        &&receipt.failures===0&&receipt.skipped===0&&receipt.sources_unchanged===true
        &&receipt.source_before?.length===18
        &&JSON.stringify(receipt.source_before)===JSON.stringify(receipt.source_after)
        &&receipt.forbidden_attempts?.length===0&&receipt.forbidden_imports?.length===0
        &&receipt.G1_imported===false&&receipt.constructor_invoked===false
        &&receipt.native_executed===false&&receipt.profile_compiled===false
        &&receipt.FULL===false&&receipt.release===false,
        'Résultat historique WRAPPER14 modifié ou requalifié');
      let originalAbsent=false,currentRef=null;
      try{fs.lstatSync(expected.original.path);}
      catch(error){originalAbsent=error?.code==='ENOENT';need(originalAbsent,'Erreur stat snapshot historique');}
      if(!originalAbsent){
        currentRef=ref(expected.original.path);
        need(sameRef(currentRef,expected.current)&&!sameRef(currentRef,expected.original),
          'Chemin courant du snapshot historique non exactement changé');
      }
      const archivedStat=fs.lstatSync(expected.archive),archivedRef=ref(expected.archive);
      need(archivedStat.isFile()&&!archivedStat.isSymbolicLink()
        &&archivedStat.uid===501&&archivedStat.gid===0&&archivedStat.mode===0o100644
        &&archivedStat.nlink===1&&fs.realpathSync(expected.archive)===expected.archive
        &&archivedRef.sha256===expected.original.sha256&&archivedRef.bytes===expected.original.bytes,
        'Préimage physique du snapshot historique WRAPPER14 différente');
      collect(archivedRef,origin,pointer+'/archival');
      historicalObservations.push({kind:'historical_wrapper14_pure_source_archival_byte_match',
        origin:originRef,origin_pointer:pointer,original_ref:expected.original,
        original_path_absent_ENOENT:originalAbsent,current_ref:currentRef,
        archival_ref:archivedRef,archival_metadata:{uid:archivedStat.uid,gid:archivedStat.gid,
          mode:archivedStat.mode,nlink:archivedStat.nlink},
        historical_tests:receipt.tests,historical_passed:receipt.passed,historical_errors:receipt.errors,
        runtime_qualification:false,measured_at:new Date().toISOString()});
    }else if(origin===historicalWrapper15PureOrigin&&historicalWrapper15PureRoutes.has(pointer)){
      const expected=historicalWrapper15Test,originRef=ref(origin),receipt=read(origin);
      need(sameRef(x,expected.original)&&originRef.sha256==='87d194cb513bdaa81ea0bc818e36414e7c0cc661f994dd717855674421b500ed'
        &&originRef.bytes===12517&&receipt.schema==='c17-wrapper15-own-rendezvous-pure-tests-v1'
        &&receipt.actor==='/root/shared4_execution'&&receipt.tests===38&&receipt.passed===false
        &&receipt.errors===4&&receipt.failures===0&&receipt.skipped===0&&receipt.exit_code===1
        &&receipt.sources_unchanged===true&&receipt.source_before?.length===18
        &&JSON.stringify(receipt.source_before)===JSON.stringify(receipt.source_after)
        &&receipt.forbidden_attempts?.length===0&&receipt.forbidden_imports?.length===0
        &&receipt.G1_imported===false&&receipt.constructor_invoked===false&&receipt.native_executed===false
        &&receipt.profile_compiled===false&&receipt.FULL===false&&receipt.release===false,
        'Ancien test/rouge WRAPPER15 non exactement lié');
      need(sameRef(ref(expected.current.path),expected.current),'Test courant WRAPPER15 divergent');
      const st=fs.lstatSync(expected.archive),archiveRef=ref(expected.archive);
      need(st.isFile()&&!st.isSymbolicLink()&&st.uid===501&&st.gid===0&&st.mode===0o100644&&st.nlink===1
        &&archiveRef.sha256===expected.original.sha256&&archiveRef.bytes===expected.original.bytes,
        'Préimage rouge WRAPPER15 divergente');
      collect(archiveRef,origin,pointer+'/archival');
      historicalObservations.push({kind:'historical_wrapper15_pure_source_archival_byte_match',origin:originRef,
        origin_pointer:pointer,original_ref:expected.original,archival_ref:archiveRef,current_ref:expected.current,
        historical_passed:false,historical_errors:4,runtime_qualification:false});
    }else if(typeof x.path==='string'&&x.path.startsWith('/')&&/^[a-f0-9]{64}$/.test(x.sha256)&&Object.keys(x).every(k=>['path','sha256','bytes','git_blob'].includes(k))){
      const old=refs.get(x.path);need(!old||old.sha256===x.sha256,'Pins contradictoires '+x.path+' origine='+origin+' '+JSON.stringify({old,new:x}));
      if(!old){refs.set(x.path,x);pending.push(x);}
    }else for(const [k,v] of Object.entries(x))collect(v,origin,pointerChild(pointer,k));
  }
};
const construction=read(root+'/fresh-wrapper-construction.json');
need(construction.head===head&&construction.root===root&&construction.source_refs_count===79
  &&construction.runtime_executed===false&&construction.G1_imported===false&&construction.FULL===false,'Construction hors préparation');
need(Array.isArray(construction.historical_ips_observations)
  &&construction.historical_ips_observations.length===3
  &&new Set(construction.historical_ips_observations.map(o=>o.origin+'#'+o.pointer)).size===3
  &&construction.historical_ips_observations.every(o=>o.old_path===historicalCrashRef.path
    &&o.old_sha256===historicalCrashRef.sha256&&o.old_bytes===historicalCrashRef.bytes
    &&o.old_path_absent===true&&o.archive_path===archivalCrashPath
    &&o.archive_sha256===historicalCrashRef.sha256&&o.archive_bytes===historicalCrashRef.bytes
    &&o.runtime_qualification===false&&o.close6_receipt_provenance_claimed===false)
  &&construction.historical_ips_observations.some(o=>o.kind==='pure_replay_red'
    &&o.passed===false&&o.errors===3),
  'Trois observations IPS archivales exactes/rouge V2 absents');
const table=read(construction.source_refs_ref.path);
need(table.source_refs.length===79&&new Set(table.source_refs.map(x=>x.path)).size===79,'Table79 invalide');
need(construction.deltas.length===6&&construction.runner_boundary_definition_refs.length===7,'Deltas6/preuves7 absents');
collect(construction);collect(table);collect(ref(root+'/fresh-wrapper-construction.json'));
for(const [key,count] of [['base11_ref',11],['support8_ref',8],['overlay28_ref',28]]){
  const j=read(construction[key].path);need(Object.keys(j.outputs).length===count,'Sorties '+key);collect(j);
}
const core=read(construction.core18_ref.path);need(core.copies.length===18,'Core18 absent');
for(const row of core.copies)if(row.derivation==='byte_exact')need(ref(row.input.path).sha256===ref(row.output.path).sha256,'Copie non byte-exacte');
const authority=read(construction.authority_ref.path);
const chromeV10Ref=ref('/private/tmp/therese-c17-fresh-wrapper-builder-v10-ynPAzC/profile/chrome.sb');
const chromeMain11Ref=ref('/private/tmp/therese-c17-wrapper-profile-three-builder-G8n4Ef/profile/chrome.sb');
const chromeMain12Ref=ref('/private/tmp/therese-c17-wrapper12-metadata-parent-MtcoJZ/profile/chrome.sb');
const chromeMain12IndexRef=ref('/private/tmp/therese-c17-wrapper12-metadata-parent-MtcoJZ/PLAN-INDEX.json');
const chromeDirhelperRef=ref('/private/tmp/therese-c17-wrapper13-dirhelper-P5WQpQ/profile/chrome.sb');
const chromeCandidateRef=ref('/private/tmp/therese-c17-wrapper15-own-rendezvous-ky7lgh/profile/chrome.sb');
const getconfProfileRef=ref('/private/tmp/therese-c17-getconf-dirhelper-XeZCB9/profiles/dirhelper.sb');
const getconfIndexRef=ref('/private/tmp/therese-c17-getconf-dirhelper-XeZCB9/INDEX.json');
const chromeProposalRef=ref('/private/tmp/therese-c17-chrome-targeted-three-McWh5vFc/INDEX.json');
const builderProposal=read(oldBuilder14IndexRef.path);
const proposal15=read(builderProposalIndexRef.path);
const main13IndexRef=ref('/private/tmp/therese-c17-wrapper13-dirhelper-P5WQpQ/PLAN-INDEX.json');
const main13=read(main13IndexRef.path);
const wrapper14ProfileRef=ref('/private/tmp/therese-c17-wrapper14-chromium-tmp-SYH6Mx/profile/chrome.sb');
const chromeProposal=read(chromeProposalRef.path);
need(chromeV10Ref.sha256==='19808ee2cac3169e9fb8c71c24385bcbb97f924c5ed785f4651817ecaa179b0c'
  &&chromeV10Ref.bytes===2067
  &&chromeMain11Ref.sha256==='bee3c2e780e58cbc80ed7e37d64115adf08997aab39dae8f11b56050785633a9'
  &&chromeMain11Ref.bytes===2375
  &&chromeMain12Ref.sha256==='980b12368975718d33dba1572ce94da04ca378ca827df1be10a1ed15a7104cdb'
  &&chromeMain12Ref.bytes===2439
  &&chromeMain12IndexRef.sha256==='e7ab1ad86f5ba0dde5dde38bb2feeb3dd31b1d53d18981ac3a9d34aa29f12a15'
  &&chromeMain12IndexRef.bytes===4788
  &&chromeDirhelperRef.sha256==='2ecae3a24ec871a44827b3f712ced1ef5e84d8f778906c37b3a5b51bb374dcdf'
  &&chromeDirhelperRef.bytes===2499
  &&getconfProfileRef.sha256===chromeDirhelperRef.sha256
  &&getconfProfileRef.bytes===chromeDirhelperRef.bytes
  &&getconfIndexRef.sha256==='72a3724edd8687408184b9a0a425247f0c152a17373e602e655ef2281b66cb9c'
  &&getconfIndexRef.bytes===2141
  &&chromeProposalRef.sha256==='499ed6c8c75ba66857e6797728b0c1a39a2fb93bff6f96827049639195b6d966'
  &&main13IndexRef.sha256==='0956da6b74598f64639c4dd491cdaf21378247b14316a5ac7e2084cd018529e9'
  &&main13IndexRef.bytes===4918&&sameRef(main13.candidate_chrome_profile,chromeDirhelperRef)
  &&sameRef(main13.historical_main11_builder_index,
    ref('/private/tmp/therese-c17-wrapper-profile-three-builder-G8n4Ef/PLAN-INDEX.json'))
  &&sameRef(main13.historical_main12_builder_index,chromeMain12IndexRef)
  &&sameRef(main13.getconf_preparation_index,getconfIndexRef)
  &&main13.schema==='c17-wrapper13-dirhelper-static-proposal-v1'
  &&main13.future_root==='/private/tmp/therese-c17-wrapper-canary-8612f55886284332a3ac6a7bc9615021'
  &&main13.future_root_created===false&&main13.status==='prepared_static_pure_only_not_native_qualified'
  &&sameRef(builderProposal.builder_ref,oldBuilder14Ref)
  &&sameRef(builderProposal.profile_ref,wrapper14ProfileRef)
  &&wrapper14ProfileRef.sha256===chromeDirhelperRef.sha256&&wrapper14ProfileRef.bytes===chromeDirhelperRef.bytes
  &&Array.isArray(builderProposal.origin_refs)
  &&builderProposal.origin_refs.some(r=>sameRef(r,main13IndexRef))
  &&builderProposal.origin_refs.some(r=>sameRef(r,chromeDirhelperRef))
  &&builderProposal.schema==='c17-wrapper14-chromium-tmp-static-proposal-v1'
  &&builderProposal.future_root==='/private/tmp/therese-c17-wrapper-canary-187602c63a0b498a95d25c19843000a8'&&builderProposal.future_root_created===false
  &&builderProposal.status==='prepared_static_pure_only_not_native_qualified'
  &&builderProposal.native_executed===false&&builderProposal.construction_invoked===false
  &&builderProposal.G1_imported===false&&builderProposal.admission_created===false
  &&builderProposal.FULL===false&&builderProposal.release===false
  &&builderProposal.g1_only_changed_function==='validate_environment'
  &&builderProposal.g1_other_AST_bodies_unchanged===true&&builderProposal.profile_byte_exact===true
  &&builderProposal.three_historical_IPS_routes_code_unchanged===true
  &&builderProposal.source_refs_count_preserved===79
  &&builderProposal.CDP_seconds===5&&builderProposal.Chrome_startup_seconds===50&&builderProposal.cleanup_seconds===8
  &&chromeProposal.preimage.sha256===chromeV10Ref.sha256
  &&chromeProposal.candidate.sha256===chromeMain11Ref.sha256
  &&chromeProposal.status==='prepared_static_only_unexecuted_profile_not_admitted',
  'Chaîne proposition Chrome non exacte ou admise');
const threeRuleSuffix=[
  '; ROOT10 diagnostic_only : refus ciblés, causalité non prouvée, profil non admis.',
  '(allow mach-lookup (global-name "com.apple.CARenderServer"))',
  '(allow iokit-open-user-client (iokit-user-client-class "IOSurfaceRootUserClient"))',
  '(allow iokit-open-user-client (iokit-user-client-class "AGXDeviceUserClient"))',
].join('\n')+'\n';
need(fs.readFileSync(chromeMain11Ref.path).equals(Buffer.concat([
  fs.readFileSync(chromeV10Ref.path),Buffer.from(threeRuleSuffix)])),
  'Préimage MAIN11 autre que V10 suivi des trois règles exactes');
const parentRule='(allow file-read-metadata (literal (param "AUXILIARY_PARENT")))\n';
need(fs.readFileSync(chromeMain12Ref.path).equals(Buffer.concat([
  fs.readFileSync(chromeMain11Ref.path),Buffer.from(parentRule)])),
  'Profil MAIN12 autre que MAIN11 suivi du seul parent auxiliaire metadata');
const dirhelperRule='(allow mach-lookup (global-name "com.apple.bsd.dirhelper"))\n';
need(fs.readFileSync(chromeDirhelperRef.path).equals(Buffer.concat([
  fs.readFileSync(chromeMain12Ref.path),Buffer.from(dirhelperRule)]))
  &&fs.readFileSync(chromeDirhelperRef.path).equals(fs.readFileSync(getconfProfileRef.path)),
  'Profil WRAPPER13 autre que MAIN12 suivi du seul lookup dirhelper exact');
const ownRule='(allow mach-register (global-name (param "OWN_RENDEZVOUS_SERVICE")))\n';
need(chromeCandidateRef.sha256==='1684af7c288e86b3e5fa47ebde5fa598ba2d619f50c904f899d50b396f8e2453'
  &&chromeCandidateRef.bytes===2568&&fs.readFileSync(chromeCandidateRef.path).equals(Buffer.concat([
    fs.readFileSync(chromeDirhelperRef.path),Buffer.from(ownRule)])),
  'Profil15 hors unique règle mach-register OWN');
need(proposal15.schema==='c17-wrapper15-own-rendezvous-preparation-index-v1'
  &&sameRef(proposal15.builder_ref,builderRef)&&sameRef(proposal15.chrome_profile_ref,chromeCandidateRef)
  &&proposal15.future_root===root&&proposal15.status==='prepared_pure_only_not_native_admitted'
  &&proposal15.tests===38&&proposal15.passed===true&&proposal15.native_executed===false
  &&proposal15.constructor_invoked===false&&proposal15.G1_imported===false
  &&proposal15.profile_compiled===false&&proposal15.admission_created===false
  &&proposal15.FULL===false&&proposal15.release===false&&proposal15.RUNTIME_activated===false
  &&proposal15.historical_canary_head===head&&proposal15.historical_qa_source===qa
  &&proposal15.preserved_denominators.source_refs===79&&proposal15.preserved_denominators.core===18
  &&proposal15.preserved_denominators.base_originals===11&&proposal15.preserved_denominators.RPC===15
  &&proposal15.preserved_denominators.Chrome===5&&proposal15.preserved_denominators.commands===26
  &&proposal15.preserved_denominators.physical_diff_refs===6
  &&proposal15.CDP_seconds===5&&proposal15.Chrome_startup_seconds===50&&proposal15.cleanup_seconds===8,
  'Proposition15 dénominateurs/limites divergents ou qualification inventée');
const chromeCoreRows=core.copies.filter(r=>r.output.path===root+'/g1/chrome.sb');
need(chromeCoreRows.length===1
  &&chromeCoreRows[0].derivation==='pinned_chrome_ui_exact_successor'
  &&sameRef(chromeCoreRows[0].output,ref(root+'/g1/chrome.sb'))
  &&sameRef(core.chrome_profile_ref,chromeCandidateRef)
  &&sameRef(construction.chrome_profile_ref,chromeCandidateRef)
  &&sameRef(authority.chrome_profile_ref,chromeCandidateRef)
  &&ref(root+'/g1/chrome.sb').sha256===chromeCandidateRef.sha256,
  'Profil Chrome physique/core/autorité divergent');
const runtime=fs.readFileSync(root+'/g1/runtime_session.py','utf8');
const parentParam='extra.extend(["-D", "AUXILIARY_PARENT=" + str(auxiliary_parent)])';
need(runtime.split(parentParam).length===2
  &&runtime.includes('auxiliary_parent = root / "auxiliary"')
  &&runtime.includes('child_path(root, auxiliary_parent) == auxiliary_parent'),
  'Paramètre G1 du parent auxiliaire Chrome absent ou dupliqué');
const wrapper14G1BeforeRef=ref('/private/tmp/therese-c17-wrapper14-chromium-tmp-SYH6Mx/preimages/runtime_session-before-env.py');
const wrapper14G1AfterRef=ref('/private/tmp/therese-c17-wrapper14-chromium-tmp-SYH6Mx/preview/runtime_session-after-env.py');
need(wrapper14G1BeforeRef.sha256==='355a54df40ea754541972283f14fb487dc2030036cc683752985a3360538fbe6'
  &&wrapper14G1BeforeRef.bytes===185723
  &&wrapper14G1AfterRef.sha256==='a84da2041b8ddf87e5c4d56e10dbcd717f26322cfbac2d5017fd6442c4d81ce2'
  &&wrapper14G1AfterRef.bytes===186477,'Préimage/preview G1 environnement différents');
const environmentBody=text=>{
  const begin='\ndef validate_environment(',end='\n\ndef validate_rpc_environment(';
  need(text.split(begin).length===2&&text.split(end).length===2
    &&text.indexOf(end)>text.indexOf(begin),'Ancres du corps environnement non uniques');
  return text.slice(text.indexOf(begin),text.indexOf(end));
};
need(environmentBody(runtime).replace(root,'/private/tmp/therese-c17-wrapper-canary-187602c63a0b498a95d25c19843000a8')===environmentBody(fs.readFileSync(wrapper14G1AfterRef.path,'utf8'))
  &&environmentBody(runtime)!==environmentBody(fs.readFileSync(wrapper14G1BeforeRef.path,'utf8')),
  'Corps G1 MAC autre que delta ROOT14 avec seul literal ROOT15');
collect(wrapper14G1BeforeRef);collect(wrapper14G1AfterRef);
const rendezvousPreview=ref('/private/tmp/therese-c17-wrapper15-own-rendezvous-ky7lgh/preview/runtime_session.py');
const rendezvousGate=ref('/private/tmp/therese-c17-wrapper15-own-rendezvous-ky7lgh/preview/runtime_launch_gate.py');
need(rendezvousPreview.sha256==='d8f2460878d265e6caee63128d10a6aa104deaf200b44797b5cf0d8081fce52a'
  &&rendezvousPreview.bytes===192714&&rendezvousGate.sha256==='caca6bc8390beeeba871041f97db02a6b2d5ff94ac9d92f7a58c1e297781a595'
  &&rendezvousGate.bytes===5074,'Preview G1/gate15 non exact');
const quote=x=>{need(typeof x==='string'&&!/[\u0000'\\]/.test(x),'Literal Python non fermé');return "'"+x+"'";};
const slotEntries=[['decision_path',root+'/decision.json'],['binding_path',root+'/binding.json'],
  ['actor','/root'],['round_id',path.basename(root)],['round_name','WRAPPER_CANARY'],['qa_root',root],
  ['head',head],['product_source_root',qa],['qa_python',qa+'/.venv-conforme/bin/python']];
const slotLiteral='{'+quote(path.basename(root))+': {'+slotEntries.map(([k,v])=>quote(k)+': '+quote(v)).join(', ')+'}}';
const emptySlot='WRAPPER_ADMISSION_TABLE: dict[str, dict] = {}';
const previewText=fs.readFileSync(rendezvousPreview.path,'utf8');
need(previewText.split(emptySlot).length===2
  &&runtime===previewText.replace(emptySlot,'WRAPPER_ADMISSION_TABLE: dict[str, dict] = '+slotLiteral),
  'Autre delta G1 que preview15 et slot WRAPPER unique');
const gateText=fs.readFileSync(root+'/g1/runtime_launch_gate.py','utf8');
need(gateText===fs.readFileSync(rendezvousGate.path,'utf8'),'Gate15 physique différent de la preview exacte');
const g1Core=core.copies.find(r=>r.output.path===root+'/g1/runtime_session.py');
const gateCore=core.copies.find(r=>r.output.path===root+'/g1/runtime_launch_gate.py');
const g1Preimage=ref(root+'/proofs/preimages/runtime_session.py');
const gatePreimage=ref(root+'/proofs/preimages/runtime_launch_gate.py');
need(g1Core?.derivation==='WRAPPER_slot_QA_Chrome_MAC_and_post_birth_OWN_parameter'
  &&gateCore?.derivation==='OWN_parameter_release_gate_exact'
  &&sameRef(g1Core.output,ref(root+'/g1/runtime_session.py'))
  &&sameRef(gateCore.output,ref(root+'/g1/runtime_launch_gate.py'))
  &&g1Preimage.sha256===g1Core.input.sha256&&g1Preimage.bytes===g1Core.input.bytes
  &&g1Preimage.sha256==='f8e9daacbb9b88b628aeefbd33ba86df45135eba571241c26d3d5721b3a4e781'
  &&gatePreimage.sha256===gateCore.input.sha256&&gatePreimage.bytes===gateCore.input.bytes
  &&gatePreimage.sha256==='864e1994c0fe7252aef2492b498d18c5dbcb5091d9b8e29b971b4b08108c1e8c',
  'Deux préimages G1/gate physiques et origines non jointes');
const [g1FromDiff,gateFromDiff]=applyExactUnifiedSections(fs.readFileSync(construction.deltas[0].path,'utf8'),[
  {from:'frozen_definition',to:'fresh_root_copy',before:fs.readFileSync(g1Preimage.path,'utf8')},
  {from:'frozen_runtime_launch_gate.py',to:'fresh_runtime_launch_gate.py',before:fs.readFileSync(gatePreimage.path,'utf8')},
]);
need(g1FromDiff===runtime&&gateFromDiff===gateText,'Diff premier physique autre que G1+gate exacts');
for(const r of [rendezvousPreview,rendezvousGate,g1Preimage,gatePreimage])collect(r);

need(sameRef(construction.builder_ref,builderRef),'Builder autre que WRAPPER15');
need(sameRef(authority.builder_index_ref,historicalBuilderIndexRef)
  &&sameRef(authority.builder_proposal_index_ref,builderProposalIndexRef)
  &&sameRef(authority.builder_ref,builderRef)
  &&authority.repo_head_observed==='91e0b942bfb24bfb77890960b2c4b97d04cbb750'
  &&authority.historical_source_WRAPPER_only_not_current_FULL===true,'Autorité V10 ou périmètre historique divergent');
const diagnostic='/private/tmp/therese-c17-rpc-cause-observability-NRYrmF';
const diagnosticIndex=ref(diagnostic+'/INDEX.json'),diagnosticOrigins=ref(diagnostic+'/ORIGINS.json');
need(diagnosticIndex.sha256==='604e4e02062dd37cafbf9e67b2545b7697bad70a7aeac2825598cefaa63d7596'
  &&diagnosticOrigins.sha256==='6b1a49683e195f6f35d7456027ca3b03d0d6956c3d220eb3f9b7db94c4ab4846'
  &&sameRef(construction.rpc_diagnostic_origin_index_ref,diagnosticIndex)
  &&sameRef(core.diagnostic_origin_ref,diagnosticOrigins)
  &&sameRef(authority.rpc_diagnostic_index_ref,diagnosticIndex)
  &&sameRef(authority.rpc_diagnostic_origins_ref,diagnosticOrigins),
  'Gel/origines diagnostic non joints');
const origins=read(diagnosticOrigins.path),diagnosticNames=['rpc_protocol.py','rpc_client.py','rpc_dispatcher.py','session_rpc_adapter.py'];
need(origins.scope==='WRAPPER_ROOT9_transport_diagnostic_only'
  &&origins.no_AB_composite_used===true&&origins.origin_byte_exact.length===4
  &&origins.static_diff_reconstruction.length===4,'Quatre origines diagnostic absentes');
const proofRows=construction.rpc_diagnostic_derivation_refs;
need(Array.isArray(proofRows)&&proofRows.length===8,'Huit préimages/diffs diagnostic non copiés');
for(const name of diagnosticNames){
  const origin=origins.origin_byte_exact.find(r=>r.candidate.path===diagnostic+'/source/'+name);
  need(origin&&ref(origin.baseline.path).sha256===origin.baseline.sha256
    &&ref(origin.ROOT9.path).sha256===origin.ROOT9.sha256
    &&ref(origin.preimage.path).sha256===origin.preimage.sha256
    &&ref(origin.candidate.path).sha256===origin.candidate.sha256
    &&new Set([origin.baseline.sha256,origin.ROOT9.sha256,origin.preimage.sha256]).size===1,
    'Préimage/ROOT9/candidat diagnostic divergents '+name);
  const diff=origins.static_diff_reconstruction.find(r=>r.path===diagnostic+'/diffs/'+name+'.diff');
  need(diff&&sameRef(ref(diff.path),diff),'Diff diagnostic non épinglé '+name);
  const row=core.copies.find(r=>r.output.path===root+'/source/'+name);
  need(row&&row.derivation==='diagnostic_only_exact_delta'
    &&sameRef(row.input,origin.baseline)
    &&sameRef(row.preimage_ref,origin.preimage)
    &&sameRef(row.candidate_source_ref,origin.candidate)
    &&sameRef(row.diagnostic_diff_ref,diff)
    &&row.output.sha256===origin.candidate.sha256
    &&sameRef(ref(row.output.path),row.output),
    'Source active diagnostic non reliée '+name);
  for(const [kind,expected] of [['preimage',origin.preimage],['diff',diff]]){
    const suffix=kind==='diff'?name+'.diff':name;
    const dest=root+'/proofs/rpc-diagnostic-'+kind+'/'+suffix;
    const proof=proofRows.find(r=>r.output.path===dest);
    need(proof&&sameRef(proof.origin,expected)
      &&proof.output.sha256===expected.sha256
      &&sameRef(ref(dest),proof.output),
      'Preuve brute diagnostic non copiée '+kind+'/'+name);
  }
}
const helperSource=ref(diagnostic+'/source/rpc_diagnostics.py');
need(helperSource.sha256==='ae86d9b538429ca2f168cc386ea7a6e4d05ddad4e8b9f926a29dfbb4f5533058'
  &&helperSource.bytes===6826
  &&sameRef(authority.rpc_diagnostic_helper_ref,helperSource),
  'Helper diagnostic externe non exact');
const helperPureRef=ref('/private/tmp/therese-c17-rpc-cause-pure-root-tLe4Fm0P/receipt.json');
const helperPure=read(helperPureRef.path);
need(helperPureRef.sha256==='e54ec67ce25f22ff88468a9eae2cf9fd7fdaf4e460b3de3057160b264bd75855'
  &&helperPureRef.bytes===11392
  &&sameRef(authority.rpc_diagnostic_pure_receipt_ref,helperPureRef)
  &&helperPure.schema==='c17-root-rpc-exception-observability-pure-tests-v1'
  &&helperPure.tests_run===34&&helperPure.passed===true
  &&helperPure.failures===0&&helperPure.errors===0&&helperPure.skips===0
  &&helperPure.native_executed===false&&helperPure.runtime_admission===false
  &&helperPure.G1_imported===false&&helperPure.FULL===false,
  'Reçu pur diagnostic34 différent ou promu en qualification OS');
const helperPaths=[root+'/source/rpc_diagnostics.py',
  root+'/auxiliary-ports/runtime/rpc_diagnostics.py',
  root+'/auxiliary-ports/complements/instruments/rpc_diagnostics.py'];
for(const p of helperPaths)need(sameRef(ref(p),table.source_refs.find(r=>r.path===p))
  &&ref(p).sha256===helperSource.sha256,'Helper physique absent/muté '+p);
const helperCore=core.copies.find(r=>r.output.path===helperPaths[0]);
need(helperCore?.derivation==='diagnostic_helper_byte_exact'
  &&sameRef(helperCore.input,helperSource)
  &&sameRef(helperCore.output,ref(helperPaths[0])),
  'Helper core18 non lié');
const overlay=read(construction.overlay28_ref.path);
need(overlay.script_outputs&&Object.keys(overlay.script_outputs).length===19
  &&overlay.diagnostic_derivations.length===4
  &&sameRef(overlay.diagnostic_origin_index_ref,diagnosticIndex),
  'Overlay28 diagnostic incomplet');
for(const folder of ['runtime','complements/instruments'])for(const name of diagnosticNames.slice(0,2)){
  const p=root+'/auxiliary-ports/'+folder+'/'+name;
  const origin=origins.origin_byte_exact.find(r=>r.candidate.path===diagnostic+'/source/'+name);
  const deriv=overlay.diagnostic_derivations.find(r=>r.new_output.path===p);
  need(deriv&&sameRef(deriv.old_output,origin.preimage)
    &&sameRef(deriv.candidate_source,origin.candidate)
    &&sameRef(deriv.new_output,ref(p))
    &&sameRef(overlay.script_outputs[folder+'/'+name],deriv.new_output),
    'Overlay diagnostic non relié '+p);
}
const helper=core.copies.filter(r=>r.output.path===root+'/source/chrome_contract.py');
need(helper.length===1&&helper[0].derivation==='CHROME_QA_exact_constant_only'
  &&helper[0].input.sha256==='26e8374a23b7f67a5c45cbc457156bfd15735cd2578ca0fd7990b3df989630db'
  &&helper[0].output.sha256==='7922a13bdc239338ea9dedf37bf06ef1c91931b77a5275a2db6007d89a9a42ba'
  &&helper[0].derivation_source_ref.sha256===helper[0].output.sha256
  &&JSON.stringify(helper[0].derivation_diff_ref)===JSON.stringify(construction.chrome_contract_delta_ref),'Helper QA non lié exactement');
need(JSON.stringify(construction.chrome_contract_qa_ref)===JSON.stringify(helper[0].output)
  &&table.source_refs.some(r=>JSON.stringify(r)===JSON.stringify(helper[0].output)),'Helper QA absent des79');
const copyProof=construction.chrome_qa_copy_ref;
need(copyProof.sha256==='f97793cb43454051da734685185cb5d4e5b5ffbabc516580287195ef3d32993c'&&copyProof.bytes===17160,'Autre reçu copie Chrome');
const observations=[construction.chrome_copy_fresh_before_ref,construction.chrome_copy_fresh_after_ref].map(r=>read(r.path));
for(const o of observations)need(o.schema==='c17-chrome-copy-fresh-filesystem-observation-v1'
  &&o.source==='/Applications/Google Chrome.app'&&o.target==='/private/tmp/therese-c17-chrome-qa-copy-RoZmwsja/Google Chrome.app'
  &&o.entries===1339&&o.types.file===697&&o.types.directory===635&&o.types.symlink===7
  &&o.source_manifest_equal===true&&o.copy_manifest_equal===true&&o.all_bytes_modes_UID_GID_links_equal===true
  &&o.source_and_copy_inodes_match_archived_snapshots===true&&o.no_hardlinks_to_source===true
  &&o.codesign_reexecuted===false&&o.xattrs_currently_measured===false&&o.runtime_qualified===false
  &&JSON.stringify(o.root_copy_receipt_ref)===JSON.stringify(copyProof),'Observation physique Chrome invalide');
need(observations[0].source_snapshot_sha256===observations[1].source_snapshot_sha256
  &&observations[0].copy_snapshot_sha256===observations[1].copy_snapshot_sha256
  &&Date.parse(observations[0].observed_at_utc)<=Date.parse(observations[1].observed_at_utc),'Observations Chrome discordantes');
const go=read(construction.root_go_ref.path),auxiliary=read(go.auxiliary_ref.path);
need(sameRef(go.chrome_profile_origin_ref,chromeCandidateRef)
  &&sameRef(go.chrome_profile_ref,ref(root+'/g1/chrome.sb')),
  'GO Chrome non relié à la proposition exacte');
for(const key of ['chrome_contract_qa_ref','chrome_contract_delta_ref','chrome_copy_fresh_before_ref','chrome_copy_fresh_after_ref','chrome_qa_copy_ref'])
  need(JSON.stringify(go[key])===JSON.stringify(construction[key]),'GO non joint '+key);
const executable='/private/tmp/therese-c17-chrome-qa-copy-RoZmwsja/Google Chrome.app/Contents/MacOS/Google Chrome';
const chromeJobs=['rpc-all-runtime_ui-visual_capture-network_capture','rpc-screen-negative',
  'rpc-screen-positive-visual','rpc-screen-positive-network','rpc-screen-restored'];
need(JSON.stringify(Object.keys(auxiliary.auxiliary_descriptors).sort())===JSON.stringify(chromeJobs.sort()),
  'Chrome jobs différents des cinq identités exactes');
for(const [job,row] of Object.entries(auxiliary.auxiliary_descriptors)){
  const defaults=read(row.launch_defaults_ref.path);
  need(row.executable===executable&&row.argv[0]===executable&&defaults.executable===executable
    &&JSON.stringify(defaults.argv)===JSON.stringify(row.argv)&&row.port===17594
    &&row.profile===root+'/auxiliary/aux-chrome-'+job+'/profile'
    &&row.name==='aux-chrome-'+job&&row.role==='auxiliary-'+row.name&&row.job===job
    &&row.deadline===50,'Descripteur/defaults Chrome divergents');
  const tmp=root+'/auxiliary/'+row.name+'/tmp',tmpStat=fs.lstatSync(tmp);
  need(row.env.MAC_CHROMIUM_TMPDIR===tmp&&row.env.TMPDIR===tmp
    &&tmpStat.isDirectory()&&!tmpStat.isSymbolicLink()&&tmpStat.uid===501
    &&fs.realpathSync(tmp)===tmp,'MAC_CHROMIUM_TMPDIR/TMPDIR non QA exact Chrome');

}
const sql=read(construction.sql_contract_ref.path);
need(sql.head===head&&sql.round_id===path.basename(root)&&sql.root_reviewed===false&&sql.root_review_required===true,'Contrat SQL incorrect');
const historical=read(sql.historical_contract_definition.path);
need(JSON.stringify(Object.keys(sql.relations).sort())==='["B1753","B1760"]','Groupes SQL différents');
for(const n of ['B1753','B1760'])need(JSON.stringify(sql.relations[n])===JSON.stringify(historical.relations[n]),'Relations historiques SQL réécrites '+n);
need(Object.keys(sql.source_snapshot).length===36,'SQL sources36 absentes');
for(const [n,s] of Object.entries(sql.source_snapshot))need(ref(qa+'/'+n).sha256===s,'Source SQL changée '+n);
collect(sql);
const manifestPath='/private/tmp/therese-c17-wrapper-source-kGvU1hdx/proofs/qa-source-files.json';
need(ref(manifestPath).sha256==='0904574e2b35b523b8454b33156f595f05a62e21609453a65db59ae516423b89','Manifest QA différent');
const manifest=read(manifestPath);
need(manifest.head===head&&manifest.files.length===3579&&manifest.symlinks.length===0,'Tree3579/symlinks');
need(fs.readFileSync(qa+'/.git/HEAD','utf8').trim()===head,'HEAD physique différent');
for(const r of manifest.files){
  const a=ref(r.path),raw=fs.readFileSync(r.path),n=r.path.slice(qa.length+1),mode=manifest.modes[r.path];
  need(a.sha256===r.sha256&&a.bytes===r.bytes,'Blob physique changé '+n);
  need(crypto.createHash('sha1').update(Buffer.concat([Buffer.from('blob '+raw.length+'\0'),raw])).digest('hex')===r.git_blob,'Git blob différent '+n);
  need(['100644','100755'].includes(mode)&&((fs.statSync(r.path).mode&0o111)!==0)===(mode==='100755'),'Mode Git différent '+n);
}
// Le mode post-birth n'est jamais implicite. La préparation reste contrôlée avant toute preuve native.
const nativeNames=['binding.json','decision.json','runtime/readiness.json','runtime/pile-reprise.json',
  'runtime/services-running.json','wrapper-canary-result.json'];
const present=p=>{try{fs.lstatSync(p);return true;}catch(e){if(e.code==='ENOENT')return false;throw e;}};
validateExecutionMode(nativeNames.filter(n=>present(root+'/'+n)),postBirth);
const postBirthProofs=[];
let recordedNative=null;
if(postBirth){
  const resultPath=root+'/wrapper-canary-result.json',result=read(resultPath);
  need(result.session_stop_ref?.path?.startsWith(root+'/ledger/session-close-')
    &&/^session-close-[1-9][0-9]*\.json$/.test(path.basename(result.session_stop_ref.path)),
    'Fermeture Session post-birth absente/hors chemin');
  const session=read(result.session_stop_ref.path),decision=read(root+'/decision.json'),binding=read(root+'/binding.json');
  const bindingRef=ref(root+'/binding.json'),decisionRef=ref(root+'/decision.json');
  need(sameRef(ref(result.session_stop_ref.path),result.session_stop_ref)&&session.session_closed===true
    &&decision.schema==='c17-g1-real-wrappers-canary-decision-v1'
    &&binding.schema==='c17-g1-real-wrappers-canary-binding-v1'
    &&decision.scope==='g1_rpc_real_instrument_wrappers_canary_only'
    &&decision.actor===binding.actor&&binding.actor==='/root'&&decision.qa_root===binding.qa_root&&binding.qa_root===root
    &&decision.round_id===binding.round_id&&binding.round_id===path.basename(root)
    &&decision.round_name===binding.round_name&&binding.round_name==='WRAPPER_CANARY'
    &&decision.head===binding.head&&binding.head===head&&decision.decision_id===path.basename(root)
    &&sameRef(decision.binding,bindingRef)&&sameRef(decision.root_authorization_origin,construction.root_go_ref)
    &&equal(binding.source_refs,table.source_refs)&&equal(decision.instruments,table.source_refs)
    &&equal(binding.auxiliary_descriptors,auxiliary.auxiliary_descriptors)
    &&Object.keys(binding.commands).length===26,'Autorité/binding ou Session post-birth non joints');
  recordedNative=preserveNativeOutcome(result,session);
  const hardlink=p=>{
    const a=fs.lstatSync(p),pendingPath=p+'.pending',b=fs.lstatSync(pendingPath);
    need(a.isFile()&&b.isFile()&&!a.isSymbolicLink()&&!b.isSymbolicLink()
      &&a.uid===501&&b.uid===501&&a.dev===b.dev&&a.ino===b.ino&&a.nlink===2&&b.nlink===2
      &&a.size===b.size&&fs.realpathSync(p)===p&&fs.realpathSync(pendingPath)===pendingPath,
      'Publication gate/release sans hardlinks exacts');
    const value=read(p);
    need(value.publication_protocol==='exclusive-pending-fsync-hardlink-v1','Publication autre protocole');
    collect(ref(p));collect(ref(pendingPath));return value;
  };
  for(const [job,row] of Object.entries(auxiliary.auxiliary_descriptors)){
    const folder=root+'/ledger/'+row.name,gatePath=folder+'/gate.json',releasePath=gatePath+'.release';
    const names=present(folder)?fs.readdirSync(folder):[];
    const receipts=names.filter(n=>n==='receipt.json'||/^receipt-attempt-[2-9][0-9]*\.json$/.test(n))
      .map(n=>({name:n,attempt:n==='receipt.json'?1:Number(n.match(/[0-9]+/)[0])}))
      .sort((a,b)=>a.attempt-b.attempt);
    need(!names.some(n=>n.startsWith('receipt')&&!receipts.some(r=>r.name===n)),'Nom reçu Chrome non admis');
    const birthArtifact=present(gatePath)||present(gatePath+'.pending')||present(releasePath)||present(releasePath+'.pending');
    if(receipts.length===0){need(!birthArtifact,'Gate/naissance sans reçu terminal Chrome');continue;}
    need(receipts.every((r,i)=>r.attempt===i+1),'Reçus Chrome incomplets/hors ordre');
    const raws=receipts.map(r=>read(folder+'/'+r.name)),raw=raws.at(-1);
    for(let i=0;i<raws.length;i++){
      need(raws[i].cleanup_attempt===receipts[i].attempt&&raws[i].root_identity!==undefined,'Reçu Chrome autre tentative');
      collect(ref(folder+'/'+receipts[i].name));collect(raws[i],folder+'/'+receipts[i].name);
    }
    if(raw.root_identity===null){need(!birthArtifact,'Gate sans identité terminale Chrome');continue;}
    need(raws.every(r=>equal(r.root_identity,raw.root_identity)),'Naissance change entre tentatives');
    const gate=hardlink(gatePath),release=hardlink(releasePath);
    for(const [field,p] of [['gate_ref',gatePath],['gate_pending_ref',gatePath+'.pending'],
      ['release_ref',releasePath],['release_pending_ref',releasePath+'.pending']])
      need(sameRef(raw[field],ref(p)),'Ref '+field+' post-birth divergente');
    need(sameRef(raw.admission,decisionRef)&&sameRef(raw.binding,bindingRef),'Raw autre admission/binding');
    const start=present(row.start_path)?read(row.start_path):null;
    const auxFolder=path.dirname(row.stop_path),auxNames=fs.readdirSync(auxFolder);
    const stops=auxNames.filter(n=>n==='stop.json'||/^stop-attempt-[2-9][0-9]*\.json$/.test(n))
      .map(n=>({name:n,attempt:n==='stop.json'?1:Number(n.match(/[0-9]+/)[0])})).sort((a,b)=>a.attempt-b.attempt);
    const closures=auxNames.filter(n=>n==='closure.json'||/^closure-attempt-[2-9][0-9]*\.json$/.test(n))
      .map(n=>({name:n,attempt:n==='closure.json'?1:Number(n.match(/[0-9]+/)[0])})).sort((a,b)=>a.attempt-b.attempt);
    need(stops.length===closures.length&&stops.every((r,i)=>r.attempt===i+1)
      &&closures.every((r,i)=>r.attempt===stops[i].attempt),'Stop/closure tentatives manquantes');
    let stop=null,closure=null;
    for(let i=0;i<stops.length;i++){
      stop=read(auxFolder+'/'+stops[i].name);closure=read(auxFolder+'/'+closures[i].name);
      need(start!==null&&sameRef(closure.start_ref,ref(row.start_path))
        &&sameRef(closure.stop_ref,ref(auxFolder+'/'+stops[i].name))
        &&sameRef(stop.receipt_refs?.[0],ref(row.start_path))
        &&stop.receipt_refs?.some(r=>r?.path===closure.leaf_receipt_ref?.path&&sameRef(r,closure.leaf_receipt_ref)),
        'Refs start/stop/leaf/closure non jointes');
      collect(ref(auxFolder+'/'+stops[i].name));collect(ref(auxFolder+'/'+closures[i].name));
      collect(stop);collect(closure);
    }
    if(start){need(sameRef(start.gate_ref,ref(gatePath))&&sameRef(start.release_ref,ref(releasePath)),
      'Start autre gate/release');collect(ref(row.start_path));collect(start);}
    postBirthProofs.push(validatePostBirthBundle({root,head,bindingSHA:bindingRef.sha256,
      decisionID:decision.decision_id,job,row,bindingSpec:binding.commands[row.name],raw,gate,release,start,stop,closure}));
  }
  if(result.passed===true)need(postBirthProofs.length===5&&postBirthProofs.every(p=>p.closure_present),
    'Résultat vert enregistré sans cinq clôtures réelles');
  collect(ref(resultPath));collect(result);collect(ref(root+'/binding.json'));collect(binding);
  collect(ref(root+'/decision.json'));collect(decision);collect(session);
}
for(let i=0;i<pending.length;i++){
  need(pending.length<6000,'Références hors borne');
  const r=pending[i],a=ref(r.path);need(a.sha256===r.sha256&&(r.bytes===undefined||a.bytes===r.bytes),'Ref changée '+r.path);
  if(r.path.endsWith('.json')&&r.path!==sql.historical_contract_definition.path)collect(read(r.path),r.path);
}
need(historicalObservations.filter(o=>o.kind==='historical_wrapper14_pure_source_archival_byte_match').length===6,
  'Six observations before/after des trois seuls snapshots historiques absentes');
need(historicalObservations.filter(o=>o.kind==='historical_wrapper15_pure_source_archival_byte_match').length===2,
  'Deux pointeurs du seul test pur rouge WRAPPER15 absents');
need(ref(root+'/g1/web.sb').sha256==='51ff2e21500393704ea8709fb9bd177dc1f88793d1e92d09c68be70d905807ff'
  &&ref(root+'/g1/chrome.sb').sha256==='1684af7c288e86b3e5fa47ebde5fa598ba2d619f50c904f899d50b396f8e2453','Profils autres successeurs');
console.log(JSON.stringify({status:postBirth?'post_birth_structural_verified_only':'prepared_only_static_verified',
  mode:postBirth?'--post-birth':'strict_preflight',root,refs:refs.size,historical_observations:historicalObservations,
  post_birth_proofs:postBirthProofs,recorded_native_outcome:recordedNative,sources:79,core_copies:18,
  overlay_outputs:28,diagnostic_origins:4,diagnostic_helpers:3,git_tree_files:3579,git_modes:true,
  git_blobs:true,SQL_sources:36,SQL_relations_unchanged:true,original11:true,deltas:6,
  G1_gate_two_preimages:true,G1_gate_diff_exact:true,witness_copies:7,native:false,FULL:false,release:false}));
