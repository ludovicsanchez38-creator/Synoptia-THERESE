# LOT74 source QA : successeur de sélection d'archive

Préparation statique seulement. L'ancien contrôleur `/private/tmp/therese-c17-source-qa-archive-prep-2RapwW` reste intact. Sa première exécution MAIN a échoué avant création du tar avec `ArchiveRefusal: taille de ref invalide` ; reçu rouge `/private/tmp/therese-c17-source-qa-archive-akjq935f/receipt.json`, SHA-256 `6b5beb1f1f7fcdbb1dbc9446952604335beb6d8cbac6b81b08d33094dc52c507`, 551 octets. Il ne devient pas un PASS.

Cause lue dans la source et l'INDEX : `nested_refs` analyse toutes les métadonnées de référence de l'INDEX, notamment Node externe à 110 712 624 octets, avant de retenir seulement les preuves sous `proofs/`. L'ancien `parsed_ref` appliquait aux métadonnées cette même borne de 64 MB destinée au contenu à archiver.

Delta minimal : `parsed_ref` accepte une taille de métadonnée entière non négative jusqu'à 128 000 000 octets. Cela couvre l'exécutable externe observé mais reste fini ; le chemin/SHA/structure exacts demeurent contrôlés. La borne 64 000 000 octets s'applique explicitement aux membres *après* sélection ; la somme reste exactement 32 592 096 octets pour 95 membres. Le flux tar et le gzip restent bornés respectivement à 64 MB et 16 MB. `nested_refs` ne lit aucun fichier externe : il analyse les JSON déjà épinglés. Seuls les trois JSON racines puis les 95 membres sélectionnés sont lus par le contrôleur. Aucun répertoire source, `.git`, dépendance ou venv n'est parcouru pour l'archive.

Préimage `archive_source_qa-before.py` SHA-256 `468656f79025069743d9f051c94e0e40e912f4d49bc9b4f0f601c4f87d7dd29e`, cible `archive_source_qa.py`. Diffs avant/inverse exacts et contrôlés en mémoire. Quatre tests purs réels `Python -I -B tests_pure.py` exit0 en 0,005 s : métadonnée externe 110,7 MB admise lexicalement, >128 MB/bool/float/négatif refusés, sélection exacte 95/32 592 096/aucun Node, et reçu rouge historique inchangé. Ces tests n'appellent ni `main`, ni tar/gzip, ni outil produit.

Commande future pour MAIN après revue indépendante, non exécutée ici :

```text
/Users/synoptia/.local/share/uv/python/cpython-3.13.5-macos-aarch64-none/bin/python3.13 -I -B /private/tmp/therese-c17-source-qa-archive-prep-v2-nWnRVi/archive_source_qa.py --execute
```

Une sortie future pourrait encore être rouge sur compression >16 MB, changement physique ou autre garde. Même si elle est verte, elle prouve uniquement une archive vérifiée de preuves historiques/source QA, pas une admission A/B, FULL ou release.
