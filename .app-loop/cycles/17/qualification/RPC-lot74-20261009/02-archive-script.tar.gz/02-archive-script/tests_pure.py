"""Contrôles purs du refus de sélection, sans créer d'archive."""
from __future__ import annotations

import importlib.util
import json
from pathlib import Path
import sys
import unittest


ROOT = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("archive_source_qa_v2", ROOT / "archive_source_qa.py")
assert SPEC is not None and SPEC.loader is not None
MODULE = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = MODULE
SPEC.loader.exec_module(MODULE)


class SelectionBounds(unittest.TestCase):
    def test_external_node_binary_is_metadata_not_a_member(self) -> None:
        large = MODULE.parsed_ref({
            "path": "/Users/synoptia/.nvm/versions/node/v22.19.0/bin/node",
            "sha256": "a" * 64,
            "bytes": 110_712_624,
        })
        self.assertGreater(large.bytes, MODULE.MAX_INPUT_BYTES)
        self.assertLessEqual(large.bytes, MODULE.MAX_REF_METADATA_BYTES)

    def test_metadata_bound_remains_finite_and_exact(self) -> None:
        self.assertEqual(MODULE.MAX_REF_METADATA_BYTES, 128_000_000)
        for size in (128_000_001, -1, True, 1.0):
            with self.subTest(size=size), self.assertRaises(MODULE.ArchiveRefusal):
                MODULE.parsed_ref({"path": "/private/tmp/outside", "sha256": "a" * 64,
                                   "bytes": size})

    def test_only_95_closed_members_and_64mb_effective_bound(self) -> None:
        members = MODULE.select_members()
        self.assertEqual(len(members), 95)
        self.assertEqual(sum(item.ref.bytes for item in members), 32_592_096)
        self.assertTrue(all(item.ref.bytes <= MODULE.MAX_INPUT_BYTES for item in members))
        self.assertTrue(all(item.name.startswith(("source-proofs/", "policy/", "recipe-v2/"))
                            for item in members))
        self.assertFalse(any("/bin/node" in str(item.ref.path) for item in members))
        self.assertFalse(any("/source/node_modules/" in str(item.ref.path) for item in members))

    def test_historical_red_is_not_relabelled(self) -> None:
        receipt = json.loads(Path(
            "/private/tmp/therese-c17-source-qa-archive-akjq935f/receipt.json"
        ).read_text())
        self.assertEqual((receipt["status"], receipt["error"]),
                         ("failed", "taille de ref invalide"))
        self.assertFalse(receipt["FULL"])
        self.assertFalse(receipt["A_B_admitted"])


if __name__ == "__main__":
    unittest.main()
