"""Archive fermée des preuves source QA du HEAD 91e0, sans checkout ni dépendances.

MAIN seul exécute ce script. La présence de --execute n'est pas une admission
runtime, A/B, FULL ou release. Aucun import du produit et aucun sous-processus.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
import gzip
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import tarfile
import tempfile
import time
from typing import BinaryIO, Iterator


HEAD = "91e0b942bfb24bfb77890960b2c4b97d04cbb750"
SOURCE_PROOFS = Path("/private/tmp/therese-c17-direct-source-c8a0bbba3ee44b8e876cf836f2414c95/proofs")
RECIPE_ROOT = Path("/private/tmp/therese-c17-fresh-source-recipe-v2-iMu968")
POLICY_PATH = Path("/private/tmp/therese-c17-documentary-main-policy-y0BHoBxb/policy.json")
SOURCE_INDEX_SHA = "894b59d7842a7960ebd9bea074a6eee8b438ba7f21f1f622d028e033a7617585"
RECIPE_INDEX_SHA = "23132b37d168ce1f85f82cc310cbde2df3672624f12b24fefedfc8708010cf52"
POLICY_SHA = "6729e2356a9dd4555cd007c4422b722e8438b1d3de265edbf22eae17a27e121f"
SOURCE_INDEX_BYTES = 68_932
RECIPE_INDEX_BYTES = 10_826
POLICY_BYTES = 418_056
EXPECTED_PROOF_REFS = 64
EXPECTED_RECIPE_REFS = 28
EXPECTED_MEMBERS = 95
EXPECTED_INPUT_BYTES = 32_592_096
MAX_INPUT_BYTES = 64_000_000
MAX_REF_METADATA_BYTES = 128_000_000
MAX_ARCHIVE_BYTES = 16_000_000
MAX_TAR_STREAM_BYTES = 64_000_000
CHUNK = 1024 * 1024
ALLOWED = re.compile(r"[A-Za-z0-9._/-]+\Z")


class ArchiveRefusal(ValueError):
    pass


def require(ok: bool, message: str) -> None:
    if not ok:
        raise ArchiveRefusal(message)


@dataclass(frozen=True)
class Ref:
    path: Path
    sha256: str
    bytes: int

    def json(self) -> dict[str, object]:
        return {"path": str(self.path), "sha256": self.sha256, "bytes": self.bytes}


@dataclass(frozen=True)
class Member:
    name: str
    ref: Ref

    def json(self) -> dict[str, object]:
        return {"name": self.name, "origin_ref": self.ref.json()}


@dataclass(frozen=True)
class Physical:
    dev: int
    ino: int
    mode: int
    uid: int
    gid: int
    nlink: int
    size: int
    mtime_ns: int
    ctime_ns: int


def physical(value: os.stat_result) -> Physical:
    return Physical(value.st_dev, value.st_ino, value.st_mode, value.st_uid, value.st_gid,
                    value.st_nlink, value.st_size, value.st_mtime_ns, value.st_ctime_ns)


def parsed_ref(value: object) -> Ref:
    require(isinstance(value, dict) and set(value) == {"path", "sha256", "bytes"}, "ref non exacte")
    assert isinstance(value, dict)
    raw_path, sha, size = value["path"], value["sha256"], value["bytes"]
    require(type(raw_path) is str and raw_path.startswith("/") and str(Path(raw_path)) == raw_path,
            "chemin de ref non canonique lexical")
    require(type(sha) is str and re.fullmatch(r"[0-9a-f]{64}", sha) is not None, "SHA invalide")
    require(type(size) is int and 0 <= size <= MAX_REF_METADATA_BYTES, "taille de ref invalide")
    return Ref(Path(raw_path), sha, size)


def owned_member_name(name: str) -> None:
    pure = PurePosixPath(name)
    require(type(name) is str and ALLOWED.fullmatch(name) is not None
            and not pure.is_absolute() and str(pure) == name and len(name.encode("ascii")) <= 100
            and all(part not in ("", ".", "..") for part in pure.parts)
            and pure.parts[0] in ("source-proofs", "policy", "recipe-v2"), "membre tar non fermé")


def read_pinned(ref: Ref, *, capture: bool = False) -> tuple[Physical, bytes | None]:
    path = ref.path
    before = physical(path.lstat())
    require(stat.S_ISREG(before.mode) and before.nlink == 1 and path.resolve(strict=True) == path,
            "ref symlink/hardlink/non canonique/non régulière: " + str(path))
    require(before.size == ref.bytes, "taille préalable différente: " + str(path))
    require(hasattr(os, "O_NOFOLLOW"), "O_NOFOLLOW indisponible")
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    digest = hashlib.sha256()
    length = 0
    chunks: list[bytes] = []
    try:
        require(physical(os.fstat(fd)) == before, "inode changée avant lecture: " + str(path))
        while True:
            data = os.read(fd, CHUNK)
            if not data:
                break
            length += len(data)
            require(length <= ref.bytes, "croissance pendant lecture: " + str(path))
            digest.update(data)
            if capture:
                require(ref.bytes <= 1_000_000, "capture JSON trop grande")
                chunks.append(data)
        require(physical(os.fstat(fd)) == before, "inode changée pendant lecture: " + str(path))
    finally:
        os.close(fd)
    require(length == ref.bytes and digest.hexdigest() == ref.sha256
            and physical(path.lstat()) == before, "SHA/taille/stat changés: " + str(path))
    return before, b"".join(chunks) if capture else None


def json_pinned(ref: Ref) -> dict:
    _, data = read_pinned(ref, capture=True)
    require(data is not None, "JSON absent")
    result = json.loads(data)
    require(isinstance(result, dict), "JSON racine non objet")
    return result


def nested_refs(value: object) -> Iterator[Ref]:
    if isinstance(value, dict):
        if set(value) == {"path", "sha256", "bytes"}:
            yield parsed_ref(value)
        else:
            for child in value.values():
                yield from nested_refs(child)
    elif isinstance(value, list):
        for child in value:
            yield from nested_refs(child)


def select_members() -> list[Member]:
    source_index_ref = Ref(SOURCE_PROOFS / "INDEX.json", SOURCE_INDEX_SHA, SOURCE_INDEX_BYTES)
    recipe_index_ref = Ref(RECIPE_ROOT / "INDEX.json", RECIPE_INDEX_SHA, RECIPE_INDEX_BYTES)
    policy_ref = Ref(POLICY_PATH, POLICY_SHA, POLICY_BYTES)
    source_index = json_pinned(source_index_ref)
    recipe_index = json_pinned(recipe_index_ref)
    policy = json_pinned(policy_ref)
    require(source_index.get("schema") == "c17-direct-fresh-source-preparation-index-v2"
            and source_index.get("status") == "prepared_source_only"
            and source_index.get("request", {}).get("expected_head") == HEAD
            and source_index.get("FULL_constructor_inputs", {}).get("expected_head") == HEAD
            and source_index.get("documentary_policy_ref") == policy_ref.json()
            and source_index.get("request", {}).get("documentary_policy_ref") == policy_ref.json(),
            "INDEX source/head/policy différent")
    require(policy.get("schema") == "c17-root-reviewed-documentary-source-policy-v1"
            and policy.get("expected_head") == HEAD, "policy autre HEAD")
    require(recipe_index.get("schema") == "c17-fresh-source-recipe-v2-preparation-index-v1"
            and isinstance(recipe_index.get("files"), list)
            and len(recipe_index["files"]) == EXPECTED_RECIPE_REFS, "recette index autre")

    proof_prefix = str(SOURCE_PROOFS) + "/"
    recipe_prefix = str(RECIPE_ROOT) + "/"
    proof_refs: dict[Path, Ref] = {}
    for ref in nested_refs(source_index):
        if str(ref.path).startswith(proof_prefix):
            require(ref.path not in proof_refs or proof_refs[ref.path] == ref, "ref preuve contradictoire")
            proof_refs[ref.path] = ref
    require(len(proof_refs) == EXPECTED_PROOF_REFS and source_index_ref.path not in proof_refs,
            "cardinalité preuves/source INDEX différente")
    recipe_refs: dict[Path, Ref] = {}
    for item in recipe_index["files"]:
        ref = parsed_ref(item)
        require(str(ref.path).startswith(recipe_prefix) and ref.path.name != "INDEX.json"
                and ref.path not in recipe_refs, "recette chemin/doublon")
        recipe_refs[ref.path] = ref
    require(len(recipe_refs) == EXPECTED_RECIPE_REFS, "cardinalité recette différente")
    for ref in nested_refs(source_index):
        if str(ref.path).startswith(recipe_prefix):
            require(recipe_refs.get(ref.path) == ref, "ref recette source non jointe")

    selected = [Member("source-proofs/INDEX.json", source_index_ref)]
    selected += [Member("source-proofs/" + str(path)[len(proof_prefix):], ref)
                 for path, ref in sorted(proof_refs.items(), key=lambda pair: str(pair[0]))]
    selected += [Member("policy/policy.json", policy_ref), Member("recipe-v2/INDEX.json", recipe_index_ref)]
    selected += [Member("recipe-v2/" + str(path)[len(recipe_prefix):], ref)
                 for path, ref in sorted(recipe_refs.items(), key=lambda pair: str(pair[0]))]
    names = [item.name for item in selected]
    require(len(selected) == EXPECTED_MEMBERS and len(set(names)) == EXPECTED_MEMBERS,
            "nombre/doublon membre")
    for name in names:
        owned_member_name(name)
    require(all(item.ref.bytes <= MAX_INPUT_BYTES for item in selected), "membre >64 MB")
    require(sum(item.ref.bytes for item in selected) == EXPECTED_INPUT_BYTES
            and EXPECTED_INPUT_BYTES <= MAX_INPUT_BYTES, "volume brut hors borne")
    return selected


class HashingReader:
    def __init__(self, stream: BinaryIO, size: int) -> None:
        self.stream = stream
        self.remaining = size
        self.digest = hashlib.sha256()
        self.count = 0

    def read(self, requested: int = -1) -> bytes:
        if self.remaining == 0:
            return b""
        take = self.remaining if requested < 0 else min(self.remaining, requested)
        data = self.stream.read(take)
        self.remaining -= len(data)
        self.count += len(data)
        self.digest.update(data)
        return data


def create_archive(archive_path: Path, members: list[Member], preflight: dict[Path, Physical]) -> None:
    fd = os.open(archive_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, "wb") as output:
        with gzip.GzipFile(filename="", mode="wb", fileobj=output, mtime=0, compresslevel=6) as zipped:
            with tarfile.open(fileobj=zipped, mode="w|", format=tarfile.USTAR_FORMAT) as tar:
                for item in members:
                    require(physical(item.ref.path.lstat()) == preflight[item.ref.path],
                            "source modifiée avant tar: " + str(item.ref.path))
                    source_fd = os.open(item.ref.path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
                    with os.fdopen(source_fd, "rb") as source:
                        require(physical(os.fstat(source.fileno())) == preflight[item.ref.path],
                                "inode modifiée à l'ouverture tar")
                        info = tarfile.TarInfo(item.name)
                        info.size = item.ref.bytes
                        info.mode = 0o600
                        info.uid = info.gid = 0
                        info.uname = info.gname = ""
                        info.mtime = 0
                        info.type = tarfile.REGTYPE
                        stream = HashingReader(source, item.ref.bytes)
                        tar.addfile(info, stream)
                        require(stream.remaining == 0 and stream.count == item.ref.bytes
                                and stream.digest.hexdigest() == item.ref.sha256
                                and physical(os.fstat(source.fileno())) == preflight[item.ref.path],
                                "octets source changés pendant tar")
        output.flush()
        os.fsync(output.fileno())


def archive_ref(path: Path) -> Ref:
    st = path.lstat()
    require(stat.S_ISREG(st.st_mode) and st.st_nlink == 1 and path.resolve(strict=True) == path,
            "archive non régulière/canonique")
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(CHUNK), b""):
            digest.update(chunk)
    return Ref(path, digest.hexdigest(), st.st_size)


def audit_archive(archive: Ref, members: list[Member]) -> int:
    require(archive.bytes <= MAX_ARCHIVE_BYTES, "archive compressée >16 MB")
    # Lire jusqu'au trailer gzip vérifie aussi son CRC, sans extraire de fichier.
    uncompressed = 0
    with gzip.open(archive.path, "rb") as zipped:
        for chunk in iter(lambda: zipped.read(CHUNK), b""):
            uncompressed += len(chunk)
            require(uncompressed <= MAX_TAR_STREAM_BYTES, "flux tar >64 MB")
    with tarfile.open(archive.path, mode="r:gz") as tar:
        found = tar.getmembers()
        require([item.name for item in found] == [item.name for item in members],
                "tar membre absent/supplémentaire/réordonné")
        for stored, expected in zip(found, members):
            require(stored.isfile() and not stored.issym() and not stored.islnk()
                    and stored.size == expected.ref.bytes and stored.mode == 0o600
                    and stored.uid == stored.gid == stored.mtime == 0
                    and stored.uname == stored.gname == "" and stored.linkname == "",
                    "tar type/métadonnées non neutres")
            stream = tar.extractfile(stored)
            require(stream is not None, "tar membre illisible")
            digest = hashlib.sha256()
            length = 0
            with stream:
                for chunk in iter(lambda: stream.read(CHUNK), b""):
                    length += len(chunk)
                    require(length <= expected.ref.bytes, "tar membre déborde")
                    digest.update(chunk)
            require(length == expected.ref.bytes and digest.hexdigest() == expected.ref.sha256,
                    "tar contenu différent")
    return uncompressed


def write_json_exclusive(path: Path, payload: dict) -> Ref:
    encoded = (json.dumps(payload, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode()
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, "wb") as target:
        target.write(encoded)
        target.flush()
        os.fsync(target.fileno())
    return Ref(path, hashlib.sha256(encoded).hexdigest(), len(encoded))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()
    require(args.execute, "aucune archive sans --execute MAIN")
    require(Path("/private/tmp").resolve(strict=True) == Path("/private/tmp"), "TMP canonique absent")
    output = Path(tempfile.mkdtemp(prefix="therese-c17-source-qa-archive-", dir="/private/tmp"))
    require(stat.S_IMODE(output.lstat().st_mode) == 0o700 and output.resolve(strict=True) == output,
            "sortie non privée/canonique")
    result: dict = {"schema": "c17-source-qa-evidence-archive-receipt-v1", "status": "failed",
                    "scope": "archive_only_no_runtime_admission", "expected_head": HEAD,
                    "output_root": str(output), "source_checkout_copied": False,
                    "A_B_admitted": False, "FULL": False, "release": False,
                    "started_at_unix": time.time()}
    try:
        members = select_members()
        preflight = {item.ref.path: read_pinned(item.ref)[0] for item in members}
        manifest_ref = write_json_exclusive(output / "SELECTION.json", {
            "schema": "c17-source-qa-evidence-archive-selection-v1", "expected_head": HEAD,
            "members": [item.json() for item in members], "member_count": len(members),
            "total_input_bytes": sum(item.ref.bytes for item in members),
            "archive_mode": "explicit_regular_members_only_no_recursion"})
        archive_path = output / "source-qa-evidence.tar.gz"
        create_archive(archive_path, members, preflight)
        compressed = archive_ref(archive_path)
        tar_bytes = audit_archive(compressed, members)
        require(archive_ref(archive_path) == compressed, "archive changée après audit")
        for item in members:
            require(read_pinned(item.ref)[0] == preflight[item.ref.path],
                    "source modifiée après archive: " + str(item.ref.path))
        result.update({"status": "archive_verified", "member_count": len(members),
                       "total_input_bytes": EXPECTED_INPUT_BYTES, "uncompressed_tar_bytes": tar_bytes,
                       "selection_ref": manifest_ref.json(), "archive_ref": compressed.json(),
                       "source_before_after_same": True, "tar_members_sha_verified": True,
                       "gzip_crc_verified": True})
    except (Exception, KeyboardInterrupt) as error:
        result.update({"error_type": type(error).__name__, "error": str(error),
                       "partial_output_preserved": True})
    result["completed_at_unix"] = time.time()
    receipt = write_json_exclusive(output / "receipt.json", result)
    print(json.dumps({"receipt_ref": receipt.json(), "status": result["status"]}, sort_keys=True))
    return 0 if result["status"] == "archive_verified" else 86


if __name__ == "__main__":
    raise SystemExit(main())
