"""Définition préparatoire pure. Les deux fonctions sont incorporées au builder.

Aucun helper runtime supplémentaire ; aucun G1 complet importé.
"""
import ast
import hashlib


RUNTIME_FUNCTIONS = '''def effective_sandbox_command(root: Path, *, mode: str, stage: str,
                              template: list[str], expected_template: list[str],
                              identity: dict, expected_identity: dict) -> list[str]:
    """Dérivation fermée après admit_root ; aucun PID ou paramètre d'env futur."""
    require(type(template) is list and template == expected_template and template
            and all(type(x) is str and x and "\\x00" not in x for x in template)
            and template[0] == "/usr/bin/sandbox-exec", "Template sandbox non exact")
    require(not any("OWN_RENDEZVOUS_SERVICE" in token for token in template),
            "Paramètre OWN_RENDEZVOUS_SERVICE pré-birth/interpolé interdit")
    fields = ("pid", "start_sec", "start_usec", "ppid", "uid", "pgid")
    require(isinstance(identity, dict) and isinstance(expected_identity, dict)
            and all(type(identity.get(k)) is int and identity.get(k) == expected_identity.get(k)
                    for k in fields)
            and identity["pid"] > 0 and identity["start_sec"] > 0
            and 0 <= identity["start_usec"] < 1_000_000
            and identity["ppid"] > 0 and identity["uid"] >= 0
            and identity["pgid"] == identity["pid"], "Naissance effective divergente/invalide")
    if mode != "chrome":
        require(mode in ("web", "sql") and stage not in AUXILIARY_NAMES.values(),
                "Auxiliaire Chrome sous autre mode")
        return list(template)
    require(root == Path('/private/tmp/therese-c17-wrapper-canary-9c1f04187dd24519b220372284a739c9')
            and stage in AUXILIARY_NAMES.values()
            and identity.get("role") == "auxiliary-" + stage,
            "Paramètre rendezvous hors ROOT15/mode/stage Chrome exact")
    require(template.count("-f") == 1, "Profil sandbox absent/dupliqué")
    offset = template.index("-f")
    require(template[offset + 1:offset + 3] == [str(HERE / "chrome.sb"), str(CHROME)],
            "Template Chrome autre profil/exécutable")
    value = "com.google.Chrome.MachPortRendezvousServer." + str(identity["pid"])
    return template[:offset] + ["-D", "OWN_RENDEZVOUS_SERVICE=" + value] + template[offset:]


def checked_gate_effective_command(root: Path, *, binding: dict, stage: str, round_name: str,
                                   command: list[str], approved: dict,
                                   actual_identity: dict) -> list[str]:
    """Gate : recroise getpid et le binding ; rien n'est adopté depuis l'env."""
    require(isinstance(approved, dict) and approved.get("command_template") == command
            and approved.get("stage") == stage and approved.get("mode") in ("web", "sql", "chrome"),
            "Release template/stage/mode non exact")
    identity = approved.get("identity")
    require(isinstance(identity, dict) and isinstance(actual_identity, dict)
            and set(actual_identity) == {"pid", "ppid", "uid", "pgid"}
            and all(type(actual_identity[k]) is int and identity.get(k) == actual_identity[k]
                    for k in actual_identity), "Gate getpid/parent/UID/PGID différents")
    mode = approved["mode"]
    expected = command
    if mode == "chrome":
        require(round_name == "WRAPPER_CANARY" and stage in AUXILIARY_NAMES.values(),
                "Gate Chrome hors scope exact")
        spec = binding.get("commands", {}).get(stage)
        require(isinstance(spec, dict) and spec.get("mode") == "chrome"
                and spec.get("role") == "auxiliary-" + stage and spec.get("timeout_seconds") == 50,
                "Gate binding Chrome stage/mode/borne différents")
        expected = sandbox(root, "chrome", spec["argv"],
            source_root=Path(binding["product_source_root"]), qa_python=Path(binding["qa_python"]),
            chrome_context={"AUXILIARY_ROOT": str(root / "auxiliary" / stage),
                "HOME_ROOT": spec["env"]["HOME"], "TMP_ROOT": spec["env"]["TMPDIR"]})
    effective = effective_sandbox_command(root, mode=mode, stage=stage, template=command,
        expected_template=expected, identity=identity, expected_identity=approved.get("verified_before_release"))
    require(approved.get("effective_command") == effective,
            "Release argv effectif/PID/paramètre non exactement dérivé")
    return effective


'''


def g1_rendezvous_delta(source: str) -> str:
    """ROOT15 : post-admit_root uniquement ; reçus gardent template et effectif."""
    def replace_once(old, new):
        nonlocal source
        need(source.count(old) == 1, 'Ancre G1 rendezvous absente/dupliquée : ' + old[:70])
        source = source.replace(old, new, 1)
    before = source
    replace_once('def sandbox(root: Path, mode: str, command: list[str], *,',
                 RUNTIME_FUNCTIONS + 'def sandbox(root: Path, mode: str, command: list[str], *,')
    replace_once('entry = {"name": name, "role": role, "command": wrapped, "launch_command": launch,',
                 'entry = {"name": name, "role": role, "mode": mode, "command": wrapped, "effective_command": None, "launch_command": launch,')
    replace_once('                    entry["verified_before_release"] = before_release\n',
                 '                    entry["verified_before_release"] = before_release\n'
                 '                    entry["effective_command"] = effective_sandbox_command(self.root, mode=mode, stage=name,\n'
                 '                        template=wrapped, expected_template=wrapped, identity=identity, expected_identity=before_release)\n')
    replace_once('                                                     "gate": value, "identity": identity})',
                 '                                                     "gate": value, "identity": identity, "mode": mode, "stage": name,\n'
                 '                                                     "command_template": wrapped, "effective_command": entry["effective_command"],\n'
                 '                                                     "verified_before_release": before_release})')
    replace_once('                            "stage_id": name, "argv": command, "cwd": str(cwd), "environment": environment,',
                 '                            "stage_id": name, "argv": command, "cwd": str(cwd), "environment": environment,\n'
                 '                            "command_template": wrapped, "effective_command": entry["effective_command"], "mode": mode,')
    replace_once('            return process.pid == row["pid"] and self.ledger.records.get(self.ledger.key(row)) == row\n'
                 '        except (KeyError, TypeError):',
                 '            canonical = process.pid == row["pid"] and self.ledger.records.get(self.ledger.key(row)) == row\n'
                 '            return canonical and handle.get("effective_command") == effective_sandbox_command(\n'
                 '                self.root, mode=handle["mode"], stage=handle["name"], template=handle["command"],\n'
                 '                expected_template=handle["command"], identity=row, expected_identity=handle["verified_before_release"])\n'
                 '        except (KeyError, TypeError, ValueError, InstrumentError):')
    replace_once('                "release_ref": handle["release_ref"], "gated_command": handle["command"],',
                 '                "release_ref": handle["release_ref"], "gated_command": handle["command"],\n'
                 '                "command_template": handle["command"], "effective_command": handle["effective_command"],')
    replace_once('            "name": row["name"], "role": row["role"], "actor": self.actor, "round_id": self.round_id,',
                 '            "name": row["name"], "role": row["role"], "actor": self.actor, "round_id": self.round_id,\n'
                 '            "command_template": handle["command"], "effective_command": handle["effective_command"],')
    replace_once('            "leaf_receipt_ref": leaf_receipt_ref, "start_ref": handle["auxiliary_start_ref"], "stop_ref": stop_ref,',
                 '            "leaf_receipt_ref": leaf_receipt_ref, "start_ref": handle["auxiliary_start_ref"], "stop_ref": stop_ref,\n'
                 '            "command_template": handle["command"], "effective_command": handle["effective_command"],')
    replace_once('        require(start["name"] == stop["name"] == row["name"] and start["role"] == stop["role"] == row["role"]',
                 '        expected_effective = effective_sandbox_command(self.root, mode="chrome", stage=row["name"],\n'
                 '            template=aux_handle["command"], expected_template=aux_handle["command"],\n'
                 '            identity=aux_handle["root_identity"], expected_identity=aux_handle["verified_before_release"])\n'
                 '        require(all(raw.get("command_template") == aux_handle["command"]\n'
                 '                    and raw.get("effective_command") == expected_effective for raw in (start, stop, closure))\n'
                 '                and aux_handle["effective_command"] == expected_effective,\n'
                 '                "Join template/effective argv auxiliaire différent")\n'
                 '        require(start["name"] == stop["name"] == row["name"] and start["role"] == stop["role"] == row["role"]')
    left, right = ast.parse(before), ast.parse(source)
    allowed = {'start', '_released_birth', 'start_auxiliary_for_job', 'close_auxiliary_for_job', 'checked_auxiliary_terminal'}
    a = next(n for n in left.body if isinstance(n, ast.ClassDef) and n.name == 'Session')
    b = next(n for n in right.body if isinstance(n, ast.ClassDef) and n.name == 'Session')
    for name in allowed:
        old = next(n for n in a.body if isinstance(n, ast.FunctionDef) and n.name == name)
        new = next(n for n in b.body if isinstance(n, ast.FunctionDef) and n.name == name)
        b.body[b.body.index(new)] = old
    right.body = [n for n in right.body if not isinstance(n, ast.FunctionDef)
                  or n.name not in {'effective_sandbox_command', 'checked_gate_effective_command'}]
    need(ast.dump(left, include_attributes=False) == ast.dump(right, include_attributes=False),
         'Autre delta AST G1 interdit')
    validate_closed_g1(source)
    return source


def gate_rendezvous_delta(source: str) -> str:
    """Barrière réelle : assertions, hardlinks et délai5 conservés ; exec exact."""
    need(hashlib.sha256(source.encode()).hexdigest() ==
         '864e1994c0fe7252aef2492b498d18c5dbcb5091d9b8e29b971b4b08108c1e8c',
         'Préimage gate différente')
    old_import = 'from runtime_session import load_admission'
    old_exec = 'os.execve(command[0], command, os.environ)'
    need(source.count(old_import) == source.count(old_exec) == 1, 'Ancres gate non uniques')
    derived = source.replace(old_import, old_import + ', checked_gate_effective_command', 1)
    new_exec = ('effective_command = checked_gate_effective_command(root, binding=binding, stage=stage,\n'
                '    round_name=os.environ["C17_SESSION_ROUND_NAME"], command=command, approved=approved,\n'
                '    actual_identity={"pid": os.getpid(), "ppid": os.getppid(), "uid": os.getuid(), "pgid": os.getpgrp()})\n'
                'if time.monotonic() >= deadline:\n'
                '    raise SystemExit("barrier_autonomous_timeout_no_workload")\n'
                'os.execve(effective_command[0], effective_command, os.environ)')
    derived = derived.replace(old_exec, new_exec, 1)
    need(derived.replace(new_exec, old_exec, 1).replace(old_import + ', checked_gate_effective_command', old_import, 1) == source,
         'Delta gate hors deux ancres exactes')
    ast.parse(derived)
    return derived
