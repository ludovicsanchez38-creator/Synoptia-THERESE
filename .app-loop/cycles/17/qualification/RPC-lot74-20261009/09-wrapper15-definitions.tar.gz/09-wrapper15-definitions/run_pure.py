"""Runner pur avec acteur CLI explicite ; jamais constructeur ni profil compilé."""
from __future__ import annotations
import argparse
import contextlib
from datetime import datetime, UTC
import hashlib
import json
import os
from pathlib import Path
import re
import socket
import subprocess
import sys
import tempfile
import unittest
import unittest.mock

HERE = Path(__file__).resolve().parent

def reference(path):
    data = path.read_bytes()
    return {'path': str(path), 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--actor', required=True)
    args = parser.parse_args()
    if args.actor not in ('/root/shared4_execution', '/root', '/root/environment_routes', '/root/cycle17_gate_review'):
        parser.error('Acteur canonique de la CLI obligatoire ; aucun alias fixture')
    attempted = []
    def deny(name):
        def fail(*args, **kwargs):
            attempted.append(name)
            raise RuntimeError('Opération interdite en pur : ' + name)
        return fail
    for owner, names in ((subprocess, ('Popen', 'run')), (socket, ('socket',)), (os, ('system', 'execve', 'kill'))):
        for name in names: setattr(owner, name, deny(name))
    paths = [HERE / 'build_fresh_wrapper.py', HERE / 'rendezvous_delta.py', HERE / 'run_pure.py',
             HERE / 'tests/test_wrapper15_static.py', HERE / 'profile/chrome.sb',
             *sorted((HERE / 'preimages').glob('*')), *sorted((HERE / 'preview').glob('*'))]
    paths += [Path('/private/tmp/therese-c17-wrapper14-chromium-tmp-SYH6Mx') / name
              for name in ('INDEX.json', 'build_fresh_wrapper.py', 'profile/chrome.sb', 'preview/runtime_session-after-env.py')]
    paths += [Path('/private/tmp/therese-c17-rpc-integration-UctqC8UG/g1-26/runtime_launch_gate.py')]
    before = [reference(p) for p in paths if p.is_file()]
    started = datetime.now(UTC).isoformat()
    (HERE / 'proofs').mkdir(exist_ok=True)
    output = Path(tempfile.mkdtemp(prefix='pure-', dir=HERE / 'proofs'))
    with (output / 'stdout.log').open('x') as stdout, (output / 'stderr.log').open('x') as stderr:
        with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
            suite = unittest.defaultTestLoader.discover(str(HERE / 'tests'))
            def ids(s):
                return sum((ids(t) if isinstance(t, unittest.TestSuite) else [t.id()] for t in s), [])
            test_ids = ids(suite)
            result = unittest.TextTestRunner(stream=stderr, verbosity=2).run(suite)
        stdout.flush(); stderr.flush(); os.fsync(stdout.fileno()); os.fsync(stderr.fileno())
    after = [reference(p) for p in paths if p.is_file()]
    forbidden_imports = sorted(n for n in sys.modules if n == 'runtime_session' or n == 'app' or n.startswith('app.'))
    success = result.wasSuccessful() and before == after and not attempted and not forbidden_imports
    receipt = {'schema': 'c17-wrapper15-own-rendezvous-pure-tests-v1', 'actor': args.actor,
        'command': [sys.executable, '-B', str(HERE / 'run_pure.py'), '--actor', args.actor],
        'started_at': started, 'completed_at': datetime.now(UTC).isoformat(), 'tests': result.testsRun,
        'test_ids': test_ids, 'failures': len(result.failures), 'errors': len(result.errors), 'skipped': len(result.skipped),
        'passed': success, 'exit_code': 0 if success else 1, 'source_before': before, 'source_after': after,
        'sources_unchanged': before == after, 'stdout_ref': reference(output / 'stdout.log'),
        'stderr_ref': reference(output / 'stderr.log'), 'forbidden_attempts': attempted,
        'forbidden_imports': forbidden_imports, 'fixture_identity': 'explicit_synthetic_births_paths_ledger_Popen_FDs_clock_and_receipts',
        'native_executed': False, 'G1_imported': False, 'constructor_invoked': False,
        'profile_compiled': False, 'FULL': False, 'release': False}
    (output / 'receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, sort_keys=True, indent=2) + '\n')
    print(json.dumps({'receipt_ref': reference(output / 'receipt.json'), 'tests': result.testsRun, 'passed': success}, sort_keys=True))
    return 0 if success else 1

if __name__ == '__main__':
    raise SystemExit(main())
