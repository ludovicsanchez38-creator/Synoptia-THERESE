"""Vrais corps sélectionnés + doubles synthétiques, sans import G1 complet."""
from __future__ import annotations
import ast
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import re
from types import SimpleNamespace
import unittest

HERE = Path(__file__).resolve().parents[1]
BASE = Path('/private/tmp/therese-c17-wrapper14-chromium-tmp-SYH6Mx')
spec = importlib.util.spec_from_file_location('wrapper15_builder_definition_only', HERE / 'build_fresh_wrapper.py')
builder = importlib.util.module_from_spec(spec)
spec.loader.exec_module(builder)
SOURCE = (HERE / 'preview/runtime_session.py').read_text()
TREE = ast.parse(SOURCE)
STAGE = 'aux-chrome-' + builder.JOBS[0]


class SyntheticPath(type(Path())):
    def resolve(self, strict=False):
        return self

    def is_dir(self):
        return True

    def mkdir(self, **kwargs):
        return None


class SyntheticInstrumentError(RuntimeError):
    pass


def require(ok, message):
    if not ok:
        raise SyntheticInstrumentError(message)


def template_for(root, mode, command, **kwargs):
    return ['/usr/bin/sandbox-exec', '-D', 'QA_ROOT=' + str(root),
            '-D', 'SOURCE_ROOT=' + str(builder.QA), '-f', str(root / 'g1' / (mode + '.sb')), *command]


def selected():
    names = {'CHROME_JOBS', 'AUXILIARY_NAMES', 'STAGE_TIMEOUTS', 'PERSISTENT',
             'AUXILIARY_ROLES', 'RPC_CHILDREN', 'RPC_REQUESTERS', 'WRAPPER_PARENTS',
             'WRAPPER_STAGES', 'ENV_CONSTANTS', 'ENV_PATHS', 'ENV_CONTEXT', 'REQUIRED_ENV', 'WRAPPER_PATTERN'}
    nodes = []
    for node in TREE.body:
        if isinstance(node, ast.FunctionDef) and node.name in {
                'effective_sandbox_command', 'checked_gate_effective_command', 'validate_environment'}:
            nodes.append(node)
        elif isinstance(node, (ast.Assign, ast.AnnAssign)):
            target = node.target if isinstance(node, ast.AnnAssign) else node.targets[0]
            if isinstance(target, ast.Name) and target.id in names:
                nodes.append(node)
    real_class = next(n for n in TREE.body if isinstance(n, ast.ClassDef) and n.name == 'Session')
    methods = [copy.deepcopy(n) for n in real_class.body if isinstance(n, ast.FunctionDef)
               and n.name in {'start', '_released_birth', 'checked_auxiliary_terminal'}]
    for node in methods:
        node.decorator_list = []
    nodes.append(ast.ClassDef(name='SelectedSession', bases=[], keywords=[], body=methods, decorator_list=[]))
    namespace = {'Path': SyntheticPath, 'require': require, 'InstrumentError': SyntheticInstrumentError,
        're': re, 'json': json, 'SOURCE': builder.QA, 'HEAD': builder.HEAD,
        'HERE': SyntheticPath(builder.FUTURE_ROOT / 'g1'),
        'CHROME': SyntheticPath(builder.CHROME), 'PYTHON': builder.QA / '.venv-conforme/bin/python',
        'NODE_ROOT': Path('/Users/synoptia/.nvm/versions/node/v22.19.0'), 'PUBLICATION_PROTOCOL': 'exclusive-pending-fsync-hardlink-v1',
        'sandbox': template_for, 'child_path': lambda root, path: path,
        'now': lambda: 'synthetic-time-not-native', 'CAPABILITIES': {'nested_timeout_handshake': False, 'nested_normal_completion_stable_fd': False},
        'os': SimpleNamespace(getpid=lambda: 9001, getuid=lambda: 501, fsync=lambda fd: None)}
    exec(compile(ast.fix_missing_locations(ast.Module(nodes, type_ignores=[])), '<actual-selected-G1-bodies>', 'exec'), namespace)
    return namespace


def identity(pid=12345):
    return {'pid': pid, 'start_sec': 1791500000, 'start_usec': 222333, 'ppid': 9001,
            'uid': 501, 'pgid': pid, 'status': 2, 'role': 'auxiliary-' + STAGE}


def environment():
    folder = builder.FUTURE_ROOT / 'auxiliary' / STAGE
    return {'__CF_USER_TEXT_ENCODING': '0x1F5:0:0', 'PATH': str(builder.NODE.parent) + ':/usr/bin:/bin:/usr/sbin:/sbin',
            'HOME': str(folder / 'home'), 'CFFIXED_USER_HOME': str(folder / 'home'),
            'TMPDIR': str(folder / 'tmp'), 'MAC_CHROMIUM_TMPDIR': str(folder / 'tmp'),
            'LANG': 'en_US.UTF-8', 'LC_ALL': 'en_US.UTF-8', 'PYTHONNOUSERSITE': '1',
            'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONPATH': str(builder.QA) + ':' + str(builder.QA / 'src/backend')}


def command_spec():
    return {'argv': [str(builder.CHROME), '--remote-debugging-port=17594'],
            'role': 'auxiliary-' + STAGE, 'mode': 'chrome', 'timeout_seconds': 50,
            'env': environment(), 'cwd': str(builder.FUTURE_ROOT),
            'stdout_path': str(builder.FUTURE_ROOT / 'auxiliary' / STAGE / 'stdout.log'),
            'stderr_path': str(builder.FUTURE_ROOT / 'auxiliary' / STAGE / 'stderr.log'),
            'combine_stderr': False, 'derived_deadline': 'start_monotonic_plus_exact_timeout'}


class Wrapper15(unittest.TestCase):
    def setUp(self):
        self.ns = selected()
        self.root = SyntheticPath(builder.FUTURE_ROOT)
        self.row = identity()
        self.spec = command_spec()
        self.template = template_for(self.root, 'chrome', self.spec['argv'])
        self.effective = self.ns['effective_sandbox_command'](self.root, mode='chrome', stage=STAGE,
            template=self.template, expected_template=self.template, identity=self.row, expected_identity=self.row)
        self.approved = {'identity': copy.deepcopy(self.row), 'verified_before_release': copy.deepcopy(self.row),
            'mode': 'chrome', 'stage': STAGE, 'command_template': self.template, 'effective_command': self.effective}
        self.binding = {'commands': {STAGE: self.spec}, 'product_source_root': str(builder.QA),
                        'qa_python': str(builder.QA / '.venv-conforme/bin/python')}

    def gate(self, **kwargs):
        arguments = {'binding': self.binding, 'stage': STAGE, 'round_name': 'WRAPPER_CANARY',
                     'command': self.template, 'approved': self.approved,
                     'actual_identity': {k: self.row[k] for k in ('pid', 'ppid', 'uid', 'pgid')}}
        arguments.update(kwargs)
        return self.ns['checked_gate_effective_command'](self.root, **arguments)

    def derived(self, **kwargs):
        arguments = {'mode': 'chrome', 'stage': STAGE, 'template': self.template,
                     'expected_template': self.template, 'identity': self.row, 'expected_identity': self.row}
        arguments.update(kwargs)
        return self.ns['effective_sandbox_command'](self.root, **arguments)

    def refused(self, function):
        with self.assertRaises(SyntheticInstrumentError):
            function()

    def test_01_origins_byte_exact(self):
        for rel, original in [('build_fresh_wrapper-14.py', BASE / 'build_fresh_wrapper.py'),
                ('runtime_session-14.py', BASE / 'preview/runtime_session-after-env.py'),
                ('chrome-14.sb', BASE / 'profile/chrome.sb'), ('INDEX-14.json', BASE / 'INDEX.json'),
                ('runtime_launch_gate-before.py', builder.PREP / 'g1-26/runtime_launch_gate.py')]:
            self.assertEqual((HERE / 'preimages' / rel).read_bytes(), original.read_bytes())

    def test_02_profile_only_single_parameterized_rule(self):
        before = (HERE / 'preimages/chrome-14.sb').read_bytes()
        after = (HERE / 'profile/chrome.sb').read_bytes()
        rule = b'(allow mach-register (global-name (param "OWN_RENDEZVOUS_SERVICE")))\n'
        self.assertEqual(after, before + rule)
        self.assertEqual(after.count(b'mach-register'), 1)
        self.assertEqual(after.count(b'OWN_RENDEZVOUS_SERVICE'), 1)
        self.assertEqual(after.count(b'('), after.count(b')'))

    def test_03_current_head_not_relabelled_and_root_unallocated(self):
        self.assertEqual(builder.HEAD, '2d69e30c9c6dd18823ee6102271876003a6a67cc')
        self.assertEqual(str(builder.FUTURE_ROOT), '/private/tmp/therese-c17-wrapper-canary-9c1f04187dd24519b220372284a739c9')
        self.assertFalse(builder.FUTURE_ROOT.exists())
        self.assertFalse(builder.FUTURE_ROOT.is_symlink())

    def test_04_actual_derivation_reproduces_whole_preview(self):
        before = (HERE / 'preview/runtime_session-before-rendezvous.py').read_text()
        self.assertEqual(builder.g1_rendezvous_delta(before), SOURCE)
        raw = (builder.PREP / 'g1-26/runtime_session.py').read_text()
        derived = builder.g1_chromium_tmpdir_delta(builder.g1_auxiliary_parent_delta(
            builder.g1_chrome_executable_guard(builder.g1_chrome_copy_delta(raw))))
        self.assertEqual(derived, before)
        builder.validate_closed_g1(SOURCE)

    def test_05_gate_derivation_reproduces_whole_source(self):
        self.assertEqual(builder.gate_rendezvous_delta((HERE / 'preimages/runtime_launch_gate-before.py').read_text()),
                         (HERE / 'preview/runtime_launch_gate.py').read_text())

    def test_06_template_has_no_future_pid_effective_has_unique_D(self):
        self.assertFalse(any('OWN_RENDEZVOUS_SERVICE' in x for x in self.template))
        at = self.template.index('-f')
        self.assertEqual(self.effective, self.template[:at] + ['-D',
            'OWN_RENDEZVOUS_SERVICE=com.google.Chrome.MachPortRendezvousServer.12345'] + self.template[at:])
        self.assertEqual(self.gate(), self.effective)

    def test_07_exact_five_stages(self):
        for job in builder.JOBS:
            stage = 'aux-chrome-' + job
            row = self.row | {'role': 'auxiliary-' + stage}
            self.assertIn('OWN_RENDEZVOUS_SERVICE=com.google.Chrome.MachPortRendezvousServer.12345',
                          self.derived(stage=stage, identity=row, expected_identity=row))

    def test_08_wrong_actual_pid_rejected(self):
        actual = {k: self.row[k] for k in ('pid', 'ppid', 'uid', 'pgid')}; actual['pid'] += 1
        self.refused(lambda: self.gate(actual_identity=actual))

    def test_09_pid_not_positive_integer_rejected(self):
        for value in (0, -1, True, 12345.0, '12345'):
            row = self.row | {'pid': value, 'pgid': value}
            self.refused(lambda: self.derived(identity=row, expected_identity=row))

    def test_10_each_birth_field_divergence_rejected(self):
        for field in ('pid', 'start_sec', 'start_usec', 'ppid', 'uid', 'pgid'):
            with self.subTest(field=field):
                row = self.row | {field: self.row[field] + 1}
                self.refused(lambda: self.derived(expected_identity=row))

    def test_11_wrong_stage_and_mode_rejected(self):
        for stage in ('backend', builder.JOBS[0], 'aux-chrome-unknown'):
            self.refused(lambda: self.derived(stage=stage))
        for mode in ('sql', 'web', 'unknown'):
            self.refused(lambda: self.derived(mode=mode))

    def test_12_other_root_rejected(self):
        self.refused(lambda: self.ns['effective_sandbox_command'](SyntheticPath('/private/tmp/therese-c17-wrapper-canary-other'),
            mode='chrome', stage=STAGE, template=self.template, expected_template=self.template,
            identity=self.row, expected_identity=self.row))

    def test_13_foreign_profile_or_executable_rejected(self):
        for offset in (self.template.index('-f') + 2, self.template.index('-f') + 1):
            command = self.template.copy(); command[offset] = '/synthetic/foreign'
            self.refused(lambda: self.derived(template=command, expected_template=command))

    def test_14_altered_template_vs_binding_rejected(self):
        changed = self.template + ['--new-argument']
        self.refused(lambda: self.derived(template=changed))
        approved = self.approved | {'command_template': changed}
        self.refused(lambda: self.gate(command=changed, approved=approved))

    def test_15_prebirth_or_double_parameter_rejected(self):
        for command in (self.effective, self.effective + ['-D', 'OWN_RENDEZVOUS_SERVICE=foreign']):
            self.refused(lambda: self.derived(template=command, expected_template=command))

    def test_16_foreign_missing_double_or_wrong_pid_effective_rejected(self):
        variants = [self.template, self.effective + ['-D', 'OWN_RENDEZVOUS_SERVICE=foreign'],
            [x.replace('.12345', '.12346') for x in self.effective],
            [x.replace('com.google.Chrome.', 'com.foreign.') for x in self.effective]]
        for command in variants:
            self.refused(lambda: self.gate(approved=self.approved | {'effective_command': command}))

    def test_17_release_stage_mode_scope_rejected(self):
        self.refused(lambda: self.gate(approved=self.approved | {'stage': 'backend'}))
        self.refused(lambda: self.gate(approved=self.approved | {'mode': 'sql'}))
        self.refused(lambda: self.gate(round_name='A'))

    def test_18_binding_role_mode_bound_rejected(self):
        for key, value in [('mode', 'web'), ('role', 'stage-' + STAGE), ('timeout_seconds', 51)]:
            spec = self.spec | {key: value}
            self.refused(lambda: self.gate(binding=self.binding | {'commands': {STAGE: spec}}))

    def test_19_gate_parent_uid_pgid_rejected(self):
        for key in ('ppid', 'uid', 'pgid'):
            actual = {k: self.row[k] for k in ('pid', 'ppid', 'uid', 'pgid')}; actual[key] += 1
            self.refused(lambda: self.gate(actual_identity=actual))

    def test_20_last_birth_or_missing_recheck_rejected(self):
        self.refused(lambda: self.gate(approved=self.approved | {'verified_before_release': self.row | {'start_usec': 222334}}))
        approved = self.approved.copy(); approved.pop('verified_before_release')
        self.refused(lambda: self.gate(approved=approved))

    def test_21_ordinary_modes_no_parameter_no_argv_change(self):
        for mode in ('web', 'sql'):
            command = template_for(self.root, mode, ['synthetic-python', 'witness.py'])
            row = self.row | {'role': 'stage-witness'}
            self.assertEqual(self.ns['effective_sandbox_command'](self.root, mode=mode, stage='witness',
                template=command, expected_template=command, identity=row, expected_identity=row), command)

    def test_22_free_environment_own_parameter_rejected(self):
        env = environment(); env['OWN_RENDEZVOUS_SERVICE'] = 'com.google.Chrome.MachPortRendezvousServer.12345'
        self.refused(lambda: self.ns['validate_environment'](self.root, env, 'chrome', '/root', self.root.name,
            source_root=builder.QA, stage=STAGE))

    def start_double(self, mutate_birth=False):
        trace, publications, saves = [], [], []
        row = self.row.copy()
        process = SimpleNamespace(pid=row['pid'], poll=lambda: None)
        class Stream:
            closed = False
            def close(self): self.closed = True
        class Ledger:
            records = {(row['pid'], row['start_sec'], row['start_usec']): row}
            owner = {'synthetic': True}
            def admit_root(self, pid, role): trace.append('admit_root'); return row
            def attribute(self): trace.append('attribute')
            def info(self, pid):
                trace.append('info')
                return row | {'start_usec': row['start_usec'] + (1 if mutate_birth else 0)}
            def unchanged(self, a, b): return all(a[k] == b[k] for k in ('pid', 'start_sec', 'start_usec', 'ppid', 'uid', 'pgid'))
            def executable(self, pid): return str(builder.QA / '.venv-conforme/bin/python')
            def key(self, r): return r['pid'], r['start_sec'], r['start_usec']
        def popen(*args, **kwargs): trace.append('synthetic_popen'); return process
        ns = self.ns
        ns['subprocess'] = SimpleNamespace(Popen=popen, DEVNULL='synthetic-devnull')
        ns['time'] = SimpleNamespace(monotonic=lambda: 100.0, sleep=lambda value: None)
        ns['exclusive'] = lambda path: Stream()
        ns['reference'] = lambda path: {'path': str(path), 'sha256': '1' * 64, 'bytes': 1}
        decision = {'decision_id': 'synthetic-only'}
        binding = self.binding | {'git_snapshot_ref': {'synthetic': True}}
        ns['load_admission'] = lambda *args, **kw: (decision, binding)
        def gate(path):
            entry = session.handles[STAGE]
            trace.append('gate_published_synthetic')
            return {'pid': row['pid'], 'ppid': 9001, 'uid': row['uid'], 'pgid': row['pgid'],
                'command': entry['command'], 'qa_root': str(self.root), 'actor': '/root',
                'round_id': self.root.name, 'head': builder.HEAD, 'stage': STAGE,
                'decision_id': decision['decision_id'], 'binding_sha256': '2' * 64}
        ns['read_published_json'] = lambda root, path: gate(path)
        ns['publish_json'] = lambda root, path, value: (trace.append('release'), publications.append(copy.deepcopy(value)))
        ns['save'] = lambda root, path, value: saves.append(copy.deepcopy(value))
        original_is_file = SyntheticPath.is_file
        SyntheticPath.is_file = lambda path: True
        session = ns['SelectedSession']()
        session.root = self.root; session.actor = '/root'; session.round_id = self.root.name; session.round_name = 'WRAPPER_CANARY'
        session.decision = decision; session.binding = binding; session.decision_ref = {'synthetic': True}; session.binding_ref = {'sha256': '2' * 64}
        session.head = builder.HEAD; session.product_source_root = SyntheticPath(builder.QA)
        session.qa_python = SyntheticPath(builder.QA / '.venv-conforme/bin/python')
        session.handles = {}; session.closed = False; session._handlers_restored = False; session.close_attempts = 0
        session.services_stopped = False; session._stage_admissions = {}; session._rpc_dispatcher = None
        session.ledger = Ledger(); session.prelaunch_errors = []; session.log_stability_tainted = False
        session.validate_sources = lambda: trace.append('validate_sources')
        session._raise_deferred_interrupt = lambda: None
        try:
            entry = session.start(STAGE, self.spec['role'], self.spec['argv'], mode='chrome', timeout=50,
                env=environment(), cwd=self.root, stdout_path=SyntheticPath(self.spec['stdout_path']),
                stderr_path=SyntheticPath(self.spec['stderr_path']))
        finally:
            SyntheticPath.is_file = original_is_file
        return session, entry, trace, publications, saves

    def test_23_actual_start_capture_then_effective_then_release(self):
        session, entry, trace, releases, saves = self.start_double()
        self.assertLess(trace.index('synthetic_popen'), trace.index('admit_root'))
        self.assertLess(trace.index('admit_root'), trace.index('release'))
        self.assertEqual(len(releases), 1)
        self.assertEqual(entry['command'], self.template)
        self.assertEqual(entry['effective_command'], self.effective)
        self.assertEqual(releases[0]['command_template'], entry['command'])
        self.assertEqual(releases[0]['effective_command'], entry['effective_command'])
        self.assertEqual(releases[0]['verified_before_release'], entry['verified_before_release'])
        self.assertTrue(session._released_birth(entry))

    def test_24_actual_start_birth_divergence_refuses_release(self):
        self.refused(lambda: self.start_double(mutate_birth=True))

    def test_25_start_service_receipt_keeps_template_and_effective(self):
        _, entry, _, _, saves = self.start_double()
        self.assertEqual(len(saves), 1)
        self.assertEqual(saves[0]['command_template'], entry['command'])
        self.assertEqual(saves[0]['effective_command'], entry['effective_command'])
        self.assertEqual(saves[0]['argv'], self.spec['argv'])
        self.assertNotIn('OWN_RENDEZVOUS_SERVICE', entry['environment'])
        self.assertEqual(entry['timeout_seconds'], 50)

    def test_26_released_birth_rejects_effective_or_template_mutation(self):
        session, entry, *_ = self.start_double()
        for key in ('effective_command', 'command'):
            mutated = entry | {key: entry[key] + ['unreviewed']}
            self.assertFalse(session._released_birth(mutated))
        mutated = entry | {'verified_before_release': self.row | {'start_sec': self.row['start_sec'] + 1}}
        self.assertFalse(session._released_birth(mutated))

    def closure_double(self):
        ns = self.ns; session = ns['SelectedSession']()
        refs = {name: {'path': '/synthetic/' + name, 'sha256': '3' * 64, 'bytes': 1} for name in ('leaf', 'closure', 'start', 'stop')}
        handle = {'command': self.template, 'effective_command': self.effective, 'root_identity': self.row,
                  'verified_before_release': self.row, 'auxiliary_start_ref': refs['start'],
                  'termination_proved': True, 'output_archived': True, 'role': 'auxiliary-' + STAGE}
        context = {'actor': '/root', 'round_id': self.root.name, 'head': builder.HEAD,
                   'binding_sha256': '2' * 64, 'root_identity': self.row,
                   'command_template': self.template, 'effective_command': self.effective}
        start = context | {'name': STAGE, 'role': handle['role'], 'released': True}
        stop = context | {'name': STAGE, 'role': handle['role'], 'controller_signals_attributed': True,
                          'raw_stable': True, 'taint': False}
        closure = context | {'schema': 'c17-g1-rpc-auxiliary-closure-v1', 'scope': 'WRAPPER_CANARY', 'job': builder.JOBS[0],
            'leaf_receipt_ref': refs['leaf'], 'start_ref': refs['start'], 'stop_ref': refs['stop'],
            'termination_proved': True, 'output_archived': True, 'cleanup_clean': True, 'cleanup_deadline_met': True,
            'remaining_attributed': [], 'ambiguities': [], 'errors': [], 'cleanup_elapsed_seconds': 0.125,
            'port_absent': 17594, 'log_stability_proved': True, 'tainted': False}
        objects = {'start': start, 'stop': stop, 'closure': closure,
                   'leaf': {'stage_id': builder.JOBS[0], 'raw_stable': True, 'instrument_error': None, 'exit_code': 0}}
        ns['checked_json_ref'] = lambda ref, root: objects[Path(ref['path']).name]
        ns['AUXILIARY_PORT'] = 17594
        session.root=self.root; session.actor='/root'; session.round_id=self.root.name; session.head=builder.HEAD
        session.round_name='WRAPPER_CANARY'; session.binding_ref={'sha256': '2' * 64}; session.log_stability_tainted=False
        session.binding={'auxiliary_descriptors': {builder.JOBS[0]: {'name': STAGE, 'role': handle['role']}}}
        session.handles={STAGE: handle, builder.JOBS[0]: {'auxiliary_terminal_ref': refs['closure'], 'terminal_receipt_ref': refs['leaf']}}
        session.ledger=SimpleNamespace(residuals=lambda roles: []); session._execution_scope=lambda: 'synthetic-only'
        return session, refs, objects

    def test_27_actual_closure_join_accepts_exact_effective(self):
        session, refs, _ = self.closure_double()
        self.assertTrue(session.checked_auxiliary_terminal(builder.JOBS[0], refs['leaf'])['normal_success_claimed'])

    def test_28_each_closure_representation_mutation_rejected(self):
        for raw in ('start', 'stop', 'closure'):
            for key in ('effective_command', 'command_template'):
                session, refs, objects = self.closure_double()
                objects[raw][key] = objects[raw][key] + ['unreviewed']
                self.refused(lambda: session.checked_auxiliary_terminal(builder.JOBS[0], refs['leaf']))

    def test_29_actual_gate_exec_uses_checked_effective_and_retains_deadline(self):
        tree = ast.parse((HERE / 'preview/runtime_launch_gate.py').read_text())
        nodes = tree.body[-3:]
        calls = []
        ns = {'checked_gate_effective_command': self.ns['checked_gate_effective_command'], 'root': self.root,
            'binding': self.binding, 'stage': STAGE, 'command': self.template, 'approved': self.approved,
            'os': SimpleNamespace(environ={'C17_SESSION_ROUND_NAME': 'WRAPPER_CANARY'}, getpid=lambda: self.row['pid'],
                getppid=lambda: self.row['ppid'], getuid=lambda: 501, getpgrp=lambda: self.row['pgid'],
                execve=lambda exe, argv, env: calls.append((exe, argv))),
            'time': SimpleNamespace(monotonic=lambda: 100), 'deadline': 105}
        exec(compile(ast.Module(nodes, type_ignores=[]), '<actual-gate-preexec-tail>', 'exec'), ns)
        self.assertEqual(calls, [('/usr/bin/sandbox-exec', self.effective)])
        ns['deadline'] = 100; calls.clear()
        with self.assertRaises(SystemExit):
            exec(compile(ast.Module(nodes, type_ignores=[]), '<actual-gate-expired-tail>', 'exec'), ns)
        self.assertEqual(calls, [])

    def test_30_foreign_role_rejected(self):
        self.refused(lambda: self.derived(identity=self.row | {'role': 'persistent-backend'}, expected_identity=self.row))

    def test_31_anchors_mutated_or_duplicate_refused(self):
        source = (HERE / 'preview/runtime_session-before-rendezvous.py').read_text()
        for mutant in (source + source, source.replace('entry["verified_before_release"] = before_release', 'entry["verified_before_release"] = None')):
            with self.assertRaises(ValueError): builder.g1_rendezvous_delta(mutant)
        gate = (HERE / 'preimages/runtime_launch_gate-before.py').read_text()
        with self.assertRaises(ValueError): builder.gate_rendezvous_delta(gate + '\n')

    def test_32_global_flags_tables_and_env_allowlists_unchanged(self):
        builder.validate_closed_g1(SOURCE)
        before = ast.parse((HERE / 'preview/runtime_session-before-rendezvous.py').read_text())
        after = ast.parse(SOURCE)
        globals_a = [ast.dump(n, include_attributes=False) for n in before.body if isinstance(n, (ast.Assign, ast.AnnAssign))]
        globals_b = [ast.dump(n, include_attributes=False) for n in after.body if isinstance(n, (ast.Assign, ast.AnnAssign))]
        self.assertEqual(globals_a, globals_b)

    def test_33_builder_core_counts_oracles_unchanged(self):
        old = ast.parse((HERE / 'preimages/build_fresh_wrapper-14.py').read_text())
        new = ast.parse((HERE / 'build_fresh_wrapper.py').read_text())
        exempt = {'build', 'checked_chrome_successor'}
        old_fn = {n.name: ast.dump(n, include_attributes=False) for n in old.body if isinstance(n, ast.FunctionDef)}
        new_fn = {n.name: ast.dump(n, include_attributes=False) for n in new.body if isinstance(n, ast.FunctionDef)}
        for name in old_fn.keys() - exempt:
            self.assertEqual(old_fn[name], new_fn[name], name)
        self.assertEqual(len(builder.CORE_G1), 9); self.assertEqual(len(builder.CORE_TRANSPORT), 6)
        self.assertEqual(len(builder.JOBS), 5)

    def test_34_invalid_microseconds_and_pgid_rejected(self):
        for row in (self.row | {'start_usec': -1}, self.row | {'start_usec': 1_000_000}, self.row | {'pgid': 1}):
            self.refused(lambda: self.derived(identity=row, expected_identity=row))

    def test_35_invalid_duplicate_profile_rejected(self):
        command = self.template + ['-f', str(self.root / 'g1/chrome.sb')]
        self.refused(lambda: self.derived(template=command, expected_template=command))

    def test_36_mutated_binding_argv_rejected(self):
        spec = self.spec | {'argv': self.spec['argv'] + ['--foreign']}
        self.refused(lambda: self.gate(binding=self.binding | {'commands': {STAGE: spec}}))

    def test_37_unreleased_unattributed_or_pid_changed_handle_rejected(self):
        session, entry, *_ = self.start_double()
        for mutant in (entry | {'released': False}, entry | {'process': None},
                       entry | {'root_identity': self.row | {'start_sec': 1}}):
            self.assertFalse(session._released_birth(mutant))

    def test_38_runtime_derivation_definition_embedded_exact(self):
        local = ast.parse((HERE / 'rendezvous_delta.py').read_text())
        whole = ast.parse((HERE / 'build_fresh_wrapper.py').read_text())
        for name in ('g1_rendezvous_delta', 'gate_rendezvous_delta'):
            left = next(n for n in local.body if isinstance(n, ast.FunctionDef) and n.name == name)
            right = next(n for n in whole.body if isinstance(n, ast.FunctionDef) and n.name == name)
            self.assertEqual(ast.dump(left, include_attributes=False), ast.dump(right, include_attributes=False))


if __name__ == '__main__':
    unittest.main(verbosity=2)
