# WRAPPER15, proposition fermée de rendezvous propre PID

Auteur : `/root/shared4_execution`. Ce dossier est préparatoire. Aucun ROOT15,
GO, admission, compilation Seatbelt, G1 complet, Chrome, service ou campagne
n'a été lancé par son auteur. Le microcanari autonome de l'autre acteur n'est
ni consommé ni qualifié ici.

## Périmètre exact

Origine immuable : `wrapper14-chromium-tmp-SYH6Mx`, builder
`b2e3a75cf1a2a090087f967115c105f098b28cd602744a5d951f502277c09e02`.
La future racine littérale a été choisie par MAIN et reste absente :
`/private/tmp/therese-c17-wrapper-canary-9c1f04187dd24519b220372284a739c9`.
Les deux adaptations administratives sont FUTURE_ROOT et la garde MAC de G1
sur cette même racine. HEAD/source canari restent historiques :
`2d69e30c9c6dd18823ee6102271876003a6a67cc` et QA `wrapper-source-kGvU1hdx/source`.
Le HEAD documentaire actuel ou la future source FULL ne sont pas empruntés.

Le profil `2ecae3a…`, 2 499 octets, est intégralement conservé puis reçoit
exactement cette unique ligne, 69 octets :

```scheme
(allow mach-register (global-name (param "OWN_RENDEZVOUS_SERVICE")))
```

Aucun autre lookup, register, canal d'applications, IOKit, réseau, fichier,
profil personnel ou port n'est ajouté. La règle est une hypothèse préparée,
pas la preuve de sa syntaxe native ni d'une causalité du refus ROOT14.

## Flux physique futur, jamais exécuté ici

1. `Session.start` garde l'argv sandbox pré-birth dans `entry.command` et dans
   le gate. Le nom Mach et le PID ne sont pas prévus dans cet argv ou l'env.
2. Après Popen, `admit_root` puis le dernier recheck de la vraie identity,
   G1 calcule `effective_command`. Le seul delta est le couple `-D` / valeur
   `OWN_RENDEZVOUS_SERVICE=com.google.Chrome.MachPortRendezvousServer.<pid>`
   inséré avant `-f`. PID est un entier strict positif de la birth admise.
3. La release hardlink conserve gate/identity et ajoute mode/stage,
   `command_template`, `effective_command`, `verified_before_release`.
   Les assertions/publications exclusives et rendez-vous 5 s restent en place.
4. Le gate recroise PID/PPID/UID/PGID avec ses propres appels, la birth finale,
   le mode/stage/borne du binding, puis reconstruit le template sandbox exact.
   Il n'exécute que l'effectif recomputé égal à la release, après recheck 5 s.
5. Entry, service-start, raw terminal, auxiliary-start/stop/closure conservent
   template et effectif. `_released_birth` refuse un handle sans effectif exact
   ou birth/recheck cohérents. Le lecteur de closure recroise les trois reçus.

Le scope permis est ROOT15 + WRAPPER_CANARY + Chrome + les cinq noms auxiliaires
déjà fermés. Aucun `OWN_RENDEZVOUS_SERVICE` libre n'est permis dans l'env ni
dans le template. Un mode SQL/web conserve son argv sans cette permission.
Les refus gate ordinaires et A/B fermés ne deviennent pas des admissions.

## Raccord constructeur

Le constructeur nouveau incorpore les fonctions de dérivation pure de
`rendezvous_delta.py` byte-logiquement. Ce fichier est une définition de
préparation, pas un helper copié au runtime. Il dérive les deux fichiers G1 et
gate existants. Le core reste 18, la table source reste 79, base11 intacte,
15 RPC, cinq Chrome, 26 commandes, SQL/Vite/ports et oracles restent inchangés.
CDP = 5 s, startup Chrome = 50 s, cleanup = 8 s. FULL/release/RUNTIME/OS/caps
restent false et les tables d'admission des préviews restent vides.

La première des six références de diff physiques existantes,
`root-wrapper-admission.diff`, joindra explicitement deux diffs : G1 puis gate.
Le core manifeste nomme aussi le gate comme dérivé. Sa préimage est conservée
dans `proofs/preimages/runtime_launch_gate.py`. Le checker MAIN futur devra
vérifier ces deux dérivations, pas supposer le gate byte-exact à l'ancien gel.
Les fonctions historiques de profil, de source79, d'autorité et les 11 sorties
de base restent inchangées hors raccord documenté.

L'appel constructeur n'est pas fait ici. Il exige toujours une autorité
externe MAIN exacte, les refs du profil et du builder nouvelles, les preuves
physiques fraîches et une cible absente. Aucune autorité JSON n'est émise dans
ce dossier. Exemple documentaire après les revues et l'appel outil MAIN :

```text
QA_PYTHON -B /private/tmp/therese-c17-wrapper15-own-rendezvous-ky7lgh/build_fresh_wrapper.py --root /private/tmp/therese-c17-wrapper-canary-9c1f04187dd24519b220372284a739c9 --web-profile-ref JSON_REF_WEB_EXISTANT --chrome-profile-ref JSON_REF_PROFILE15 --authority-ref JSON_REF_AUTHORITY_MAIN_FUTURE --prepare
```

## Mesures pures réelles et limites

Commande effectivement exécutée par l'auteur :

```text
/Users/synoptia/.local/share/uv/python/cpython-3.13.5-macos-aarch64-none/bin/python3.13 -B /private/tmp/therese-c17-wrapper15-own-rendezvous-ky7lgh/run_pure.py --actor /root/shared4_execution
```

Premier essai : 38 cas, quatre erreurs, brut et reçu `pure-0efgw3f_` conservés.
La fixture AST avait omis les deux vrais `STAGE_TIMEOUTS.update` ; `start`
refusait avant la birth. Sa copie initiale et son diff sont conservés. Le cas
birth exige maintenant le motif exact. Aucune assertion runtime n'est réduite.
Deuxième essai : 38 cas, zéro erreur/failure/skip, receipt `pure-15a1i5px`.
Sources avant/après égales, zéro tentative Popen/socket/execve/kill réelle et
zéro import G1/produit. Les anciens 23 tests14 ne sont pas relabellés/rejoués.

Les fixtures sont des identities/paths/ledger/Popen/FDs/horloges/reçus
explicitement synthétiques. Les vrais corps sélectionnés de start,
`_released_birth`, du calcul effectif, du lecteur de closure et du gate pré-exec
sont exercés, pas une Session physique. Le constructeur lui-même n'est pas
appelé. Ces tests ne qualifient ni libproc, ni la compilation du profil, ni
Mach-register, ni l'interface Chrome, ni FULL/A/B/release. L'exécution native
future reste exclusivement une décision MAIN après revues indépendantes.
