# Successeur SDK du microcanari Mach, fermé

Ce dossier corrige uniquement la représentation documentaire des origines
SDK. Le gel c4909875… reste immuable et ses préimages sont conservées ici.
Ses sept sources exécutables/profils sont copiées byte-exactes, sans
modification du C, du runner, des oracles, des délais ou des permissions.
Le profil candidat reste baseline2ecae3… plus la seule règle de69 octets,
SHA1684af7c…/2 568 octets.

La réserve de l'ancienne origine n'est pas masquée : le SHA e9b68… et les
3 356 octets désignaient le contenu cible, alors que servers/bootstrap.h
est un lien de14 octets. Les quatre header_refs de CONTRACT.json sont
désormais les fichiers physiques canoniques sous MacOSX26.5.sdk.
SDK-ALIASES.json distingue explicitement deux observations de liens :

1. MacOSX.sdk → MacOSX26.5.sdk, texte14 octets.
2. MacOSX26.5.sdk/usr/include/servers/bootstrap.h → ../bootstrap.h, texte14 octets.

Les textes des liens ont leur propre SHA, lstat type/UID/GID/mode/size,
dev/ino et cible résolue. Ils ne sont jamais décrits comme des fichiers
réguliers de3 356 octets. Les quatre références physiques satisfont
realpath(path)==path et lstat régulier. Aucun lien SDK n'a été changé.

La définition détaillée reste celle de la préimage README-before-sdk.md :
deux futurs enfants directs, propre label autorisé, PID réel du parent et
suffixe refusés, raw1100 requis, destruction du seul droit receive propre,
gate/birth réels avant exec, auto-exit et borne8, aucun signal inconnu.
La permission exacte reste héritée par descendants ; elle n'authentifie
pas leur PID. Aucun Chrome154, CDP, G1, FULL ou release n'est qualifié.

## Résultat pur réel

Rejeu35 de la même suite, pas35 nouveaux cas, outil f4f817, exit0.
Zéro erreur/échec/saut, sept pins avant/après identiques, 0,008378s.
Reçu aeb65a73…/3 927 octets, stdout vide, log unittest de3 560 octets.
Le contexte du précédent35 sous X7sJY7wM reste historique, non réécrit.
Les fixtures de naissance et de codes sont synthétiques, la garde Python
interdit subprocess/socket/ctypes ; elle ne prouve pas Seatbelt/Mach.

## Prochaines commandes proposées, non exécutées

Après sa revue, MAIN devra créer une racine neuve de la seule forme
/private/tmp/therese-c17-mach-register-canary-<32 hex minuscules>, privée0700,
avec auxiliary/probe/{home,tmp} et definitions, copier exactement les deux
profils puis produire le vrai reçu de compilation prévu.

```text
/usr/bin/clang -std=c11 -O2 -Wall -Wextra -Werror -isysroot /Library/Developer/CommandLineTools/SDKs/MacOSX.sdk /private/tmp/therese-c17-mach-register-micro-sdk-GhSw1pr1/probe.c -o <ROOT>/auxiliary/probe/mach-probe
```

Le SDK de cette commande reste son alias littéral documenté ; le code C
et le prédicat de compilation ne changent pas. MAIN doit revalider les
deux liens, les quatre cibles header et tous les fichiers de cet INDEX
immédiatement avant son vrai appel. Le contrat local est importé avant
le load_go interne : le préflight authentique reste une dépendance externe,
pas un contrôle de module hostile effectué après son import.

Une décision native MAIN distincte et réellement autorisée doit lier
l'INDEX courant, le binaire compilé exact, le vrai reçu compile et la racine.
Son expiration fraîche est de120s maximum. La chaîne actor=/root d'un JSON
n'authentifie pas le GO à elle seule.

```text
<Python QA physique> -I -B /private/tmp/therese-c17-mach-register-micro-sdk-GhSw1pr1/run_micro.py --run --root <ROOT> --go-ref <ref JSON de la vraie décision MAIN>
```

Aucune racine de campagne, compilation, décision native ou exécution
Seatbelt/Mach n'a été produite par l'auteur.
