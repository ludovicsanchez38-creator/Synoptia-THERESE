# LOT79 : question retenue et limites de preuve

Préparation QA synthétique du 9 octobre 2026. Ce fichier ne constitue ni
admission native, ni GO Chrome, ni qualification FULL ou release.

## Question nouvelle

Mesurer, dans un seul processus C direct, si un descripteur de B ouvert
avant la première OUTER reste utilisable alors qu'une nouvelle ouverture
de B est refusée. La baseline séparée sans OUTER doit mesurer la même
séquence positive. Le résultat du `pread` après OUTER n'est pas présumé.

Les cas fermés sont `fd-baseline`, puis `fd-outer`. Un rouge d'instrument,
d'attribution, de borne ou de contrôle positif arrête la série. Une lecture
exacte du FD conservé ou un refus explicite EPERM/EACCES constitue seulement
une observation de cette opération. Fresh B sous OUTER exige EPERM ; un
fichier absent, un EOF ou un contenu changé ne vaut jamais refus de sandbox.

La fermeture est une seule tentative contrôlée, suivie immédiatement d'un
`F_GETFD` qui doit rendre -1/EBADF avant toute réouverture pouvant réutiliser
le numéro. Cela ne prouve pas la fermeture de tous les FD d'un navigateur.

## Sources effectivement relues par MAIN

Les quatre sources LOT76 sous
`/private/tmp/therese-c17-seatbelt-native-main-FDuCgC/` ont été lues
intégralement. Leurs hashes physiques ont été contrôlés (outil 73a22a) :

- native_main.py : 8be2cafb056490a6ca5e1f7135a92f5e580572400e55dcd32ffb24c1a8633699.
- controller.py : 5712da7b51a66abe179089ba205f85c6048318636e5735187f8ad1ec9aabef73.
- native_port.py : 33b0761556b2d640f278d5bde50825ac0c97a66e3bb941adb65f9f16d347280f.
- probe-native.c : 8de3afdd3eccc89c65e60b11794f35866c95d3ebed95afb322f5cbc8ecff4f38.
- NATIVE-SOURCES.json : 6397231d40713a4cc838799edd65f3b54c16b2f010398f1cfc7a748462c45f4e.

L'import de ces modules n'a pas été exécuté. Les sources de LOT77 consultées
sont des antécédents de garde, pas une dérivation native admise de LOT79.

Les pages locales du SDK MacOSX26.5 `sandbox(7)`, `open(2)`, `close(2)` et
`read(2)` ont été consultées. Le manuel sandbox décrit généralement des
restrictions à l'acquisition. Le manuel read décrit pread à offset fixe,
sans déplacement du pointeur. Ces textes ne constituent pas des oracles
du kernel courant. Les erreurs et retours devront être capturés au syscall.

Le [README Chromium main](https://raw.githubusercontent.com/chromium/chromium/main/sandbox/mac/README.md)
et le [manuel Apple archivé read/pread](https://developer.apple.com/library/archive/documentation/System/Conceptual/ManPages_iPhoneOS/man2/read.2.html)
ont été consultés. Main reste mobile et non apparié à Chrome QA
154.0.8037.99. Ils motivent la question, sans préjuger du résultat local.

Deux appels de lecture ont échoué avant accès utile : un ancien chemin
temporaire deviné était absent, puis `/usr/bin/rg` absent. Aucun code natif
ni mutation produit n'a été exécuté par ces appels. L'inventaire filesystem
a ensuite retrouvé les chemins réels ; aucun processus n'a été adopté.

## Portée exclue

Aucun second sandbox_apply, fork ou exec du C, aucun réseau, Mach ou IOKit,
aucun Chrome ou import G1. G1 et ROOT15 restent inchangés et rouges. Aucun
profil personnel, port 17293, VM/UTM, serveur, DNS, e-mail ou message externe.
Une exception Chrome ou un nouvel instrument Chrome reste une nouvelle
décision de sécurité. Aucun diagnostic synthétique ne remplace les cinq
calibrations expirées ni les deux rondes FULL requises.

## Portes avant activation

Contrat, sources désactivées et contrôles purs doivent être relus par MAIN
et un acteur indépendant. Le futur lancement doit garder un timer C
one-shot avant la gate et les ouvertures, une deadline absolue avant Popen,
une naissance libproc réelle, un exécutable exact, un rehash suivi d'une
nouvelle vérification d'identité et de temps juste avant release. Une trace
fautive bloque spawn/release. L'attente/réapage utilise seulement le handle
direct ; aucun signal externe n'est permis dans LOT79, même avec une identité
prouvée. Aucune adoption d'un autre PID n'est permise. La deadline terminale
est fixée à started+18 s avant Popen ; cleanup8 dépassé reste rouge même
si un réapage tardif ferme ensuite le handle. Le timer ne prouve pas la
préemption de tous les syscalls du noyau.
