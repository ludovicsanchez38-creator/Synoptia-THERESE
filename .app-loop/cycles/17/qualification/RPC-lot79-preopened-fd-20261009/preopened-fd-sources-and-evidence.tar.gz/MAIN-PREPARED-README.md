# LOT79 : contrôleur MAIN direct, préparation désactivée

Ce dossier contient trois copies préparatoires dérivées des sources LOT76
physiquement épinglées dans
`/private/tmp/therese-c17-seatbelt-native-main-FDuCgC/ACTIVATION-INDEX.json`.
Les sources LOT76 ne sont pas modifiées. Le ROOT de toute future mesure est
fixé à `/private/tmp/therese-c17-fd-main-Bp9K3omj` ; les deux seuls cas sont
`fd-baseline` et `fd-outer`.

`native_main-prepared.py` refuse immédiatement toute exécution via
`PREPARATION_ONLY=True`, avant création de cas, lecture de manifeste ou import
local. `controller-prepared.py` conserve `NATIVE_MEASUREMENT_ENABLED=False` et
son entrée `_drive` refuse toujours. `native_port-prepared.py` refuse donc sa
construction, son spawn et sa release. Les tests n'appellent que `_drive_core`
avec un double sous garde d'audit ; leur champ `actual_native_IO` est faux.

Le futur manifeste `NATIVE-SOURCES.json` n'est ni créé ni admis ici. Son
ensemble fermé prévu est : copies activées distinctes `native_main-active.py`,
`controller-native.py`, `native_port-native.py`, binaire `probe`, source
`probe-native.c`, deux témoins `witnesses/a.txt` et `witnesses/b.txt`, et
`policies/outer.sb`. Tout pin devra être physique et revu avant une dérivation
activée par MAIN. Le profil n'est utilisé que par `fd-outer` ; la baseline
reste sans OUTER. Aucune preuve d'héritage, de navigateur ou de FULL n'en
découle.

Le contrôle direct garde une naissance libproc externe complète (parent et
enfant PID, PPID, UID, PGID, birth, statut vivant 2/3, exécutable exact), une
gate ready/release/ACK compacte bornée à cinq secondes, puis un cas borné à
cinq secondes après ACK et au plafond global `started+10`, et une file
terminale de wait/reap jusqu'à
`started+18`. La fermeture gate et l'attente du seul handle sont les seules
actions de cleanup ; aucun signal ou kill de groupe n'existe dans cette
copie. Un réapage après cleanup8 reste rouge. Les événements de trace fautifs
bloquent avant spawn et release, y compris si l'écriture de l'intention
échoue. Le rehash est suivi d'une lecture fraîche des deux identités et de
l'horloge avant release.

Si le C ne sort pas avant `started+18`, le résultat reste rouge et non réapé ;
ce contrôleur ne peut alors garantir l'absence d'un processus encore vivant.
Il n'envoie aucun signal et ne transforme pas ce cas
en fermeture propre. Une décision de supervision supplémentaire serait
nécessaire avant toute utilisation native si le timer autonome est jugé
insuffisant.

L'oracle final stdout exige quinze lignes JSONL fermées. Ready et ACK sont
les mêmes octets que ceux observés pendant la gate et sont relus contre les
naissances réellement attribuées. Il contrôle aussi l'ambiance, les deux
témoins avant OUTER, l'identité du FD B retenu, les témoins du cas, les deux
lectures `pread` à offset zéro, le close/F_GETFD EBADF, le témoin B après
close et le résumé sans qualification. Un code de sortie zéro ne suffit pas.
Le `errno` de `ambient_probe` est conservé brut lorsque son retour vaut zéro :
seul `rc=0` établit la condition préalable de cette API, pas un `errno`
résiduel non nul.
La lecture du descripteur B conservé après OUTER peut être exacte ou refusée
EPERM/EACCES : ces deux issues sont des observations distinctes, jamais une
réussite d'accès présumée. Les fixtures de test sont synthétiques ; elles ne
prouvent aucun appel système. Le test
`test_mocked_oracle_never_claims_native_io` remplace l'oracle dans un double
pour vérifier la logique de clôture seulement.

Commande de test pur autorisée après relecture des sources :

`python3 -I -B /private/tmp/therese-c17-fd-main-Bp9K3omj/tests_prepared.py`

Cette commande charge les définitions Python désactivées sous audit hook et
n'appelle ni Popen, ni libproc, ni sandbox, ni socket, ni signal. Elle n'est
pas une admission ni une mesure kernel. Une future copie activée devra être
distincte, épinglée et revue par MAIN ; les copies préparées présentes ne
seront pas mutées pour l'activer.
