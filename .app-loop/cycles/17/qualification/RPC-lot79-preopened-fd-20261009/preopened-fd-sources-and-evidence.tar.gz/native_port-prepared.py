"""Port OS LOT79 préparatoire, désactivé jusqu'à dérivation MAIN.

Deux FD O_EXCL, un Popen direct, PIPE FD0 et libproc typé ; zéro signal.
Le runner fermé fournit un troisième FD exclusif pour la trace bornée.
"""

from __future__ import annotations

import errno
import hashlib
import json
import os
import stat
import subprocess
import time
from pathlib import Path
from typing import Any

from controller_prepared import NATIVE_MEASUREMENT_ENABLED, Plan, require


class NativePort:
    ACTUAL_NATIVE_IO = True

    def __init__(self, trace_fd: int) -> None:
        require(NATIVE_MEASUREMENT_ENABLED, "NativePort désactivé")
        st = os.fstat(trace_fd)
        require(stat.S_ISREG(st.st_mode) and st.st_uid == os.getuid()
                and stat.S_IMODE(st.st_mode) == 0o600 and st.st_nlink == 1,
                "trace QA non privée")
        self.trace_fd = trace_fd
        self.trace_count = 0
        self.trace_bytes = 0
        self.trace_fault = False
        self._record("port_created")

    def _record(self, op: str, **fields: Any) -> None:
        if self.trace_fault:
            return
        raw = (json.dumps({"op": op, "monotonic": self.now(), **fields},
                          separators=(",", ":"), ensure_ascii=True) + "\n").encode("ascii")
        if len(raw) > 512 or self.trace_count >= 128 or self.trace_bytes + len(raw) > 32768:
            self.trace_fault = True
            return
        try:
            if os.write(self.trace_fd, raw) != len(raw):
                self.trace_fault = True
                return
        except OSError:
            self.trace_fault = True
            return
        self.trace_count += 1
        self.trace_bytes += len(raw)

    def now(self) -> float:
        return time.monotonic()

    def self_pid(self) -> int:
        return os.getpid()

    def read_identity(self, pid: int) -> dict[str, Any]:
        # Le module libproc n'est pas chargé dans les tests purs ni à l'import.
        self._record("identity_call", pid=pid)
        import ctypes

        class Info(ctypes.Structure):
            _fields_ = [(k, ctypes.c_uint32) for k in
                        ("flags", "status", "xstatus", "pid", "ppid", "uid", "gid",
                         "ruid", "rgid", "svuid", "svgid", "reserved")]
            _fields_ += [("comm", ctypes.c_char * 16), ("name", ctypes.c_char * 32)]
            _fields_ += [(k, ctypes.c_uint32) for k in
                         ("nfiles", "pgid", "jobc", "tdev", "tpgid")]
            _fields_ += [("nice", ctypes.c_int32), ("start_sec", ctypes.c_uint64),
                         ("start_usec", ctypes.c_uint64)]

        lib = ctypes.CDLL("/usr/lib/libproc.dylib", use_errno=True)
        lib.proc_pidinfo.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_uint64,
                                     ctypes.c_void_p, ctypes.c_int]
        lib.proc_pidinfo.restype = ctypes.c_int
        lib.proc_pidpath.argtypes = [ctypes.c_int, ctypes.c_void_p, ctypes.c_uint32]
        lib.proc_pidpath.restype = ctypes.c_int
        info = Info()
        ctypes.set_errno(0)
        count = lib.proc_pidinfo(pid, 3, 0, ctypes.byref(info), ctypes.sizeof(info))
        if count == 0 and ctypes.get_errno() == errno.ESRCH:
            raise ProcessLookupError(pid)
        require(count == ctypes.sizeof(info) and info.pid == pid
                and not (info.flags & 4),
                "libproc refus/lecture partielle/PID divergent/PROC_FLAG_INEXIT")
        path = ctypes.create_string_buffer(4096)
        ctypes.set_errno(0)
        require(lib.proc_pidpath(pid, path, len(path)) > 0, "proc_pidpath illisible")
        row = {k: int(getattr(info, k)) for k in
               ("pid", "ppid", "uid", "pgid", "start_sec", "start_usec", "status")}
        row["executable"] = path.value.decode("utf-8", "strict")
        self._record("identity_result", **row)
        return row

    def verify_sources(self, refs: tuple[dict[str, Any], ...]) -> bool:
        self._record("sources_check", count=len(refs))
        for ref in refs:
            path = Path(ref["path"])
            before = path.lstat()
            if (not stat.S_ISREG(before.st_mode) or before.st_nlink != 1
                    or path.resolve(strict=True) != path):
                return False
            if before.st_size != ref["bytes"]:
                return False
            digest = hashlib.sha256()
            fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
            try:
                opened = os.fstat(fd)
                if self._stable_stat(before) != self._stable_stat(opened):
                    return False
                with os.fdopen(fd, "rb", closefd=False) as stream:
                    for block in iter(lambda: stream.read(1024 * 1024), b""):
                        digest.update(block)
                after = path.lstat()
                if self._stable_stat(before) != self._stable_stat(after):
                    return False
            finally:
                os.close(fd)
            if digest.hexdigest() != ref["sha256"]:
                return False
        self._record("sources_unchanged", count=len(refs))
        return True

    @staticmethod
    def _stable_stat(st: os.stat_result) -> tuple[int, ...]:
        # atime peut changer lors de la lecture ; ctime/mtime et identité non.
        return (st.st_dev, st.st_ino, st.st_uid, st.st_gid, st.st_mode,
                st.st_nlink, st.st_size, st.st_mtime_ns, st.st_ctime_ns)

    def _private_directory(self, path: Path) -> None:
        st = path.lstat()
        require(path.resolve(strict=True) == path and stat.S_ISDIR(st.st_mode)
                and st.st_uid == os.getuid() and stat.S_IMODE(st.st_mode) == 0o700,
                "répertoire QA non canonique/privé")

    def open_sinks(self, plan: Plan) -> tuple[int, int]:
        self._record("sinks_open_call")
        for path in (plan.root, plan.cwd, plan.root / "home", plan.root / "tmp",
                     plan.stdout_path.parent, plan.stderr_path.parent):
            self._private_directory(path)
        binary = plan.binary.lstat()
        require(plan.binary.resolve(strict=True) == plan.binary and stat.S_ISREG(binary.st_mode)
                and binary.st_uid == os.getuid() and binary.st_nlink == 1
                and binary.st_mode & 0o111 != 0,
                "binaire QA non régulier/propriétaire")
        flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC
        out = os.open(plan.stdout_path, flags, 0o600)
        try:
            err = os.open(plan.stderr_path, flags, 0o600)
        except BaseException:
            os.close(out)
            raise
        try:
            first, second = os.fstat(out), os.fstat(err)
            require(all(stat.S_ISREG(st.st_mode) and st.st_uid == os.getuid()
                        and stat.S_IMODE(st.st_mode) == 0o600 and st.st_nlink == 1
                        for st in (first, second))
                    and (first.st_dev, first.st_ino) != (second.st_dev, second.st_ino),
                    "sinks O_EXCL non privés/distincts")
        except BaseException:
            os.close(out)
            os.close(err)
            raise
        self._record("sinks_opened", stdout_inode=first.st_ino, stderr_inode=second.st_ino)
        return out, err

    def spawn(self, plan: Plan, sinks: tuple[int, int]) -> subprocess.Popen[bytes]:
        require(NATIVE_MEASUREMENT_ENABLED, "Popen natif désactivé")
        require(sinks[0] != sinks[1], "sinks FD identiques")
        require(not self.trace_fault, "trace fautive avant Popen")
        self._record("spawn_call", case=plan.case)
        require(not self.trace_fault, "trace fautive après annonce Popen")
        handle = subprocess.Popen(plan.argv(), cwd=plan.cwd, env=plan.environment,
                                  stdin=subprocess.PIPE, stdout=sinks[0], stderr=sinks[1],
                                  close_fds=True, start_new_session=True)
        self._plan = plan
        self._record("spawned", pid=handle.pid)
        return handle

    def _line(self, handle: subprocess.Popen[bytes], plan: Plan, ordinal: int,
              deadline: float, sinks: tuple[int, int]) -> bytes:
        fd = os.open(plan.stdout_path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
        try:
            reader, writer, named = os.fstat(fd), os.fstat(sinks[0]), plan.stdout_path.lstat()
            key = lambda st: (st.st_dev, st.st_ino, st.st_uid, st.st_gid,
                              stat.S_IFMT(st.st_mode), st.st_nlink)
            require(stat.S_ISREG(reader.st_mode) and reader.st_nlink == 1
                    and key(reader) == key(writer) == key(named),
                    "sink ready différent du FD O_EXCL")
            while time.monotonic() <= deadline:
                raw = os.pread(fd, 1025, 0)
                lines = raw.split(b"\n")
                if len(lines) > ordinal + 1:
                    line = lines[ordinal] + b"\n"
                    require(len(line) <= 512, "ligne gate trop grande")
                    if ordinal == 0:
                        require(len(raw) == len(line), "sortie avant release")
                    require(key(os.fstat(fd)) == key(os.fstat(sinks[0]))
                            == key(plan.stdout_path.lstat()), "sink muté pendant gate")
                    return line
                require(len(raw) <= 1024, "sortie gate non bornée")
                require(handle.poll() is None, "enfant sorti avant gate")
                time.sleep(0.01)
            raise TimeoutError("gate dépassé")
        finally:
            os.close(fd)

    def read_ready(self, handle: subprocess.Popen[bytes], sinks: tuple[int, int],
                   deadline: float) -> bytes:
        self._record("ready_read_call", pid=handle.pid)
        raw = self._line(handle, self._plan, 0, deadline, sinks)
        self._record("ready_read", bytes=len(raw))
        return raw

    def read_gate_released(self, handle: subprocess.Popen[bytes], sinks: tuple[int, int],
                           deadline: float) -> bytes:
        self._record("ack_read_call", pid=handle.pid)
        raw = self._line(handle, self._plan, 1, deadline, sinks)
        self._record("ack_read", bytes=len(raw))
        return raw

    def read_final(self, handle: subprocess.Popen[bytes], sinks: tuple[int, int]) -> bytes:
        require(handle.poll() is not None, "stdout final avant sortie enfant")
        self._record("final_read_call", pid=handle.pid)
        path = self._plan.stdout_path
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
        try:
            opened, held, named = os.fstat(fd), os.fstat(sinks[0]), path.lstat()
            require(stat.S_ISREG(opened.st_mode) and opened.st_nlink == 1
                    and self._stable_stat(opened) == self._stable_stat(held)
                    == self._stable_stat(named)
                    and opened.st_size <= 8192, "stdout final hors sink O_EXCL/bornes")
            raw = os.pread(fd, 8193, 0)
            require(len(raw) == opened.st_size
                    and self._stable_stat(os.fstat(fd)) == self._stable_stat(path.lstat()),
                    "stdout final partiel ou modifié")
            self._record("final_read", pid=handle.pid, bytes=len(raw))
            return raw
        finally:
            os.close(fd)

    def release(self, handle: subprocess.Popen[bytes], payload: bytes) -> None:
        require(NATIVE_MEASUREMENT_ENABLED, "release natif désactivé")
        require(handle.stdin is not None, "stdin PIPE absent")
        require(not self.trace_fault, "trace fautive avant release")
        self._record("release_write_call", pid=handle.pid, bytes=len(payload))
        require(not self.trace_fault, "trace fautive après annonce release")
        handle.stdin.write(payload)
        handle.stdin.flush()
        self._record("release_written", pid=handle.pid)

    def close_gate(self, handle: subprocess.Popen[bytes]) -> None:
        if handle.stdin is not None and not handle.stdin.closed:
            handle.stdin.close()
        self._record("gate_closed", pid=handle.pid)

    def poll(self, handle: subprocess.Popen[bytes]) -> int | None:
        code = handle.poll()
        self._record("poll", pid=handle.pid, returncode=code)
        return code

    def wait_until(self, handle: subprocess.Popen[bytes], deadline: float) -> int | None:
        self._record("wait_call", pid=handle.pid, deadline=deadline)
        try:
            code = handle.wait(timeout=max(0.0, deadline - time.monotonic()))
        except subprocess.TimeoutExpired:
            code = None
        self._record("wait_result", pid=handle.pid, returncode=code)
        return code

    def close_sinks(self, sinks: tuple[int, int]) -> bool:
        self._record("sinks_close_call")
        stable = True
        for fd in sinks:
            try:
                os.fsync(fd)
            except OSError:
                stable = False
            finally:
                try:
                    os.close(fd)
                except OSError:
                    stable = False
        self._record("sinks_closed", stable=stable)
        return stable and not self.trace_fault
