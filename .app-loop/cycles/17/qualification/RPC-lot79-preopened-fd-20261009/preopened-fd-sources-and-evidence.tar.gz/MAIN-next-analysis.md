# Suite préparatoire après LOT79

Retour de l'agent `/root/environment_routes`, après lecture ciblée des pièces
canoniques LOT77/78 et du suivi : aucun delta concret équivalent pour Chrome
154 inchangé ni bug produit confirmé ne ressort des pièces examinées.
Ce constat est borné à ces pièces, pas à tout le backlog du produit.

La mesure LOT79 ne couvre qu'une sonde C : son B préouvert reste lisible sous
OUTER, même si une ouverture fraîche est refusée. Elle ne montre pas quels FD
ou canaux Chrome ouvre ou transmet. Un candidat appliquant une protection
seulement après ouverture de capacités doit apporter une preuve explicite de
leur traitement ; une liste de chemins ne répond pas à cette lacune.

Pour un candidat Chrome réellement spécifiable, restent à établir le raccord
entre code cible et binaire QA, la protection du browser et des helpers sans
seconde application conflictuelle, et le traitement des FD/canaux transmis.
Les sources Chromium main et la table M128 ne fournissent pas ce raccord.

Sous l'autorité actuelle, une analyse statique ciblée d'un candidat concret ou
la préparation d'un diagnostic synthétique différent reste possible, de même
que la vérification d'un bug produit confirmé hors de cette dépendance.
Ne pas répéter LOT79 inchangé. Une exception Chrome hors G1 ou un changement
d'instrument doit faire l'objet d'une nouvelle décision de sécurité précise.
Ce document prépare le choix suivant ; il n'accorde aucun droit, ne change
aucune frontière et n'admet ni Chrome, ni FULL, ni release.
