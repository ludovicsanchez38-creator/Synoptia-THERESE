import fs from 'node:fs';
import crypto from 'node:crypto';
import { execFileSync } from 'node:child_process';
const root = "/private/tmp/therese-c17-fd-main-Bp9K3omj";
const destination = "/Users/synoptia/Desktop/Dev Synoptia/Synoptia-THERESE-c15-codex/.app-loop/cycles/17/qualification/RPC-lot79-preopened-fd-20261009";
const archive = destination + '/preopened-fd-sources-and-evidence.tar.gz';
const members = [
  "MAIN-syntax-receipt.json",
  "MAIN-python-pure-tests.log",
  "preimages/verify-outcomes-v1.mjs",
  "preimages/probe-lot76-native.c",
  "preimages/inspect-sources-v3.mjs",
  "preimages/inspect-sources-v2.mjs",
  "preimages/inspect-sources-v1.mjs",
  "C-INDEX.json",
  "native_port-native.py",
  "native_main-active.py",
  "MAIN-PREP-INDEX.json",
  "MAIN-native-executions.json",
  "MAIN-SOURCE-NOTES.md",
  "diffs/probe-lot76-to-lot79.diff",
  "diffs/probe-lot79-to-lot76.diff",
  "MAIN-outcome-filesystem-check.json",
  "NATIVE-SOURCES.json",
  "probe-native.c",
  "MAIN-LAUNCH-PLAN.json",
  "test-receipt.json",
  "MAIN-filesystem-inspection.json",
  "MAIN-preparation-receipt.json",
  "policies/outer.sb",
  "test_c_static.py",
  "cases/fd-outer/trace.jsonl",
  "cases/fd-outer/stdout.log",
  "cases/fd-outer/result.json",
  "cases/fd-outer/stderr.log",
  "cases/fd-baseline/trace.jsonl",
  "cases/fd-baseline/stdout.log",
  "cases/fd-baseline/result.json",
  "cases/fd-baseline/stderr.log",
  "witnesses/a.txt",
  "witnesses/b.txt",
  "native_port-prepared.py",
  "test-output.log",
  "inspect-sources.mjs",
  "tests_prepared.py",
  "controller-prepared.py",
  "README-C.md",
  "MAIN-PREPARED-README.md",
  "verify-outcomes.mjs",
  "ACTIVATION-DERIVATION.json",
  "PLAN.json",
  "controller-native.py",
  "MAIN-c-static-tests.log",
  "MAIN-PREPARED-INDEX.json",
  "native_main-prepared.py",
  "probe-prepared.c",
  "MAIN-outcome-check-failure.json",
  "MAIN-next-analysis.md",
  "TAR-ROOT-FILES.txt",
  "archive-lot79.mjs",
  "review/INDEX.json",
  "review/REVIEW.json",
  "review/ACTIVATION-INDEX.json",
  "review/ACTIVATION-REVIEW.json",
  "review/OUTCOME-INDEX.json",
  "review/OUTCOME-REVIEW.json"
];
const fields = ['dev', 'ino', 'uid', 'gid', 'mode', 'nlink', 'size', 'mtimeNs', 'ctimeNs'];
function require(ok, reason) { if (!ok) throw new Error(reason); }
function pin(path, cap = 65536) {
  const a = fs.lstatSync(path, { bigint: true }), raw = fs.readFileSync(path), b = fs.lstatSync(path, { bigint: true });
  require(fs.realpathSync(path) === path && a.isFile() && a.uid === 501n && a.nlink === 1n && a.size <= BigInt(cap) && BigInt(raw.length) === a.size && fields.every(k => a[k] === b[k]), 'physical file ' + path);
  return { path, bytes: raw.length, sha256: crypto.createHash('sha256').update(raw).digest('hex') };
}
require(fs.realpathSync(root) === root && fs.realpathSync(destination) === destination, 'canonical dirs');
require(!fs.existsSync(archive), 'archive already exists: do not overwrite');
require(new Set(members).size === members.length && members.every(x => /^[A-Za-z0-9_.\/-]+$/.test(x) && !x.startsWith('/') && !x.split('/').includes('..') && x !== 'probe' && !x.startsWith('home/') && !x.startsWith('tmp/')), 'closed member list');
const before = members.map(member => ({ member, ...pin(root + '/' + member) }));
execFileSync('/usr/bin/tar', ['-czf', archive, '-C', root, ...members], { env: { ...process.env, COPYFILE_DISABLE: '1' }, maxBuffer: 1048576 });
const archiveRef = pin(archive, 3000000);
const names = execFileSync('/usr/bin/tar', ['-tzf', archive], { encoding: 'utf8', maxBuffer: 1048576 }).trimEnd().split('\n');
require(names.length === members.length && names.every((x, i) => x === members[i]), 'TAR members exact and ordered');
for (const row of before) {
  const raw = execFileSync('/usr/bin/tar', ['-xOzf', archive, row.member], { maxBuffer: 65537 });
  require(raw.length === row.bytes && crypto.createHash('sha256').update(raw).digest('hex') === row.sha256, 'archive member bytes ' + row.member);
  require(JSON.stringify(pin(row.path)) === JSON.stringify({ path: row.path, bytes: row.bytes, sha256: row.sha256 }), 'source after archive ' + row.member);
}
require(JSON.stringify(pin(archive, 3000000)) === JSON.stringify(archiveRef), 'archive stable');
console.log(JSON.stringify({ schema: 'c17-lot79-archive-manifest-v1', actor: '/root', createdAt: new Date().toISOString(), archiveRef, sourceRoot: root, members: before, archiveMembersRecheckedWithoutExtraction: before.length, sourcesRecheckedAfterArchive: true, statBigintStrict: true, noTimestampTolerance: true, compiledBinaryExcluded: true, excluded: ['probe binary', 'SDKs', 'HOME/TMP dirs', 'personal profile', 'nine preexisting documents'], archiveIsProvenanceNotAdmission: true, nativeQAStartedByArchiveTool: false, ChromeQualified: false, FULL: false, release: false }, null, 2));
