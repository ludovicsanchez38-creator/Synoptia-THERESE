// Lecture filesystem seulement : aucun import de sonde, API native ou processus.
import fs from 'node:fs';
import crypto from 'node:crypto';

const root = '/private/tmp/therese-c17-fd-main-Bp9K3omj';
const repository = '/Users/synoptia/Desktop/Dev Synoptia/Synoptia-THERESE-c15-codex';
const sdk = '/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX26.5.sdk/usr/share/man';
const expected = [
  'MAIN-SOURCE-NOTES.md', 'PLAN.json', 'probe-prepared.c',
  'controller-prepared.py', 'native_port-prepared.py', 'native_main-prepared.py',
  'tests_prepared.py', 'witnesses/a.txt', 'witnesses/b.txt', 'policies/outer.sb',
];
const dirty = {
  'docs/application-map/README.md': '10a24b4eab25e37fe19ac47220554740210446f702da67ddbca4b97db2bbf134',
  'docs/application-map/architecture.md': 'a84fb3c6db7864e95bd9003a37dadd80567bc2c9876e6afc5427634484d25fe4',
  'docs/application-map/constats-visuels.md': '094e21dcc76aa3039afde1a183e34fc7adafa0a131e2f184baf2c19bcbf8328c',
  'docs/application-map/couverture.md': '23de3dddc41d574353a067833bfabd6a2ad8d920a10c269b1e9f2046dcf34a7e',
  'docs/application-map/dependances.md': '79ec6502cae73cc14072a6a083aaa800941637903dfb3ab44b6a692afb87e430',
  'docs/application-map/fonctionnalites.md': 'e3ccb88c7b91e75133378387998f4a27a3665ca4df9bd06200c4b9ea1c93ccb3',
  'docs/application-map/inconnues.md': '9174af38012989902f55072e8c9fdc783ce2888bdec17eaccfaf746e1a4234b1',
  'docs/application-map/risques.md': '0e307d0be5336f982cff0ace0e3219d51dba99fd4f926f5ef2e67043ae6503b7',
  'docs/releases/v0.77.1-alpha.md': 'f0ce0458539fa71116efb775abcf6b780669ffeb41c583364f4bfc23bd24eb8a',
};
// Tailles reelles de ces neuf preimages seulement (stat MAIN 3357a2).
// Aucune augmentation de la borne 65536 des sources QA natives.
const dirtySizes = {
  'docs/application-map/README.md': 694,
  'docs/application-map/architecture.md': 752234,
  'docs/application-map/constats-visuels.md': 679758,
  'docs/application-map/couverture.md': 60447,
  'docs/application-map/dependances.md': 467680,
  'docs/application-map/fonctionnalites.md': 371695,
  'docs/application-map/inconnues.md': 626113,
  'docs/application-map/risques.md': 3902685,
  'docs/releases/v0.77.1-alpha.md': 28448,
};

function require(condition, message) {
  if (!condition) throw new Error(message);
}
function key(st) {
  return [st.dev, st.ino, st.uid, st.gid, st.mode, st.nlink, st.size, st.mtimeNs, st.ctimeNs]
    .map(String).join(':');
}
function reference(path, maximum = 65536, expectedUid = process.getuid()) {
  const before = fs.lstatSync(path, { bigint: true });
  require(fs.realpathSync(path) === path && before.isFile()
    && before.uid === BigInt(expectedUid) && before.nlink === 1n
    && before.size <= BigInt(maximum), `fichier non canonique/prive/borne: ${path}`);
  const fd = fs.openSync(path, fs.constants.O_RDONLY | fs.constants.O_NOFOLLOW | fs.constants.O_CLOEXEC);
  let raw;
  try {
    require(key(fs.fstatSync(fd, { bigint: true })) === key(before), `ouverture changee: ${path}`);
    raw = fs.readFileSync(fd);
    require(raw.length === Number(before.size)
      && key(fs.fstatSync(fd, { bigint: true })) === key(before)
      && key(fs.lstatSync(path, { bigint: true })) === key(before), `lecture changee: ${path}`);
  } finally {
    fs.closeSync(fd);
  }
  return { path, bytes: raw.length, sha256: crypto.createHash('sha256').update(raw).digest('hex') };
}
const sourceRefs = expected.map(name => reference(`${root}/${name}`));
const preserved = Object.entries(dirty).map(([name, sha256]) => {
  const actual = reference(`${repository}/${name}`, dirtySizes[name]);
  require(actual.bytes === dirtySizes[name] && actual.sha256 === sha256,
    `modification preexistante changee: ${name}`);
  return actual;
});
const manualRefs = ['man7/sandbox.7', 'man2/open.2', 'man2/close.2', 'man2/read.2', 'man2/fcntl.2']
  .map(name => reference(`${sdk}/${name}`, 120000, 0));
const c = fs.readFileSync(`${root}/probe-prepared.c`, 'utf8');
const controller = fs.readFileSync(`${root}/controller-prepared.py`, 'utf8');
const port = fs.readFileSync(`${root}/native_port-prepared.py`, 'utf8');
const runner = fs.readFileSync(`${root}/native_main-prepared.py`, 'utf8');
require(c.includes('NATIVE_MEASUREMENT_ENABLED = false;')
  && controller.includes('NATIVE_MEASUREMENT_ENABLED = False')
  && runner.includes('PREPARATION_ONLY = True'), 'preparation non desactivee');
require(!/\b(?:fork|execve|sandbox_apply|sandbox_compile_string)\s*\(/.test(c), 'API C hors contrat');
require(!/os\.(?:kill|killpg)\s*\(/.test(port), 'signal externe present');
console.log(JSON.stringify({
  schema: 'c17-lot79-main-filesystem-inspection-v1', at: new Date().toISOString(),
  sourceRefs, manualRefs, preexistingRefs: preserved,
  filesystemOnly: true, codeImported: false, nativeStarted: false,
  compilationStarted: false, ChromeQualified: false, FULL: false,
}, null, 2));
