import fs from 'node:fs';
import crypto from 'node:crypto';
const root = '/private/tmp/therese-c17-fd-main-Bp9K3omj';
const fields = ['dev', 'ino', 'uid', 'gid', 'mode', 'nlink', 'size', 'mtimeNs', 'ctimeNs'];
function demand(ok, why) { if (!ok) throw new Error(why); }
function read(path) {
  const a = fs.lstatSync(path, { bigint: true });
  demand(fs.realpathSync(path) === path && a.isFile() && a.uid === 501n && a.nlink === 1n && a.size <= 65536n, `file:${path}`);
  const raw = fs.readFileSync(path);
  const b = fs.lstatSync(path, { bigint: true });
  demand(fields.every(k => a[k] === b[k]) && BigInt(raw.length) === a.size, `stat:${path}`);
  return { raw, ref: { path, bytes: raw.length, sha256: crypto.createHash('sha256').update(raw).digest('hex') } };
}
const manifestFile = read(root + '/NATIVE-SOURCES.json');
demand(manifestFile.ref.sha256 === '6c240aa8425c163ebbde343757d68edf1a9aa72ed0d931c5283ac4db862d2e67', 'manifest pin');
const manifest = JSON.parse(manifestFile.raw);
for (const ref of manifest.files) demand(JSON.stringify(read(ref.path).ref) === JSON.stringify(ref), `source:${ref.path}`);
const cases = [];
const ahex = Buffer.from('A:synthetic-witness-only\n').toString('hex');
const bhex = Buffer.from('B:synthetic-witness-only\n').toString('hex');
for (const name of ['fd-baseline', 'fd-outer']) {
  const base = root + '/cases/' + name;
  const files = ['stdout.log', 'stderr.log', 'trace.jsonl', 'result.json'].map(f => read(base + '/' + f));
  demand(files[1].raw.length === 0, 'stderr');
  const result = JSON.parse(files[3].raw);
  const c = result.controller;
  demand(result.case === name && result.source_unchanged === true && result.manifest_unchanged === true && result.trace_fault === false, 'runner closure');
  for (const key of ['clean', 'termination_proved', 'cleanup_deadline_met', 'final_oracle', 'gate_release_written', 'gate_release_confirmed', 'source_refs_unchanged']) demand(c[key] === true, key);
  demand(c.returncode === 0 && c.errors.length === 0 && c.signals.length === 0 && c.actual_native_IO === true, 'controller');
  demand(result.native_qualification === false && result.FULL === false && result.Chrome_qualified === false, 'nonqualification');
  demand(result.manifest_ref.sha256 === manifestFile.ref.sha256 && JSON.stringify(result.source_refs) === JSON.stringify(manifest.files), 'runner pins');
  const text = files[0].raw.toString('utf8');
  demand(text.endsWith('\n'), 'stdout final newline');
  const lines = text.trimEnd().split('\n').map(JSON.parse);
  demand(lines.length === 15 && lines[0].case === name && lines[0].nonce === result.nonce && lines[1].nonce === result.nonce, 'fifteen gate lines');
  for (const key of ['pid', 'ppid', 'uid', 'pgid', 'start_sec', 'start_usec']) demand(lines[0][key] === c.child[key], `birth:${key}`);
  demand(lines[1].pid === c.child.pid && lines[1].start_sec === c.child.start_sec && lines[1].start_usec === c.child.start_usec, 'ACK birth');
  demand(lines[3].bytes_hex === ahex && lines[4].bytes_hex === bhex && lines[6].bytes_hex === bhex && lines[8].bytes_hex === ahex, 'positive controls');
  demand(lines[5].fd === 0 && lines[5].cloexec === true && lines[5].read_only === true && lines[5].identity_verified === true, 'retained fd');
  demand(lines[10].identity_matches === true && lines[11].read_count === 25 && lines[11].bytes_hex === bhex && lines[11].content_matches === true, 'actual retained read');
  demand(lines[12].close_rc === 0 && lines[12].f_getfd_rc === -1 && lines[12].f_getfd_errno === 9 && lines[12].closed_verified === true, 'close EBADF');
  if (name === 'fd-outer') {
    demand(lines[7].applied === true && lines[7].rc === 0, 'first OUTER');
    demand([9, 13].every(i => lines[i].open_ok === false && lines[i].open_errno === 1), 'fresh B EPERM before/after close');
  } else demand(lines[7].applied === false && lines[7].rc === null && [9, 13].every(i => lines[i].read_count === 25 && lines[i].bytes_hex === bhex), 'baseline without policy');
  demand(lines[14].retained_access === 'read_exact' && lines[14].retained_access_presumed === false && lines[14].FULL === false && lines[14].Chrome_qualified === false, 'local observation');
  const trace = files[2].raw.toString('utf8').trimEnd().split('\n').map(JSON.parse);
  demand(trace.length === 38 && trace.length === result.trace_events && files[2].ref.sha256 === result.trace_ref.sha256, 'trace pin/count');
  demand(trace.every((row, i) => i === 0 || row.monotonic >= trace[i - 1].monotonic), 'trace monotonic');
  const at = op => { const selected = trace.filter(x => x.op === op); demand(selected.length === 1, op); return selected[0]; };
  const release = at('release_written'), wait = at('wait_call'), reaped = at('wait_result');
  demand(reaped.returncode === 0 && reaped.pid === c.child.pid && reaped.monotonic <= wait.deadline && at('sinks_closed').stable === true, 'actual wait/sink closure');
  demand(at('ack_read').monotonic > release.monotonic && reaped.monotonic > release.monotonic, 'release then ACK then reap');
  cases.push({ case: name, child: c.child, owner: c.owner, source_unchanged: true, manifest_unchanged: true, actualReturnAndReap: 0, externalSignals: 0, retainedAccess: lines[14].retained_access, stdoutLines: 15, traceEvents: 38, refs: files.map(f => f.ref), releaseMonotonic: release.monotonic, reapMonotonic: reaped.monotonic });
}
demand(cases[0].reapMonotonic < cases[1].releaseMonotonic, 'baseline closed before outer release');
console.log(JSON.stringify({ schema: 'c17-lot79-main-outcome-filesystem-check-v1', actor: '/root', checkedAt: new Date().toISOString(), manifestRef: manifestFile.ref, cases, strictBigintStatBeforeAfter: true, timestampTolerance: null, fileSystemOnly: true, nativeApisCalledByThisCheck: false, ChromeQualified: false, FULL: false, release: false }, null, 2));
