"""Runner LOT79 préparatoire fermé : aucun enfant possible dans cette copie.

Le manifeste extérieur est vérifié avant import local. MAIN doit en épingler
les octets et les trois sources Python avant de lancer ce fichier avec -I -B.
"""

from __future__ import annotations

import fcntl
import hashlib
import json
import os
import secrets
import stat
import sys
import types
from pathlib import Path
from typing import Any

PREPARATION_ONLY = True
ROOT = Path("/private/tmp/therese-c17-fd-main-Bp9K3omj")
WITNESS_ROOT = ROOT
MANIFEST = ROOT / "NATIVE-SOURCES.json"
CASES = frozenset(("fd-baseline", "fd-outer"))
EXPECTED = frozenset((
    ROOT / "native_main-active.py", ROOT / "controller-native.py", ROOT / "native_port-native.py",
    ROOT / "probe", ROOT / "probe-native.c",
    WITNESS_ROOT / "witnesses/a.txt", WITNESS_ROOT / "witnesses/b.txt",
    WITNESS_ROOT / "policies/outer.sb",
))


def require(ok: bool, message: str) -> None:
    if not ok:
        raise ValueError(message)


def stable(st: os.stat_result) -> tuple[int, ...]:
    return (st.st_dev, st.st_ino, st.st_uid, st.st_gid, st.st_mode,
            st.st_nlink, st.st_size, st.st_mtime_ns, st.st_ctime_ns)


def file_ref(path: Path) -> dict[str, Any]:
    before = path.lstat()
    require(path.resolve(strict=True) == path and stat.S_ISREG(before.st_mode)
            and before.st_uid == os.getuid() and before.st_nlink == 1
            and before.st_size <= 65536, "source non régulière/privée/bornée")
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        require(stable(os.fstat(fd)) == stable(before), "source changée à l'ouverture")
        digest = hashlib.sha256()
        while block := os.read(fd, 65536):
            digest.update(block)
        require(stable(path.lstat()) == stable(before), "source changée après lecture")
    finally:
        os.close(fd)
    return {"path": str(path), "bytes": before.st_size, "sha256": digest.hexdigest()}


def private_dir(path: Path, *, create: bool = False, exclusive: bool = False) -> None:
    if create:
        try:
            path.mkdir(mode=0o700)
        except FileExistsError:
            require(not exclusive, "cas déjà utilisé")
    st = path.lstat()
    require(path.resolve(strict=True) == path and stat.S_ISDIR(st.st_mode)
            and st.st_uid == os.getuid() and stat.S_IMODE(st.st_mode) == 0o700,
            "répertoire QA non canonique/privé")


def read_locked_manifest() -> tuple[int, tuple[dict[str, Any], ...], dict[str, Any], tuple[int, ...]]:
    before = MANIFEST.lstat()
    require(MANIFEST.resolve(strict=True) == MANIFEST and stat.S_ISREG(before.st_mode)
            and before.st_uid == os.getuid() and before.st_nlink == 1
            and before.st_size <= 8192, "manifeste non canonique/borné")
    fd = os.open(MANIFEST, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        require(stable(os.fstat(fd)) == stable(before), "manifeste changé avant verrou")
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        raw = os.pread(fd, 8193, 0)
        require(len(raw) == before.st_size and stable(MANIFEST.lstat()) == stable(before),
                "manifeste changé pendant lecture")
        data = json.loads(raw.decode("utf-8"))
        require(type(data) is dict and frozenset(data) ==
                frozenset(("schema", "root", "witness_root", "files"))
                and data["schema"] == "c17-seatbelt-fd-native-sources-v1"
                and data["root"] == str(ROOT)
                and data["witness_root"] == str(WITNESS_ROOT), "manifeste hors contrat")
        rows = data["files"]
        require(type(rows) is list and len(rows) == len(EXPECTED), "table sources incomplète")
        require(all(type(row) is dict and frozenset(row) ==
                    frozenset(("path", "bytes", "sha256"))
                    and type(row["path"]) is str and type(row["bytes"]) is int
                    and type(row["sha256"]) is str for row in rows), "source ref mal formée")
        require({Path(row["path"]) for row in rows} == EXPECTED,
                "chemins sources hors table")
        refs = tuple(rows)
        require(all(file_ref(Path(ref["path"])) == ref for ref in refs),
                "source différente avant import/Popen")
        own = {"path": str(MANIFEST), "bytes": len(raw),
               "sha256": hashlib.sha256(raw).hexdigest()}
        return fd, refs, own, stable(before)
    except BaseException:
        os.close(fd)
        raise


def load_local(name: str, path: Path, expected: dict[str, Any]) -> Any:
    before = path.lstat()
    require(path.resolve(strict=True) == path and stat.S_ISREG(before.st_mode)
            and before.st_uid == os.getuid() and before.st_nlink == 1
            and before.st_size == expected["bytes"], "module local changé")
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        require(stable(os.fstat(fd)) == stable(before), "module changé à l'ouverture")
        raw = os.read(fd, 65537)
        require(len(raw) == before.st_size and
                hashlib.sha256(raw).hexdigest() == expected["sha256"]
                and stable(path.lstat()) == stable(before), "module non épinglé")
    finally:
        os.close(fd)
    module = types.ModuleType(name)
    module.__file__ = str(path)
    sys.modules[name] = module
    exec(compile(raw, str(path), "exec"), module.__dict__)
    return module


def exclusive_json(path: Path, body: dict[str, Any]) -> None:
    raw = (json.dumps(body, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=True) + "\n").encode("ascii")
    require(len(raw) <= 65536, "résultat non borné")
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC,
                 0o600)
    try:
        st = os.fstat(fd)
        require(stat.S_ISREG(st.st_mode) and st.st_uid == os.getuid()
                and stat.S_IMODE(st.st_mode) == 0o600 and st.st_nlink == 1
                and stable(st) == stable(path.lstat()), "résultat non exclusif")
        require(os.write(fd, raw) == len(raw), "résultat écrit partiellement")
        os.fsync(fd)
    finally:
        os.close(fd)


def main() -> int:
    require(not PREPARATION_ONLY, "LOT79 préparé seulement : aucun Popen autorisé")
    require(len(sys.argv) == 3 and sys.argv[1] == "--reviewed-case"
            and sys.argv[2] in CASES, "CLI hors cas fermés")
    require(sys.flags.isolated == 1 and sys.dont_write_bytecode,
            "interpréteur -I -B requis")
    case = sys.argv[2]
    private_dir(ROOT)
    fd, refs, manifest_ref, manifest_stat = read_locked_manifest()
    try:
        private_dir(ROOT / "home", create=True)
        private_dir(ROOT / "tmp", create=True)
        private_dir(ROOT / "cases", create=True)
        case_dir = ROOT / "cases" / case
        private_dir(case_dir, create=True, exclusive=True)
        nonce = secrets.token_hex(16)
        refs_by_path = {ref["path"]: ref for ref in refs}
        controller = load_local("controller", ROOT / "controller-native.py",
                                refs_by_path[str(ROOT / "controller-native.py")])
        native_port = load_local("native_port", ROOT / "native_port-native.py",
                                 refs_by_path[str(ROOT / "native_port-native.py")])
        plan = controller.Plan(root=ROOT, binary=ROOT / "probe", cwd=case_dir,
                               stdout_path=case_dir / "stdout.log",
                               stderr_path=case_dir / "stderr.log", case=case,
                               nonce=nonce,
                               environment={"HOME": str(ROOT / "home"),
                                            "TMPDIR": str(ROOT / "tmp") + "/",
                                            "PATH": "/usr/bin:/bin"},
                               source_refs=refs)
        require(plan.argv() == (str(ROOT / "probe"), "--reviewed-case", case,
                                "--gate-nonce", nonce), "argv binaire divergent")
        trace_path = case_dir / "trace.jsonl"
        trace_fd = os.open(trace_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL |
                           os.O_NOFOLLOW | os.O_CLOEXEC, 0o600)
        trace_fault = False
        try:
            port = native_port.NativePort(trace_fd)
            observation = controller._drive(plan, port)
            trace_fault = port.trace_fault
            trace_count = port.trace_count
        finally:
            try:
                os.fsync(trace_fd)
            except OSError:
                trace_fault = True
            finally:
                os.close(trace_fd)
        if trace_fault:
            observation["errors"].append("trace JSONL incomplète")
            observation["clean"] = False
        try:
            source_unchanged = all(file_ref(Path(ref["path"])) == ref for ref in refs)
        except Exception as exc:
            source_unchanged = False
            observation["errors"].append(f"rehash sources:{type(exc).__name__}:{exc}")
        try:
            manifest_unchanged = (file_ref(MANIFEST) == manifest_ref
                                  and stable(MANIFEST.lstat()) == manifest_stat)
        except Exception as exc:
            manifest_unchanged = False
            observation["errors"].append(f"rehash manifeste:{type(exc).__name__}:{exc}")
        if not source_unchanged or not manifest_unchanged:
            observation["errors"].append("sources ou manifeste modifiés après mesure")
            observation["clean"] = False
        try:
            trace_ref = file_ref(trace_path)
        except Exception as exc:
            trace_ref = None
            observation["errors"].append(f"trace illisible:{type(exc).__name__}:{exc}")
            observation["clean"] = False
        result = {"schema": "c17-seatbelt-fd-native-result-v1", "case": case,
                  "nonce": nonce, "manifest_ref": manifest_ref, "trace_ref": trace_ref,
                  "trace_events": trace_count, "trace_fault": trace_fault,
                  "source_refs": list(refs), "source_unchanged": source_unchanged,
                  "manifest_unchanged": manifest_unchanged,
                  "controller": observation, "diagnostic_only": True,
                  "native_qualification": False, "FULL": False,
                  "Chrome_qualified": False}
        exclusive_json(case_dir / "result.json", result)
        return 0 if observation["clean"] and not trace_fault else 86
    finally:
        os.close(fd)


if __name__ == "__main__":
    raise SystemExit(main())
