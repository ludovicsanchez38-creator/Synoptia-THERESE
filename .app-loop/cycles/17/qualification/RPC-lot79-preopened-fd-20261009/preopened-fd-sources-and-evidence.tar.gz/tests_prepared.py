"""Tests purs LOT79 : aucun port OS ni lancement de la sonde."""

from __future__ import annotations

import json
import os
import sys
import types
import unittest
from pathlib import Path

ROOT = Path("/private/tmp/therese-c17-fd-main-Bp9K3omj")


def audit(event: str, args: tuple[object, ...]) -> None:
    blocked = ("subprocess.Popen", "os.system", "os.fork", "os.posix_spawn",
               "os.exec", "os.kill", "os.killpg", "socket.", "ctypes.dlopen")
    if any(event == name or event.startswith(name) for name in blocked):
        raise AssertionError(f"appel OS interdit dans test pur: {event}")


sys.addaudithook(audit)
source = (ROOT / "controller-prepared.py").read_text(encoding="utf-8")
controller = types.ModuleType("controller_prepared")
controller.__file__ = str(ROOT / "controller-prepared.py")
sys.modules[controller.__name__] = controller
exec(compile(source, controller.__file__, "exec"), controller.__dict__)


def sample_plan(case: str = "fd-baseline") -> object:
    binary = ROOT / "probe"
    return controller.Plan(
        root=ROOT, binary=binary, cwd=ROOT / "cases" / case,
        stdout_path=ROOT / "cases" / case / "stdout.log",
        stderr_path=ROOT / "cases" / case / "stderr.log",
        case=case, nonce="a" * 32,
        environment={"HOME": str(ROOT / "home"), "TMPDIR": str(ROOT / "tmp") + "/",
                     "PATH": "/usr/bin:/bin"},
        source_refs=({"path": str(binary), "bytes": 1, "sha256": "0" * 64},),
    )


def final_fixture(case: str, outcome: str = "read_exact") -> tuple[bytes, object,
                                                                    dict[str, object],
                                                                    dict[str, object], bytes, bytes]:
    p = FakePort()
    plan = sample_plan(case)
    common = {"diagnostic_only": True, "native_qualification": False}
    def witness(phase: str, name: str, denied: bool = False) -> dict[str, object]:
        return {"event": "witness_read", "phase": phase, "witness": name,
                "fd": -1 if denied else 0, "open_ok": not denied,
                "open_errno": 1 if denied else 0, "read_count": -1 if denied else 25,
                "read_errno": 0, "close_errno": 0, "offset": 0,
                "bytes_hex": "" if denied else
                             (controller.A_HEX if name == "A" else controller.B_HEX),
                "content_matches": not denied, "identity_matches": not denied,
                **common}
    def pread(phase: str, denied: bool = False) -> dict[str, object]:
        return {"event": "retained_pread", "phase": phase, "witness": "B", "fd": 0,
                "offset": 0, "read_count": -1 if denied else 25,
                "read_errno": 1 if denied else 0,
                "bytes_hex": "" if denied else controller.B_HEX,
                "content_matches": not denied, **common}
    ready_row = {"schema": controller.READY_SCHEMA, "case": case, "nonce": "a" * 32,
                 **{k: p.child[k] for k in controller.IDENTITY}}
    ack_row = {"schema": controller.RELEASED_SCHEMA, "case": case, "nonce": "a" * 32,
               "pid": 2000, "start_sec": 101, "start_usec": 2}
    outer = case == "fd-outer"
    denied_pread = outer and outcome == "pread_denied"
    observation = ("fd_baseline_controls_observed" if not outer
                   else "fd_outer_observed_retained_pread_denied" if denied_pread
                   else "fd_outer_observed_retained_read_exact")
    rows: list[dict[str, object]] = [
        ready_row, ack_row,
        {"event": "ambient_probe", "rc": 0, "errno": 0, **common},
        witness("baseline", "A"), witness("baseline", "B"),
        {"event": "retained_open", "witness": "B", "fd": 0, "open_errno": 0,
         "fd_flags": 1, "status_flags": 0, "fstat_rc": 0, "fstat_errno": 0,
         "dev": 1, "ino": 2, "uid": 501, "mode": 384, "nlink": 1, "size": 25,
         "cloexec": True, "read_only": True, "identity_verified": True, **common},
        pread("before_outer"),
        {"event": "outer_apply", "case": case, "applied": outer,
         "pid": 2000, "ppid": 1000, "uid": 501,
         "rc": 0 if outer else None, "errno": 0 if outer else None,
         "error": "", **common},
        witness("case", "A"), witness("case", "B", denied=outer),
        {"event": "retained_stat", "phase": "case", "witness": "B", "fd": 0,
         "rc": 0, "errno": 0, "dev": 1, "ino": 2, "uid": 501, "mode": 384,
         "nlink": 1, "size": 25, "identity_matches": True, **common},
        pread("case", denied=denied_pread),
        {"event": "retained_close", "witness": "B", "fd": 0,
         "close_rc": 0, "close_errno": 0, "f_getfd_rc": -1,
         "f_getfd_errno": 9, "closed_verified": True, **common},
        witness("after_close", "B", denied=outer),
        {"event": "case_finished", "case": case, "observation": observation,
         "retained_access": outcome, "measurement_completed": True,
         "controls_proved": True, "held_fd_closed": True, "deadline_met": True,
         "retained_access_presumed": False, "FULL": False,
         "Chrome_qualified": False, **common},
    ]
    def encode(row: dict[str, object]) -> bytes:
        return json.dumps(row, separators=(",", ":"), ensure_ascii=True).encode("ascii") + b"\n"
    parts = [encode(row) for row in rows]
    return b"".join(parts), plan, p.owner, p.child, parts[0], parts[1]


class FakePort:
    ACTUAL_NATIVE_IO = False

    def __init__(self) -> None:
        self.trace_fault = False
        self.t = 0.0
        self.spawn_count = 0
        self.release_count = 0
        self.rehash_count = 0
        self.child_changed = False
        self.exit_code: int | None = 0
        self.child_unknown = False
        self.fault_before_spawn = False
        self.fault_before_release = False
        self.expire_before_release = False
        self.ack_time: float | None = None
        self.wait_deadlines: list[float] = []
        self.wait_results: list[int | None] = []
        self.handle = types.SimpleNamespace(pid=2000)
        self.owner = {"pid": 1000, "ppid": 900, "uid": 501, "pgid": 1000,
                      "start_sec": 100, "start_usec": 1, "status": 2,
                      "executable": "/usr/bin/python3"}
        self.child = {"pid": 2000, "ppid": 1000, "uid": 501, "pgid": 2000,
                      "start_sec": 101, "start_usec": 2, "status": 2,
                      "executable": str(ROOT / "probe")}

    def now(self) -> float:
        return self.t

    def self_pid(self) -> int:
        return 1000

    def read_identity(self, pid: int) -> dict[str, object]:
        if pid == 1000:
            return dict(self.owner)
        if self.child_unknown:
            raise ProcessLookupError(pid)
        row = dict(self.child)
        if self.child_changed:
            row["start_usec"] = 3
        return row

    def verify_sources(self, refs: object) -> bool:
        self.rehash_count += 1
        if self.rehash_count == 2:
            if self.fault_before_release:
                self.trace_fault = True
            if self.expire_before_release:
                self.t = 5.1
        return True

    def open_sinks(self, plan: object) -> tuple[int, int]:
        if self.fault_before_spawn:
            self.trace_fault = True
        return (10, 11)

    def spawn(self, plan: object, sinks: object) -> object:
        self.spawn_count += 1
        return self.handle

    def read_ready(self, handle: object, sinks: object, deadline: float) -> bytes:
        row = {"schema": controller.READY_SCHEMA, "case": "fd-baseline",
               "nonce": "a" * 32,
               **{k: self.child[k] for k in controller.IDENTITY}}
        return json.dumps(row, separators=(",", ":")).encode("ascii") + b"\n"

    def read_gate_released(self, handle: object, sinks: object, deadline: float) -> bytes:
        if self.ack_time is not None:
            self.t = self.ack_time
        row = {"schema": controller.RELEASED_SCHEMA, "case": "fd-baseline",
               "nonce": "a" * 32, "pid": 2000, "start_sec": 101,
               "start_usec": 2}
        return json.dumps(row, separators=(",", ":")).encode("ascii") + b"\n"

    def release(self, handle: object, payload: bytes) -> None:
        self.release_count += 1

    def close_gate(self, handle: object) -> None:
        pass

    def poll(self, handle: object) -> None:
        return None

    def wait_until(self, handle: object, deadline: float) -> int | None:
        self.wait_deadlines.append(deadline)
        if self.wait_results:
            result = self.wait_results.pop(0)
            self.t = deadline
            return result
        self.t = min(deadline, max(self.t, 0.1))
        return self.exit_code

    def read_final(self, handle: object, sinks: object) -> bytes:
        return b"synthetic-final\n"

    def close_sinks(self, sinks: object) -> bool:
        return True


class PreparedTests(unittest.TestCase):
    def test_entry_is_disabled(self) -> None:
        self.assertFalse(controller.NATIVE_MEASUREMENT_ENABLED)
        with self.assertRaises(RuntimeError):
            controller._drive(sample_plan(), FakePort())
        with self.assertRaises(RuntimeError):
            controller.activate()

    def test_closed_cases_and_environment(self) -> None:
        self.assertEqual(controller.CASES, frozenset(("fd-baseline", "fd-outer")))
        sample_plan().validate()
        bad = sample_plan()
        object.__setattr__(bad, "case", "compiled-alpha")
        with self.assertRaises(ValueError):
            bad.validate()

    def test_ack_exact_bytes_and_boolean_refused(self) -> None:
        p = FakePort()
        raw = p.read_gate_released(p.handle, (), 5)
        controller.parse_released(raw, sample_plan(), p.child)
        for mutant in (raw.replace(b'"pid":2000', b'"pid":true'),
                       raw.replace(b',"pid":', b', "pid":'),
                       raw.replace(b'"pid":2000', b'"pid":2000,"pid":2000')):
            with self.assertRaises(ValueError):
                controller.parse_released(mutant, sample_plan(), p.child)

    def test_final_gate_lines_are_same_observations(self) -> None:
        p = FakePort()
        ready = p.read_ready(p.handle, (), 5)
        ack = p.read_gate_released(p.handle, (), 5)
        with self.assertRaisesRegex(ValueError, "ne sont pas les lignes"):
            raw, *_ = final_fixture("fd-baseline")
            controller.parse_final(raw, sample_plan(), p.owner, p.child,
                                   ready.replace(b'"case":"fd-baseline"', b'"case":"fd-outer"'),
                                   ack)
        self.assertTrue(controller.parse_final(raw, sample_plan(), p.owner, p.child,
                                               ready, ack))

    def test_three_closed_outcomes(self) -> None:
        for case, outcome in (("fd-baseline", "read_exact"),
                              ("fd-outer", "read_exact"),
                              ("fd-outer", "pread_denied")):
            with self.subTest(case=case, outcome=outcome):
                self.assertTrue(controller.parse_final(*final_fixture(case, outcome)))

    def test_retained_pread_eacces_is_raw_observation(self) -> None:
        raw, plan, owner, child, ready, ack = final_fixture("fd-outer", "pread_denied")
        rows = [json.loads(line) for line in raw.splitlines()]
        rows[11]["read_errno"] = 13
        changed = b"".join(json.dumps(row, separators=(",", ":"))
                           .encode("ascii") + b"\n" for row in rows)
        self.assertTrue(controller.parse_final(changed, plan, owner, child, ready, ack))

    def test_ambient_errno_is_raw_when_rc_zero(self) -> None:
        raw, plan, owner, child, ready, ack = final_fixture("fd-baseline")
        rows = [json.loads(line) for line in raw.splitlines()]
        rows[2]["errno"] = 1
        changed = b"".join(json.dumps(row, separators=(",", ":"))
                           .encode("ascii") + b"\n" for row in rows)
        self.assertTrue(controller.parse_final(changed, plan, owner, child, ready, ack))
        rows[2]["rc"] = -1
        denied = b"".join(json.dumps(row, separators=(",", ":"))
                          .encode("ascii") + b"\n" for row in rows)
        with self.assertRaises(ValueError):
            controller.parse_final(denied, plan, owner, child, ready, ack)

    def test_final_mutants_are_red(self) -> None:
        raw, plan, owner, child, ready, ack = final_fixture("fd-outer", "pread_denied")
        rows = [json.loads(line) for line in raw.splitlines()]
        mutations = (
            (9, "open_errno", 0),  # B ne peut être fraîchement ouvert sous OUTER.
            (11, "read_errno", 9),  # EBADF retenu n'est pas EPERM/EACCES.
            (12, "f_getfd_errno", 0),
            (14, "retained_access_presumed", True),
            (14, "FULL", True),
            (5, "uid", 0),
            (10, "ino", 999),
            (3, "content_matches", False),
            (14, "deadline_met", False),
        )
        for index, key, value in mutations:
            with self.subTest(index=index, key=key):
                changed = [dict(row) for row in rows]
                changed[index][key] = value
                mutant = b"".join(json.dumps(row, separators=(",", ":"))
                                   .encode("ascii") + b"\n" for row in changed)
                with self.assertRaises(ValueError):
                    controller.parse_final(mutant, plan, owner, child, ready, ack)
        for mutation in (rows[:14], rows + [rows[-1]],
                         rows[:8] + [rows[9], rows[8]] + rows[10:]):
            with self.subTest(length=len(mutation)):
                mutant = b"".join(json.dumps(row, separators=(",", ":"))
                                   .encode("ascii") + b"\n" for row in mutation)
                with self.assertRaises(ValueError):
                    controller.parse_final(mutant, plan, owner, child, ready, ack)
        baseline_raw, baseline_plan, bo, bc, br, ba = final_fixture("fd-baseline")
        baseline_rows = [json.loads(line) for line in baseline_raw.splitlines()]
        baseline_rows[9]["open_ok"] = False
        mutant = b"".join(json.dumps(row, separators=(",", ":"))
                           .encode("ascii") + b"\n" for row in baseline_rows)
        with self.assertRaises(ValueError):
            controller.parse_final(mutant, baseline_plan, bo, bc, br, ba)

    def test_jsonl_rejects_duplicates_and_non_objects(self) -> None:
        for raw in (b'{"event":"x","event":"x"}\n', b'[]\n',
                    b'{"event":"x"}\r\n'):
            with self.assertRaises(ValueError):
                controller._unique_json_line(raw)

    def test_trace_failure_blocks_spawn(self) -> None:
        p = FakePort()
        p.fault_before_spawn = True
        result = controller._drive_core(sample_plan(), p)
        self.assertEqual(p.spawn_count, 0)
        self.assertFalse(result["clean"])

    def test_trace_failure_blocks_release(self) -> None:
        p = FakePort()
        p.fault_before_release = True
        result = controller._drive_core(sample_plan(), p)
        self.assertEqual(p.spawn_count, 1)
        self.assertEqual(p.release_count, 0)
        self.assertFalse(result["clean"])

    def test_recheck_after_rehash_blocks_release(self) -> None:
        p = FakePort()
        original = p.verify_sources
        def change_after_rehash(refs: object) -> bool:
            okay = original(refs)
            if p.rehash_count == 2:
                p.child_changed = True
            return okay
        p.verify_sources = change_after_rehash  # type: ignore[method-assign]
        result = controller._drive_core(sample_plan(), p)
        self.assertEqual(p.release_count, 0)
        self.assertFalse(result["clean"])

    def test_absolute_gate_blocks_release(self) -> None:
        p = FakePort()
        p.expire_before_release = True
        result = controller._drive_core(sample_plan(), p)
        self.assertEqual(p.release_count, 0)
        self.assertFalse(result["clean"])

    def test_unknown_birth_no_clean(self) -> None:
        p = FakePort()
        p.child_unknown = True
        result = controller._drive_core(sample_plan(), p)
        self.assertIsNone(result["child"])
        self.assertEqual(result["signals"], [])
        self.assertFalse(result["termination_proved"])
        self.assertFalse(result["clean"])

    def test_mocked_oracle_never_claims_native_io(self) -> None:
        p = FakePort()
        old = controller.parse_final
        controller.parse_final = lambda raw, plan, owner, child, ready, ack: True
        try:
            result = controller._drive_core(sample_plan(), p)
        finally:
            controller.parse_final = old
        self.assertEqual(p.release_count, 1)
        self.assertTrue(result["clean"])
        self.assertFalse(result["actual_native_IO"])

    def test_case_window_is_five_seconds_after_ack(self) -> None:
        p = FakePort()
        p.ack_time = 4.5
        old = controller.parse_final
        controller.parse_final = lambda raw, plan, owner, child, ready, ack: True
        try:
            result = controller._drive_core(sample_plan(), p)
        finally:
            controller.parse_final = old
        self.assertEqual(p.wait_deadlines[0], 9.5)
        self.assertTrue(result["clean"])

    def test_prepared_runner_future_paths_and_no_signal_api(self) -> None:
        runner = (ROOT / "native_main-prepared.py").read_text(encoding="utf-8")
        port = (ROOT / "native_port-prepared.py").read_text(encoding="utf-8")
        compile(runner, str(ROOT / "native_main-prepared.py"), "exec")
        compile(port, str(ROOT / "native_port-prepared.py"), "exec")
        self.assertIn("PREPARATION_ONLY = True", runner)
        self.assertIn('"fd-baseline", "fd-outer"', runner)
        self.assertIn("controller-native.py", runner)
        self.assertIn("native_port-native.py", runner)
        self.assertNotIn("os.kill(", port)
        self.assertNotIn("signal_pid", port)
        spawn = port.split("    def spawn(", 1)[1].split("    def _line(", 1)[0]
        release = port.split("    def release(", 1)[1].split("    def close_gate(", 1)[0]
        self.assertLess(spawn.index('self._record("spawn_call"'),
                        spawn.rindex("require(not self.trace_fault"))
        self.assertLess(spawn.rindex("require(not self.trace_fault"),
                        spawn.index("subprocess.Popen("))
        self.assertLess(release.index('self._record("release_write_call"'),
                        release.rindex("require(not self.trace_fault"))
        self.assertLess(release.rindex("require(not self.trace_fault"),
                        release.index("handle.stdin.write("))

    def test_nonzero_exit_is_never_clean(self) -> None:
        p = FakePort()
        p.exit_code = 86
        result = controller._drive_core(sample_plan(), p)
        self.assertEqual(result["returncode"], 86)
        self.assertFalse(result["clean"])

    def test_late_terminal_reap_does_not_whiten_cleanup(self) -> None:
        p = FakePort()
        p.wait_results = [None, None, 0]
        result = controller._drive_core(sample_plan(), p)
        self.assertEqual(p.wait_deadlines, [5.0, 13.0, 18.0])
        self.assertEqual(result["returncode"], 0)
        self.assertTrue(result["termination_proved"])
        self.assertFalse(result["cleanup_deadline_met"])
        self.assertFalse(result["clean"])


if __name__ == "__main__":
    unittest.main()
