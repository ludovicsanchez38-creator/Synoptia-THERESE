"""Contrôleur préparatoire LOT79, mono-sonde et désactivé.

`activate` et `_drive` refusent toujours. `_drive_core` n'est exercé que par
des ports doubles sous garde d'audit ; aucun lancement n'est autorisé ici.
"""

from __future__ import annotations

import errno
import json
import math
import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Protocol

NATIVE_MEASUREMENT_ENABLED = False
ROOT = Path("/private/tmp/therese-c17-fd-main-Bp9K3omj")
CASES = frozenset(("fd-baseline", "fd-outer"))
IDENTITY = ("pid", "ppid", "uid", "pgid", "start_sec", "start_usec")
READY_SCHEMA = "c17-seatbelt-composition-ready-v1"
RELEASE_SCHEMA = "c17-seatbelt-composition-release-v1"
RELEASED_SCHEMA = "c17-seatbelt-composition-gate-released-v1"
READY_KEYS = frozenset(("schema", "case", "nonce", *IDENTITY))
GATE_SECONDS = 5.0
CASE_SECONDS = 5.0
CLEANUP_SECONDS = 8.0
TOTAL_MEASUREMENT_SECONDS = GATE_SECONDS + CASE_SECONDS
TERMINAL_WAIT_SECONDS = TOTAL_MEASUREMENT_SECONDS + CLEANUP_SECONDS
A_HEX = b"A:synthetic-witness-only\n".hex()
B_HEX = b"B:synthetic-witness-only\n".hex()


def require(ok: bool, reason: str) -> None:
    if not ok:
        raise ValueError(reason)


@dataclass(frozen=True)
class Plan:
    root: Path
    binary: Path
    cwd: Path
    stdout_path: Path
    stderr_path: Path
    case: str
    nonce: str
    environment: dict[str, str]
    source_refs: tuple[dict[str, Any], ...]

    def validate(self) -> None:
        require(self.case in CASES, "cas hors table")
        require(type(self.nonce) is str and re.fullmatch(r"[0-9a-f]{32}", self.nonce) is not None,
                "nonce invalide")
        require(all(isinstance(p, Path) and p.is_absolute() for p in
                    (self.root, self.binary, self.cwd, self.stdout_path, self.stderr_path)),
                "chemins absolus requis")
        require(self.root == ROOT and self.binary == ROOT / "probe"
                and self.cwd == ROOT / "cases" / self.case,
                "root/binaire/cwd hors QA exacte")
        require(self.stdout_path == self.cwd / "stdout.log"
                and self.stderr_path == self.cwd / "stderr.log",
                "sinks QA distincts et exacts")
        require(type(self.environment) is dict and self.environment == {
            "HOME": str(self.root / "home"),
            "TMPDIR": str(self.root / "tmp") + "/",
            "PATH": "/usr/bin:/bin",
        }, "environnement synthétique non fermé")
        require(type(self.source_refs) is tuple and len(self.source_refs) > 0,
                "préimages exactes requises")
        require(any(type(ref) is dict and ref.get("path") == str(self.binary)
                    and type(ref.get("bytes")) is int and type(ref.get("sha256")) is str
                    for ref in self.source_refs), "binaire non épinglé")

    def argv(self) -> tuple[str, ...]:
        self.validate()
        return (str(self.binary), "--reviewed-case", self.case, "--gate-nonce", self.nonce)


def identity(row: dict[str, Any], *, expected_binary: str | None = None) -> tuple[int, ...]:
    require(type(row) is dict and all(type(row.get(k)) is int for k in IDENTITY),
            "naissance libproc incomplète")
    require(row["pid"] > 1 and row["ppid"] > 0 and row["uid"] >= 0 and row["pgid"] > 0
            and row["start_sec"] > 0 and 0 <= row["start_usec"] < 1_000_000,
            "naissance libproc invalide")
    # BSD SRUN=2, SSLEEP=3. SIDL/SSTOP/SZOMB ne sont pas une gate vivante.
    require(type(row.get("status")) is int and row["status"] in (2, 3),
            "statut non vivant/incertain")
    if expected_binary is not None:
        require(row.get("executable") == expected_binary, "exécutable différent")
    return tuple(row[k] for k in IDENTITY)


def parse_ready(raw: bytes, plan: Plan, owner: dict[str, Any], child: dict[str, Any]) -> None:
    require(type(raw) is bytes and len(raw) <= 512 and raw.endswith(b"\n")
            and raw.count(b"\n") == 1, "ready non borné ou incomplet")

    def unique(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for key, value in pairs:
            require(key not in result, "clé ready dupliquée")
            result[key] = value
        return result

    row = json.loads(raw.decode("ascii"), object_pairs_hook=unique)
    require(type(row) is dict and frozenset(row) == READY_KEYS, "schéma ready divergent")
    require(row["schema"] == READY_SCHEMA and row["case"] == plan.case
            and row["nonce"] == plan.nonce, "ready cas/nonce divergent")
    require(all(type(row[k]) is int and row[k] == child[k] for k in IDENTITY),
            "ready naissance divergente")
    require(child["ppid"] == owner["pid"] and child["uid"] == owner["uid"]
            and child["pgid"] == child["pid"], "filiation/UID/PGID divergents")


def release_bytes(plan: Plan, child: dict[str, Any]) -> bytes:
    row = {"schema": RELEASE_SCHEMA, "case": plan.case, "nonce": plan.nonce,
           "pid": child["pid"], "start_sec": child["start_sec"],
           "start_usec": child["start_usec"]}
    return json.dumps(row, separators=(",", ":"), ensure_ascii=True).encode("ascii") + b"\n"


def parse_released(raw: bytes, plan: Plan, child: dict[str, Any]) -> None:
    require(type(raw) is bytes and len(raw) <= 512 and raw.endswith(b"\n")
            and raw.count(b"\n") == 1, "ACK gate incomplet")
    def unique(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
        row: dict[str, Any] = {}
        for key, value in pairs:
            require(key not in row, "ACK gate clé dupliquée")
            row[key] = value
        return row

    row = json.loads(raw.decode("ascii"), object_pairs_hook=unique)
    require(type(row) is dict and frozenset(row) == frozenset(
        ("schema", "case", "nonce", "pid", "start_sec", "start_usec")),
        "ACK gate champs divergents")
    require(all(type(row[k]) is int for k in ("pid", "start_sec", "start_usec")),
            "ACK gate entiers stricts requis")
    expected = {"schema": RELEASED_SCHEMA, "case": plan.case, "nonce": plan.nonce,
                "pid": child["pid"], "start_sec": child["start_sec"],
                "start_usec": child["start_usec"]}
    require(row == expected and raw == json.dumps(expected, separators=(",", ":"),
                                              ensure_ascii=True).encode("ascii") + b"\n",
            "ACK gate octets compacts exacts divergents")


def _unique_json_line(raw: bytes) -> dict[str, Any]:
    require(type(raw) is bytes and len(raw) <= 512 and raw.endswith(b"\n")
            and raw.count(b"\n") == 1 and b"\r" not in raw,
            "ligne JSONL non compacte/bornée")
    def unique(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
        row: dict[str, Any] = {}
        for key, value in pairs:
            require(key not in row, "clé JSONL dupliquée")
            row[key] = value
        return row
    row = json.loads(raw.decode("ascii"), object_pairs_hook=unique)
    require(type(row) is dict, "événement JSONL non objet")
    require(raw == json.dumps(row, separators=(",", ":"),
                              ensure_ascii=True).encode("ascii") + b"\n",
            "événement JSONL non compact")
    return row


def _fields(row: dict[str, Any], names: tuple[str, ...], event: str) -> None:
    require(frozenset(row) == frozenset(names) and row.get("event") == event,
            f"{event} champs/nom divergents")
    require(type(row.get("diagnostic_only")) is bool and row["diagnostic_only"] is True
            and type(row.get("native_qualification")) is bool
            and row["native_qualification"] is False,
            f"{event} qualification interdite")


def _int(row: dict[str, Any], key: str, *, minimum: int | None = None) -> int:
    value = row.get(key)
    require(type(value) is int and (minimum is None or value >= minimum),
            f"entier strict {key} invalide")
    return value


def _witness(row: dict[str, Any], phase: str, name: str, *, denied: bool) -> None:
    _fields(row, ("event", "phase", "witness", "fd", "open_ok", "open_errno",
                  "read_count", "read_errno", "close_errno", "offset", "bytes_hex",
                  "content_matches", "identity_matches", "diagnostic_only",
                  "native_qualification"), "witness_read")
    require(row["phase"] == phase and row["witness"] == name
            and _int(row, "offset") == 0, "témoin phase/nom/offset divergents")
    require(type(row["open_ok"]) is bool and type(row["content_matches"]) is bool
            and type(row["identity_matches"]) is bool
            and type(row["bytes_hex"]) is str, "témoin types invalides")
    expected = A_HEX if name == "A" else B_HEX
    if denied:
        require(_int(row, "fd") == -1 and row["open_ok"] is False
                and _int(row, "open_errno") == errno.EPERM
                and _int(row, "read_count") == -1
                and _int(row, "read_errno") == 0
                and _int(row, "close_errno") == 0
                and row["bytes_hex"] == ""
                and row["content_matches"] is False
                and row["identity_matches"] is False,
                "témoin refus B non prouvé")
    else:
        fd = _int(row, "fd", minimum=0)
        require(fd not in (1, 2) and row["open_ok"] is True
                and _int(row, "open_errno") == 0
                and _int(row, "read_count") == 25
                and _int(row, "read_errno") == 0
                and _int(row, "close_errno") == 0
                and row["bytes_hex"] == expected
                and row["content_matches"] is True
                and row["identity_matches"] is True,
                "témoin positif incomplet")


def _pread(row: dict[str, Any], phase: str, fd: int,
           *, outcome: str) -> None:
    _fields(row, ("event", "phase", "witness", "fd", "offset", "read_count",
                  "read_errno", "bytes_hex", "content_matches",
                  "diagnostic_only", "native_qualification"), "retained_pread")
    require(row["phase"] == phase and row["witness"] == "B"
            and _int(row, "fd") == fd and _int(row, "offset") == 0
            and type(row["bytes_hex"]) is str
            and type(row["content_matches"]) is bool,
            "pread identité/offset/type divergent")
    if outcome == "read_exact":
        require(_int(row, "read_count") == 25 and _int(row, "read_errno") == 0
                and row["bytes_hex"] == B_HEX and row["content_matches"] is True,
                "pread B conservé non exact")
    else:
        require(outcome == "pread_denied" and _int(row, "read_count") == -1
                and _int(row, "read_errno") in (errno.EPERM, errno.EACCES)
                and row["bytes_hex"] == "" and row["content_matches"] is False,
                "pread B refusé non prouvé")


def parse_final(raw: bytes, plan: Plan, owner: dict[str, Any],
                child: dict[str, Any], ready_line: bytes, ack_line: bytes) -> bool:
    """Vérifie quinze événements directs, sans présumer la lecture FD sous OUTER."""
    require(type(raw) is bytes and 0 < len(raw) <= 8192 and raw.endswith(b"\n"),
            "stdout final non borné/incomplet")
    lines = raw.splitlines(keepends=True)
    require(len(lines) == 15 and all(0 < len(line) <= 512
                                     and line.endswith(b"\n") for line in lines),
            "lignes stdout finales hors bornes")
    require(lines[0] == ready_line and lines[1] == ack_line,
            "ready/ACK finaux ne sont pas les lignes de gate observées")
    parse_ready(lines[0], plan, owner, child)
    parse_released(lines[1], plan, child)
    rows = [_unique_json_line(line) for line in lines[2:]]
    ambient = rows[0]
    _fields(ambient, ("event", "rc", "errno", "diagnostic_only",
                      "native_qualification"), "ambient_probe")
    require(_int(ambient, "rc") == 0 and _int(ambient, "errno", minimum=0) >= 0,
            "sandbox ambiante non libre")
    _witness(rows[1], "baseline", "A", denied=False)
    _witness(rows[2], "baseline", "B", denied=False)

    opened = rows[3]
    _fields(opened, ("event", "witness", "fd", "open_errno", "fd_flags",
                     "status_flags", "fstat_rc", "fstat_errno", "dev", "ino",
                     "uid", "mode", "nlink", "size", "cloexec", "read_only",
                     "identity_verified", "diagnostic_only", "native_qualification"),
            "retained_open")
    held_fd = _int(opened, "fd", minimum=0)
    require(opened["witness"] == "B" and held_fd not in (1, 2)
            and _int(opened, "open_errno") == 0
            and _int(opened, "fd_flags", minimum=0) & 1 == 1
            and _int(opened, "status_flags", minimum=0) & os.O_ACCMODE == os.O_RDONLY
            and _int(opened, "fstat_rc") == 0 and _int(opened, "fstat_errno") == 0
            and _int(opened, "dev", minimum=1) > 0
            and _int(opened, "ino", minimum=1) > 0
            and _int(opened, "uid") == owner["uid"]
            and _int(opened, "mode") == 0o600 and _int(opened, "nlink") == 1
            and _int(opened, "size") == 25
            and all(type(opened[k]) is bool and opened[k] is True
                    for k in ("cloexec", "read_only", "identity_verified")),
            "FD B préouvert non attribué/privé")
    _pread(rows[4], "before_outer", held_fd, outcome="read_exact")

    outer = rows[5]
    _fields(outer, ("event", "case", "applied", "pid", "ppid", "uid", "rc",
                    "errno", "error", "diagnostic_only", "native_qualification"),
            "outer_apply")
    require(outer["case"] == plan.case and type(outer["applied"]) is bool
            and _int(outer, "pid") == child["pid"]
            and _int(outer, "ppid") == owner["pid"]
            and _int(outer, "uid") == owner["uid"]
            and outer["error"] == "", "OUTER identité/cas divergents")
    if plan.case == "fd-baseline":
        require(outer["applied"] is False and outer["rc"] is None
                and outer["errno"] is None, "baseline a appliqué OUTER")
    else:
        require(outer["applied"] is True and _int(outer, "rc") == 0
                and _int(outer, "errno", minimum=0) >= 0,
                "OUTER non appliquée")
    _witness(rows[6], "case", "A", denied=False)
    _witness(rows[7], "case", "B", denied=plan.case == "fd-outer")

    held_stat = rows[8]
    _fields(held_stat, ("event", "phase", "witness", "fd", "rc", "errno",
                        "dev", "ino", "uid", "mode", "nlink", "size",
                        "identity_matches", "diagnostic_only", "native_qualification"),
            "retained_stat")
    require(held_stat["phase"] == "case" and held_stat["witness"] == "B"
            and _int(held_stat, "fd") == held_fd
            and _int(held_stat, "rc") == 0 and _int(held_stat, "errno") == 0
            and type(held_stat["identity_matches"]) is bool
            and held_stat["identity_matches"] is True
            and all(_int(held_stat, k) == _int(opened, k)
                    for k in ("dev", "ino", "uid", "mode", "nlink", "size")),
            "FD B retenu a changé")

    case_pread = rows[9]
    outcome = ("read_exact" if plan.case == "fd-baseline" or
               type(case_pread.get("read_count")) is int
               and case_pread["read_count"] == 25 else "pread_denied")
    _pread(case_pread, "case", held_fd, outcome=outcome)

    closed = rows[10]
    _fields(closed, ("event", "witness", "fd", "close_rc", "close_errno",
                     "f_getfd_rc", "f_getfd_errno", "closed_verified",
                     "diagnostic_only", "native_qualification"), "retained_close")
    require(closed["witness"] == "B" and _int(closed, "fd") == held_fd
            and _int(closed, "close_rc") == 0 and _int(closed, "close_errno") == 0
            and _int(closed, "f_getfd_rc") == -1
            and _int(closed, "f_getfd_errno") == errno.EBADF
            and type(closed["closed_verified"]) is bool
            and closed["closed_verified"] is True,
            "fermeture unique FD B/EBADF non prouvée")
    _witness(rows[11], "after_close", "B", denied=plan.case == "fd-outer")

    finished = rows[12]
    _fields(finished, ("event", "case", "observation", "retained_access",
                       "measurement_completed", "controls_proved", "held_fd_closed",
                       "deadline_met", "retained_access_presumed", "diagnostic_only",
                       "native_qualification", "FULL", "Chrome_qualified"),
            "case_finished")
    expected_observation = ("fd_baseline_controls_observed" if plan.case == "fd-baseline"
                            else "fd_outer_observed_retained_read_exact" if outcome == "read_exact"
                            else "fd_outer_observed_retained_pread_denied")
    require(finished["case"] == plan.case
            and finished["observation"] == expected_observation
            and finished["retained_access"] == outcome
            and all(type(finished[k]) is bool and finished[k] is True for k in
                    ("measurement_completed", "controls_proved", "held_fd_closed",
                     "deadline_met"))
            and all(type(finished[k]) is bool and finished[k] is False for k in
                    ("retained_access_presumed", "FULL", "Chrome_qualified")),
            "résumé C contradictoire ou qualification fictive")
    return True


class Port(Protocol):
    def now(self) -> float: ...
    def self_pid(self) -> int: ...
    def read_identity(self, pid: int) -> dict[str, Any]: ...
    def verify_sources(self, refs: tuple[dict[str, Any], ...]) -> bool: ...
    def open_sinks(self, plan: Plan) -> Any: ...
    def spawn(self, plan: Plan, sinks: Any) -> Any: ...
    def read_ready(self, handle: Any, sinks: Any, deadline: float) -> bytes: ...
    def read_gate_released(self, handle: Any, sinks: Any, deadline: float) -> bytes: ...
    def release(self, handle: Any, payload: bytes) -> None: ...
    def close_gate(self, handle: Any) -> None: ...
    def poll(self, handle: Any) -> int | None: ...
    def wait_until(self, handle: Any, deadline: float) -> int | None: ...
    def read_final(self, handle: Any, sinks: Any) -> bytes: ...
    def close_sinks(self, sinks: Any) -> bool: ...


def _same_live(port: Port, owner: dict[str, Any], child: dict[str, Any],
               plan: Plan) -> bool:
    """Lecture fraîche avant release ; erreur = incertitude."""
    try:
        same_owner = identity(port.read_identity(owner["pid"]),
                              expected_binary=owner["executable"]) == identity(owner)
        same_child = identity(port.read_identity(child["pid"]),
                              expected_binary=str(plan.binary)) == identity(child)
        return same_owner and same_child
    except BaseException:
        # Une interruption ou une lecture partielle interdit la libération.
        return False


def _drive(plan: Plan, port: Port) -> dict[str, Any]:
    """Entrée native fermée jusqu'à dérivation et revue MAIN distinctes."""
    raise RuntimeError("LOT79 préparé seulement : activation native interdite")


def _drive_core(plan: Plan, port: Port) -> dict[str, Any]:
    """Logique purement testable par port double ; aucun port réel ici."""
    plan.validate()
    started = port.now()
    require(type(started) in (int, float) and math.isfinite(started) and started >= 0,
            "horloge monotone invalide")
    gate_deadline = started + GATE_SECONDS
    measurement_deadline = started + TOTAL_MEASUREMENT_SECONDS
    terminal_deadline = started + TERMINAL_WAIT_SECONDS
    owner = port.read_identity(port.self_pid())
    identity(owner)
    require(type(owner.get("executable")) is str and owner["executable"].startswith("/"),
            "exécutable parent inconnu")
    sinks = handle = child = None
    released = confirmed = gate_closed = reaped = stable = sources_unchanged = False
    returncode: int | None = None
    errors: list[str] = []
    final_oracle = False
    ready_line = ack_line = b""
    try:
        require(getattr(port, "trace_fault", True) is False,
                "trace défaillante avant préflight")
        require(port.verify_sources(plan.source_refs), "préimages modifiées avant Popen")
        sinks = port.open_sinks(plan)
        require(port.now() <= gate_deadline, "gate expiré avant Popen")
        require(getattr(port, "trace_fault", True) is False,
                "trace défaillante avant Popen")
        handle = port.spawn(plan, sinks)
        # Une naissance attribuée est requise AVANT de croire le ready.
        candidate = port.read_identity(handle.pid)
        identity(candidate, expected_binary=str(plan.binary))
        require(candidate["pid"] == handle.pid
                and candidate["ppid"] == owner["pid"] and candidate["uid"] == owner["uid"]
                and candidate["pgid"] == candidate["pid"], "enfant non attribué")
        # Le candidat devient attribué seulement après contrôle relationnel.
        child = candidate
        ready_line = port.read_ready(handle, sinks, gate_deadline)
        parse_ready(ready_line, plan, owner, child)
        require(port.now() <= gate_deadline, "gate dépassé")
        require(port.poll(handle) is None and _same_live(port, owner, child, plan),
                "naissance/parent changés avant rehash")
        require(port.verify_sources(plan.source_refs), "préimages modifiées avant release")
        require(port.poll(handle) is None and _same_live(port, owner, child, plan),
                "naissance/parent changés après rehash")
        require(port.now() <= gate_deadline,
                "gate expiré après rehash, avant release")
        require(getattr(port, "trace_fault", True) is False,
                "trace défaillante avant release")
        port.release(handle, release_bytes(plan, child))
        released = True
        ack_line = port.read_gate_released(handle, sinks, gate_deadline)
        parse_released(ack_line, plan, child)
        require(port.now() <= gate_deadline, "ACK gate hors borne")
        confirmed = True
        port.close_gate(handle)
        gate_closed = True
        case_deadline = min(port.now() + CASE_SECONDS, measurement_deadline)
        returncode = port.wait_until(handle, case_deadline)
        require(returncode is not None, "cas expiré")
        reaped = True
        require(returncode == 0, f"sonde exit {returncode}")
        require(port.now() <= case_deadline,
                "mesure hors fenêtre absolue")
        final_oracle = parse_final(port.read_final(handle, sinks), plan, owner, child,
                                   ready_line, ack_line)
    except (Exception, KeyboardInterrupt, SystemExit) as exc:
        errors.append(f"{type(exc).__name__}:{exc}")
    finally:
        cleanup_start = port.now()
        cleanup_deadline = min(cleanup_start + CLEANUP_SECONDS, terminal_deadline)
        if handle is not None:
            if not gate_closed:
                try:
                    port.close_gate(handle)
                except Exception as exc:
                    errors.append(f"close_gate:{type(exc).__name__}:{exc}")
            if not reaped:
                # Zéro signal, même avec une naissance connue : seul le handle
                # Popen permet le wait/reap. La sortie autonome C est attendue.
                try:
                    waited = port.wait_until(handle, cleanup_deadline)
                    if waited is not None:
                        returncode, reaped = waited, True
                except Exception as exc:
                    errors.append(f"wait_cleanup:{type(exc).__name__}:{exc}")
        if handle is not None and not reaped:
            # File terminale sans reset ni signal, jusqu'au plafond pré-Popen.
            try:
                waited = port.wait_until(handle, terminal_deadline)
                if waited is not None:
                    returncode, reaped = waited, True
            except Exception as exc:
                errors.append(f"wait_terminal:{type(exc).__name__}:{exc}")
        if sinks is not None:
            try:
                stable = port.close_sinks(sinks)
            except Exception as exc:
                errors.append(f"close_sinks:{type(exc).__name__}:{exc}")
        try:
            sources_unchanged = port.verify_sources(plan.source_refs)
            if not sources_unchanged:
                errors.append("préimages modifiées après fermeture")
        except Exception as exc:
            errors.append(f"rehash final:{type(exc).__name__}:{exc}")
        ended = port.now()
        deadline_met = type(ended) in (int, float) and math.isfinite(ended) and ended <= cleanup_deadline
        if not deadline_met:
            errors.append("cleanup deadline dépassée")
        if handle is not None and not reaped:
            errors.append("enfant non reaped")
    termination_proved = handle is not None and child is not None and reaped
    clean = (termination_proved and stable and sources_unchanged and confirmed
             and final_oracle and returncode == 0 and not errors and deadline_met)
    return {"schema": "c17-seatbelt-fd-controller-native-v1", "case": plan.case,
            "owner": owner, "child": child, "gate_release_written": released,
            "gate_release_confirmed": confirmed,
            "returncode": returncode, "signals": [], "errors": errors,
            "termination_proved": termination_proved, "clean": clean,
            "final_oracle": final_oracle,
            "source_refs_unchanged": sources_unchanged,
            "cleanup_deadline_met": deadline_met,
            "actual_native_IO": getattr(port, "ACTUAL_NATIVE_IO", False) is True,
            "native_child_started": handle is not None,
            "diagnostic_only": True, "native_qualification": False,
            "FULL": False, "Chrome_qualified": False}


def activate(*_args: Any, **_kwargs: Any) -> None:
    raise RuntimeError("Mesure native désactivée ; dérivation distincte et revue MAIN requises")
