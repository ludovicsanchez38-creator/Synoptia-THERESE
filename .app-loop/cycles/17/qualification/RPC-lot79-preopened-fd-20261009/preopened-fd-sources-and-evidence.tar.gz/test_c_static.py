"""LOT79 real-source textual/mutant tests; never compile or execute C/SBPL."""
import ast
import json
import re
import stat
import sys
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
SOURCE = (HERE / "probe-prepared.c").read_text()
OLD = (HERE / "preimages/probe-lot76-native.c").read_text()
PLAN = json.loads((HERE / "PLAN.json").read_text())
PROFILE = (HERE / "policies/outer.sb").read_text()
ATTEMPTS = []


def audit_guard(event, args):
    if event in {"subprocess.Popen", "os.system", "os.exec", "os.posix_spawn",
                 "os.fork", "os.kill", "os.killpg", "ctypes.dlopen", "socket.__new__"}:
        ATTEMPTS.append(event)
        raise AssertionError("forbidden native/tool attempt: " + event)


sys.addaudithook(audit_guard)


def function(text, name):
    start = re.search(r"\b" + re.escape(name) + r"\([^;]*?\)\s*\{", text)
    if not start:
        raise ValueError("missing function " + name)
    pos = start.end()
    depth = 1
    quote = None
    line_comment = False
    block_comment = False
    while pos < len(text):
        c = text[pos]
        following = text[pos:pos + 2]
        if line_comment:
            line_comment = c != "\n"
        elif block_comment:
            if following == "*/":
                block_comment = False
                pos += 1
        elif quote:
            if c == "\\":
                pos += 1
            elif c == quote:
                quote = None
        elif following == "//":
            line_comment = True
            pos += 1
        elif following == "/*":
            block_comment = True
            pos += 1
        elif c in "\"'":
            quote = c
        elif c == "{":
            depth += 1
        elif c == "}":
            depth -= 1
            if depth == 0:
                return text[start.start():pos + 1]
        pos += 1
    raise ValueError("unclosed function " + name)


def section(text, first, last):
    return text[text.index(first):text.index(last) + len(last)]


def without_comments(text):
    return re.sub(r"/\*.*?\*/|//[^\n]*", "", text, flags=re.S)


def c_string(text, name):
    start = text.index("static const char " + name + "[] =")
    end = text.index(";", start)
    literals = re.findall(r'"(?:\\.|[^"\\])*"', text[start:end])
    return "".join(ast.literal_eval(value) for value in literals)


def validate(text):
    main = function(text, "main")
    timer = function(text, "prepare_watchdog")
    fresh = function(text, "fresh_read")
    held = function(text, "retained_pread")
    close = function(text, "close_retained")
    opened = function(text, "open_retained")
    budget = function(text, "within_budget")
    clean = without_comments(text)
    require = lambda ok, label: None if ok else (_ for _ in ()).throw(ValueError(label))
    require("NATIVE_MEASUREMENT_ENABLED = false;" in text, "disabled")
    require(main.index("if (!NATIVE_MEASUREMENT_ENABLED)") < main.index("prepare_watchdog"),
            "disabled before work")
    require('(strcmp(argv[2], "fd-baseline") && strcmp(argv[2], "fd-outer"))' in main,
            "two closed cases")
    order = ['prepare_watchdog(&armed_ns)', 'close_inherited_fds()', 'fd0_gate(argv[2]',
             'witness_preflight(a', 'sandbox_check(getpid()', 'fresh_read("baseline", "A"',
             'fresh_read("baseline", "B"', 'open_retained(b', 'retained_pread("before_outer"',
             'sandbox_init_with_parameters(OUTER', 'fresh_read("case", "A"',
             'fresh_read("case", "B"', 'retained_stat(retained', 'retained_pread("case"',
             'close_retained(&retained)', 'fresh_read("after_close", "B"']
    require([main.index(item) for item in order] == sorted(main.index(item) for item in order),
            "main order")
    require(len(re.findall(r"\bclose_inherited_fds\s*\(", main)) == 1, "no late FD cleanup")
    require(len(re.findall(r"\bsandbox_init_with_parameters\s*\(", main)) == 1,
            "single application")
    require("if (baseline)" in main and main.index("if (baseline)") <
            main.index("} else {") < main.index("sandbox_init_with_parameters(OUTER"),
            "baseline does not apply OUTER")
    require(not re.search(r"\b(?:sandbox_apply|sandbox_compile_string|sandbox_create_params|"
                          r"fork|vfork|execve|execl|execv|posix_spawn|socket|connect|kill|killpg)\s*\(", clean),
            "excluded API")
    require("struct itimerval previous, observed_timer, timer = {{0, 0}, {10, 0}};" in timer,
            "timer10 one-shot")
    require(text.count("setitimer(ITIMER_REAL") == 1, "no rearm")
    for clause in ["previous.it_value.tv_sec", "previous.it_interval.tv_sec",
                   "action.sa_handler = SIG_DFL", "SIG_UNBLOCK",
                   "observed.sa_handler != SIG_DFL", "sigismember(&current, SIGALRM) != 0",
                   "getitimer(ITIMER_REAL, &observed_timer)", "observed_timer.it_interval.tv_sec"]:
        require(clause in timer, "timer verified " + clause)
    require("now - armed_ns < TOTAL_LIMIT_NS" in budget and
            "now - released_ns < GATE_LIMIT_NS" in budget, "two absolute deadlines")
    require("open_errno == EPERM) return READ_DENIED;" in fresh and
            "open_errno == EACCES" not in fresh, "fresh denial exact EPERM")
    require("n == -1 && (read_errno == EPERM || read_errno == EACCES)" in held,
            "retained denial observational")
    require("pread(fd, data, sizeof(data), 0)" in fresh and
            "pread(fd, data, sizeof(data), 0)" in held, "fixed pread argument")
    require('!memcmp(data, WITNESS_B, WITNESS_BYTES)' in held and
            "n == WITNESS_BYTES" in held, "exact retained bytes")
    require("return *retained >= 0 && *retained != STDOUT_FILENO && *retained != STDERR_FILENO" in opened,
            "FD0 allowed, sinks never retained")
    require("O_RDONLY | O_NOFOLLOW | O_CLOEXEC" in opened and
            "F_GETFD" in opened and "FD_CLOEXEC" in opened and "O_ACCMODE" in opened,
            "retained flags")
    require("same_witness_identity(identity, &current)" in opened, "retained identity")
    require(close.index("*retained = -1") < close.index("int rc = close(fd)") <
            close.index("if (rc == 0)") < close.index("fcntl(fd, F_GETFD)") <
            close.index("printf("), "close and EBADF before output/reuse")
    require(len(re.findall(r"\bclose\s*\(", without_comments(close))) == 1 and
            not re.search(r"\bopen\s*\(", without_comments(close)), "single close no reuse")
    require("check_rc == -1 && check_errno == EBADF" in close, "closed proof")
    require("bool controls = metadata_ok && case_a == READ_OK" in main,
            "metadata guard retained")
    require("held == READ_OK || (!baseline && held == READ_DENIED)" in main,
            "unknown retained capability is not assumed")
    for flag in [r'\"retained_access_presumed\":false', r'\"native_qualification\":false',
                 r'\"FULL\":false', r'\"Chrome_qualified\":false']:
        require(flag in main, "unqualified flags")
    require("if (flush_measurement()) return 86;" in main and
            "return controls ? 0 : 86;" in main, "logging/controls are mandatory")
    return True


class SourceTests(unittest.TestCase):
    def mutant(self, original, replacement, label):
        self.assertIn(original, SOURCE)
        with self.assertRaises(ValueError, msg=label):
            validate(SOURCE.replace(original, replacement, 1))

    def test_actual_disabled_source(self):
        self.assertTrue(validate(SOURCE))
        self.assertFalse(ATTEMPTS)

    def test_native_true_refused(self):
        self.mutant("NATIVE_MEASUREMENT_ENABLED = false;", "NATIVE_MEASUREMENT_ENABLED = true;", "activation")

    def test_foreign_case_refused(self):
        self.mutant('strcmp(argv[2], "fd-outer")', 'strcmp(argv[2], "fd-unreviewed")', "case")

    def test_timer_extended_refused(self):
        self.mutant("timer = {{0, 0}, {10, 0}}", "timer = {{0, 0}, {11, 0}}", "timer")

    def test_timer_rearm_refused(self):
        with self.assertRaises(ValueError):
            validate(SOURCE.replace("cleanup:", "cleanup:\nsetitimer(ITIMER_REAL, NULL, NULL);"))

    def test_timer_before_cleanup_is_mandatory(self):
        self.mutant("if (prepare_watchdog(&armed_ns)) return 86;\n    if (close_inherited_fds())",
                    "if (close_inherited_fds()) return 86;\n    if (prepare_watchdog(&armed_ns))", "order")

    def test_second_application_refused(self):
        self.mutant("int ambient_errno = errno;", "int ambient_errno = errno; sandbox_apply(NULL);", "second")

    def test_fresh_eacces_is_not_accepted_as_eperm(self):
        self.mutant("open_errno == EPERM) return READ_DENIED;", "open_errno == EACCES) return READ_DENIED;", "fresh")

    def test_retained_denial_has_only_two_reviewed_errno(self):
        self.mutant("read_errno == EPERM || read_errno == EACCES",
                    "read_errno == EPERM || read_errno == ENOENT", "retained")

    def test_incorrect_pread_offset_refused(self):
        self.mutant("n = pread(fd, data, sizeof(data), 0);", "n = pread(fd, data, sizeof(data), 1);", "offset")

    def test_retained_fd_zero_is_supported(self):
        self.assertIn("return *retained >= 0", function(SOURCE, "open_retained"))
        self.mutant("return *retained >= 0", "return *retained >= 3", "FD0")

    def test_no_cloexec_refused(self):
        self.mutant("*retained = open(path, O_RDONLY | O_NOFOLLOW | O_CLOEXEC)",
                    "*retained = open(path, O_RDONLY | O_NOFOLLOW)", "flags")

    def test_reuse_before_closed_proof_refused(self):
        self.mutant("check_rc = fcntl(fd, F_GETFD);", "open(\"fake\", O_RDONLY); check_rc = fcntl(fd, F_GETFD);", "reuse")

    def test_ebadf_removed_refused(self):
        self.mutant("check_errno == EBADF", "check_errno == ENOENT", "closed")

    def test_metadata_cannot_be_silently_dropped(self):
        self.mutant("bool controls = metadata_ok && case_a", "bool controls = case_a", "identity")

    def test_pread_success_is_not_required_under_outer(self):
        self.assertIn("held == READ_OK || (!baseline && held == READ_DENIED)", SOURCE)
        self.mutant("held == READ_OK || (!baseline && held == READ_DENIED)", "held == READ_OK", "presumption")

    def test_case_qualification_cannot_be_promoted(self):
        self.mutant(r'\"FULL\":false', r'\"FULL\":true', "FULL")

    def test_fd_gate_and_cleanup_exact_preimage(self):
        for first, last in [("/* BEGIN FD0_GATE", "/* END FD0_GATE */"),
                            ("/* BEGIN FD_CLEANUP", "/* END FD_CLEANUP */")]:
            self.assertEqual(section(SOURCE, first, last), section(OLD, first, last))
        self.assertIn("close(STDIN_FILENO)", function(SOURCE, "fd0_gate"))

    def test_profile_exact_literals_no_extra_rights(self):
        expected = (
            '(version 1)\n(deny default)\n'
            f'(allow file-read-metadata (literal "{HERE}/witnesses/a.txt") '
            f'(literal "{HERE}/witnesses/b.txt"))\n'
            f'(allow file-read-data (literal "{HERE}/witnesses/a.txt"))\n'
        )
        self.assertEqual(PROFILE, expected)
        self.assertEqual(c_string(SOURCE, "OUTER"), PROFILE)
        for extra in ["(allow default)", "(allow file-write*)", "(allow network*)",
                      "(allow process-fork)", "(allow mach-lookup)"]:
            self.assertNotEqual(PROFILE + extra + "\n", expected)

    def test_synthetic_witness_bytes_and_private_modes(self):
        self.assertEqual(c_string(SOURCE, "WITNESS_A").encode(), (HERE / "witnesses/a.txt").read_bytes())
        self.assertEqual(c_string(SOURCE, "WITNESS_B").encode(), (HERE / "witnesses/b.txt").read_bytes())
        for name in ["witnesses/a.txt", "witnesses/b.txt", "policies/outer.sb"]:
            path = HERE / name
            info = path.lstat()
            self.assertTrue(stat.S_ISREG(info.st_mode))
            self.assertEqual(info.st_nlink, 1)
            self.assertEqual(stat.S_IMODE(info.st_mode), 0o600)
            self.assertEqual(path.resolve(), path)
        for name in ["", "witnesses", "policies"]:
            self.assertEqual(stat.S_IMODE((HERE / name).stat().st_mode), 0o700)

    def test_plan_fifteen_lines_two_cases_and_no_authority(self):
        self.assertEqual(PLAN["qa_root"], str(HERE))
        self.assertEqual(PLAN["cases"], ["fd-baseline", "fd-outer"])
        self.assertFalse(PLAN["native_enabled"])
        self.assertEqual(PLAN["status"], "PREPARATION_ONLY")
        rows = PLAN["release_protocol"]["stdout_ordinal_sequence"]
        self.assertEqual([row["ordinal"] for row in rows], list(range(15)))
        self.assertEqual([row.get("event", row.get("schema")) for row in rows], [
            "c17-seatbelt-composition-ready-v1", "c17-seatbelt-composition-gate-released-v1",
            "ambient_probe", "witness_read", "witness_read", "retained_open",
            "retained_pread", "outer_apply", "witness_read", "witness_read",
            "retained_stat", "retained_pread", "retained_close", "witness_read", "case_finished"])
        self.assertEqual(PLAN["profile"]["applications_by_case"], {"fd-baseline": 0, "fd-outer": 1})
        self.assertFalse(PLAN["bounds"]["hard_preemption_claimed"])

    def test_json_key_sets_are_unique_and_nonqualifying(self):
        for event, keys in PLAN["stdout_exact_key_sets"].items():
            self.assertEqual(len(keys), len(set(keys)), event)
            self.assertIn("diagnostic_only", keys)
            self.assertIn("native_qualification", keys)


if __name__ == "__main__":
    unittest.main(verbosity=2)
