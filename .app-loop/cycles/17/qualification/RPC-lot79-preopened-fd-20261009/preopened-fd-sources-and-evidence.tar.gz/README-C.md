# LOT79 : FD préouvert, préparation désactivée

Racine commune MAIN : /private/tmp/therese-c17-fd-main-Bp9K3omj. Ce lot ne modifie ni G1, ni Chrome, ni les gels LOT76/77. Il n'est ni un GO ni un instrument activé.

## Question et contrôles

Deux cas seulement, dans cet ordre et arrêt au premier rouge : `fd-baseline` sans OUTER puis `fd-outer` avec une seule première `sandbox_init_with_parameters`. La première OUTER deny-default ne nomme que la lecture de A et les métadonnées de A/B. Aucun second apply, compilation interne, fork, exec, réseau, Mach ou signal externe.

Après attribution réelle et release FD0, les lectures fraîches A/B hors OUTER doivent retrouver les 25 octets exacts. B est ensuite ouvert une seule fois avec O_RDONLY|O_NOFOLLOW|O_CLOEXEC, fstat comparé au témoin régulier privé et pread positif avant OUTER. Le FD observé peut être 0, car le gate ferme stdin avant son ACK ; ni 1 ni 2 n'est admissible.

Sous OUTER : A frais exact, B frais -1/EPERM exactement. Le pread du B retenu reste une issue mesurable : 25 octets exacts, ou -1/EPERM|EACCES ; aucune accessibilité n'est supposée. Toute autre issue est rouge. Fstat post-OUTER est enregistré séparément ; même s'il échoue, le pread brut reste tenté, mais l'identité incertaine empêche un contrôle vert.

Le FD retenu est fermé une fois. Immédiatement après close0, avant toute sortie ou ouverture réutilisatrice, F_GETFD doit donner -1/EBADF. Une nouvelle ouverture fraîche de B vérifie ensuite le même oracle que dans ce cas. `offset=0` est l'argument de pread, pas une mesure du pointeur courant par lseek.

## Origines et séquence

Préimage C LOT76 réelle : /private/tmp/therese-c17-seatbelt-native-main-FDuCgC/probe-native.c, SHA8de3afdd3eccc89c65e60b11794f35866c95d3ebed95afb322f5cbc8ecff4f38, 16733B. La copie preimages/probe-lot76-native.c est byte-exacte. Les blocs FD_CLEANUP et FD0_GATE sont conservés byte-exacts. Le timer s'inspire du vrai C LOT77 d5db75bb, sans fork ni timer enfant.

PLAN.json ferme l'argv, les 15 lignes stdout, leurs jeux de clés, les deux cas et les issues. Les ready/release/ACK LOT76 restent exacts ; le contrôleur externe doit attribuer/revérifier les vraies naissances et l'exécutable avant release. Les JSON du C ne font pas autorité d'identité.

La constante NATIVE_MEASUREMENT_ENABLED=false refuse avant toute opération de sonde. Une dérivation MAIN distincte, revue et épinglée, sera nécessaire pour compiler puis éventuellement mesurer. Aucun binaire ou manifest d'activation n'est créé ici.

## Bornes et limites

One-shot autonome 10s armé et relu avant nettoyage FD/gate/témoins, SIGALRM par défaut et débloqué. Gate5s, mesure5s à partir du retour du gate, jamais réarmés ; la borne globale peut donc arrêter un cas qui n'a pas fini. Contrôleur externe attendu : horloge avant Popen, wait/reap du seul handle, fenêtre globale18s et nettoyage8s sans signal externe. Aucune préemption dure de syscall, absence de course hostile ou équivalence Chromium/G1 n'est démontrée.

Toutes les sorties expérimentales vérifient flush/ferror ; l'héritage des FD1/2 ne prouve pas à lui seul une permission d'écriture sous OUTER. Un échec de sortie est rouge. Les témoins sont 25B, fichiers0600, dossiers700 ; aucune permission file-write ou FD globale n'est ajoutée.

## Vérification réellement faite

22 tests textuels/mutants réellement exécutés via Python UV physique -I -B : chunk1910c1, exit0, zéro erreur/échec/skip, 0.052s rapportées par unittest. Sept pins avant/après identiques d16d1e/89e8ed. Les tests lisent le C/profil/témoins, contrôlent l'ordre et rejettent des mutations de borne, application, cas, errno, offset, fermeture, identité et qualification. Ce n'est ni une compilation C ni une mesure sandbox/libproc. La skill salle-decision impose cette séparation entre source préparée, autorité future et résultat natif.

Le contrôleur Python dérivé est la responsabilité d'Environment et n'est pas adopté par cet index de source C. Les anciens rouges restent inchangés. G1/Chrome/FULL et les deux rondes A/B restent non qualifiés.
