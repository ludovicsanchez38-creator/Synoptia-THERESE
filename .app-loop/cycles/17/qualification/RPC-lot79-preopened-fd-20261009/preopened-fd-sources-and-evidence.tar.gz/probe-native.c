/* LOT79: separate enabled mono-process synthetic preopened-FD diagnostic.
 * Derives LOT76 FD0/birth gate and own-FD cleanup; no second policy application.
 * No fork, exec, network, Chrome or G1 change. No native result is assumed.
 * MAIN must review a separate enabled-source/binary/controller derivation.
 */
#define _DARWIN_C_SOURCE 1
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <inttypes.h>
#include <libproc.h>
#include <poll.h>
#include <signal.h>
#include <sys/proc.h>
#include <sys/proc_info.h>
#include <sys/time.h>
#include <time.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

static const bool NATIVE_MEASUREMENT_ENABLED = true;
static const char QA_ROOT[] = "/private/tmp/therese-c17-fd-main-Bp9K3omj";

/* Private ABI: declaration is not a support/semantic guarantee. */
extern void sandbox_free_error(char *);
extern int sandbox_init_with_parameters(const char *, uint64_t, const char *const *, char **);
extern int sandbox_check(pid_t, const char *, int, ...);

static const char OUTER[] =
    "(version 1)\n"
    "(deny default)\n"
    "(allow file-read-metadata (literal \"/private/tmp/therese-c17-fd-main-Bp9K3omj/witnesses/a.txt\") (literal \"/private/tmp/therese-c17-fd-main-Bp9K3omj/witnesses/b.txt\"))\n"
    "(allow file-read-data (literal \"/private/tmp/therese-c17-fd-main-Bp9K3omj/witnesses/a.txt\"))\n";
static const char WITNESS_A[] = "A:synthetic-witness-only\n";
static const char WITNESS_B[] = "B:synthetic-witness-only\n";
#define WITNESS_BYTES 25
#define TOTAL_LIMIT_NS INT64_C(10000000000)

static void json_string(const char *value) {
    putchar('"');
    for (size_t i = 0; value && value[i] && i < 1024; ++i) {
        unsigned char c = (unsigned char)value[i];
        if (c == '"' || c == '\\') { putchar('\\'); putchar(c); }
        else if (c < 0x20) printf("\\u%04x", c);
        else putchar(c);
    }
    putchar('"');
}

/* BEGIN FD_CLEANUP: own PID only, typed SDK rows, fixed capacity. */
#define OWN_FD_CAPACITY 256
static int read_own_fds(struct proc_fdinfo rows[OWN_FD_CAPACITY]) {
    memset(rows, 0, OWN_FD_CAPACITY * sizeof(*rows));
    int bytes = proc_pidinfo(getpid(), PROC_PIDLISTFDS, 0, rows,
                            (int)(OWN_FD_CAPACITY * sizeof(*rows)));
    if (bytes <= 0 || bytes >= (int)(OWN_FD_CAPACITY * sizeof(*rows)) ||
        bytes % (int)sizeof(*rows) != 0) return -1;
    int count = bytes / (int)sizeof(*rows);
    for (int i = 0; i < count; ++i) {
        if (rows[i].proc_fd < 0) return -1;
        for (int j = 0; j < i; ++j)
            if (rows[j].proc_fd == rows[i].proc_fd) return -1;
    }
    return count;
}

static int close_inherited_fds(void) {
    struct proc_fdinfo rows[OWN_FD_CAPACITY];
    int count = read_own_fds(rows);
    if (count < 0) return -1;
    for (int i = 0; i < count; ++i) {
        if (rows[i].proc_fd >= 3 && close(rows[i].proc_fd)) return -1;
        /* No retry on EINTR/other error; never close a parent FD. */
    }
    count = read_own_fds(rows);
    if (count != 3) return -1;
    unsigned present = 0;
    for (int i = 0; i < count; ++i) {
        if (rows[i].proc_fd > 2) return -1;
        present |= 1u << (unsigned)rows[i].proc_fd;
    }
    return present == 7u ? 0 : -1; /* Exactly stdin, stdout and stderr. */
}
/* END FD_CLEANUP */

/* BEGIN FD0_GATE: typed SDK libproc, no fabricated identity. */
#define GATE_LIMIT_NS INT64_C(5000000000)
#define GATE_FRAME_BYTES 512
struct gate_birth {
    uint32_t pid, ppid, uid, pgid;
    uint64_t start_sec, start_usec;
};

static int read_gate_birth(pid_t pid, struct gate_birth *out) {
    struct proc_bsdinfo info;
    memset(&info, 0, sizeof(info));
    int count = proc_pidinfo(pid, PROC_PIDTBSDINFO, 0, &info, (int)sizeof(info));
    if (count != (int)sizeof(info) || info.pbi_pid != (uint32_t)pid ||
        (info.pbi_status != SRUN && info.pbi_status != SSLEEP) ||
        (info.pbi_flags & PROC_FLAG_INEXIT) || info.pbi_pid <= 1 ||
        info.pbi_ppid == 0 || info.pbi_pgid == 0 ||
        info.pbi_start_tvsec == 0 || info.pbi_start_tvusec >= 1000000) return -1;
    *out = (struct gate_birth){info.pbi_pid, info.pbi_ppid, info.pbi_uid,
        info.pbi_pgid, info.pbi_start_tvsec, info.pbi_start_tvusec};
    return 0;
}

static bool same_gate_birth(const struct gate_birth *a, const struct gate_birth *b) {
    return a->pid == b->pid && a->ppid == b->ppid && a->uid == b->uid &&
        a->pgid == b->pgid && a->start_sec == b->start_sec && a->start_usec == b->start_usec;
}

static bool gate_nonce_valid(const char *nonce) {
    if (!nonce || strlen(nonce) != 32) return false;
    for (size_t i = 0; i < 32; ++i)
        if (!((nonce[i] >= '0' && nonce[i] <= '9') ||
              (nonce[i] >= 'a' && nonce[i] <= 'f'))) return false;
    return true;
}

static int64_t gate_now_ns(void) {
    struct timespec now;
    if (clock_gettime(CLOCK_MONOTONIC, &now) || now.tv_sec < 0 ||
        now.tv_sec > (INT64_MAX - GATE_LIMIT_NS) / INT64_C(1000000000)) return -1;
    return (int64_t)now.tv_sec * INT64_C(1000000000) + now.tv_nsec;
}

static int fd0_gate(const char *case_name, const char *nonce) {
    int64_t start = gate_now_ns();
    if (start < 0 || !gate_nonce_valid(nonce)) return -1;
    const int64_t deadline = start + GATE_LIMIT_NS;
    struct stat channel;
    int flags = fcntl(STDIN_FILENO, F_GETFL);
    if (fstat(STDIN_FILENO, &channel) || !S_ISFIFO(channel.st_mode) || flags < 0 ||
        fcntl(STDIN_FILENO, F_SETFL, flags | O_NONBLOCK)) return -1;

    struct gate_birth child, owner, child_now, owner_now;
    if (read_gate_birth(getpid(), &child) || read_gate_birth(getppid(), &owner) ||
        child.pid != (uint32_t)getpid() || child.ppid != (uint32_t)getppid() ||
        child.ppid != owner.pid || child.uid != (uint32_t)getuid() ||
        child.uid != (uint32_t)geteuid() || child.uid != owner.uid ||
        child.pgid != child.pid || child.pgid != (uint32_t)getpgrp()) return -1;

    printf("{\"schema\":\"c17-seatbelt-composition-ready-v1\",\"case\":\"%s\","
           "\"nonce\":\"%s\",\"pid\":%u,\"ppid\":%u,\"uid\":%u,\"pgid\":%u,"
           "\"start_sec\":%" PRIu64 ",\"start_usec\":%" PRIu64 "}\n",
           case_name, nonce, child.pid, child.ppid, child.uid, child.pgid,
           child.start_sec, child.start_usec);
    if (fflush(stdout) || ferror(stdout)) return -1;

    char expected[GATE_FRAME_BYTES], received[GATE_FRAME_BYTES];
    int wanted = snprintf(expected, sizeof(expected),
        "{\"schema\":\"c17-seatbelt-composition-release-v1\",\"case\":\"%s\","
        "\"nonce\":\"%s\",\"pid\":%u,\"start_sec\":%" PRIu64 ",\"start_usec\":%" PRIu64 "}\n",
        case_name, nonce, child.pid, child.start_sec, child.start_usec);
    if (wanted <= 0 || wanted >= GATE_FRAME_BYTES) return -1;
    size_t used = 0;
    for (;;) {
        int64_t now = gate_now_ns();
        if (now < 0 || now >= deadline) return -1;
        int milliseconds = (int)((deadline - now + INT64_C(999999)) / INT64_C(1000000));
        struct pollfd pipe = {STDIN_FILENO, POLLIN, 0};
        int polled = poll(&pipe, 1, milliseconds);
        if (polled < 0 && errno == EINTR) continue;
        now = gate_now_ns();
        if (polled <= 0 || now < 0 || now >= deadline ||
            (pipe.revents & (POLLERR | POLLNVAL))) return -1;
        ssize_t count = read(STDIN_FILENO, received + used, sizeof(received) - used);
        if (count < 0 && (errno == EINTR || errno == EAGAIN)) continue;
        if (count <= 0) return -1; /* EOF never supplies a release. */
        used += (size_t)count;
        if (used >= sizeof(received)) return -1;
        if (memchr(received, '\n', used)) {
            if (used != (size_t)wanted || memcmp(received, expected, used)) return -1;
            /* One closed frame; any already queued additional byte is refused. */
            char extra;
            ssize_t more = read(STDIN_FILENO, &extra, 1);
            if (more != -1 || errno != EAGAIN) return -1;
            break;
        }
    }
    if (close(STDIN_FILENO)) return -1;
    if (read_gate_birth(getpid(), &child_now) || read_gate_birth((pid_t)owner.pid, &owner_now) ||
        !same_gate_birth(&child, &child_now) || !same_gate_birth(&owner, &owner_now) ||
        getppid() != (pid_t)owner.pid) return -1;
    int64_t done = gate_now_ns();
    if (done < 0 || done >= deadline) return -1;
    printf("{\"schema\":\"c17-seatbelt-composition-gate-released-v1\",\"case\":\"%s\","
           "\"nonce\":\"%s\",\"pid\":%u,\"start_sec\":%" PRIu64 ",\"start_usec\":%" PRIu64 "}\n",
           case_name, nonce, child.pid, child.start_sec, child.start_usec);
    if (fflush(stdout) || ferror(stdout)) return -1;
    done = gate_now_ns();
    return done < 0 || done >= deadline ? -1 : 0;
}
/* END FD0_GATE */

/* BEGIN LOT79_TIMER: self-only one-shot armed BEFORE cleanup/gate/open. */
static int prepare_watchdog(int64_t *armed_ns) {
    struct sigaction action, observed;
    sigset_t unblocked, current;
    struct itimerval previous, observed_timer, timer = {{0, 0}, {10, 0}};
    memset(&previous, 0, sizeof(previous));
    memset(&observed_timer, 0, sizeof(observed_timer));
    if (getitimer(ITIMER_REAL, &previous) ||
        previous.it_value.tv_sec || previous.it_value.tv_usec ||
        previous.it_interval.tv_sec || previous.it_interval.tv_usec) return -1;
    memset(&action, 0, sizeof(action));
    action.sa_handler = SIG_DFL;
    if (sigemptyset(&action.sa_mask) || sigemptyset(&unblocked) ||
        sigaddset(&unblocked, SIGALRM) || sigaction(SIGALRM, &action, NULL) ||
        sigprocmask(SIG_UNBLOCK, &unblocked, NULL)) return -1;
    *armed_ns = gate_now_ns(); /* No rearm/reset after any preparation step. */
    if (*armed_ns < 0 || *armed_ns > INT64_MAX - TOTAL_LIMIT_NS ||
        setitimer(ITIMER_REAL, &timer, NULL)) return -1;
    memset(&observed, 0, sizeof(observed));
    if (sigaction(SIGALRM, NULL, &observed) || observed.sa_handler != SIG_DFL ||
        sigprocmask(SIG_BLOCK, NULL, &current) || sigismember(&current, SIGALRM) != 0 ||
        getitimer(ITIMER_REAL, &observed_timer) ||
        observed_timer.it_interval.tv_sec || observed_timer.it_interval.tv_usec ||
        observed_timer.it_value.tv_sec < 0 || observed_timer.it_value.tv_sec > 10 ||
        observed_timer.it_value.tv_usec < 0 || observed_timer.it_value.tv_usec >= 1000000 ||
        (observed_timer.it_value.tv_sec == 0 && observed_timer.it_value.tv_usec == 0))
        return -1;
    int64_t now = gate_now_ns();
    return now < *armed_ns || now - *armed_ns >= TOTAL_LIMIT_NS ? -1 : 0;
}
static bool within_budget(int64_t armed_ns, int64_t released_ns) {
    int64_t now = gate_now_ns();
    return now >= armed_ns && now >= released_ns &&
        now - armed_ns < TOTAL_LIMIT_NS && now - released_ns < GATE_LIMIT_NS;
}
/* END LOT79_TIMER */

static bool same_witness_identity(const struct stat *a, const struct stat *b) {
    return S_ISREG(b->st_mode) && a->st_dev == b->st_dev && a->st_ino == b->st_ino &&
        a->st_uid == b->st_uid && a->st_gid == b->st_gid &&
        a->st_mode == b->st_mode && a->st_nlink == b->st_nlink &&
        b->st_nlink == 1 && a->st_size == b->st_size && b->st_size == WITNESS_BYTES;
}
static int witness_preflight(const char *path, const char *expected, struct stat *identity) {
    struct stat before, after;
    char canonical[PATH_MAX], data[WITNESS_BYTES];
    if (!realpath(path, canonical) || strcmp(path, canonical) ||
        lstat(path, &before) || !S_ISREG(before.st_mode) || before.st_nlink != 1 ||
        before.st_uid != getuid() || (before.st_mode & 0777) != 0600 ||
        before.st_size != WITNESS_BYTES) return -1;
    int fd = open(path, O_RDONLY | O_NOFOLLOW | O_CLOEXEC);
    if (fd < 0) return -1;
    int result = fstat(fd, &after) || !same_witness_identity(&before, &after) ||
        pread(fd, data, sizeof(data), 0) != WITNESS_BYTES ||
        memcmp(data, expected, sizeof(data));
    if (close(fd)) result = 1; /* Exactly one close; no EINTR retry. */
    if (!result) *identity = after;
    return result ? -1 : 0;
}
static int flush_measurement(void) {
    return fflush(stdout) || ferror(stdout) ? -1 : 0;
}
static void bytes_hex(const unsigned char data[WITNESS_BYTES], ssize_t count) {
    putchar('"');
    if (count > 0 && count <= WITNESS_BYTES)
        for (ssize_t i = 0; i < count; ++i) printf("%02x", data[i]);
    putchar('"');
}
static void print_stat_fields(const struct stat *s) {
    printf(",\"dev\":%" PRIu64 ",\"ino\":%" PRIu64 ",\"uid\":%u,"
           "\"mode\":%u,\"nlink\":%" PRIu64 ",\"size\":%" PRId64,
           (uint64_t)s->st_dev, (uint64_t)s->st_ino, (unsigned)s->st_uid,
           (unsigned)(s->st_mode & 07777), (uint64_t)s->st_nlink, (int64_t)s->st_size);
}

enum read_state { READ_OK, READ_DENIED, READ_UNEXPECTED };
static enum read_state fresh_read(const char *phase, const char *label,
                                  const char *path, const char *expected,
                                  const struct stat *identity) {
    unsigned char data[WITNESS_BYTES] = {0};
    struct stat current;
    bool identity_matches = false;
    ssize_t n = -1;
    int read_errno = 0, close_errno = 0;
    errno = 0;
    int fd = open(path, O_RDONLY | O_NOFOLLOW | O_CLOEXEC);
    int open_errno = fd < 0 ? errno : 0;
    if (fd >= 0) {
        identity_matches = fstat(fd, &current) == 0 && same_witness_identity(identity, &current);
        errno = 0;
        n = pread(fd, data, sizeof(data), 0); /* Offset argument, not a measured file position. */
        read_errno = n < 0 ? errno : 0;
        errno = 0;
        if (close(fd)) close_errno = errno;
    }
    bool matches = n == WITNESS_BYTES && !memcmp(data, expected, WITNESS_BYTES);
    printf("{\"event\":\"witness_read\",\"phase\":"); json_string(phase);
    printf(",\"witness\":"); json_string(label);
    printf(",\"fd\":%d,\"open_ok\":%s,\"open_errno\":%d,\"read_count\":%ld,"
           "\"read_errno\":%d,\"close_errno\":%d,\"offset\":0,\"bytes_hex\":",
           fd, fd >= 0 ? "true" : "false", open_errno, (long)n, read_errno, close_errno);
    bytes_hex(data, n);
    printf(",\"content_matches\":%s,\"identity_matches\":%s,"
           "\"diagnostic_only\":true,\"native_qualification\":false}\n",
           matches ? "true" : "false", identity_matches ? "true" : "false");
    if (flush_measurement()) return READ_UNEXPECTED;
    if (fd >= 0 && matches && identity_matches && !read_errno && !close_errno) return READ_OK;
    if (fd < 0 && open_errno == EPERM) return READ_DENIED; /* Exact fresh-open oracle. */
    return READ_UNEXPECTED;
}

static int open_retained(const char *path, const struct stat *identity, int *retained) {
    struct stat current;
    memset(&current, 0, sizeof(current));
    int fd_flags = -1, status_flags = -1, stat_rc = -1, stat_errno = 0;
    errno = 0;
    *retained = open(path, O_RDONLY | O_NOFOLLOW | O_CLOEXEC);
    int open_errno = *retained < 0 ? errno : 0;
    if (*retained >= 0) {
        fd_flags = fcntl(*retained, F_GETFD);
        status_flags = fcntl(*retained, F_GETFL);
        errno = 0;
        stat_rc = fstat(*retained, &current);
        stat_errno = stat_rc < 0 ? errno : 0;
    }
    bool cloexec = fd_flags >= 0 && (fd_flags & FD_CLOEXEC) != 0;
    bool read_only = status_flags >= 0 && (status_flags & O_ACCMODE) == O_RDONLY;
    bool verified = stat_rc == 0 && same_witness_identity(identity, &current);
    printf("{\"event\":\"retained_open\",\"witness\":\"B\",\"fd\":%d,"
           "\"open_errno\":%d,\"fd_flags\":%d,\"status_flags\":%d,"
           "\"fstat_rc\":%d,\"fstat_errno\":%d",
           *retained, open_errno, fd_flags, status_flags, stat_rc, stat_errno);
    print_stat_fields(&current);
    printf(",\"cloexec\":%s,\"read_only\":%s,\"identity_verified\":%s,"
           "\"diagnostic_only\":true,\"native_qualification\":false}\n",
           cloexec ? "true" : "false", read_only ? "true" : "false",
           verified ? "true" : "false");
    if (flush_measurement()) return -1;
    return *retained >= 0 && *retained != STDOUT_FILENO && *retained != STDERR_FILENO &&
        !open_errno && cloexec && read_only && verified ? 0 : -1;
}
static bool retained_stat(int fd, const struct stat *identity) {
    struct stat current;
    memset(&current, 0, sizeof(current));
    errno = 0;
    int rc = fstat(fd, &current);
    int stat_errno = rc < 0 ? errno : 0;
    bool matches = rc == 0 && same_witness_identity(identity, &current);
    printf("{\"event\":\"retained_stat\",\"phase\":\"case\",\"witness\":\"B\","
           "\"fd\":%d,\"rc\":%d,\"errno\":%d", fd, rc, stat_errno);
    print_stat_fields(&current);
    printf(",\"identity_matches\":%s,\"diagnostic_only\":true,"
           "\"native_qualification\":false}\n", matches ? "true" : "false");
    return flush_measurement() == 0 && matches;
}
static enum read_state retained_pread(const char *phase, int fd) {
    unsigned char data[WITNESS_BYTES] = {0};
    errno = 0;
    ssize_t n = pread(fd, data, sizeof(data), 0);
    int read_errno = n < 0 ? errno : 0;
    bool matches = n == WITNESS_BYTES && !memcmp(data, WITNESS_B, WITNESS_BYTES);
    printf("{\"event\":\"retained_pread\",\"phase\":"); json_string(phase);
    printf(",\"witness\":\"B\",\"fd\":%d,\"offset\":0,\"read_count\":%ld,"
           "\"read_errno\":%d,\"bytes_hex\":", fd, (long)n, read_errno);
    bytes_hex(data, n);
    printf(",\"content_matches\":%s,\"diagnostic_only\":true,"
           "\"native_qualification\":false}\n", matches ? "true" : "false");
    if (flush_measurement()) return READ_UNEXPECTED;
    if (matches && !read_errno) return READ_OK;
    if (n == -1 && (read_errno == EPERM || read_errno == EACCES)) return READ_DENIED;
    return READ_UNEXPECTED;
}
static bool close_retained(int *retained) {
    int fd = *retained;
    *retained = -1; /* No retry/second close, including ambiguous close errors. */
    errno = 0;
    int rc = close(fd);
    int close_errno = rc < 0 ? errno : 0;
    int check_rc = 0, check_errno = 0;
    bool closed = false;
    if (rc == 0) {
        /* Immediately before any open, output or potential descriptor reuse. */
        errno = 0;
        check_rc = fcntl(fd, F_GETFD);
        check_errno = check_rc < 0 ? errno : 0;
        closed = check_rc == -1 && check_errno == EBADF;
    }
    printf("{\"event\":\"retained_close\",\"witness\":\"B\",\"fd\":%d,"
           "\"close_rc\":%d,\"close_errno\":%d,\"f_getfd_rc\":", fd, rc, close_errno);
    if (rc == 0) printf("%d,\"f_getfd_errno\":%d", check_rc, check_errno);
    else fputs("null,\"f_getfd_errno\":null", stdout);
    printf(",\"closed_verified\":%s,\"diagnostic_only\":true,"
           "\"native_qualification\":false}\n", closed ? "true" : "false");
    return flush_measurement() == 0 && closed;
}

int main(int argc, char **argv) {
    if (!NATIVE_MEASUREMENT_ENABLED) {
        fputs("prepared_only: compilation/native execution not admitted\n", stderr);
        return 2;
    }
    if (argc != 5 || strcmp(argv[1], "--reviewed-case") ||
        strcmp(argv[3], "--gate-nonce") || !gate_nonce_valid(argv[4]) ||
        (strcmp(argv[2], "fd-baseline") && strcmp(argv[2], "fd-outer"))) return 2;
    int64_t armed_ns = -1;
    if (prepare_watchdog(&armed_ns)) return 86;
    if (close_inherited_fds()) return 86; /* Initial cleanup only; before retained B. */
    if (fd0_gate(argv[2], argv[4])) {
        fputs("gate refused: no witness/sandbox experiment\n", stderr);
        return 86;
    }
    const int64_t released_ns = gate_now_ns();
    if (released_ns < 0 || !within_budget(armed_ns, released_ns)) return 86;

    char canonical[PATH_MAX], a[PATH_MAX], b[PATH_MAX], witnesses[PATH_MAX];
    struct stat root_stat, directory_stat, a_identity, b_identity;
    if (!realpath(QA_ROOT, canonical) || strcmp(canonical, QA_ROOT) ||
        lstat(QA_ROOT, &root_stat) || !S_ISDIR(root_stat.st_mode) ||
        root_stat.st_uid != getuid() || (root_stat.st_mode & 0777) != 0700) return 2;
    if (snprintf(a, sizeof(a), "%s/witnesses/a.txt", QA_ROOT) >= (int)sizeof(a) ||
        snprintf(b, sizeof(b), "%s/witnesses/b.txt", QA_ROOT) >= (int)sizeof(b) ||
        snprintf(witnesses, sizeof(witnesses), "%s/witnesses", QA_ROOT) >= (int)sizeof(witnesses) ||
        !realpath(witnesses, canonical) || strcmp(canonical, witnesses) ||
        lstat(witnesses, &directory_stat) || !S_ISDIR(directory_stat.st_mode) ||
        directory_stat.st_uid != getuid() || (directory_stat.st_mode & 0777) != 0700 ||
        witness_preflight(a, WITNESS_A, &a_identity) ||
        witness_preflight(b, WITNESS_B, &b_identity)) return 2;
    if (!within_budget(armed_ns, released_ns)) return 86;

    errno = 0;
    int ambient = sandbox_check(getpid(), NULL, 0);
    int ambient_errno = errno;
    printf("{\"event\":\"ambient_probe\",\"rc\":%d,\"errno\":%d,"
           "\"diagnostic_only\":true,\"native_qualification\":false}\n",
           ambient, ambient_errno);
    if (flush_measurement()) return 86;
    if (ambient != 0) return 2; /* Never replace an inherited/unknown policy. */

    if (!within_budget(armed_ns, released_ns)) return 86;
    enum read_state baseline_a = fresh_read("baseline", "A", a, WITNESS_A, &a_identity);
    enum read_state baseline_b = fresh_read("baseline", "B", b, WITNESS_B, &b_identity);
    if (baseline_a != READ_OK || baseline_b != READ_OK ||
        !within_budget(armed_ns, released_ns)) return 86;

    int retained = -1;
    int exit_code = 86;
    if (open_retained(b, &b_identity, &retained)) goto cleanup;
    if (retained_pread("before_outer", retained) != READ_OK ||
        !within_budget(armed_ns, released_ns)) goto cleanup;
    const bool baseline = !strcmp(argv[2], "fd-baseline");
    char *error = NULL;
    if (baseline) {
        printf("{\"event\":\"outer_apply\",\"case\":\"fd-baseline\",\"applied\":false,"
               "\"pid\":%d,\"ppid\":%d,\"uid\":%u,\"rc\":null,\"errno\":null,"
               "\"error\":\"\",\"diagnostic_only\":true,\"native_qualification\":false}\n",
               getpid(), getppid(), (unsigned)getuid());
        if (flush_measurement()) goto cleanup;
    } else {
        if (fflush(NULL) || ferror(stdout) || ferror(stderr)) goto cleanup;
        errno = 0;
        int outer_rc = sandbox_init_with_parameters(OUTER, 0, NULL, &error);
        int outer_errno = errno;
        printf("{\"event\":\"outer_apply\",\"case\":\"fd-outer\",\"applied\":true,"
               "\"pid\":%d,\"ppid\":%d,\"uid\":%u,\"rc\":%d,\"errno\":%d,\"error\":",
               getpid(), getppid(), (unsigned)getuid(), outer_rc, outer_errno);
        json_string(error);
        fputs(",\"diagnostic_only\":true,\"native_qualification\":false}\n", stdout);
        if (error) { sandbox_free_error(error); error = NULL; }
        if (flush_measurement() || outer_rc != 0) goto cleanup;
    }
    if (!within_budget(armed_ns, released_ns)) goto cleanup;
    enum read_state case_a = fresh_read("case", "A", a, WITNESS_A, &a_identity);
    enum read_state case_b = fresh_read("case", "B", b, WITNESS_B, &b_identity);
    bool metadata_ok = retained_stat(retained, &b_identity);
    /* A metadata failure is recorded, but does not silently replace the pread measurement. */
    enum read_state held = retained_pread("case", retained);
    bool closed = close_retained(&retained);
    if (!closed) return 86; /* No new open while closure is unproved. */
    if (!within_budget(armed_ns, released_ns)) return 86;
    enum read_state after_b = fresh_read("after_close", "B", b, WITNESS_B, &b_identity);
    bool deadline_met = within_budget(armed_ns, released_ns);
    bool controls = metadata_ok && case_a == READ_OK &&
        case_b == (baseline ? READ_OK : READ_DENIED) &&
        after_b == (baseline ? READ_OK : READ_DENIED) &&
        (held == READ_OK || (!baseline && held == READ_DENIED)) && deadline_met;
    const char *retained_access = held == READ_OK ? "read_exact" :
        held == READ_DENIED ? "pread_denied" : "incoherent";
    const char *observation = !controls ? "fd_instrument_error" :
        baseline ? "fd_baseline_controls_observed" :
        held == READ_OK ? "fd_outer_observed_retained_read_exact" :
        "fd_outer_observed_retained_pread_denied";
    printf("{\"event\":\"case_finished\",\"case\":"); json_string(argv[2]);
    printf(",\"observation\":"); json_string(observation);
    printf(",\"retained_access\":"); json_string(retained_access);
    printf(",\"measurement_completed\":true,\"controls_proved\":%s,"
           "\"held_fd_closed\":true,\"deadline_met\":%s,\"retained_access_presumed\":false,"
           "\"diagnostic_only\":true,\"native_qualification\":false,\"FULL\":false,"
           "\"Chrome_qualified\":false}\n",
           controls ? "true" : "false", deadline_met ? "true" : "false");
    if (flush_measurement()) return 86;
    return controls ? 0 : 86;

cleanup:
    /* Any error with a held descriptor closes it once; its transcript remains RED. */
    if (retained >= 0 && !close_retained(&retained)) exit_code = 86;
    return exit_code;
}
